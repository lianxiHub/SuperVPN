package com.google.android.exoplayer2.metadata;

public interface C1605a {
    Object mo2257a(byte[] bArr, int i);

    boolean mo2258a(String str);
}
