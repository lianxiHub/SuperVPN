package com.google.android.exoplayer2.metadata;

import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Looper;
import android.os.Message;
import com.google.android.exoplayer2.C1354a;
import com.google.android.exoplayer2.C1581h;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.p030a.C1347e;
import com.google.android.exoplayer2.p031c.C1392a;
import java.nio.ByteBuffer;

public final class C1610b extends C1354a implements Callback {
    private final C1605a f3478a;
    private final C1589a f3479b;
    private final Handler f3480c;
    private final C1581h f3481d;
    private final C1347e f3482e;
    private boolean f3483f;
    private long f3484g;
    private Object f3485h;

    public interface C1589a {
        void mo2243a(Object obj);
    }

    public C1610b(C1589a c1589a, Looper looper, C1605a c1605a) {
        super(4);
        this.f3479b = (C1589a) C1392a.m2707a((Object) c1589a);
        this.f3480c = looper == null ? null : new Handler(looper, this);
        this.f3478a = (C1605a) C1392a.m2707a((Object) c1605a);
        this.f3481d = new C1581h();
        this.f3482e = new C1347e(1);
    }

    public int mo2119a(Format format) {
        return this.f3478a.mo2258a(format.f2183e) ? 3 : 0;
    }

    protected void mo2121a(long j, boolean z) {
        this.f3485h = null;
        this.f3483f = false;
    }

    public void mo2120a(long j, long j2) {
        if (!this.f3483f && this.f3485h == null) {
            this.f3482e.mo2090a();
            if (m2485a(this.f3481d, this.f3482e) == -4) {
                if (this.f3482e.m2424c()) {
                    this.f3483f = true;
                } else {
                    this.f3484g = this.f3482e.f2221c;
                    try {
                        this.f3482e.m2439e();
                        ByteBuffer byteBuffer = this.f3482e.f2220b;
                        this.f3485h = this.f3478a.mo2257a(byteBuffer.array(), byteBuffer.limit());
                    } catch (Exception e) {
                        throw ExoPlaybackException.m2399a(e, m2509p());
                    }
                }
            }
        }
        if (this.f3485h != null && this.f3484g <= j) {
            m3769a(this.f3485h);
            this.f3485h = null;
        }
    }

    protected void mo2125o() {
        this.f3485h = null;
        super.mo2125o();
    }

    public boolean mo2127s() {
        return this.f3483f;
    }

    public boolean mo2126r() {
        return true;
    }

    private void m3769a(Object obj) {
        if (this.f3480c != null) {
            this.f3480c.obtainMessage(0, obj).sendToTarget();
        } else {
            m3770b(obj);
        }
    }

    public boolean handleMessage(Message message) {
        switch (message.what) {
            case 0:
                m3770b(message.obj);
                return true;
            default:
                return false;
        }
    }

    private void m3770b(Object obj) {
        this.f3479b.mo2243a(obj);
    }
}
