package com.google.android.exoplayer2.metadata.p040a;

public final class C1603b extends C1601e {
    public final byte[] f3468a;

    public C1603b(String str, byte[] bArr) {
        super(str);
        this.f3468a = bArr;
    }
}
