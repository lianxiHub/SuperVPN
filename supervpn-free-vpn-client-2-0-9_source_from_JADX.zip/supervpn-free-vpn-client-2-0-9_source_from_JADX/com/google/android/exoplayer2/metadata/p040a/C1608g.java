package com.google.android.exoplayer2.metadata.p040a;

public final class C1608g extends C1601e {
    public final String f3475a;

    public C1608g(String str, String str2) {
        super(str);
        this.f3475a = str2;
    }
}
