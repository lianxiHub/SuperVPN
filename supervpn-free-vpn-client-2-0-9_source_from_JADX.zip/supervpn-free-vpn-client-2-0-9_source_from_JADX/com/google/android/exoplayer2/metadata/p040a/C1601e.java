package com.google.android.exoplayer2.metadata.p040a;

public abstract class C1601e {
    public final String f3463e;

    public C1601e(String str) {
        this.f3463e = str;
    }
}
