package com.google.android.exoplayer2.metadata.p040a;

public final class C1604c extends C1601e {
    public final String f3469a;
    public final String f3470b;
    public final String f3471c;
    public final byte[] f3472d;

    public C1604c(String str, String str2, String str3, byte[] bArr) {
        super("GEOB");
        this.f3469a = str;
        this.f3470b = str2;
        this.f3471c = str3;
        this.f3472d = bArr;
    }
}
