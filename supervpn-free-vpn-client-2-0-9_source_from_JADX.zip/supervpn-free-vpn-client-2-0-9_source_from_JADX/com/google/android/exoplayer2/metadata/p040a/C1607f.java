package com.google.android.exoplayer2.metadata.p040a;

public final class C1607f extends C1601e {
    public final String f3473a;
    public final byte[] f3474b;

    public C1607f(String str, byte[] bArr) {
        super("PRIV");
        this.f3473a = str;
        this.f3474b = bArr;
    }
}
