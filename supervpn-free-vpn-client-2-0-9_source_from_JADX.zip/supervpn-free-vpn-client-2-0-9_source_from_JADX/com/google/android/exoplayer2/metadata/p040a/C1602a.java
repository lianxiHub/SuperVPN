package com.google.android.exoplayer2.metadata.p040a;

public final class C1602a extends C1601e {
    public final String f3464a;
    public final String f3465b;
    public final int f3466c;
    public final byte[] f3467d;

    public C1602a(String str, String str2, int i, byte[] bArr) {
        super("APIC");
        this.f3464a = str;
        this.f3465b = str2;
        this.f3466c = i;
        this.f3467d = bArr;
    }
}
