package com.google.android.exoplayer2.metadata.p040a;

public final class C1609h extends C1601e {
    public final String f3476a;
    public final String f3477b;

    public C1609h(String str, String str2) {
        super("TXXX");
        this.f3476a = str;
        this.f3477b = str2;
    }
}
