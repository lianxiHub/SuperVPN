package com.google.android.exoplayer2.metadata.p040a;

import com.google.android.exoplayer2.metadata.C1605a;
import com.google.android.exoplayer2.metadata.MetadataDecoderException;
import com.google.android.exoplayer2.p031c.C1403k;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public final class C1606d implements C1605a {
    public /* synthetic */ Object mo2257a(byte[] bArr, int i) {
        return m3768b(bArr, i);
    }

    public boolean mo2258a(String str) {
        return str.equals("application/id3");
    }

    public List m3768b(byte[] bArr, int i) {
        List arrayList = new ArrayList();
        C1403k c1403k = new C1403k(bArr, i);
        int a = C1606d.m3756a(c1403k);
        while (a > 0) {
            int g = c1403k.m2766g();
            int g2 = c1403k.m2766g();
            int g3 = c1403k.m2766g();
            int g4 = c1403k.m2766g();
            int s = c1403k.m2778s();
            if (s <= 1) {
                break;
            }
            Object a2;
            c1403k.m2762d(2);
            if (g == 84 && g2 == 88 && g3 == 88 && g4 == 88) {
                try {
                    a2 = C1606d.m3759a(c1403k, s);
                } catch (Throwable e) {
                    throw new MetadataDecoderException("Unsupported encoding", e);
                }
            } else if (g == 80 && g2 == 82 && g3 == 73 && g4 == 86) {
                a2 = C1606d.m3761b(c1403k, s);
            } else if (g == 71 && g2 == 69 && g3 == 79 && g4 == 66) {
                a2 = C1606d.m3764c(c1403k, s);
            } else if (g == 65 && g2 == 80 && g3 == 73 && g4 == 67) {
                a2 = C1606d.m3765d(c1403k, s);
            } else if (g == 84) {
                a2 = C1606d.m3758a(c1403k, s, String.format(Locale.US, "%c%c%c%c", new Object[]{Integer.valueOf(g), Integer.valueOf(g2), Integer.valueOf(g3), Integer.valueOf(g4)}));
            } else {
                a2 = C1606d.m3760b(c1403k, s, String.format(Locale.US, "%c%c%c%c", new Object[]{Integer.valueOf(g), Integer.valueOf(g2), Integer.valueOf(g3), Integer.valueOf(g4)}));
            }
            arrayList.add(a2);
            a -= s + 10;
        }
        return Collections.unmodifiableList(arrayList);
    }

    private static int m3757a(byte[] bArr, int i, int i2) {
        int c = C1606d.m3763c(bArr, i);
        if (i2 == 0 || i2 == 3) {
            return c;
        }
        while (c < bArr.length - 1) {
            if (c % 2 == 0 && bArr[c + 1] == (byte) 0) {
                return c;
            }
            c = C1606d.m3763c(bArr, c + 1);
        }
        return bArr.length;
    }

    private static int m3763c(byte[] bArr, int i) {
        while (i < bArr.length) {
            if (bArr[i] == (byte) 0) {
                return i;
            }
            i++;
        }
        return bArr.length;
    }

    private static int m3755a(int i) {
        return (i == 0 || i == 3) ? 1 : 2;
    }

    private static int m3756a(C1403k c1403k) {
        int g = c1403k.m2766g();
        int g2 = c1403k.m2766g();
        int g3 = c1403k.m2766g();
        if (g == 73 && g2 == 68 && g3 == 51) {
            c1403k.m2762d(2);
            g2 = c1403k.m2766g();
            g = c1403k.m2778s();
            if ((g2 & 2) != 0) {
                g3 = c1403k.m2778s();
                if (g3 > 4) {
                    c1403k.m2762d(g3 - 4);
                }
                g -= g3;
            }
            if ((g2 & 8) != 0) {
                return g - 10;
            }
            return g;
        }
        throw new MetadataDecoderException(String.format(Locale.US, "Unexpected ID3 file identifier, expected \"ID3\", actual \"%c%c%c\".", new Object[]{Integer.valueOf(g), Integer.valueOf(g2), Integer.valueOf(g3)}));
    }

    private static C1609h m3759a(C1403k c1403k, int i) {
        int g = c1403k.m2766g();
        String b = C1606d.m3762b(g);
        byte[] bArr = new byte[(i - 1)];
        c1403k.m2756a(bArr, 0, i - 1);
        int a = C1606d.m3757a(bArr, 0, g);
        String str = new String(bArr, 0, a, b);
        a += C1606d.m3755a(g);
        return new C1609h(str, new String(bArr, a, C1606d.m3757a(bArr, a, g) - a, b));
    }

    private static C1607f m3761b(C1403k c1403k, int i) {
        byte[] bArr = new byte[i];
        c1403k.m2756a(bArr, 0, i);
        int c = C1606d.m3763c(bArr, 0);
        return new C1607f(new String(bArr, 0, c, "ISO-8859-1"), Arrays.copyOfRange(bArr, c + 1, bArr.length));
    }

    private static C1604c m3764c(C1403k c1403k, int i) {
        int g = c1403k.m2766g();
        String b = C1606d.m3762b(g);
        byte[] bArr = new byte[(i - 1)];
        c1403k.m2756a(bArr, 0, i - 1);
        int c = C1606d.m3763c(bArr, 0);
        String str = new String(bArr, 0, c, "ISO-8859-1");
        c++;
        int a = C1606d.m3757a(bArr, c, g);
        String str2 = new String(bArr, c, a - c, b);
        c = C1606d.m3755a(g) + a;
        a = C1606d.m3757a(bArr, c, g);
        return new C1604c(str, str2, new String(bArr, c, a - c, b), Arrays.copyOfRange(bArr, C1606d.m3755a(g) + a, bArr.length));
    }

    private static C1602a m3765d(C1403k c1403k, int i) {
        int g = c1403k.m2766g();
        String b = C1606d.m3762b(g);
        byte[] bArr = new byte[(i - 1)];
        c1403k.m2756a(bArr, 0, i - 1);
        int c = C1606d.m3763c(bArr, 0);
        String str = new String(bArr, 0, c, "ISO-8859-1");
        int i2 = bArr[c + 1] & 255;
        c += 2;
        int a = C1606d.m3757a(bArr, c, g);
        return new C1602a(str, new String(bArr, c, a - c, b), i2, Arrays.copyOfRange(bArr, C1606d.m3755a(g) + a, bArr.length));
    }

    private static C1608g m3758a(C1403k c1403k, int i, String str) {
        int g = c1403k.m2766g();
        String b = C1606d.m3762b(g);
        byte[] bArr = new byte[(i - 1)];
        c1403k.m2756a(bArr, 0, i - 1);
        return new C1608g(str, new String(bArr, 0, C1606d.m3757a(bArr, 0, g), b));
    }

    private static C1603b m3760b(C1403k c1403k, int i, String str) {
        byte[] bArr = new byte[i];
        c1403k.m2756a(bArr, 0, i);
        return new C1603b(str, bArr);
    }

    private static String m3762b(int i) {
        switch (i) {
            case 0:
                return "ISO-8859-1";
            case 1:
                return WebRequest.CHARSET_UTF_16;
            case 2:
                return "UTF-16BE";
            case 3:
                return WebRequest.CHARSET_UTF_8;
            default:
                return "ISO-8859-1";
        }
    }
}
