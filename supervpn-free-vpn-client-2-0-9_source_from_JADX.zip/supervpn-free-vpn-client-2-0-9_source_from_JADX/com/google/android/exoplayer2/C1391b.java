package com.google.android.exoplayer2;

import android.support.v4.view.PointerIconCompat;
import com.google.android.exoplayer2.p031c.C1414r;
import java.util.UUID;

public final class C1391b {
    public static final int f2436a;
    public static final UUID f2437b = new UUID(0, 0);
    public static final UUID f2438c = new UUID(-1301668207276963122L, -6645017420763422227L);
    public static final UUID f2439d = new UUID(-7348484286925749626L, -6083546864340672619L);

    static {
        int i;
        if (C1414r.f2503a < 23) {
            i = PointerIconCompat.TYPE_GRAB;
        } else {
            i = 6396;
        }
        f2436a = i;
    }

    public static long m2704a(long j) {
        return j == -9223372036854775807L ? -9223372036854775807L : j / 1000;
    }

    public static long m2705b(long j) {
        return j == -9223372036854775807L ? -9223372036854775807L : 1000 * j;
    }
}
