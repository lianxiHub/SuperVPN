package com.google.android.exoplayer2;

import com.google.android.exoplayer2.p032b.C1387g;
import com.google.android.exoplayer2.source.C1631h;
import com.google.android.exoplayer2.upstream.C1684b;

public interface C1416i {
    void mo2146a();

    void mo2147a(C1352k[] c1352kArr, C1631h c1631h, C1387g c1387g);

    boolean mo2148a(long j);

    boolean mo2149a(long j, boolean z);

    void mo2150b();

    void mo2151c();

    C1684b mo2152d();
}
