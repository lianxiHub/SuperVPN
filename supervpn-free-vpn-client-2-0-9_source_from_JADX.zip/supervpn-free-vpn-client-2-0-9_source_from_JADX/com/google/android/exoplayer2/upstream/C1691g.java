package com.google.android.exoplayer2.upstream;

import android.os.Handler;
import android.os.SystemClock;
import android.support.v4.media.session.PlaybackStateCompat;
import com.facebook.ads.AdError;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1410o;
import com.google.android.exoplayer2.upstream.C1686c.C1685a;

public final class C1691g implements C1686c, C1690l {
    private final Handler f3869a;
    private final C1685a f3870b;
    private final C1410o f3871c;
    private int f3872d;
    private long f3873e;
    private long f3874f;
    private long f3875g;
    private long f3876h;
    private long f3877i;

    public C1691g() {
        this(null, null);
    }

    public C1691g(Handler handler, C1685a c1685a) {
        this(handler, c1685a, AdError.SERVER_ERROR_CODE);
    }

    public C1691g(Handler handler, C1685a c1685a, int i) {
        this.f3869a = handler;
        this.f3870b = c1685a;
        this.f3871c = new C1410o(i);
        this.f3877i = -1;
    }

    public synchronized long mo2322a() {
        return this.f3877i;
    }

    public synchronized void mo2325a(Object obj, C1687e c1687e) {
        if (this.f3872d == 0) {
            this.f3873e = SystemClock.elapsedRealtime();
        }
        this.f3872d++;
    }

    public synchronized void mo2324a(Object obj, int i) {
        this.f3874f += (long) i;
    }

    public synchronized void mo2323a(Object obj) {
        C1392a.m2711b(this.f3872d > 0);
        long elapsedRealtime = SystemClock.elapsedRealtime();
        int i = (int) (elapsedRealtime - this.f3873e);
        this.f3875g += (long) i;
        this.f3876h += this.f3874f;
        if (i > 0) {
            this.f3871c.m2802a((int) Math.sqrt((double) this.f3874f), (float) ((this.f3874f * 8000) / ((long) i)));
            if (this.f3875g >= 2000 || this.f3876h >= PlaybackStateCompat.ACTION_SET_SHUFFLE_MODE_ENABLED) {
                float a = this.f3871c.m2801a(0.5f);
                this.f3877i = Float.isNaN(a) ? -1 : (long) a;
            }
        }
        m4239a(i, this.f3874f, this.f3877i);
        int i2 = this.f3872d - 1;
        this.f3872d = i2;
        if (i2 > 0) {
            this.f3873e = elapsedRealtime;
        }
        this.f3874f = 0;
    }

    private void m4239a(int i, long j, long j2) {
        if (this.f3869a != null && this.f3870b != null) {
            final int i2 = i;
            final long j3 = j;
            final long j4 = j2;
            this.f3869a.post(new Runnable(this) {
                final /* synthetic */ C1691g f3868d;

                public void run() {
                    this.f3868d.f3870b.m4225a(i2, j3, j4);
                }
            });
        }
    }
}
