package com.google.android.exoplayer2.upstream;

import android.net.Uri;
import java.io.EOFException;
import java.io.IOException;
import java.io.RandomAccessFile;

public final class FileDataSource implements C1678d {
    private final C1690l f3825a;
    private RandomAccessFile f3826b;
    private Uri f3827c;
    private long f3828d;
    private boolean f3829e;

    public static class FileDataSourceException extends IOException {
        public FileDataSourceException(IOException iOException) {
            super(iOException);
        }
    }

    public FileDataSource() {
        this(null);
    }

    public FileDataSource(C1690l c1690l) {
        this.f3825a = c1690l;
    }

    public long mo2314a(C1687e c1687e) {
        try {
            this.f3827c = c1687e.f3850a;
            this.f3826b = new RandomAccessFile(c1687e.f3850a.getPath(), "r");
            this.f3826b.seek(c1687e.f3853d);
            this.f3828d = c1687e.f3854e == -1 ? this.f3826b.length() - c1687e.f3853d : c1687e.f3854e;
            if (this.f3828d < 0) {
                throw new EOFException();
            }
            this.f3829e = true;
            if (this.f3825a != null) {
                this.f3825a.mo2325a((Object) this, c1687e);
            }
            return this.f3828d;
        } catch (IOException e) {
            throw new FileDataSourceException(e);
        }
    }

    public int mo2313a(byte[] bArr, int i, int i2) {
        if (i2 == 0) {
            return 0;
        }
        if (this.f3828d == 0) {
            return -1;
        }
        try {
            int read = this.f3826b.read(bArr, i, (int) Math.min(this.f3828d, (long) i2));
            if (read <= 0) {
                return read;
            }
            this.f3828d -= (long) read;
            if (this.f3825a == null) {
                return read;
            }
            this.f3825a.mo2324a((Object) this, read);
            return read;
        } catch (IOException e) {
            throw new FileDataSourceException(e);
        }
    }

    public void mo2315a() {
        this.f3827c = null;
        try {
            if (this.f3826b != null) {
                this.f3826b.close();
            }
            this.f3826b = null;
            if (this.f3829e) {
                this.f3829e = false;
                if (this.f3825a != null) {
                    this.f3825a.mo2323a(this);
                }
            }
        } catch (IOException e) {
            throw new FileDataSourceException(e);
        } catch (Throwable th) {
            this.f3826b = null;
            if (this.f3829e) {
                this.f3829e = false;
                if (this.f3825a != null) {
                    this.f3825a.mo2323a(this);
                }
            }
        }
    }
}
