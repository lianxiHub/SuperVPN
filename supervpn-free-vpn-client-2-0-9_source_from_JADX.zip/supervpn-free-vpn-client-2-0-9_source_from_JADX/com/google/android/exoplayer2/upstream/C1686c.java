package com.google.android.exoplayer2.upstream;

public interface C1686c {

    public interface C1685a {
        void m4225a(int i, long j, long j2);
    }

    long mo2322a();
}
