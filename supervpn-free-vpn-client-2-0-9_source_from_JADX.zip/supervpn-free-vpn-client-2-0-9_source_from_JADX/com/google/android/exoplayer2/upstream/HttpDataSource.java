package com.google.android.exoplayer2.upstream;

import android.text.TextUtils;
import com.google.android.exoplayer2.p031c.C1405m;
import com.google.android.exoplayer2.p031c.C1414r;
import com.google.android.exoplayer2.upstream.C1678d.C1680a;
import com.mopub.common.AdType;
import java.io.IOException;
import java.util.Map;

public interface HttpDataSource extends C1678d {
    public static final C1405m f3835a = new C16791();

    static class C16791 implements C1405m {
        C16791() {
        }

        public boolean m4201a(String str) {
            String d = C1414r.m2829d(str);
            return (TextUtils.isEmpty(d) || ((d.contains("text") && !d.contains("text/vtt")) || d.contains(AdType.HTML) || d.contains("xml"))) ? false : true;
        }
    }

    public static class HttpDataSourceException extends IOException {
        public final int f3830a;
        public final C1687e f3831b;

        public HttpDataSourceException(String str, C1687e c1687e, int i) {
            super(str);
            this.f3831b = c1687e;
            this.f3830a = i;
        }

        public HttpDataSourceException(IOException iOException, C1687e c1687e, int i) {
            super(iOException);
            this.f3831b = c1687e;
            this.f3830a = i;
        }

        public HttpDataSourceException(String str, IOException iOException, C1687e c1687e, int i) {
            super(str, iOException);
            this.f3831b = c1687e;
            this.f3830a = i;
        }
    }

    public static final class InvalidContentTypeException extends HttpDataSourceException {
        public final String f3832c;

        public InvalidContentTypeException(String str, C1687e c1687e) {
            super("Invalid content type: " + str, c1687e, 1);
            this.f3832c = str;
        }
    }

    public static final class InvalidResponseCodeException extends HttpDataSourceException {
        public final int f3833c;
        public final Map f3834d;

        public InvalidResponseCodeException(int i, Map map, C1687e c1687e) {
            super("Response code: " + i, c1687e, 1);
            this.f3833c = i;
            this.f3834d = map;
        }
    }

    public interface C1681a extends C1680a {
    }
}
