package com.google.android.exoplayer2.upstream;

import android.content.Context;
import android.content.res.AssetManager;
import android.net.Uri;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

public final class AssetDataSource implements C1678d {
    private final AssetManager f3811a;
    private final C1690l f3812b;
    private Uri f3813c;
    private InputStream f3814d;
    private long f3815e;
    private boolean f3816f;

    public static final class AssetDataSourceException extends IOException {
        public AssetDataSourceException(IOException iOException) {
            super(iOException);
        }
    }

    public AssetDataSource(Context context, C1690l c1690l) {
        this.f3811a = context.getAssets();
        this.f3812b = c1690l;
    }

    public long mo2314a(C1687e c1687e) {
        try {
            this.f3813c = c1687e.f3850a;
            String path = this.f3813c.getPath();
            if (path.startsWith("/android_asset/")) {
                path = path.substring(15);
            } else if (path.startsWith("/")) {
                path = path.substring(1);
            }
            this.f3814d = this.f3811a.open(path, 1);
            if (this.f3814d.skip(c1687e.f3853d) < c1687e.f3853d) {
                throw new EOFException();
            }
            if (c1687e.f3854e != -1) {
                this.f3815e = c1687e.f3854e;
            } else {
                this.f3815e = (long) this.f3814d.available();
                if (this.f3815e == 2147483647L) {
                    this.f3815e = -1;
                }
            }
            this.f3816f = true;
            if (this.f3812b != null) {
                this.f3812b.mo2325a((Object) this, c1687e);
            }
            return this.f3815e;
        } catch (IOException e) {
            throw new AssetDataSourceException(e);
        }
    }

    public int mo2313a(byte[] bArr, int i, int i2) {
        if (i2 == 0) {
            return 0;
        }
        if (this.f3815e == 0) {
            return -1;
        }
        try {
            if (this.f3815e != -1) {
                i2 = (int) Math.min(this.f3815e, (long) i2);
            }
            int read = this.f3814d.read(bArr, i, i2);
            if (read != -1) {
                if (this.f3815e != -1) {
                    this.f3815e -= (long) read;
                }
                if (this.f3812b != null) {
                    this.f3812b.mo2324a((Object) this, read);
                }
                return read;
            } else if (this.f3815e == -1) {
                return -1;
            } else {
                throw new AssetDataSourceException(new EOFException());
            }
        } catch (IOException e) {
            throw new AssetDataSourceException(e);
        }
    }

    public void mo2315a() {
        this.f3813c = null;
        try {
            if (this.f3814d != null) {
                this.f3814d.close();
            }
            this.f3814d = null;
            if (this.f3816f) {
                this.f3816f = false;
                if (this.f3812b != null) {
                    this.f3812b.mo2323a(this);
                }
            }
        } catch (IOException e) {
            throw new AssetDataSourceException(e);
        } catch (Throwable th) {
            this.f3814d = null;
            if (this.f3816f) {
                this.f3816f = false;
                if (this.f3812b != null) {
                    this.f3812b.mo2323a(this);
                }
            }
        }
    }
}
