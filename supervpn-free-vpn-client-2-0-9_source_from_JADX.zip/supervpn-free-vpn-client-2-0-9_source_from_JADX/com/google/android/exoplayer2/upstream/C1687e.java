package com.google.android.exoplayer2.upstream;

import android.net.Uri;
import com.google.android.exoplayer2.p031c.C1392a;
import java.util.Arrays;

public final class C1687e {
    public final Uri f3850a;
    public final byte[] f3851b;
    public final long f3852c;
    public final long f3853d;
    public final long f3854e;
    public final String f3855f;
    public final int f3856g;

    public C1687e(Uri uri, long j, long j2, String str) {
        this(uri, j, j, j2, str, 0);
    }

    public C1687e(Uri uri, long j, long j2, long j3, String str, int i) {
        this(uri, null, j, j2, j3, str, i);
    }

    public C1687e(Uri uri, byte[] bArr, long j, long j2, long j3, String str, int i) {
        C1392a.m2709a(j >= 0);
        C1392a.m2709a(j2 >= 0);
        boolean z = j3 > 0 || j3 == -1;
        C1392a.m2709a(z);
        this.f3850a = uri;
        this.f3851b = bArr;
        this.f3852c = j;
        this.f3853d = j2;
        this.f3854e = j3;
        this.f3855f = str;
        this.f3856g = i;
    }

    public String toString() {
        return "DataSpec[" + this.f3850a + ", " + Arrays.toString(this.f3851b) + ", " + this.f3852c + ", " + this.f3853d + ", " + this.f3854e + ", " + this.f3855f + ", " + this.f3856g + "]";
    }
}
