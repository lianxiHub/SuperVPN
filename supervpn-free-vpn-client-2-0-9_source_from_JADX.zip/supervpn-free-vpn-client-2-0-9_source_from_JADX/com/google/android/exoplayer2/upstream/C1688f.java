package com.google.android.exoplayer2.upstream;

import com.google.android.exoplayer2.p031c.C1392a;
import java.util.Arrays;

public final class C1688f implements C1684b {
    private final boolean f3857a;
    private final int f3858b;
    private final byte[] f3859c;
    private final C1683a[] f3860d;
    private int f3861e;
    private int f3862f;
    private int f3863g;
    private C1683a[] f3864h;

    public C1688f(boolean z, int i) {
        this(z, i, 0);
    }

    public C1688f(boolean z, int i, int i2) {
        boolean z2;
        int i3 = 0;
        C1392a.m2709a(i > 0);
        if (i2 >= 0) {
            z2 = true;
        } else {
            z2 = false;
        }
        C1392a.m2709a(z2);
        this.f3857a = z;
        this.f3858b = i;
        this.f3863g = i2;
        this.f3864h = new C1683a[(i2 + 100)];
        if (i2 > 0) {
            this.f3859c = new byte[(i2 * i)];
            while (i3 < i2) {
                this.f3864h[i3] = new C1683a(this.f3859c, i3 * i);
                i3++;
            }
        } else {
            this.f3859c = null;
        }
        this.f3860d = new C1683a[1];
    }

    public synchronized void m4233d() {
        if (this.f3857a) {
            m4228a(0);
        }
    }

    public synchronized void m4228a(int i) {
        Object obj = i < this.f3861e ? 1 : null;
        this.f3861e = i;
        if (obj != null) {
            mo2320b();
        }
    }

    public synchronized C1683a mo2317a() {
        C1683a c1683a;
        this.f3862f++;
        if (this.f3863g > 0) {
            C1683a[] c1683aArr = this.f3864h;
            int i = this.f3863g - 1;
            this.f3863g = i;
            c1683a = c1683aArr[i];
            this.f3864h[this.f3863g] = null;
        } else {
            c1683a = new C1683a(new byte[this.f3858b], 0);
        }
        return c1683a;
    }

    public synchronized void mo2318a(C1683a c1683a) {
        this.f3860d[0] = c1683a;
        mo2319a(this.f3860d);
    }

    public synchronized void mo2319a(C1683a[] c1683aArr) {
        if (this.f3863g + c1683aArr.length >= this.f3864h.length) {
            this.f3864h = (C1683a[]) Arrays.copyOf(this.f3864h, Math.max(this.f3864h.length * 2, this.f3863g + c1683aArr.length));
        }
        for (C1683a c1683a : c1683aArr) {
            boolean z;
            if (c1683a.f3848a == this.f3859c || c1683a.f3848a.length == this.f3858b) {
                z = true;
            } else {
                z = false;
            }
            C1392a.m2709a(z);
            C1683a[] c1683aArr2 = this.f3864h;
            int i = this.f3863g;
            this.f3863g = i + 1;
            c1683aArr2[i] = c1683a;
        }
        this.f3862f -= c1683aArr.length;
        notifyAll();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized void mo2320b() {
        /*
        r7 = this;
        r1 = 0;
        monitor-enter(r7);
        r0 = r7.f3861e;	 Catch:{ all -> 0x005e }
        r2 = r7.f3858b;	 Catch:{ all -> 0x005e }
        r0 = com.google.android.exoplayer2.p031c.C1414r.m2813a(r0, r2);	 Catch:{ all -> 0x005e }
        r2 = 0;
        r3 = r7.f3862f;	 Catch:{ all -> 0x005e }
        r0 = r0 - r3;
        r3 = java.lang.Math.max(r2, r0);	 Catch:{ all -> 0x005e }
        r0 = r7.f3863g;	 Catch:{ all -> 0x005e }
        if (r3 < r0) goto L_0x0018;
    L_0x0016:
        monitor-exit(r7);
        return;
    L_0x0018:
        r0 = r7.f3859c;	 Catch:{ all -> 0x005e }
        if (r0 == 0) goto L_0x0061;
    L_0x001c:
        r0 = r7.f3863g;	 Catch:{ all -> 0x005e }
        r0 = r0 + -1;
    L_0x0020:
        if (r1 > r0) goto L_0x004b;
    L_0x0022:
        r2 = r7.f3864h;	 Catch:{ all -> 0x005e }
        r4 = r2[r1];	 Catch:{ all -> 0x005e }
        r2 = r4.f3848a;	 Catch:{ all -> 0x005e }
        r5 = r7.f3859c;	 Catch:{ all -> 0x005e }
        if (r2 != r5) goto L_0x002f;
    L_0x002c:
        r1 = r1 + 1;
        goto L_0x0020;
    L_0x002f:
        r2 = r7.f3864h;	 Catch:{ all -> 0x005e }
        r5 = r2[r0];	 Catch:{ all -> 0x005e }
        r2 = r5.f3848a;	 Catch:{ all -> 0x005e }
        r6 = r7.f3859c;	 Catch:{ all -> 0x005e }
        if (r2 == r6) goto L_0x003c;
    L_0x0039:
        r0 = r0 + -1;
        goto L_0x0020;
    L_0x003c:
        r6 = r7.f3864h;	 Catch:{ all -> 0x005e }
        r2 = r1 + 1;
        r6[r1] = r5;	 Catch:{ all -> 0x005e }
        r5 = r7.f3864h;	 Catch:{ all -> 0x005e }
        r1 = r0 + -1;
        r5[r0] = r4;	 Catch:{ all -> 0x005e }
        r0 = r1;
        r1 = r2;
        goto L_0x0020;
    L_0x004b:
        r0 = java.lang.Math.max(r3, r1);	 Catch:{ all -> 0x005e }
        r1 = r7.f3863g;	 Catch:{ all -> 0x005e }
        if (r0 >= r1) goto L_0x0016;
    L_0x0053:
        r1 = r7.f3864h;	 Catch:{ all -> 0x005e }
        r2 = r7.f3863g;	 Catch:{ all -> 0x005e }
        r3 = 0;
        java.util.Arrays.fill(r1, r0, r2, r3);	 Catch:{ all -> 0x005e }
        r7.f3863g = r0;	 Catch:{ all -> 0x005e }
        goto L_0x0016;
    L_0x005e:
        r0 = move-exception;
        monitor-exit(r7);
        throw r0;
    L_0x0061:
        r0 = r3;
        goto L_0x0053;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.upstream.f.b():void");
    }

    public synchronized int m4234e() {
        return this.f3862f * this.f3858b;
    }

    public int mo2321c() {
        return this.f3858b;
    }
}
