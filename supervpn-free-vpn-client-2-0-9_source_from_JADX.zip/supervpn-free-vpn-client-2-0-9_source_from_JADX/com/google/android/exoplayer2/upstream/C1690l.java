package com.google.android.exoplayer2.upstream;

public interface C1690l {
    void mo2323a(Object obj);

    void mo2324a(Object obj, int i);

    void mo2325a(Object obj, C1687e c1687e);
}
