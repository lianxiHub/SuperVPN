package com.google.android.exoplayer2.upstream;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1412q;
import com.google.android.exoplayer2.p031c.C1414r;
import java.io.IOException;
import java.util.concurrent.ExecutorService;

public final class Loader {
    private final ExecutorService f3845a;
    private C1682b f3846b;
    private IOException f3847c;

    public interface C1620c {
        void mo2264a();

        boolean mo2265b();

        void mo2266c();
    }

    public interface C1627a {
        int mo2271a(C1620c c1620c, long j, long j2, IOException iOException);

        void mo2278a(C1620c c1620c, long j, long j2);

        void mo2279a(C1620c c1620c, long j, long j2, boolean z);
    }

    public static final class UnexpectedLoaderException extends IOException {
        public UnexpectedLoaderException(Exception exception) {
            super("Unexpected " + exception.getClass().getSimpleName() + ": " + exception.getMessage(), exception);
        }
    }

    @SuppressLint({"HandlerLeak"})
    private final class C1682b extends Handler implements Runnable {
        public final int f3836a;
        final /* synthetic */ Loader f3837b;
        private final C1620c f3838c;
        private final C1627a f3839d;
        private final long f3840e;
        private IOException f3841f;
        private int f3842g;
        private volatile Thread f3843h;
        private volatile boolean f3844i;

        public C1682b(Loader loader, Looper looper, C1620c c1620c, C1627a c1627a, int i, long j) {
            this.f3837b = loader;
            super(looper);
            this.f3838c = c1620c;
            this.f3839d = c1627a;
            this.f3836a = i;
            this.f3840e = j;
        }

        public void m4206a(int i) {
            if (this.f3841f != null && this.f3842g > i) {
                throw this.f3841f;
            }
        }

        public void m4207a(long j) {
            C1392a.m2711b(this.f3837b.f3846b == null);
            this.f3837b.f3846b = this;
            if (j > 0) {
                sendEmptyMessageDelayed(0, j);
            } else {
                m4203a();
            }
        }

        public void m4208a(boolean z) {
            this.f3844i = z;
            this.f3841f = null;
            if (hasMessages(0)) {
                removeMessages(0);
                if (!z) {
                    sendEmptyMessage(1);
                }
            } else {
                this.f3838c.mo2264a();
                if (this.f3843h != null) {
                    this.f3843h.interrupt();
                }
            }
            if (z) {
                m4204b();
                long elapsedRealtime = SystemClock.elapsedRealtime();
                this.f3839d.mo2279a(this.f3838c, elapsedRealtime, elapsedRealtime - this.f3840e, true);
            }
        }

        public void run() {
            try {
                this.f3843h = Thread.currentThread();
                if (!this.f3838c.mo2265b()) {
                    C1412q.m2809a("load:" + this.f3838c.getClass().getSimpleName());
                    this.f3838c.mo2266c();
                    C1412q.m2808a();
                }
                if (!this.f3844i) {
                    sendEmptyMessage(2);
                }
            } catch (IOException e) {
                if (!this.f3844i) {
                    obtainMessage(3, e).sendToTarget();
                }
            } catch (InterruptedException e2) {
                C1392a.m2711b(this.f3838c.mo2265b());
                if (!this.f3844i) {
                    sendEmptyMessage(2);
                }
            } catch (Throwable e3) {
                Log.e("LoadTask", "Unexpected exception loading stream", e3);
                if (!this.f3844i) {
                    obtainMessage(3, new UnexpectedLoaderException(e3)).sendToTarget();
                }
            } catch (Throwable e32) {
                Log.e("LoadTask", "Unexpected error loading stream", e32);
                if (!this.f3844i) {
                    obtainMessage(4, e32).sendToTarget();
                }
                throw e32;
            } catch (Throwable th) {
                C1412q.m2808a();
            }
        }

        public void handleMessage(Message message) {
            if (!this.f3844i) {
                if (message.what == 0) {
                    m4203a();
                } else if (message.what == 4) {
                    throw ((Error) message.obj);
                } else {
                    m4204b();
                    long elapsedRealtime = SystemClock.elapsedRealtime();
                    long j = elapsedRealtime - this.f3840e;
                    if (this.f3838c.mo2265b()) {
                        this.f3839d.mo2279a(this.f3838c, elapsedRealtime, j, false);
                        return;
                    }
                    switch (message.what) {
                        case 1:
                            this.f3839d.mo2279a(this.f3838c, elapsedRealtime, j, false);
                            return;
                        case 2:
                            this.f3839d.mo2278a(this.f3838c, elapsedRealtime, j);
                            return;
                        case 3:
                            this.f3841f = (IOException) message.obj;
                            int a = this.f3839d.mo2271a(this.f3838c, elapsedRealtime, j, this.f3841f);
                            if (a == 3) {
                                this.f3837b.f3847c = this.f3841f;
                                return;
                            } else if (a != 2) {
                                if (a == 1) {
                                    a = 1;
                                } else {
                                    a = this.f3842g + 1;
                                }
                                this.f3842g = a;
                                m4207a(m4205c());
                                return;
                            } else {
                                return;
                            }
                        default:
                            return;
                    }
                }
            }
        }

        private void m4203a() {
            this.f3841f = null;
            this.f3837b.f3845a.submit(this.f3837b.f3846b);
        }

        private void m4204b() {
            this.f3837b.f3846b = null;
        }

        private long m4205c() {
            return (long) Math.min((this.f3842g - 1) * 1000, 5000);
        }
    }

    public Loader(String str) {
        this.f3845a = C1414r.m2820a(str);
    }

    public long m4213a(C1620c c1620c, C1627a c1627a, int i) {
        Looper myLooper = Looper.myLooper();
        C1392a.m2711b(myLooper != null);
        long elapsedRealtime = SystemClock.elapsedRealtime();
        new C1682b(this, myLooper, c1620c, c1627a, i, elapsedRealtime).m4207a(0);
        return elapsedRealtime;
    }

    public boolean m4216a() {
        return this.f3846b != null;
    }

    public void m4217b() {
        this.f3846b.m4208a(false);
    }

    public void m4215a(Runnable runnable) {
        if (this.f3846b != null) {
            this.f3846b.m4208a(true);
        }
        if (runnable != null) {
            this.f3845a.submit(runnable);
        }
        this.f3845a.shutdown();
    }

    public void m4218c() {
        m4214a(Integer.MIN_VALUE);
    }

    public void m4214a(int i) {
        if (this.f3847c != null) {
            throw this.f3847c;
        } else if (this.f3846b != null) {
            C1682b c1682b = this.f3846b;
            if (i == Integer.MIN_VALUE) {
                i = this.f3846b.f3836a;
            }
            c1682b.m4206a(i);
        }
    }
}
