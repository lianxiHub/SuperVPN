package com.google.android.exoplayer2.upstream;

public final class C1683a {
    public final byte[] f3848a;
    private final int f3849b;

    public C1683a(byte[] bArr, int i) {
        this.f3848a = bArr;
        this.f3849b = i;
    }

    public int m4219a(int i) {
        return this.f3849b + i;
    }
}
