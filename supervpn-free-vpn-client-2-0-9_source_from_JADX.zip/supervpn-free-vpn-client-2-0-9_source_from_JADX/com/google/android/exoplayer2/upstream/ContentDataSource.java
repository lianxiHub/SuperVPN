package com.google.android.exoplayer2.upstream;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.net.Uri;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public final class ContentDataSource implements C1678d {
    private final ContentResolver f3817a;
    private final C1690l f3818b;
    private Uri f3819c;
    private AssetFileDescriptor f3820d;
    private InputStream f3821e;
    private long f3822f;
    private boolean f3823g;

    public static class ContentDataSourceException extends IOException {
        public ContentDataSourceException(IOException iOException) {
            super(iOException);
        }
    }

    public ContentDataSource(Context context, C1690l c1690l) {
        this.f3817a = context.getContentResolver();
        this.f3818b = c1690l;
    }

    public long mo2314a(C1687e c1687e) {
        try {
            this.f3819c = c1687e.f3850a;
            this.f3820d = this.f3817a.openAssetFileDescriptor(this.f3819c, "r");
            this.f3821e = new FileInputStream(this.f3820d.getFileDescriptor());
            if (this.f3821e.skip(c1687e.f3853d) < c1687e.f3853d) {
                throw new EOFException();
            }
            if (c1687e.f3854e != -1) {
                this.f3822f = c1687e.f3854e;
            } else {
                this.f3822f = (long) this.f3821e.available();
                if (this.f3822f == 0) {
                    this.f3822f = -1;
                }
            }
            this.f3823g = true;
            if (this.f3818b != null) {
                this.f3818b.mo2325a((Object) this, c1687e);
            }
            return this.f3822f;
        } catch (IOException e) {
            throw new ContentDataSourceException(e);
        }
    }

    public int mo2313a(byte[] bArr, int i, int i2) {
        if (i2 == 0) {
            return 0;
        }
        if (this.f3822f == 0) {
            return -1;
        }
        try {
            if (this.f3822f != -1) {
                i2 = (int) Math.min(this.f3822f, (long) i2);
            }
            int read = this.f3821e.read(bArr, i, i2);
            if (read != -1) {
                if (this.f3822f != -1) {
                    this.f3822f -= (long) read;
                }
                if (this.f3818b != null) {
                    this.f3818b.mo2324a((Object) this, read);
                }
                return read;
            } else if (this.f3822f == -1) {
                return -1;
            } else {
                throw new ContentDataSourceException(new EOFException());
            }
        } catch (IOException e) {
            throw new ContentDataSourceException(e);
        }
    }

    public void mo2315a() {
        this.f3819c = null;
        try {
            if (this.f3821e != null) {
                this.f3821e.close();
            }
            this.f3821e = null;
            try {
                if (this.f3820d != null) {
                    this.f3820d.close();
                }
                this.f3820d = null;
                if (this.f3823g) {
                    this.f3823g = false;
                    if (this.f3818b != null) {
                        this.f3818b.mo2323a(this);
                    }
                }
            } catch (IOException e) {
                throw new ContentDataSourceException(e);
            } catch (Throwable th) {
                this.f3820d = null;
                if (this.f3823g) {
                    this.f3823g = false;
                    if (this.f3818b != null) {
                        this.f3818b.mo2323a(this);
                    }
                }
            }
        } catch (IOException e2) {
            throw new ContentDataSourceException(e2);
        } catch (Throwable th2) {
            this.f3821e = null;
            try {
                if (this.f3820d != null) {
                    this.f3820d.close();
                }
                this.f3820d = null;
                if (this.f3823g) {
                    this.f3823g = false;
                    if (this.f3818b != null) {
                        this.f3818b.mo2323a(this);
                    }
                }
            } catch (IOException e22) {
                throw new ContentDataSourceException(e22);
            } catch (Throwable th3) {
                this.f3820d = null;
                if (this.f3823g) {
                    this.f3823g = false;
                    if (this.f3818b != null) {
                        this.f3818b.mo2323a(this);
                    }
                }
            }
        }
    }
}
