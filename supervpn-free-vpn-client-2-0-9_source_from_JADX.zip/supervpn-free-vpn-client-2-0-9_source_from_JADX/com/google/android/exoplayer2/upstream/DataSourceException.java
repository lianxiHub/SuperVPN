package com.google.android.exoplayer2.upstream;

import java.io.IOException;

public final class DataSourceException extends IOException {
    public final int f3824a;

    public DataSourceException(int i) {
        this.f3824a = i;
    }
}
