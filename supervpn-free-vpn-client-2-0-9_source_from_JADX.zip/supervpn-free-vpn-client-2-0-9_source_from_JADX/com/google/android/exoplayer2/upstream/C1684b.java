package com.google.android.exoplayer2.upstream;

public interface C1684b {
    C1683a mo2317a();

    void mo2318a(C1683a c1683a);

    void mo2319a(C1683a[] c1683aArr);

    void mo2320b();

    int mo2321c();
}
