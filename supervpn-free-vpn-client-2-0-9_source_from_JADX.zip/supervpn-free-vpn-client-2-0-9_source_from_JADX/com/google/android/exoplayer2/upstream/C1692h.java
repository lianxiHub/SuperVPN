package com.google.android.exoplayer2.upstream;

import android.content.Context;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1414r;

public final class C1692h implements C1678d {
    private final C1678d f3878a;
    private final C1678d f3879b;
    private final C1678d f3880c;
    private final C1678d f3881d;
    private C1678d f3882e;

    public C1692h(Context context, C1690l c1690l, C1678d c1678d) {
        this.f3878a = (C1678d) C1392a.m2707a((Object) c1678d);
        this.f3879b = new FileDataSource(c1690l);
        this.f3880c = new AssetDataSource(context, c1690l);
        this.f3881d = new ContentDataSource(context, c1690l);
    }

    public long mo2314a(C1687e c1687e) {
        C1392a.m2711b(this.f3882e == null);
        String scheme = c1687e.f3850a.getScheme();
        if (C1414r.m2822a(c1687e.f3850a)) {
            if (c1687e.f3850a.getPath().startsWith("/android_asset/")) {
                this.f3882e = this.f3880c;
            } else {
                this.f3882e = this.f3879b;
            }
        } else if ("asset".equals(scheme)) {
            this.f3882e = this.f3880c;
        } else if ("content".equals(scheme)) {
            this.f3882e = this.f3881d;
        } else {
            this.f3882e = this.f3878a;
        }
        return this.f3882e.mo2314a(c1687e);
    }

    public int mo2313a(byte[] bArr, int i, int i2) {
        return this.f3882e.mo2313a(bArr, i, i2);
    }

    public void mo2315a() {
        if (this.f3882e != null) {
            try {
                this.f3882e.mo2315a();
            } finally {
                this.f3882e = null;
            }
        }
    }
}
