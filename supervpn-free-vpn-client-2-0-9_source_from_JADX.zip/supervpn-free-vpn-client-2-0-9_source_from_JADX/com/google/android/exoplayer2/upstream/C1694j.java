package com.google.android.exoplayer2.upstream;

import android.support.v4.media.session.PlaybackStateCompat;
import android.support.v7.widget.helper.ItemTouchHelper.Callback;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1405m;
import com.google.android.exoplayer2.p031c.C1414r;
import com.google.android.exoplayer2.upstream.HttpDataSource.HttpDataSourceException;
import com.google.android.exoplayer2.upstream.HttpDataSource.InvalidContentTypeException;
import com.google.android.exoplayer2.upstream.HttpDataSource.InvalidResponseCodeException;
import com.mopub.common.Constants;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.NoRouteToHostException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class C1694j implements HttpDataSource {
    private static final Pattern f3886b = Pattern.compile("^bytes (\\d+)-(\\d+)/(\\d+)$");
    private static final AtomicReference f3887c = new AtomicReference();
    private final boolean f3888d;
    private final int f3889e;
    private final int f3890f;
    private final String f3891g;
    private final C1405m f3892h;
    private final HashMap f3893i = new HashMap();
    private final C1690l f3894j;
    private C1687e f3895k;
    private HttpURLConnection f3896l;
    private InputStream f3897m;
    private boolean f3898n;
    private long f3899o;
    private long f3900p;
    private long f3901q;
    private long f3902r;

    public C1694j(String str, C1405m c1405m, C1690l c1690l, int i, int i2, boolean z) {
        this.f3891g = C1392a.m2708a(str);
        this.f3892h = c1405m;
        this.f3894j = c1690l;
        this.f3889e = i;
        this.f3890f = i2;
        this.f3888d = z;
    }

    public long mo2314a(C1687e c1687e) {
        long j = 0;
        this.f3895k = c1687e;
        this.f3902r = 0;
        this.f3901q = 0;
        try {
            this.f3896l = m4254b(c1687e);
            try {
                int responseCode = this.f3896l.getResponseCode();
                if (responseCode < Callback.DEFAULT_DRAG_ANIMATION_DURATION || responseCode > 299) {
                    Map headerFields = this.f3896l.getHeaderFields();
                    m4256d();
                    InvalidResponseCodeException invalidResponseCodeException = new InvalidResponseCodeException(responseCode, headerFields, c1687e);
                    if (responseCode == 416) {
                        invalidResponseCodeException.initCause(new DataSourceException(0));
                    }
                    throw invalidResponseCodeException;
                }
                String contentType = this.f3896l.getContentType();
                if (this.f3892h == null || this.f3892h.mo2316a(contentType)) {
                    if (responseCode == Callback.DEFAULT_DRAG_ANIMATION_DURATION && c1687e.f3853d != 0) {
                        j = c1687e.f3853d;
                    }
                    this.f3899o = j;
                    if ((c1687e.f3856g & 1) != 0) {
                        this.f3900p = c1687e.f3854e;
                    } else if (c1687e.f3854e != -1) {
                        this.f3900p = c1687e.f3854e;
                    } else {
                        j = C1694j.m4249a(this.f3896l);
                        this.f3900p = j != -1 ? j - this.f3899o : -1;
                    }
                    try {
                        this.f3897m = this.f3896l.getInputStream();
                        this.f3898n = true;
                        if (this.f3894j != null) {
                            this.f3894j.mo2325a((Object) this, c1687e);
                        }
                        return this.f3900p;
                    } catch (IOException e) {
                        m4256d();
                        throw new HttpDataSourceException(e, c1687e, 1);
                    }
                }
                m4256d();
                throw new InvalidContentTypeException(contentType, c1687e);
            } catch (IOException e2) {
                m4256d();
                throw new HttpDataSourceException("Unable to connect to " + c1687e.f3850a.toString(), e2, c1687e, 1);
            }
        } catch (IOException e22) {
            throw new HttpDataSourceException("Unable to connect to " + c1687e.f3850a.toString(), e22, c1687e, 1);
        }
    }

    public int mo2313a(byte[] bArr, int i, int i2) {
        try {
            m4255c();
            return m4253b(bArr, i, i2);
        } catch (IOException e) {
            throw new HttpDataSourceException(e, this.f3895k, 2);
        }
    }

    public void mo2315a() {
        try {
            if (this.f3897m != null) {
                C1694j.m4252a(this.f3896l, m4260b());
                this.f3897m.close();
            }
            this.f3897m = null;
            m4256d();
            if (this.f3898n) {
                this.f3898n = false;
                if (this.f3894j != null) {
                    this.f3894j.mo2323a(this);
                }
            }
        } catch (IOException e) {
            throw new HttpDataSourceException(e, this.f3895k, 3);
        } catch (Throwable th) {
            this.f3897m = null;
            m4256d();
            if (this.f3898n) {
                this.f3898n = false;
                if (this.f3894j != null) {
                    this.f3894j.mo2323a(this);
                }
            }
        }
    }

    protected final long m4260b() {
        return this.f3900p == -1 ? this.f3900p : this.f3900p - this.f3902r;
    }

    private HttpURLConnection m4254b(C1687e c1687e) {
        URL url = new URL(c1687e.f3850a.toString());
        byte[] bArr = c1687e.f3851b;
        long j = c1687e.f3853d;
        long j2 = c1687e.f3854e;
        boolean z = (c1687e.f3856g & 1) != 0;
        if (!this.f3888d) {
            return m4250a(url, bArr, j, j2, z, true);
        }
        HttpURLConnection a;
        int i = 0;
        while (true) {
            int i2 = i + 1;
            if (i <= 20) {
                a = m4250a(url, bArr, j, j2, z, false);
                int responseCode = a.getResponseCode();
                if (responseCode == 300 || responseCode == 301 || responseCode == 302 || responseCode == 303 || (bArr == null && (responseCode == 307 || responseCode == 308))) {
                    bArr = null;
                    String headerField = a.getHeaderField("Location");
                    a.disconnect();
                    url = C1694j.m4251a(url, headerField);
                    i = i2;
                }
            } else {
                throw new NoRouteToHostException("Too many redirects: " + i2);
            }
        }
        return a;
    }

    private HttpURLConnection m4250a(URL url, byte[] bArr, long j, long j2, boolean z, boolean z2) {
        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
        httpURLConnection.setConnectTimeout(this.f3889e);
        httpURLConnection.setReadTimeout(this.f3890f);
        synchronized (this.f3893i) {
            for (Entry entry : this.f3893i.entrySet()) {
                httpURLConnection.setRequestProperty((String) entry.getKey(), (String) entry.getValue());
            }
        }
        if (!(j == 0 && j2 == -1)) {
            String str = "bytes=" + j + "-";
            if (j2 != -1) {
                str = str + ((j + j2) - 1);
            }
            httpURLConnection.setRequestProperty("Range", str);
        }
        httpURLConnection.setRequestProperty("User-Agent", this.f3891g);
        if (!z) {
            httpURLConnection.setRequestProperty("Accept-Encoding", "identity");
        }
        httpURLConnection.setInstanceFollowRedirects(z2);
        httpURLConnection.setDoOutput(bArr != null);
        if (bArr != null) {
            httpURLConnection.setRequestMethod("POST");
            if (bArr.length == 0) {
                httpURLConnection.connect();
            } else {
                httpURLConnection.setFixedLengthStreamingMode(bArr.length);
                httpURLConnection.connect();
                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(bArr);
                outputStream.close();
            }
        } else {
            httpURLConnection.connect();
        }
        return httpURLConnection;
    }

    private static URL m4251a(URL url, String str) {
        if (str == null) {
            throw new ProtocolException("Null location redirect");
        }
        URL url2 = new URL(url, str);
        String protocol = url2.getProtocol();
        if (Constants.HTTPS.equals(protocol) || Constants.HTTP.equals(protocol)) {
            return url2;
        }
        throw new ProtocolException("Unsupported protocol redirect: " + protocol);
    }

    private static long m4249a(HttpURLConnection httpURLConnection) {
        long j = -1;
        String headerField = httpURLConnection.getHeaderField("Content-Length");
        if (!TextUtils.isEmpty(headerField)) {
            try {
                j = Long.parseLong(headerField);
            } catch (NumberFormatException e) {
                Log.e("DefaultHttpDataSource", "Unexpected Content-Length [" + headerField + "]");
            }
        }
        String headerField2 = httpURLConnection.getHeaderField("Content-Range");
        if (TextUtils.isEmpty(headerField2)) {
            return j;
        }
        Matcher matcher = f3886b.matcher(headerField2);
        if (!matcher.find()) {
            return j;
        }
        try {
            long parseLong = (Long.parseLong(matcher.group(2)) - Long.parseLong(matcher.group(1))) + 1;
            if (j < 0) {
                return parseLong;
            }
            if (j == parseLong) {
                return j;
            }
            Log.w("DefaultHttpDataSource", "Inconsistent headers [" + headerField + "] [" + headerField2 + "]");
            return Math.max(j, parseLong);
        } catch (NumberFormatException e2) {
            Log.e("DefaultHttpDataSource", "Unexpected Content-Range [" + headerField2 + "]");
            return j;
        }
    }

    private void m4255c() {
        if (this.f3901q != this.f3899o) {
            Object obj = (byte[]) f3887c.getAndSet(null);
            if (obj == null) {
                obj = new byte[4096];
            }
            while (this.f3901q != this.f3899o) {
                int read = this.f3897m.read(obj, 0, (int) Math.min(this.f3899o - this.f3901q, (long) obj.length));
                if (Thread.interrupted()) {
                    throw new InterruptedIOException();
                } else if (read == -1) {
                    throw new EOFException();
                } else {
                    this.f3901q += (long) read;
                    if (this.f3894j != null) {
                        this.f3894j.mo2324a((Object) this, read);
                    }
                }
            }
            f3887c.set(obj);
        }
    }

    private int m4253b(byte[] bArr, int i, int i2) {
        if (i2 == 0) {
            return 0;
        }
        if (this.f3900p != -1) {
            long j = this.f3900p - this.f3902r;
            if (j == 0) {
                return -1;
            }
            i2 = (int) Math.min((long) i2, j);
        }
        int read = this.f3897m.read(bArr, i, i2);
        if (read != -1) {
            this.f3902r += (long) read;
            if (this.f3894j != null) {
                this.f3894j.mo2324a((Object) this, read);
            }
            return read;
        } else if (this.f3900p == -1) {
            return -1;
        } else {
            throw new EOFException();
        }
    }

    private static void m4252a(HttpURLConnection httpURLConnection, long j) {
        if (C1414r.f2503a == 19 || C1414r.f2503a == 20) {
            try {
                InputStream inputStream = httpURLConnection.getInputStream();
                if (j == -1) {
                    if (inputStream.read() == -1) {
                        return;
                    }
                } else if (j <= PlaybackStateCompat.ACTION_PLAY_FROM_SEARCH) {
                    return;
                }
                String name = inputStream.getClass().getName();
                if (name.equals("com.android.okhttp.internal.http.HttpTransport$ChunkedInputStream") || name.equals("com.android.okhttp.internal.http.HttpTransport$FixedLengthInputStream")) {
                    Method declaredMethod = inputStream.getClass().getSuperclass().getDeclaredMethod("unexpectedEndOfInput", new Class[0]);
                    declaredMethod.setAccessible(true);
                    declaredMethod.invoke(inputStream, new Object[0]);
                }
            } catch (Exception e) {
            }
        }
    }

    private void m4256d() {
        if (this.f3896l != null) {
            try {
                this.f3896l.disconnect();
            } catch (Throwable e) {
                Log.e("DefaultHttpDataSource", "Unexpected error while disconnecting", e);
            }
            this.f3896l = null;
        }
    }
}
