package com.google.android.exoplayer2.upstream;

import android.content.Context;
import com.google.android.exoplayer2.upstream.C1678d.C1680a;

public final class C1693i implements C1680a {
    private final Context f3883a;
    private final C1690l f3884b;
    private final C1680a f3885c;

    public /* synthetic */ C1678d mo2326a() {
        return m4248b();
    }

    public C1693i(Context context, String str, C1690l c1690l) {
        this(context, c1690l, new C1695k(str, c1690l));
    }

    public C1693i(Context context, C1690l c1690l, C1680a c1680a) {
        this.f3883a = context.getApplicationContext();
        this.f3884b = c1690l;
        this.f3885c = c1680a;
    }

    public C1692h m4248b() {
        return new C1692h(this.f3883a, this.f3884b, this.f3885c.mo2326a());
    }
}
