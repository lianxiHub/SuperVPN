package com.google.android.exoplayer2.upstream;

public interface C1678d {

    public interface C1680a {
        C1678d mo2326a();
    }

    int mo2313a(byte[] bArr, int i, int i2);

    long mo2314a(C1687e c1687e);

    void mo2315a();
}
