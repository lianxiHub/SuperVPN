package com.google.android.exoplayer2.upstream;

import com.google.android.exoplayer2.upstream.HttpDataSource.C1681a;

public final class C1695k implements C1681a {
    private final String f3903a;
    private final C1690l f3904b;
    private final int f3905c;
    private final int f3906d;
    private final boolean f3907e;

    public /* synthetic */ C1678d mo2326a() {
        return m4262b();
    }

    public C1695k(String str, C1690l c1690l) {
        this(str, c1690l, 8000, 8000, false);
    }

    public C1695k(String str, C1690l c1690l, int i, int i2, boolean z) {
        this.f3903a = str;
        this.f3904b = c1690l;
        this.f3905c = i;
        this.f3906d = i2;
        this.f3907e = z;
    }

    public C1694j m4262b() {
        return new C1694j(this.f3903a, null, this.f3904b, this.f3905c, this.f3906d, this.f3907e);
    }
}
