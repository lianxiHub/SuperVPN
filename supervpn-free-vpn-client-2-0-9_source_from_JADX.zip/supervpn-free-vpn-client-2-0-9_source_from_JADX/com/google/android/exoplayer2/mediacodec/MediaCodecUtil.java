package com.google.android.exoplayer2.mediacodec;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.media.MediaCodecInfo;
import android.media.MediaCodecInfo.CodecCapabilities;
import android.media.MediaCodecInfo.CodecProfileLevel;
import android.media.MediaCodecList;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;
import com.facebook.appevents.AppEventsConstants;
import com.google.android.exoplayer2.p031c.C1414r;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@SuppressLint({"InlinedApi"})
@TargetApi(16)
public final class MediaCodecUtil {
    private static final C1598a f3451a = C1598a.m3739a("OMX.google.raw.decoder");
    private static final Pattern f3452b = Pattern.compile("^\\D?(\\d+)$");
    private static final HashMap f3453c = new HashMap();
    private static final Map f3454d = new HashMap();
    private static final Map f3455e = new HashMap();
    private static final Map f3456f = new HashMap();
    private static int f3457g = -1;

    public static class DecoderQueryException extends Exception {
        private DecoderQueryException(Throwable th) {
            super("Failed to query underlying media codecs", th);
        }
    }

    private static final class C1594a {
        public final String f3447a;
        public final boolean f3448b;

        public C1594a(String str, boolean z) {
            this.f3447a = str;
            this.f3448b = z;
        }

        public int hashCode() {
            return (this.f3448b ? 1231 : 1237) + (((this.f3447a == null ? 0 : this.f3447a.hashCode()) + 31) * 31);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || obj.getClass() != C1594a.class) {
                return false;
            }
            C1594a c1594a = (C1594a) obj;
            if (TextUtils.equals(this.f3447a, c1594a.f3447a) && this.f3448b == c1594a.f3448b) {
                return true;
            }
            return false;
        }
    }

    private interface C1595b {
        int mo2251a();

        MediaCodecInfo mo2252a(int i);

        boolean mo2253a(String str, CodecCapabilities codecCapabilities);

        boolean mo2254b();
    }

    private static final class C1596c implements C1595b {
        private C1596c() {
        }

        public int mo2251a() {
            return MediaCodecList.getCodecCount();
        }

        public MediaCodecInfo mo2252a(int i) {
            return MediaCodecList.getCodecInfoAt(i);
        }

        public boolean mo2254b() {
            return false;
        }

        public boolean mo2253a(String str, CodecCapabilities codecCapabilities) {
            return "video/avc".equals(str);
        }
    }

    @TargetApi(21)
    private static final class C1597d implements C1595b {
        private final int f3449a;
        private MediaCodecInfo[] f3450b;

        public C1597d(boolean z) {
            this.f3449a = z ? 1 : 0;
        }

        public int mo2251a() {
            m3724c();
            return this.f3450b.length;
        }

        public MediaCodecInfo mo2252a(int i) {
            m3724c();
            return this.f3450b[i];
        }

        public boolean mo2254b() {
            return true;
        }

        public boolean mo2253a(String str, CodecCapabilities codecCapabilities) {
            return codecCapabilities.isFeatureSupported("secure-playback");
        }

        private void m3724c() {
            if (this.f3450b == null) {
                this.f3450b = new MediaCodecList(this.f3449a).getCodecInfos();
            }
        }
    }

    static {
        f3454d.put(Integer.valueOf(66), Integer.valueOf(1));
        f3454d.put(Integer.valueOf(77), Integer.valueOf(2));
        f3454d.put(Integer.valueOf(88), Integer.valueOf(4));
        f3454d.put(Integer.valueOf(100), Integer.valueOf(8));
        f3455e.put(Integer.valueOf(10), Integer.valueOf(1));
        f3455e.put(Integer.valueOf(11), Integer.valueOf(4));
        f3455e.put(Integer.valueOf(12), Integer.valueOf(8));
        f3455e.put(Integer.valueOf(13), Integer.valueOf(16));
        f3455e.put(Integer.valueOf(20), Integer.valueOf(32));
        f3455e.put(Integer.valueOf(21), Integer.valueOf(64));
        f3455e.put(Integer.valueOf(22), Integer.valueOf(128));
        f3455e.put(Integer.valueOf(30), Integer.valueOf(256));
        f3455e.put(Integer.valueOf(31), Integer.valueOf(512));
        f3455e.put(Integer.valueOf(32), Integer.valueOf(1024));
        f3455e.put(Integer.valueOf(40), Integer.valueOf(2048));
        f3455e.put(Integer.valueOf(41), Integer.valueOf(4096));
        f3455e.put(Integer.valueOf(42), Integer.valueOf(8192));
        f3455e.put(Integer.valueOf(50), Integer.valueOf(16384));
        f3455e.put(Integer.valueOf(51), Integer.valueOf(32768));
        f3455e.put(Integer.valueOf(52), Integer.valueOf(65536));
        f3456f.put("L30", Integer.valueOf(1));
        f3456f.put("L60", Integer.valueOf(4));
        f3456f.put("L63", Integer.valueOf(16));
        f3456f.put("L90", Integer.valueOf(64));
        f3456f.put("L93", Integer.valueOf(256));
        f3456f.put("L120", Integer.valueOf(1024));
        f3456f.put("L123", Integer.valueOf(4096));
        f3456f.put("L150", Integer.valueOf(16384));
        f3456f.put("L153", Integer.valueOf(65536));
        f3456f.put("L156", Integer.valueOf(262144));
        f3456f.put("L180", Integer.valueOf(1048576));
        f3456f.put("L183", Integer.valueOf(4194304));
        f3456f.put("L186", Integer.valueOf(16777216));
        f3456f.put("H30", Integer.valueOf(2));
        f3456f.put("H60", Integer.valueOf(8));
        f3456f.put("H63", Integer.valueOf(32));
        f3456f.put("H90", Integer.valueOf(128));
        f3456f.put("H93", Integer.valueOf(512));
        f3456f.put("H120", Integer.valueOf(2048));
        f3456f.put("H123", Integer.valueOf(8192));
        f3456f.put("H150", Integer.valueOf(32768));
        f3456f.put("H153", Integer.valueOf(131072));
        f3456f.put("H156", Integer.valueOf(524288));
        f3456f.put("H180", Integer.valueOf(2097152));
        f3456f.put("H183", Integer.valueOf(8388608));
        f3456f.put("H186", Integer.valueOf(33554432));
    }

    public static C1598a m3732a() {
        return f3451a;
    }

    public static C1598a m3733a(String str, boolean z) {
        List b = m3738b(str, z);
        return b.isEmpty() ? null : (C1598a) b.get(0);
    }

    public static synchronized List m3738b(String str, boolean z) {
        List list;
        synchronized (MediaCodecUtil.class) {
            C1594a c1594a = new C1594a(str, z);
            list = (List) f3453c.get(c1594a);
            if (list == null) {
                list = m3734a(c1594a, C1414r.f2503a >= 21 ? new C1597d(z) : new C1596c());
                if (z && list.isEmpty() && 21 <= C1414r.f2503a && C1414r.f2503a <= 23) {
                    List a = m3734a(c1594a, new C1596c());
                    if (!a.isEmpty()) {
                        Log.w("MediaCodecUtil", "MediaCodecList API didn't list secure decoder for: " + str + ". Assuming: " + ((C1598a) a.get(0)).f3458a);
                    }
                    list = a;
                }
                list = Collections.unmodifiableList(list);
                f3453c.put(c1594a, list);
            }
        }
        return list;
    }

    private static List m3734a(C1594a c1594a, C1595b c1595b) {
        String name;
        try {
            List arrayList = new ArrayList();
            String str = c1594a.f3447a;
            int a = c1595b.mo2251a();
            boolean b = c1595b.mo2254b();
            loop0:
            for (int i = 0; i < a; i++) {
                MediaCodecInfo a2 = c1595b.mo2252a(i);
                name = a2.getName();
                if (m3735a(a2, name, b)) {
                    for (String str2 : a2.getSupportedTypes()) {
                        if (str2.equalsIgnoreCase(str)) {
                            CodecCapabilities capabilitiesForType = a2.getCapabilitiesForType(str2);
                            boolean a3 = c1595b.mo2253a(str, capabilitiesForType);
                            if ((!b || c1594a.f3448b != a3) && (b || c1594a.f3448b)) {
                                if (!b && a3) {
                                    arrayList.add(C1598a.m3740a(name + ".secure", str, capabilitiesForType));
                                    break loop0;
                                }
                            }
                            arrayList.add(C1598a.m3740a(name, str, capabilitiesForType));
                        }
                    }
                    continue;
                }
            }
            return arrayList;
        } catch (Exception e) {
            if (C1414r.f2503a > 23 || arrayList.isEmpty()) {
                Log.e("MediaCodecUtil", "Failed to query codec " + name + " (" + str2 + ")");
                throw e;
            }
            Log.e("MediaCodecUtil", "Skipping codec " + name + " (failed to query capabilities)");
        } catch (Throwable e2) {
            throw new DecoderQueryException(e2);
        }
    }

    private static boolean m3735a(MediaCodecInfo mediaCodecInfo, String str, boolean z) {
        if (mediaCodecInfo.isEncoder()) {
            return false;
        }
        if (!z && str.endsWith(".secure")) {
            return false;
        }
        if (C1414r.f2503a < 21 && ("CIPAACDecoder".equals(str) || "CIPMP3Decoder".equals(str) || "CIPVorbisDecoder".equals(str) || "AACDecoder".equals(str) || "MP3Decoder".equals(str))) {
            return false;
        }
        if (C1414r.f2503a < 18 && "OMX.SEC.MP3.Decoder".equals(str)) {
            return false;
        }
        if (C1414r.f2503a < 18 && "OMX.MTK.AUDIO.DECODER.AAC".equals(str) && "a70".equals(C1414r.f2504b)) {
            return false;
        }
        if (C1414r.f2503a == 16 && "OMX.qcom.audio.decoder.mp3".equals(str) && ("dlxu".equals(C1414r.f2504b) || "protou".equals(C1414r.f2504b) || "ville".equals(C1414r.f2504b) || "villeplus".equals(C1414r.f2504b) || "villec2".equals(C1414r.f2504b) || C1414r.f2504b.startsWith("gee") || "C6602".equals(C1414r.f2504b) || "C6603".equals(C1414r.f2504b) || "C6606".equals(C1414r.f2504b) || "C6616".equals(C1414r.f2504b) || "L36h".equals(C1414r.f2504b) || "SO-02E".equals(C1414r.f2504b))) {
            return false;
        }
        if (C1414r.f2503a == 16 && "OMX.qcom.audio.decoder.aac".equals(str) && ("C1504".equals(C1414r.f2504b) || "C1505".equals(C1414r.f2504b) || "C1604".equals(C1414r.f2504b) || "C1605".equals(C1414r.f2504b))) {
            return false;
        }
        if (C1414r.f2503a <= 19 && ((C1414r.f2504b.startsWith("d2") || C1414r.f2504b.startsWith("serrano") || C1414r.f2504b.startsWith("jflte") || C1414r.f2504b.startsWith("santos")) && "samsung".equals(C1414r.f2505c) && "OMX.SEC.vp8.dec".equals(str))) {
            return false;
        }
        if (C1414r.f2503a <= 19 && C1414r.f2504b.startsWith("jflte") && "OMX.qcom.video.decoder.vp8".equals(str)) {
            return false;
        }
        return true;
    }

    public static int m3736b() {
        int i = 0;
        if (f3457g == -1) {
            C1598a a = m3733a("video/avc", false);
            if (a != null) {
                CodecProfileLevel[] a2 = a.m3746a();
                int length = a2.length;
                int i2 = 0;
                while (i < length) {
                    i2 = Math.max(m3729a(a2[i].level), i2);
                    i++;
                }
                i = Math.max(i2, 172800);
            }
            f3457g = i;
        }
        return f3457g;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static android.util.Pair m3730a(java.lang.String r6) {
        /*
        r0 = 0;
        r1 = 0;
        if (r6 != 0) goto L_0x0005;
    L_0x0004:
        return r0;
    L_0x0005:
        r2 = "\\.";
        r3 = r6.split(r2);
        r4 = r3[r1];
        r2 = -1;
        r5 = r4.hashCode();
        switch(r5) {
            case 3006243: goto L_0x0035;
            case 3006244: goto L_0x0040;
            case 3199032: goto L_0x0020;
            case 3214780: goto L_0x002a;
            default: goto L_0x0016;
        };
    L_0x0016:
        r1 = r2;
    L_0x0017:
        switch(r1) {
            case 0: goto L_0x001b;
            case 1: goto L_0x001b;
            case 2: goto L_0x004b;
            case 3: goto L_0x004b;
            default: goto L_0x001a;
        };
    L_0x001a:
        goto L_0x0004;
    L_0x001b:
        r0 = m3731a(r6, r3);
        goto L_0x0004;
    L_0x0020:
        r5 = "hev1";
        r4 = r4.equals(r5);
        if (r4 == 0) goto L_0x0016;
    L_0x0029:
        goto L_0x0017;
    L_0x002a:
        r1 = "hvc1";
        r1 = r4.equals(r1);
        if (r1 == 0) goto L_0x0016;
    L_0x0033:
        r1 = 1;
        goto L_0x0017;
    L_0x0035:
        r1 = "avc1";
        r1 = r4.equals(r1);
        if (r1 == 0) goto L_0x0016;
    L_0x003e:
        r1 = 2;
        goto L_0x0017;
    L_0x0040:
        r1 = "avc2";
        r1 = r4.equals(r1);
        if (r1 == 0) goto L_0x0016;
    L_0x0049:
        r1 = 3;
        goto L_0x0017;
    L_0x004b:
        r0 = m3737b(r6, r3);
        goto L_0x0004;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.mediacodec.MediaCodecUtil.a(java.lang.String):android.util.Pair");
    }

    private static Pair m3731a(String str, String[] strArr) {
        if (strArr.length < 4) {
            Log.w("MediaCodecUtil", "Ignoring malformed HEVC codec string: " + str);
            return null;
        }
        Matcher matcher = f3452b.matcher(strArr[1]);
        if (matcher.matches()) {
            int i;
            String group = matcher.group(1);
            if (AppEventsConstants.EVENT_PARAM_VALUE_YES.equals(group)) {
                i = 1;
            } else if ("2".equals(group)) {
                i = 2;
            } else {
                Log.w("MediaCodecUtil", "Unknown HEVC profile string: " + group);
                return null;
            }
            Integer num = (Integer) f3456f.get(strArr[3]);
            if (num != null) {
                return new Pair(Integer.valueOf(i), num);
            }
            Log.w("MediaCodecUtil", "Unknown HEVC level string: " + matcher.group(1));
            return null;
        }
        Log.w("MediaCodecUtil", "Ignoring malformed HEVC codec string: " + str);
        return null;
    }

    private static Pair m3737b(String str, String[] strArr) {
        if (strArr.length < 2) {
            Log.w("MediaCodecUtil", "Ignoring malformed AVC codec string: " + str);
            return null;
        }
        try {
            Object valueOf;
            Object valueOf2;
            if (strArr[1].length() == 6) {
                valueOf = Integer.valueOf(Integer.parseInt(strArr[1].substring(0, 2), 16));
                valueOf2 = Integer.valueOf(Integer.parseInt(strArr[1].substring(4), 16));
            } else if (strArr.length >= 3) {
                valueOf = Integer.valueOf(Integer.parseInt(strArr[1]));
                Integer valueOf3 = Integer.valueOf(Integer.parseInt(strArr[2]));
            } else {
                Log.w("MediaCodecUtil", "Ignoring malformed AVC codec string: " + str);
                return null;
            }
            Integer num = (Integer) f3454d.get(valueOf);
            if (num == null) {
                Log.w("MediaCodecUtil", "Unknown AVC profile: " + valueOf);
                return null;
            }
            Integer num2 = (Integer) f3455e.get(valueOf2);
            if (num2 != null) {
                return new Pair(num, num2);
            }
            Log.w("MediaCodecUtil", "Unknown AVC level: " + valueOf2);
            return null;
        } catch (NumberFormatException e) {
            Log.w("MediaCodecUtil", "Ignoring malformed AVC codec string: " + str);
            return null;
        }
    }

    private static int m3729a(int i) {
        switch (i) {
            case 1:
            case 2:
                return 25344;
            case 8:
                return 101376;
            case 16:
                return 101376;
            case 32:
                return 101376;
            case 64:
                return 202752;
            case 128:
                return 414720;
            case 256:
                return 414720;
            case 512:
                return 921600;
            case 1024:
                return 1310720;
            case 2048:
                return 2097152;
            case 4096:
                return 2097152;
            case 8192:
                return 2228224;
            case 16384:
                return 5652480;
            case 32768:
                return 9437184;
            default:
                return -1;
        }
    }
}
