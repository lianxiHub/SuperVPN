package com.google.android.exoplayer2.mediacodec;

import android.annotation.TargetApi;
import android.media.MediaCodec;
import android.media.MediaCodec.BufferInfo;
import android.media.MediaCodec.CodecException;
import android.media.MediaCodec.CryptoInfo;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import com.google.android.exoplayer2.C1354a;
import com.google.android.exoplayer2.C1581h;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.drm.C1437a;
import com.google.android.exoplayer2.drm.C1438b;
import com.google.android.exoplayer2.drm.C1440d;
import com.google.android.exoplayer2.mediacodec.MediaCodecUtil.DecoderQueryException;
import com.google.android.exoplayer2.p030a.C1346d;
import com.google.android.exoplayer2.p030a.C1347e;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1401i;
import com.google.android.exoplayer2.p031c.C1412q;
import com.google.android.exoplayer2.p031c.C1414r;
import com.mopub.mobileads.VastIconXmlManager;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

@TargetApi(16)
public abstract class MediaCodecRenderer extends C1354a {
    private static final byte[] f2334b = C1414r.m2831f("0000016742C00BDA259000000168CE0F13200000016588840DCE7118A0002FBF1C31C3275D78");
    private int f2335A;
    private boolean f2336B;
    private boolean f2337C;
    private int f2338D;
    private int f2339E;
    private boolean f2340F;
    private boolean f2341G;
    private boolean f2342H;
    private boolean f2343I;
    private boolean f2344J;
    protected C1346d f2345a;
    private final C1599b f2346c;
    private final C1438b f2347d;
    private final boolean f2348e;
    private final C1347e f2349f;
    private final C1581h f2350g;
    private final List f2351h;
    private final BufferInfo f2352i;
    private Format f2353j;
    private MediaCodec f2354k;
    private C1437a f2355l;
    private C1437a f2356m;
    private boolean f2357n;
    private boolean f2358o;
    private boolean f2359p;
    private boolean f2360q;
    private boolean f2361r;
    private boolean f2362s;
    private boolean f2363t;
    private boolean f2364u;
    private boolean f2365v;
    private ByteBuffer[] f2366w;
    private ByteBuffer[] f2367x;
    private long f2368y;
    private int f2369z;

    public static class DecoderInitializationException extends Exception {
        public final String f3443a;
        public final boolean f3444b;
        public final String f3445c;
        public final String f3446d;

        public DecoderInitializationException(Format format, Throwable th, boolean z, int i) {
            super("Decoder init failed: [" + i + "], " + format, th);
            this.f3443a = format.f2183e;
            this.f3444b = z;
            this.f3445c = null;
            this.f3446d = m3714a(i);
        }

        public DecoderInitializationException(Format format, Throwable th, boolean z, String str) {
            super("Decoder init failed: " + str + ", " + format, th);
            this.f3443a = format.f2183e;
            this.f3444b = z;
            this.f3445c = str;
            this.f3446d = C1414r.f2503a >= 21 ? m3715a(th) : null;
        }

        @TargetApi(21)
        private static String m3715a(Throwable th) {
            if (th instanceof CodecException) {
                return ((CodecException) th).getDiagnosticInfo();
            }
            return null;
        }

        private static String m3714a(int i) {
            return "com.google.android.exoplayer.MediaCodecTrackRenderer_" + (i < 0 ? "neg_" : "") + Math.abs(i);
        }
    }

    protected abstract int mo2128a(C1599b c1599b, Format format);

    protected abstract void mo2131a(MediaCodec mediaCodec, Format format, MediaCrypto mediaCrypto);

    protected abstract boolean mo2133a(long j, long j2, MediaCodec mediaCodec, ByteBuffer byteBuffer, int i, int i2, long j3, boolean z);

    public MediaCodecRenderer(int i, C1599b c1599b, C1438b c1438b, boolean z) {
        super(i);
        C1392a.m2711b(C1414r.f2503a >= 16);
        this.f2346c = (C1599b) C1392a.m2707a((Object) c1599b);
        this.f2347d = c1438b;
        this.f2348e = z;
        this.f2349f = new C1347e(0);
        this.f2350g = new C1581h();
        this.f2351h = new ArrayList();
        this.f2352i = new BufferInfo();
        this.f2338D = 0;
        this.f2339E = 0;
    }

    public final int mo2112l() {
        return 4;
    }

    public final int mo2119a(Format format) {
        try {
            return mo2128a(this.f2346c, format);
        } catch (Exception e) {
            throw ExoPlaybackException.m2399a(e, m2509p());
        }
    }

    protected C1598a mo2129a(C1599b c1599b, Format format, boolean z) {
        return c1599b.mo2256a(format.f2183e, z);
    }

    protected final void m2633w() {
        MediaCrypto mediaCrypto;
        Throwable th;
        long elapsedRealtime;
        long elapsedRealtime2;
        if (mo2155x()) {
            boolean a;
            C1598a c1598a;
            String str;
            C1346d c1346d;
            this.f2355l = this.f2356m;
            String str2 = this.f2353j.f2183e;
            if (this.f2355l != null) {
                int a2 = this.f2355l.m2940a();
                if (a2 == 0) {
                    throw ExoPlaybackException.m2399a(this.f2355l.m2943c(), m2509p());
                } else if (a2 == 3 || a2 == 4) {
                    MediaCrypto a3 = ((C1440d) this.f2355l.m2942b()).m2946a();
                    a = this.f2355l.m2941a(str2);
                    mediaCrypto = a3;
                } else {
                    return;
                }
            }
            a = false;
            mediaCrypto = null;
            try {
                C1598a a4 = mo2129a(this.f2346c, this.f2353j, a);
                if (a4 == null && a) {
                    try {
                        a4 = mo2129a(this.f2346c, this.f2353j, false);
                        if (a4 != null) {
                            Log.w("MediaCodecRenderer", "Drm session requires secure decoder for " + str2 + ", but no secure decoder available. Trying to proceed with " + a4.f3458a + ".");
                        }
                    } catch (Throwable e) {
                        Throwable th2 = e;
                        c1598a = a4;
                        th = th2;
                        m2599a(new DecoderInitializationException(this.f2353j, th, a, -49998));
                        if (c1598a == null) {
                            m2599a(new DecoderInitializationException(this.f2353j, null, a, -49999));
                        }
                        str = c1598a.f3458a;
                        this.f2357n = c1598a.f3459b;
                        this.f2358o = m2601a(str, this.f2353j);
                        this.f2359p = mo2134a(str);
                        this.f2360q = m2603b(str);
                        this.f2361r = m2606c(str);
                        this.f2362s = m2608d(str);
                        this.f2363t = m2604b(str, this.f2353j);
                        elapsedRealtime = SystemClock.elapsedRealtime();
                        C1412q.m2809a("createCodec:" + str);
                        this.f2354k = MediaCodec.createByCodecName(str);
                        C1412q.m2808a();
                        C1412q.m2809a("configureCodec");
                        mo2131a(this.f2354k, this.f2353j, mediaCrypto);
                        C1412q.m2808a();
                        C1412q.m2809a("startCodec");
                        this.f2354k.start();
                        C1412q.m2808a();
                        elapsedRealtime2 = SystemClock.elapsedRealtime();
                        mo2132a(str, elapsedRealtime2, elapsedRealtime2 - elapsedRealtime);
                        this.f2366w = this.f2354k.getInputBuffers();
                        this.f2367x = this.f2354k.getOutputBuffers();
                        this.f2368y = mo2104d() == 2 ? -9223372036854775807L : SystemClock.elapsedRealtime() + 1000;
                        this.f2369z = -1;
                        this.f2335A = -1;
                        c1346d = this.f2345a;
                        c1346d.f2212a++;
                    }
                }
                c1598a = a4;
            } catch (DecoderQueryException e2) {
                th = e2;
                c1598a = null;
                m2599a(new DecoderInitializationException(this.f2353j, th, a, -49998));
                if (c1598a == null) {
                    m2599a(new DecoderInitializationException(this.f2353j, null, a, -49999));
                }
                str = c1598a.f3458a;
                this.f2357n = c1598a.f3459b;
                this.f2358o = m2601a(str, this.f2353j);
                this.f2359p = mo2134a(str);
                this.f2360q = m2603b(str);
                this.f2361r = m2606c(str);
                this.f2362s = m2608d(str);
                this.f2363t = m2604b(str, this.f2353j);
                elapsedRealtime = SystemClock.elapsedRealtime();
                C1412q.m2809a("createCodec:" + str);
                this.f2354k = MediaCodec.createByCodecName(str);
                C1412q.m2808a();
                C1412q.m2809a("configureCodec");
                mo2131a(this.f2354k, this.f2353j, mediaCrypto);
                C1412q.m2808a();
                C1412q.m2809a("startCodec");
                this.f2354k.start();
                C1412q.m2808a();
                elapsedRealtime2 = SystemClock.elapsedRealtime();
                mo2132a(str, elapsedRealtime2, elapsedRealtime2 - elapsedRealtime);
                this.f2366w = this.f2354k.getInputBuffers();
                this.f2367x = this.f2354k.getOutputBuffers();
                if (mo2104d() == 2) {
                }
                this.f2368y = mo2104d() == 2 ? -9223372036854775807L : SystemClock.elapsedRealtime() + 1000;
                this.f2369z = -1;
                this.f2335A = -1;
                c1346d = this.f2345a;
                c1346d.f2212a++;
            }
            if (c1598a == null) {
                m2599a(new DecoderInitializationException(this.f2353j, null, a, -49999));
            }
            str = c1598a.f3458a;
            this.f2357n = c1598a.f3459b;
            this.f2358o = m2601a(str, this.f2353j);
            this.f2359p = mo2134a(str);
            this.f2360q = m2603b(str);
            this.f2361r = m2606c(str);
            this.f2362s = m2608d(str);
            this.f2363t = m2604b(str, this.f2353j);
            try {
                elapsedRealtime = SystemClock.elapsedRealtime();
                C1412q.m2809a("createCodec:" + str);
                this.f2354k = MediaCodec.createByCodecName(str);
                C1412q.m2808a();
                C1412q.m2809a("configureCodec");
                mo2131a(this.f2354k, this.f2353j, mediaCrypto);
                C1412q.m2808a();
                C1412q.m2809a("startCodec");
                this.f2354k.start();
                C1412q.m2808a();
                elapsedRealtime2 = SystemClock.elapsedRealtime();
                mo2132a(str, elapsedRealtime2, elapsedRealtime2 - elapsedRealtime);
                this.f2366w = this.f2354k.getInputBuffers();
                this.f2367x = this.f2354k.getOutputBuffers();
            } catch (Throwable e3) {
                m2599a(new DecoderInitializationException(this.f2353j, e3, a, str));
            }
            if (mo2104d() == 2) {
            }
            this.f2368y = mo2104d() == 2 ? -9223372036854775807L : SystemClock.elapsedRealtime() + 1000;
            this.f2369z = -1;
            this.f2335A = -1;
            c1346d = this.f2345a;
            c1346d.f2212a++;
        }
    }

    private void m2599a(DecoderInitializationException decoderInitializationException) {
        throw ExoPlaybackException.m2399a(decoderInitializationException, m2509p());
    }

    protected boolean mo2155x() {
        return this.f2354k == null && this.f2353j != null;
    }

    protected void mo2122a(boolean z) {
        this.f2345a = new C1346d();
    }

    protected void mo2121a(long j, boolean z) {
        this.f2342H = false;
        this.f2343I = false;
        if (this.f2354k != null) {
            m2636z();
        }
    }

    protected void mo2125o() {
        this.f2353j = null;
        try {
            m2635y();
            try {
                if (this.f2355l != null) {
                    this.f2347d.m2945a(this.f2355l);
                }
                try {
                    if (!(this.f2356m == null || this.f2356m == this.f2355l)) {
                        this.f2347d.m2945a(this.f2356m);
                    }
                    this.f2355l = null;
                    this.f2356m = null;
                } catch (Throwable th) {
                    this.f2355l = null;
                    this.f2356m = null;
                }
            } catch (Throwable th2) {
                this.f2355l = null;
                this.f2356m = null;
            }
        } catch (Throwable th3) {
            this.f2355l = null;
            this.f2356m = null;
        }
    }

    protected void m2635y() {
        if (this.f2354k != null) {
            this.f2368y = -9223372036854775807L;
            this.f2369z = -1;
            this.f2335A = -1;
            this.f2344J = false;
            this.f2336B = false;
            this.f2351h.clear();
            this.f2366w = null;
            this.f2367x = null;
            this.f2337C = false;
            this.f2340F = false;
            this.f2357n = false;
            this.f2358o = false;
            this.f2359p = false;
            this.f2360q = false;
            this.f2361r = false;
            this.f2362s = false;
            this.f2363t = false;
            this.f2364u = false;
            this.f2365v = false;
            this.f2341G = false;
            this.f2338D = 0;
            this.f2339E = 0;
            C1346d c1346d = this.f2345a;
            c1346d.f2213b++;
            try {
                this.f2354k.stop();
                try {
                    this.f2354k.release();
                    this.f2354k = null;
                    if (this.f2355l != null && this.f2356m != this.f2355l) {
                        try {
                            this.f2347d.m2945a(this.f2355l);
                        } finally {
                            this.f2355l = null;
                        }
                    }
                } catch (Throwable th) {
                    this.f2354k = null;
                    if (!(this.f2355l == null || this.f2356m == this.f2355l)) {
                        this.f2347d.m2945a(this.f2355l);
                    }
                } finally {
                    this.f2355l = null;
                }
            } catch (Throwable th2) {
                this.f2354k = null;
                if (!(this.f2355l == null || this.f2356m == this.f2355l)) {
                    try {
                        this.f2347d.m2945a(this.f2355l);
                    } finally {
                        this.f2355l = null;
                    }
                }
            } finally {
                this.f2355l = null;
            }
        }
    }

    protected void mo2123m() {
    }

    protected void mo2124n() {
    }

    public void mo2120a(long j, long j2) {
        if (this.f2353j == null) {
            mo2136t();
        }
        m2633w();
        if (this.f2354k != null) {
            C1412q.m2809a("drainAndFeed");
            do {
            } while (m2602b(j, j2));
            do {
            } while (mo2138v());
            C1412q.m2808a();
        } else if (this.f2353j != null) {
            m2495b(j);
        }
        this.f2345a.m2435a();
    }

    private void mo2136t() {
        if (m2485a(this.f2350g, null) == -5) {
            mo2135b(this.f2350g.f3419a);
        }
    }

    protected void m2636z() {
        this.f2368y = -9223372036854775807L;
        this.f2369z = -1;
        this.f2335A = -1;
        this.f2344J = false;
        this.f2336B = false;
        this.f2351h.clear();
        this.f2364u = false;
        this.f2365v = false;
        if (this.f2359p || (this.f2362s && this.f2341G)) {
            m2635y();
            m2633w();
        } else if (this.f2339E != 0) {
            m2635y();
            m2633w();
        } else {
            this.f2354k.flush();
            this.f2340F = false;
        }
        if (this.f2337C && this.f2353j != null) {
            this.f2338D = 1;
        }
    }

    private boolean mo2138v() {
        if (this.f2342H || this.f2339E == 2) {
            return false;
        }
        if (this.f2369z < 0) {
            this.f2369z = this.f2354k.dequeueInputBuffer(0);
            if (this.f2369z < 0) {
                return false;
            }
            this.f2349f.f2220b = this.f2366w[this.f2369z];
            this.f2349f.mo2090a();
        }
        if (this.f2339E == 1) {
            if (!this.f2361r) {
                this.f2341G = true;
                this.f2354k.queueInputBuffer(this.f2369z, 0, 0, 0, 4);
                this.f2369z = -1;
            }
            this.f2339E = 2;
            return false;
        } else if (this.f2364u) {
            this.f2364u = false;
            this.f2349f.f2220b.put(f2334b);
            this.f2354k.queueInputBuffer(this.f2369z, 0, f2334b.length, 0, 0);
            this.f2369z = -1;
            this.f2340F = true;
            return true;
        } else {
            int i;
            int i2;
            if (this.f2344J) {
                i = -4;
                i2 = 0;
            } else {
                if (this.f2338D == 1) {
                    for (i = 0; i < this.f2353j.f2185g.size(); i++) {
                        this.f2349f.f2220b.put((byte[]) this.f2353j.f2185g.get(i));
                    }
                    this.f2338D = 2;
                }
                i2 = this.f2349f.f2220b.position();
                i = m2485a(this.f2350g, this.f2349f);
            }
            if (i == -3) {
                return false;
            }
            if (i == -5) {
                if (this.f2338D == 2) {
                    this.f2349f.mo2090a();
                    this.f2338D = 1;
                }
                mo2135b(this.f2350g.f3419a);
                return true;
            } else if (this.f2349f.m2424c()) {
                if (this.f2338D == 2) {
                    this.f2349f.mo2090a();
                    this.f2338D = 1;
                }
                this.f2342H = true;
                if (this.f2340F) {
                    try {
                        if (this.f2361r) {
                            return false;
                        }
                        this.f2341G = true;
                        this.f2354k.queueInputBuffer(this.f2369z, 0, 0, 0, 4);
                        this.f2369z = -1;
                        return false;
                    } catch (Exception e) {
                        throw ExoPlaybackException.m2399a(e, m2509p());
                    }
                }
                m2597D();
                return false;
            } else {
                boolean d = this.f2349f.m2438d();
                this.f2344J = m2605b(d);
                if (this.f2344J) {
                    return false;
                }
                if (this.f2358o && !d) {
                    C1401i.m2739a(this.f2349f.f2220b);
                    if (this.f2349f.f2220b.position() == 0) {
                        return true;
                    }
                    this.f2358o = false;
                }
                try {
                    long j = this.f2349f.f2221c;
                    if (this.f2349f.b_()) {
                        this.f2351h.add(Long.valueOf(j));
                    }
                    this.f2349f.m2439e();
                    m2619a(this.f2349f);
                    if (d) {
                        this.f2354k.queueSecureInputBuffer(this.f2369z, 0, m2598a(this.f2349f, i2), j, 0);
                    } else {
                        this.f2354k.queueInputBuffer(this.f2369z, 0, this.f2349f.f2220b.limit(), j, 0);
                    }
                    this.f2369z = -1;
                    this.f2340F = true;
                    this.f2338D = 0;
                    C1346d c1346d = this.f2345a;
                    c1346d.f2214c++;
                    return true;
                } catch (Exception e2) {
                    throw ExoPlaybackException.m2399a(e2, m2509p());
                }
            }
        }
    }

    private static CryptoInfo m2598a(C1347e c1347e, int i) {
        CryptoInfo a = c1347e.f2219a.m2428a();
        if (i != 0) {
            if (a.numBytesOfClearData == null) {
                a.numBytesOfClearData = new int[1];
            }
            int[] iArr = a.numBytesOfClearData;
            iArr[0] = iArr[0] + i;
        }
        return a;
    }

    private boolean m2605b(boolean z) {
        if (this.f2355l == null) {
            return false;
        }
        int a = this.f2355l.m2940a();
        if (a == 0) {
            throw ExoPlaybackException.m2399a(this.f2355l.m2943c(), m2509p());
        } else if (a == 4) {
            return false;
        } else {
            if (z || !this.f2348e) {
                return true;
            }
            return false;
        }
    }

    protected void mo2132a(String str, long j, long j2) {
    }

    protected void mo2135b(Format format) {
        Format format2 = this.f2353j;
        this.f2353j = format;
        if (!C1414r.m2823a(this.f2353j.f2186h, format2 == null ? null : format2.f2186h)) {
            if (this.f2353j.f2186h == null) {
                this.f2356m = null;
            } else if (this.f2347d == null) {
                throw ExoPlaybackException.m2399a(new IllegalStateException("Media requires a DrmSessionManager"), m2509p());
            } else {
                this.f2356m = this.f2347d.m2944a(Looper.myLooper(), this.f2353j.f2186h);
                if (this.f2356m == this.f2355l) {
                    this.f2347d.m2945a(this.f2356m);
                }
            }
        }
        if (this.f2356m == this.f2355l && this.f2354k != null && mo2154a(this.f2354k, this.f2357n, format2, this.f2353j)) {
            boolean z;
            this.f2337C = true;
            this.f2338D = 1;
            if (this.f2360q && this.f2353j.f2187i == format2.f2187i && this.f2353j.f2188j == format2.f2188j) {
                z = true;
            } else {
                z = false;
            }
            this.f2364u = z;
        } else if (this.f2340F) {
            this.f2339E = 1;
        } else {
            m2635y();
            m2633w();
        }
    }

    protected void mo2130a(MediaCodec mediaCodec, MediaFormat mediaFormat) {
    }

    protected void mo2137u() {
    }

    protected void m2619a(C1347e c1347e) {
    }

    protected void m2625c(long j) {
    }

    protected boolean mo2154a(MediaCodec mediaCodec, boolean z, Format format, Format format2) {
        return false;
    }

    public boolean mo2127s() {
        return this.f2343I;
    }

    public boolean mo2126r() {
        return (this.f2353j == null || this.f2344J || (!m2510q() && this.f2335A < 0 && (this.f2368y == -9223372036854775807L || SystemClock.elapsedRealtime() >= this.f2368y))) ? false : true;
    }

    protected long m2611A() {
        return 0;
    }

    private boolean m2602b(long j, long j2) {
        if (this.f2343I) {
            return false;
        }
        if (this.f2335A < 0) {
            this.f2335A = this.f2354k.dequeueOutputBuffer(this.f2352i, m2611A());
            if (this.f2335A >= 0) {
                if (this.f2365v) {
                    this.f2365v = false;
                    this.f2354k.releaseOutputBuffer(this.f2335A, false);
                    this.f2335A = -1;
                    return true;
                } else if ((this.f2352i.flags & 4) != 0) {
                    m2597D();
                    this.f2335A = -1;
                    return true;
                } else {
                    ByteBuffer byteBuffer = this.f2367x[this.f2335A];
                    if (byteBuffer != null) {
                        byteBuffer.position(this.f2352i.offset);
                        byteBuffer.limit(this.f2352i.offset + this.f2352i.size);
                    }
                    this.f2336B = m2607d(this.f2352i.presentationTimeUs);
                }
            } else if (this.f2335A == -2) {
                m2595B();
                return true;
            } else if (this.f2335A == -3) {
                m2596C();
                return true;
            } else if (!this.f2361r || (!this.f2342H && this.f2339E != 2)) {
                return false;
            } else {
                m2597D();
                return true;
            }
        }
        if (!mo2133a(j, j2, this.f2354k, this.f2367x[this.f2335A], this.f2335A, this.f2352i.flags, this.f2352i.presentationTimeUs, this.f2336B)) {
            return false;
        }
        m2625c(this.f2352i.presentationTimeUs);
        this.f2335A = -1;
        return true;
    }

    private void m2595B() {
        MediaFormat outputFormat = this.f2354k.getOutputFormat();
        if (this.f2360q && outputFormat.getInteger(VastIconXmlManager.WIDTH) == 32 && outputFormat.getInteger(VastIconXmlManager.HEIGHT) == 32) {
            this.f2365v = true;
            return;
        }
        if (this.f2363t) {
            outputFormat.setInteger("channel-count", 1);
        }
        mo2130a(this.f2354k, outputFormat);
    }

    private void m2596C() {
        this.f2367x = this.f2354k.getOutputBuffers();
    }

    private void m2597D() {
        if (this.f2339E == 2) {
            m2635y();
            m2633w();
            return;
        }
        this.f2343I = true;
        mo2137u();
    }

    private boolean m2607d(long j) {
        int size = this.f2351h.size();
        for (int i = 0; i < size; i++) {
            if (((Long) this.f2351h.get(i)).longValue() == j) {
                this.f2351h.remove(i);
                return true;
            }
        }
        return false;
    }

    private static boolean mo2134a(String str) {
        return C1414r.f2503a < 18 || ((C1414r.f2503a == 18 && ("OMX.SEC.avc.dec".equals(str) || "OMX.SEC.avc.dec.secure".equals(str))) || (C1414r.f2503a == 19 && C1414r.f2506d.startsWith("SM-G800") && ("OMX.Exynos.avc.dec".equals(str) || "OMX.Exynos.avc.dec.secure".equals(str))));
    }

    private static boolean m2603b(String str) {
        return C1414r.f2503a < 24 && (("OMX.Nvidia.h264.decode".equals(str) || "OMX.Nvidia.h264.decode.secure".equals(str)) && ("flounder".equals(C1414r.f2504b) || "flounder_lte".equals(C1414r.f2504b) || "grouper".equals(C1414r.f2504b) || "tilapia".equals(C1414r.f2504b)));
    }

    private static boolean m2601a(String str, Format format) {
        return C1414r.f2503a < 21 && format.f2185g.isEmpty() && "OMX.MTK.VIDEO.DECODER.AVC".equals(str);
    }

    private static boolean m2606c(String str) {
        return C1414r.f2503a <= 17 && ("OMX.rk.video_decoder.avc".equals(str) || "OMX.allwinner.video.decoder.avc".equals(str));
    }

    private static boolean m2608d(String str) {
        return C1414r.f2503a <= 23 && "OMX.google.vorbis.decoder".equals(str);
    }

    private static boolean m2604b(String str, Format format) {
        if (C1414r.f2503a <= 18 && format.f2194p == 1 && "OMX.MTK.AUDIO.DECODER.MP3".equals(str)) {
            return true;
        }
        return false;
    }
}
