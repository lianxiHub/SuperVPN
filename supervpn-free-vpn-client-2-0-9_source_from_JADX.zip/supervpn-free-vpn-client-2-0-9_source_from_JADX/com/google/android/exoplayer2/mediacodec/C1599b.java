package com.google.android.exoplayer2.mediacodec;

public interface C1599b {
    public static final C1599b f3462a = new C16001();

    static class C16001 implements C1599b {
        C16001() {
        }

        public C1598a mo2256a(String str, boolean z) {
            return MediaCodecUtil.m3733a(str, z);
        }

        public C1598a mo2255a() {
            return MediaCodecUtil.m3732a();
        }
    }

    C1598a mo2255a();

    C1598a mo2256a(String str, boolean z);
}
