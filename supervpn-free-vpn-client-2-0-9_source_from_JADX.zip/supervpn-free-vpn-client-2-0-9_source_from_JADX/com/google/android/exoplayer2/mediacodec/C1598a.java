package com.google.android.exoplayer2.mediacodec;

import android.annotation.TargetApi;
import android.media.MediaCodecInfo.AudioCapabilities;
import android.media.MediaCodecInfo.CodecCapabilities;
import android.media.MediaCodecInfo.CodecProfileLevel;
import android.media.MediaCodecInfo.VideoCapabilities;
import android.util.Pair;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1398h;
import com.google.android.exoplayer2.p031c.C1414r;

@TargetApi(16)
public final class C1598a {
    public final String f3458a;
    public final boolean f3459b;
    private final String f3460c;
    private final CodecCapabilities f3461d;

    public static C1598a m3739a(String str) {
        return new C1598a(str, null, null);
    }

    public static C1598a m3740a(String str, String str2, CodecCapabilities codecCapabilities) {
        return new C1598a(str, str2, codecCapabilities);
    }

    private C1598a(String str, String str2, CodecCapabilities codecCapabilities) {
        this.f3458a = (String) C1392a.m2707a((Object) str);
        this.f3460c = str2;
        this.f3461d = codecCapabilities;
        boolean z = codecCapabilities != null && C1598a.m3741a(codecCapabilities);
        this.f3459b = z;
    }

    public CodecProfileLevel[] m3746a() {
        return (this.f3461d == null || this.f3461d.profileLevels == null) ? new CodecProfileLevel[0] : this.f3461d.profileLevels;
    }

    public boolean m3748b(String str) {
        if (str == null || this.f3460c == null) {
            return true;
        }
        String d = C1398h.m2733d(str);
        if (d == null) {
            return true;
        }
        if (!this.f3460c.equals(d)) {
            return false;
        }
        Pair a = MediaCodecUtil.m3730a(str);
        if (a == null) {
            return true;
        }
        for (CodecProfileLevel codecProfileLevel : m3746a()) {
            if (codecProfileLevel.profile == ((Integer) a.first).intValue() && codecProfileLevel.level >= ((Integer) a.second).intValue()) {
                return true;
            }
        }
        return false;
    }

    @TargetApi(21)
    public boolean m3744a(int i, int i2) {
        if (this.f3461d == null) {
            return false;
        }
        VideoCapabilities videoCapabilities = this.f3461d.getVideoCapabilities();
        if (videoCapabilities == null || !videoCapabilities.isSizeSupported(i, i2)) {
            return false;
        }
        return true;
    }

    @TargetApi(21)
    public boolean m3745a(int i, int i2, double d) {
        if (this.f3461d == null) {
            return false;
        }
        VideoCapabilities videoCapabilities = this.f3461d.getVideoCapabilities();
        if (videoCapabilities == null || !videoCapabilities.areSizeAndRateSupported(i, i2, d)) {
            return false;
        }
        return true;
    }

    @TargetApi(21)
    public boolean m3743a(int i) {
        if (this.f3461d == null) {
            return false;
        }
        AudioCapabilities audioCapabilities = this.f3461d.getAudioCapabilities();
        if (audioCapabilities == null || !audioCapabilities.isSampleRateSupported(i)) {
            return false;
        }
        return true;
    }

    @TargetApi(21)
    public boolean m3747b(int i) {
        if (this.f3461d == null) {
            return false;
        }
        AudioCapabilities audioCapabilities = this.f3461d.getAudioCapabilities();
        if (audioCapabilities == null || audioCapabilities.getMaxInputChannelCount() < i) {
            return false;
        }
        return true;
    }

    private static boolean m3741a(CodecCapabilities codecCapabilities) {
        return C1414r.f2503a >= 19 && C1598a.m3742b(codecCapabilities);
    }

    @TargetApi(19)
    private static boolean m3742b(CodecCapabilities codecCapabilities) {
        return codecCapabilities.isFeatureSupported("adaptive-playback");
    }
}
