package com.google.android.exoplayer2.ui;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.CaptioningManager;
import com.google.android.exoplayer2.p031c.C1414r;
import com.google.android.exoplayer2.text.C1639a;
import com.google.android.exoplayer2.text.C1643b;
import com.google.android.exoplayer2.text.C1670j.C1590a;
import com.mopub.volley.DefaultRetryPolicy;
import java.util.ArrayList;
import java.util.List;

public final class SubtitleView extends View implements C1590a {
    private final List f3771a;
    private List f3772b;
    private int f3773c;
    private float f3774d;
    private boolean f3775e;
    private C1639a f3776f;
    private float f3777g;

    public SubtitleView(Context context) {
        this(context, null);
    }

    public SubtitleView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f3771a = new ArrayList();
        this.f3773c = 0;
        this.f3774d = 0.0533f;
        this.f3775e = true;
        this.f3776f = C1639a.f3596a;
        this.f3777g = 0.08f;
    }

    public void mo2245a(List list) {
        m4184b(list);
    }

    public void m4184b(List list) {
        if (this.f3772b != list) {
            this.f3772b = list;
            int size = list == null ? 0 : list.size();
            while (this.f3771a.size() < size) {
                this.f3771a.add(new C1677a(getContext()));
            }
            invalidate();
        }
    }

    public void m4178a() {
        m4179a((C1414r.f2503a >= 19 ? m4176c() : DefaultRetryPolicy.DEFAULT_BACKOFF_MULT) * 0.0533f);
    }

    public void m4179a(float f) {
        m4180a(f, false);
    }

    public void m4180a(float f, boolean z) {
        m4175a(z ? 1 : 0, f);
    }

    private void m4175a(int i, float f) {
        if (this.f3773c != i || this.f3774d != f) {
            this.f3773c = i;
            this.f3774d = f;
            invalidate();
        }
    }

    public void m4183b() {
        m4181a(C1414r.f2503a >= 19 ? m4177d() : C1639a.f3596a);
    }

    public void m4181a(C1639a c1639a) {
        if (this.f3776f != c1639a) {
            this.f3776f = c1639a;
            invalidate();
        }
    }

    public void dispatchDraw(Canvas canvas) {
        int i;
        if (this.f3772b == null) {
            i = 0;
        } else {
            i = this.f3772b.size();
        }
        int top = getTop();
        int bottom = getBottom();
        int left = getLeft() + getPaddingLeft();
        int paddingTop = top + getPaddingTop();
        int right = getRight() + getPaddingRight();
        int paddingBottom = bottom - getPaddingBottom();
        if (paddingBottom > paddingTop && right > left) {
            float f;
            if (this.f3773c == 2) {
                f = this.f3774d;
            } else {
                f = this.f3774d * ((float) (this.f3773c == 0 ? paddingBottom - paddingTop : bottom - top));
            }
            if (f > 0.0f) {
                for (int i2 = 0; i2 < i; i2++) {
                    ((C1677a) this.f3771a.get(i2)).m4187a((C1643b) this.f3772b.get(i2), this.f3775e, this.f3776f, f, this.f3777g, canvas, left, paddingTop, right, paddingBottom);
                }
            }
        }
    }

    @TargetApi(19)
    private float m4176c() {
        return ((CaptioningManager) getContext().getSystemService("captioning")).getFontScale();
    }

    @TargetApi(19)
    private C1639a m4177d() {
        return C1639a.m3938a(((CaptioningManager) getContext().getSystemService("captioning")).getUserStyle());
    }
}
