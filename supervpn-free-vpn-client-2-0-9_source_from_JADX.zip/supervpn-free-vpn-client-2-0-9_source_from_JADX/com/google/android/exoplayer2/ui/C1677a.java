package com.google.android.exoplayer2.ui;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Join;
import android.graphics.Paint.Style;
import android.graphics.RectF;
import android.text.Layout.Alignment;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.exoplayer2.p031c.C1414r;
import com.google.android.exoplayer2.text.C1639a;
import com.google.android.exoplayer2.text.C1643b;
import com.mopub.volley.DefaultRetryPolicy;

final class C1677a {
    private int f3778A;
    private int f3779B;
    private int f3780C;
    private StaticLayout f3781D;
    private int f3782E;
    private int f3783F;
    private int f3784G;
    private final RectF f3785a = new RectF();
    private final float f3786b;
    private final float f3787c;
    private final float f3788d;
    private final float f3789e;
    private final float f3790f;
    private final float f3791g;
    private final TextPaint f3792h;
    private final Paint f3793i;
    private CharSequence f3794j;
    private Alignment f3795k;
    private float f3796l;
    private int f3797m;
    private int f3798n;
    private float f3799o;
    private int f3800p;
    private float f3801q;
    private boolean f3802r;
    private int f3803s;
    private int f3804t;
    private int f3805u;
    private int f3806v;
    private int f3807w;
    private float f3808x;
    private float f3809y;
    private int f3810z;

    public C1677a(Context context) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(null, new int[]{16843287, 16843288}, 0, 0);
        this.f3791g = (float) obtainStyledAttributes.getDimensionPixelSize(0, 0);
        this.f3790f = obtainStyledAttributes.getFloat(1, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        obtainStyledAttributes.recycle();
        int round = Math.round((((float) context.getResources().getDisplayMetrics().densityDpi) * 2.0f) / 160.0f);
        this.f3786b = (float) round;
        this.f3787c = (float) round;
        this.f3788d = (float) round;
        this.f3789e = (float) round;
        this.f3792h = new TextPaint();
        this.f3792h.setAntiAlias(true);
        this.f3792h.setSubpixelText(true);
        this.f3793i = new Paint();
        this.f3793i.setAntiAlias(true);
        this.f3793i.setStyle(Style.FILL);
    }

    public void m4187a(C1643b c1643b, boolean z, C1639a c1639a, float f, float f2, Canvas canvas, int i, int i2, int i3, int i4) {
        CharSequence charSequence = c1643b.f3609a;
        if (!TextUtils.isEmpty(charSequence)) {
            if (!z) {
                charSequence = charSequence.toString();
            }
            if (C1677a.m4186a(this.f3794j, charSequence) && C1414r.m2823a(this.f3795k, c1643b.f3610b) && this.f3796l == c1643b.f3611c && this.f3797m == c1643b.f3612d && C1414r.m2823a(Integer.valueOf(this.f3798n), Integer.valueOf(c1643b.f3613e)) && this.f3799o == c1643b.f3614f && C1414r.m2823a(Integer.valueOf(this.f3800p), Integer.valueOf(c1643b.f3615g)) && this.f3801q == c1643b.f3616h && this.f3802r == z && this.f3803s == c1639a.f3597b && this.f3804t == c1639a.f3598c && this.f3805u == c1639a.f3599d && this.f3807w == c1639a.f3600e && this.f3806v == c1639a.f3601f && C1414r.m2823a(this.f3792h.getTypeface(), c1639a.f3602g) && this.f3808x == f && this.f3809y == f2 && this.f3810z == i && this.f3778A == i2 && this.f3779B == i3 && this.f3780C == i4) {
                m4185a(canvas);
                return;
            }
            this.f3794j = charSequence;
            this.f3795k = c1643b.f3610b;
            this.f3796l = c1643b.f3611c;
            this.f3797m = c1643b.f3612d;
            this.f3798n = c1643b.f3613e;
            this.f3799o = c1643b.f3614f;
            this.f3800p = c1643b.f3615g;
            this.f3801q = c1643b.f3616h;
            this.f3802r = z;
            this.f3803s = c1639a.f3597b;
            this.f3804t = c1639a.f3598c;
            this.f3805u = c1639a.f3599d;
            this.f3807w = c1639a.f3600e;
            this.f3806v = c1639a.f3601f;
            this.f3792h.setTypeface(c1639a.f3602g);
            this.f3808x = f;
            this.f3809y = f2;
            this.f3810z = i;
            this.f3778A = i2;
            this.f3779B = i3;
            this.f3780C = i4;
            int i5 = this.f3779B - this.f3810z;
            int i6 = this.f3780C - this.f3778A;
            this.f3792h.setTextSize(f);
            int i7 = (int) ((0.125f * f) + 0.5f);
            int i8 = i5 - (i7 * 2);
            if (this.f3801q != Float.MIN_VALUE) {
                i8 = (int) (((float) i8) * this.f3801q);
            }
            if (i8 <= 0) {
                Log.w("SubtitlePainter", "Skipped drawing subtitle cue (insufficient space)");
                return;
            }
            Alignment alignment = this.f3795k == null ? Alignment.ALIGN_CENTER : this.f3795k;
            this.f3781D = new StaticLayout(charSequence, this.f3792h, i8, alignment, this.f3790f, this.f3791g, true);
            int height = this.f3781D.getHeight();
            int lineCount = this.f3781D.getLineCount();
            int i9 = 0;
            int i10 = 0;
            while (i10 < lineCount) {
                int max = Math.max((int) Math.ceil((double) this.f3781D.getLineWidth(i10)), i9);
                i10++;
                i9 = max;
            }
            if (this.f3801q == Float.MIN_VALUE || i9 >= i8) {
                i8 = i9;
            }
            i8 += i7 * 2;
            if (this.f3799o != Float.MIN_VALUE) {
                i9 = Math.round(((float) i5) * this.f3799o) + this.f3810z;
                if (this.f3800p == 2) {
                    i9 -= i8;
                } else if (this.f3800p == 1) {
                    i9 = ((i9 * 2) - i8) / 2;
                }
                i10 = Math.max(i9, this.f3810z);
                i9 = Math.min(i10 + i8, this.f3779B);
                i5 = i10;
            } else {
                i10 = (i5 - i8) / 2;
                i9 = i10 + i8;
                i5 = i10;
            }
            if (this.f3796l != Float.MIN_VALUE) {
                if (this.f3797m == 0) {
                    i10 = Math.round(((float) i6) * this.f3796l) + this.f3778A;
                } else {
                    i10 = this.f3781D.getLineBottom(0) - this.f3781D.getLineTop(0);
                    if (this.f3796l >= 0.0f) {
                        i10 = Math.round(((float) i10) * this.f3796l) + this.f3778A;
                    } else {
                        i10 = Math.round(((float) i10) * this.f3796l) + this.f3780C;
                    }
                }
                if (this.f3798n == 2) {
                    i10 -= height;
                } else if (this.f3798n == 1) {
                    i10 = ((i10 * 2) - height) / 2;
                }
                if (i10 + height > this.f3780C) {
                    i10 = this.f3780C - height;
                } else if (i10 < this.f3778A) {
                    i10 = this.f3778A;
                }
                i6 = i10;
            } else {
                i6 = (this.f3780C - height) - ((int) (((float) i6) * f2));
            }
            this.f3781D = new StaticLayout(charSequence, this.f3792h, i9 - i5, alignment, this.f3790f, this.f3791g, true);
            this.f3782E = i5;
            this.f3783F = i6;
            this.f3784G = i7;
            m4185a(canvas);
        }
    }

    private void m4185a(Canvas canvas) {
        StaticLayout staticLayout = this.f3781D;
        if (staticLayout != null) {
            int lineCount;
            int i;
            int save = canvas.save();
            canvas.translate((float) this.f3782E, (float) this.f3783F);
            if (Color.alpha(this.f3805u) > 0) {
                this.f3793i.setColor(this.f3805u);
                canvas.drawRect((float) (-this.f3784G), 0.0f, (float) (staticLayout.getWidth() + this.f3784G), (float) staticLayout.getHeight(), this.f3793i);
            }
            if (Color.alpha(this.f3804t) > 0) {
                this.f3793i.setColor(this.f3804t);
                float lineTop = (float) staticLayout.getLineTop(0);
                lineCount = staticLayout.getLineCount();
                float f = lineTop;
                for (i = 0; i < lineCount; i++) {
                    this.f3785a.left = staticLayout.getLineLeft(i) - ((float) this.f3784G);
                    this.f3785a.right = staticLayout.getLineRight(i) + ((float) this.f3784G);
                    this.f3785a.top = f;
                    this.f3785a.bottom = (float) staticLayout.getLineBottom(i);
                    f = this.f3785a.bottom;
                    canvas.drawRoundRect(this.f3785a, this.f3786b, this.f3786b, this.f3793i);
                }
            }
            if (this.f3807w == 1) {
                this.f3792h.setStrokeJoin(Join.ROUND);
                this.f3792h.setStrokeWidth(this.f3787c);
                this.f3792h.setColor(this.f3806v);
                this.f3792h.setStyle(Style.FILL_AND_STROKE);
                staticLayout.draw(canvas);
            } else if (this.f3807w == 2) {
                this.f3792h.setShadowLayer(this.f3788d, this.f3789e, this.f3789e, this.f3806v);
            } else if (this.f3807w == 3 || this.f3807w == 4) {
                lineCount = this.f3807w == 3 ? 1 : 0;
                int i2 = lineCount != 0 ? -1 : this.f3806v;
                if (lineCount != 0) {
                    i = this.f3806v;
                } else {
                    i = -1;
                }
                float f2 = this.f3788d / 2.0f;
                this.f3792h.setColor(this.f3803s);
                this.f3792h.setStyle(Style.FILL);
                this.f3792h.setShadowLayer(this.f3788d, -f2, -f2, i2);
                staticLayout.draw(canvas);
                this.f3792h.setShadowLayer(this.f3788d, f2, f2, i);
            }
            this.f3792h.setColor(this.f3803s);
            this.f3792h.setStyle(Style.FILL);
            staticLayout.draw(canvas);
            this.f3792h.setShadowLayer(0.0f, 0.0f, 0.0f, 0);
            canvas.restoreToCount(save);
        }
    }

    private static boolean m4186a(CharSequence charSequence, CharSequence charSequence2) {
        return charSequence == charSequence2 || (charSequence != null && charSequence.equals(charSequence2));
    }
}
