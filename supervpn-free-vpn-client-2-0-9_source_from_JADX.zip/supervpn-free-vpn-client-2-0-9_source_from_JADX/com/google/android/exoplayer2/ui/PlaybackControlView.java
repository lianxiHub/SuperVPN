package com.google.android.exoplayer2.ui;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import com.google.android.exoplayer2.C1434d;
import com.google.android.exoplayer2.C1434d.C0507a;
import com.google.android.exoplayer2.C1587j.C1582a;
import com.google.android.exoplayer2.C1587j.C1583b;
import com.google.android.exoplayer2.C1587j.C1584c;
import com.google.android.exoplayer2.C1587j.C1585d;
import com.google.android.exoplayer2.C1587j.C1586e;
import com.google.android.exoplayer2.C1613n;
import com.google.android.exoplayer2.C1613n.C1612b;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.p031c.C1414r;
import com.mopub.volley.DefaultRetryPolicy;
import java.util.Formatter;
import java.util.Locale;

public class PlaybackControlView extends FrameLayout {
    private final C1673a f3740a;
    private final View f3741b;
    private final View f3742c;
    private final ImageButton f3743d;
    private final TextView f3744e;
    private final TextView f3745f;
    private final SeekBar f3746g;
    private final View f3747h;
    private final View f3748i;
    private final StringBuilder f3749j;
    private final Formatter f3750k;
    private final C1612b f3751l;
    private C1434d f3752m;
    private C1674b f3753n;
    private boolean f3754o;
    private int f3755p;
    private int f3756q;
    private int f3757r;
    private long f3758s;
    private final Runnable f3759t;
    private final Runnable f3760u;

    class C16711 implements Runnable {
        final /* synthetic */ PlaybackControlView f3737a;

        C16711(PlaybackControlView playbackControlView) {
            this.f3737a = playbackControlView;
        }

        public void run() {
            this.f3737a.m4149i();
        }
    }

    class C16722 implements Runnable {
        final /* synthetic */ PlaybackControlView f3738a;

        C16722(PlaybackControlView playbackControlView) {
            this.f3738a = playbackControlView;
        }

        public void run() {
            this.f3738a.m4166c();
        }
    }

    private final class C1673a implements OnClickListener, OnSeekBarChangeListener, C0507a {
        final /* synthetic */ PlaybackControlView f3739a;

        private C1673a(PlaybackControlView playbackControlView) {
            this.f3739a = playbackControlView;
        }

        public void onStartTrackingTouch(SeekBar seekBar) {
            this.f3739a.removeCallbacks(this.f3739a.f3760u);
            this.f3739a.f3754o = true;
        }

        public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
            if (z) {
                this.f3739a.f3745f.setText(this.f3739a.m4131a(this.f3739a.m4139d(i)));
            }
        }

        public void onStopTrackingTouch(SeekBar seekBar) {
            this.f3739a.f3754o = false;
            this.f3739a.f3752m.mo2216a(this.f3739a.m4139d(seekBar.getProgress()));
            this.f3739a.m4141e();
        }

        public void onPlayerStateChanged(boolean z, int i) {
            this.f3739a.m4145g();
            this.f3739a.m4149i();
        }

        public void onPositionDiscontinuity() {
            this.f3739a.m4148h();
            this.f3739a.m4149i();
        }

        public void onTimelineChanged(C1613n c1613n, Object obj) {
            this.f3739a.m4148h();
            this.f3739a.m4149i();
        }

        public void onLoadingChanged(boolean z) {
        }

        public void onPlayerError(ExoPlaybackException exoPlaybackException) {
        }

        public void onClick(View view) {
            C1613n f = this.f3739a.f3752m.mo2226f();
            if (this.f3739a.f3742c == view) {
                this.f3739a.m4153k();
            } else if (this.f3739a.f3741b == view) {
                this.f3739a.m4152j();
            } else if (this.f3739a.f3747h == view) {
                this.f3739a.m4157m();
            } else if (this.f3739a.f3748i == view && f != null) {
                this.f3739a.m4156l();
            } else if (this.f3739a.f3743d == view) {
                this.f3739a.f3752m.mo2219a(!this.f3739a.f3752m.mo2222b());
            }
            this.f3739a.m4141e();
        }
    }

    public interface C1674b {
        void m4129a(int i);
    }

    public PlaybackControlView(Context context) {
        this(context, null);
    }

    public PlaybackControlView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public PlaybackControlView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3759t = new C16711(this);
        this.f3760u = new C16722(this);
        this.f3755p = 5000;
        this.f3756q = 15000;
        this.f3757r = 5000;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(attributeSet, C1586e.PlaybackControlView, 0, 0);
            try {
                this.f3755p = obtainStyledAttributes.getInt(C1586e.PlaybackControlView_rewind_increment, this.f3755p);
                this.f3756q = obtainStyledAttributes.getInt(C1586e.PlaybackControlView_fastforward_increment, this.f3756q);
                this.f3757r = obtainStyledAttributes.getInt(C1586e.PlaybackControlView_show_timeout, this.f3757r);
            } finally {
                obtainStyledAttributes.recycle();
            }
        }
        this.f3751l = new C1612b();
        this.f3749j = new StringBuilder();
        this.f3750k = new Formatter(this.f3749j, Locale.getDefault());
        this.f3740a = new C1673a();
        LayoutInflater.from(context).inflate(C1584c.exo_playback_control_view, this);
        this.f3744e = (TextView) findViewById(C1583b.time);
        this.f3745f = (TextView) findViewById(C1583b.time_current);
        this.f3746g = (SeekBar) findViewById(C1583b.mediacontroller_progress);
        this.f3746g.setOnSeekBarChangeListener(this.f3740a);
        this.f3746g.setMax(1000);
        this.f3743d = (ImageButton) findViewById(C1583b.play);
        this.f3743d.setOnClickListener(this.f3740a);
        this.f3741b = findViewById(C1583b.prev);
        this.f3741b.setOnClickListener(this.f3740a);
        this.f3742c = findViewById(C1583b.next);
        this.f3742c.setOnClickListener(this.f3740a);
        this.f3748i = findViewById(C1583b.rew);
        this.f3748i.setOnClickListener(this.f3740a);
        this.f3747h = findViewById(C1583b.ffwd);
        this.f3747h.setOnClickListener(this.f3740a);
    }

    public void m4163a(int i) {
        this.f3755p = i;
        m4148h();
    }

    public void m4165b(int i) {
        this.f3756q = i;
        m4148h();
    }

    public int m4162a() {
        return this.f3757r;
    }

    public void m4167c(int i) {
        this.f3757r = i;
    }

    public void m4164b() {
        if (!m4168d()) {
            setVisibility(0);
            if (this.f3753n != null) {
                this.f3753n.m4129a(getVisibility());
            }
            m4143f();
        }
        m4141e();
    }

    public void m4166c() {
        if (m4168d()) {
            setVisibility(8);
            if (this.f3753n != null) {
                this.f3753n.m4129a(getVisibility());
            }
            removeCallbacks(this.f3759t);
            removeCallbacks(this.f3760u);
            this.f3758s = -9223372036854775807L;
        }
    }

    public boolean m4168d() {
        return getVisibility() == 0;
    }

    private void m4141e() {
        removeCallbacks(this.f3760u);
        if (this.f3757r > 0) {
            this.f3758s = SystemClock.uptimeMillis() + ((long) this.f3757r);
            if (isAttachedToWindow()) {
                postDelayed(this.f3760u, (long) this.f3757r);
                return;
            }
            return;
        }
        this.f3758s = -9223372036854775807L;
    }

    private void m4143f() {
        m4145g();
        m4148h();
        m4149i();
    }

    private void m4145g() {
        if (m4168d() && isAttachedToWindow()) {
            Object obj = (this.f3752m == null || !this.f3752m.mo2222b()) ? null : 1;
            this.f3743d.setContentDescription(getResources().getString(obj != null ? C1585d.exo_controls_pause_description : C1585d.exo_controls_play_description));
            this.f3743d.setImageResource(obj != null ? C1582a.exo_controls_pause : C1582a.exo_controls_play);
        }
    }

    private void m4148h() {
        boolean z = true;
        if (m4168d() && isAttachedToWindow()) {
            boolean z2;
            boolean z3;
            boolean z4;
            C1613n f = this.f3752m != null ? this.f3752m.mo2226f() : null;
            if (f != null) {
                z2 = true;
            } else {
                z2 = false;
            }
            if (z2) {
                int g = this.f3752m.mo2227g();
                f.m3790a(g, this.f3751l);
                z3 = this.f3751l.f3494d;
                if (g > 0 || z3 || !this.f3751l.f3495e) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                if (g < f.mo2287a() - 1 || this.f3751l.f3495e) {
                    z4 = true;
                } else {
                    z4 = false;
                }
            } else {
                z4 = false;
                z2 = false;
                z3 = false;
            }
            m4134a(z2, this.f3741b);
            m4134a(z4, this.f3742c);
            if (this.f3756q <= 0 || !z3) {
                z2 = false;
            } else {
                z2 = true;
            }
            m4134a(z2, this.f3747h);
            if (this.f3755p <= 0 || !z3) {
                z = false;
            }
            m4134a(z, this.f3748i);
            this.f3746g.setEnabled(z3);
        }
    }

    private void m4149i() {
        long j = 0;
        if (m4168d() && isAttachedToWindow()) {
            long h = this.f3752m == null ? 0 : this.f3752m.mo2228h();
            long i = this.f3752m == null ? 0 : this.f3752m.mo2229i();
            this.f3744e.setText(m4131a(h));
            if (!this.f3754o) {
                this.f3745f.setText(m4131a(i));
            }
            if (!this.f3754o) {
                this.f3746g.setProgress(m4136b(i));
            }
            if (this.f3752m != null) {
                j = this.f3752m.mo2230j();
            }
            this.f3746g.setSecondaryProgress(m4136b(j));
            removeCallbacks(this.f3759t);
            int a = this.f3752m == null ? 1 : this.f3752m.mo2214a();
            if (a != 1 && a != 4) {
                if (this.f3752m.mo2222b() && a == 3) {
                    h = 1000 - (i % 1000);
                    if (h < 200) {
                        h += 1000;
                    }
                } else {
                    h = 1000;
                }
                postDelayed(this.f3759t, h);
            }
        }
    }

    private void m4134a(boolean z, View view) {
        view.setEnabled(z);
        if (C1414r.f2503a >= 11) {
            view.setAlpha(z ? DefaultRetryPolicy.DEFAULT_BACKOFF_MULT : 0.3f);
            view.setVisibility(0);
            return;
        }
        view.setVisibility(z ? 0 : 4);
    }

    private String m4131a(long j) {
        if (j == -9223372036854775807L) {
            j = 0;
        }
        long j2 = (500 + j) / 1000;
        long j3 = j2 % 60;
        long j4 = (j2 / 60) % 60;
        j2 /= 3600;
        this.f3749j.setLength(0);
        if (j2 > 0) {
            return this.f3750k.format("%d:%02d:%02d", new Object[]{Long.valueOf(j2), Long.valueOf(j4), Long.valueOf(j3)}).toString();
        }
        return this.f3750k.format("%02d:%02d", new Object[]{Long.valueOf(j4), Long.valueOf(j3)}).toString();
    }

    private int m4136b(long j) {
        long h = this.f3752m == null ? -9223372036854775807L : this.f3752m.mo2228h();
        return (h == -9223372036854775807L || h == 0) ? 0 : (int) ((1000 * j) / h);
    }

    private long m4139d(int i) {
        long h = this.f3752m == null ? -9223372036854775807L : this.f3752m.mo2228h();
        return h == -9223372036854775807L ? 0 : (h * ((long) i)) / 1000;
    }

    private void m4152j() {
        C1613n f = this.f3752m.mo2226f();
        if (f != null) {
            int g = this.f3752m.mo2227g();
            f.m3790a(g, this.f3751l);
            if (g <= 0 || (this.f3752m.mo2229i() > 3000 && (!this.f3751l.f3495e || this.f3751l.f3494d))) {
                this.f3752m.mo2216a(0);
            } else {
                this.f3752m.mo2215a(g - 1);
            }
        }
    }

    private void m4153k() {
        C1613n f = this.f3752m.mo2226f();
        if (f != null) {
            int g = this.f3752m.mo2227g();
            if (g < f.mo2287a() - 1) {
                this.f3752m.mo2215a(g + 1);
            } else if (f.mo2290a(g, this.f3751l, false).f3495e) {
                this.f3752m.mo2223c();
            }
        }
    }

    private void m4156l() {
        if (this.f3755p > 0) {
            this.f3752m.mo2216a(Math.max(this.f3752m.mo2229i() - ((long) this.f3755p), 0));
        }
    }

    private void m4157m() {
        if (this.f3756q > 0) {
            this.f3752m.mo2216a(Math.min(this.f3752m.mo2229i() + ((long) this.f3756q), this.f3752m.mo2228h()));
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.f3758s != -9223372036854775807L) {
            long uptimeMillis = this.f3758s - SystemClock.uptimeMillis();
            if (uptimeMillis <= 0) {
                m4166c();
            } else {
                postDelayed(this.f3760u, uptimeMillis);
            }
        }
        m4143f();
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.f3759t);
        removeCallbacks(this.f3760u);
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        boolean z = false;
        if (this.f3752m == null || keyEvent.getAction() != 0) {
            return super.dispatchKeyEvent(keyEvent);
        }
        switch (keyEvent.getKeyCode()) {
            case 21:
            case 89:
                m4156l();
                break;
            case 22:
            case 90:
                m4157m();
                break;
            case 85:
                C1434d c1434d = this.f3752m;
                if (!this.f3752m.mo2222b()) {
                    z = true;
                }
                c1434d.mo2219a(z);
                break;
            case 87:
                m4153k();
                break;
            case 88:
                m4152j();
                break;
            case 126:
                this.f3752m.mo2219a(true);
                break;
            case 127:
                this.f3752m.mo2219a(false);
                break;
            default:
                return false;
        }
        m4164b();
        return true;
    }
}
