package com.google.android.exoplayer2.ui;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View.MeasureSpec;
import android.widget.FrameLayout;
import com.google.android.exoplayer2.C1587j.C1586e;
import com.mopub.volley.DefaultRetryPolicy;

public final class AspectRatioFrameLayout extends FrameLayout {
    private float f3735a;
    private int f3736b;

    public AspectRatioFrameLayout(Context context) {
        this(context, null);
    }

    public AspectRatioFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f3736b = 0;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(attributeSet, C1586e.AspectRatioFrameLayout, 0, 0);
            try {
                this.f3736b = obtainStyledAttributes.getInt(C1586e.AspectRatioFrameLayout_resize_mode, 0);
            } finally {
                obtainStyledAttributes.recycle();
            }
        }
    }

    public void m4127a(float f) {
        if (this.f3735a != f) {
            this.f3735a = f;
            requestLayout();
        }
    }

    public void m4128a(int i) {
        if (this.f3736b != i) {
            this.f3736b = i;
            requestLayout();
        }
    }

    protected void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.f3735a != 0.0f) {
            int measuredWidth = getMeasuredWidth();
            int measuredHeight = getMeasuredHeight();
            float f = (this.f3735a / (((float) measuredWidth) / ((float) measuredHeight))) - DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;
            if (Math.abs(f) > 0.01f) {
                switch (this.f3736b) {
                    case 1:
                        measuredHeight = (int) (((float) measuredWidth) / this.f3735a);
                        break;
                    case 2:
                        measuredWidth = (int) (((float) measuredHeight) * this.f3735a);
                        break;
                    default:
                        if (f <= 0.0f) {
                            measuredWidth = (int) (((float) measuredHeight) * this.f3735a);
                            break;
                        } else {
                            measuredHeight = (int) (((float) measuredWidth) / this.f3735a);
                            break;
                        }
                }
                super.onMeasure(MeasureSpec.makeMeasureSpec(measuredWidth, 1073741824), MeasureSpec.makeMeasureSpec(measuredHeight, 1073741824));
            }
        }
    }
}
