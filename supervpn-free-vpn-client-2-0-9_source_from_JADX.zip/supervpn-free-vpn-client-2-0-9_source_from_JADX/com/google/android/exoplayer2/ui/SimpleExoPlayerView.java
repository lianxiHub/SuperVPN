package com.google.android.exoplayer2.ui;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import com.google.android.exoplayer2.C1434d.C0507a;
import com.google.android.exoplayer2.C1587j.C1583b;
import com.google.android.exoplayer2.C1587j.C1584c;
import com.google.android.exoplayer2.C1587j.C1586e;
import com.google.android.exoplayer2.C1592m;
import com.google.android.exoplayer2.C1592m.C0508b;
import com.google.android.exoplayer2.C1613n;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.text.C1670j.C1590a;
import com.mopub.volley.DefaultRetryPolicy;
import java.util.List;

@TargetApi(16)
public final class SimpleExoPlayerView extends FrameLayout {
    private final View f3762a;
    private final View f3763b;
    private final SubtitleView f3764c;
    private final AspectRatioFrameLayout f3765d;
    private final PlaybackControlView f3766e;
    private final C1676a f3767f;
    private C1592m f3768g;
    private boolean f3769h;
    private int f3770i;

    private final class C1676a implements C0507a, C0508b, C1590a {
        final /* synthetic */ SimpleExoPlayerView f3761a;

        private C1676a(SimpleExoPlayerView simpleExoPlayerView) {
            this.f3761a = simpleExoPlayerView;
        }

        public void mo2245a(List list) {
            this.f3761a.f3764c.mo2245a(list);
        }

        public void onVideoSizeChanged(int i, int i2, int i3, float f) {
            this.f3761a.f3765d.m4127a(i2 == 0 ? DefaultRetryPolicy.DEFAULT_BACKOFF_MULT : (((float) i) * f) / ((float) i2));
        }

        public void onRenderedFirstFrame() {
            this.f3761a.f3763b.setVisibility(8);
        }

        public void onVideoTracksDisabled() {
            this.f3761a.f3763b.setVisibility(0);
        }

        public void onLoadingChanged(boolean z) {
        }

        public void onPlayerStateChanged(boolean z, int i) {
            this.f3761a.m4172a(false);
        }

        public void onPlayerError(ExoPlaybackException exoPlaybackException) {
        }

        public void onPositionDiscontinuity() {
        }

        public void onTimelineChanged(C1613n c1613n, Object obj) {
        }
    }

    public SimpleExoPlayerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public SimpleExoPlayerView(Context context, AttributeSet attributeSet, int i) {
        int i2;
        int i3;
        int i4;
        int i5;
        super(context, attributeSet, i);
        this.f3769h = true;
        boolean z = false;
        int i6 = 15000;
        if (attributeSet != null) {
            Theme theme = context.getTheme();
            int[] iArr = C1586e.SimpleExoPlayerView;
            TypedArray obtainStyledAttributes = theme.obtainStyledAttributes(attributeSet, iArr, 0, 0);
            try {
                this.f3769h = obtainStyledAttributes.getBoolean(C1586e.SimpleExoPlayerView_use_controller, this.f3769h);
                i2 = obtainStyledAttributes.getBoolean(C1586e.SimpleExoPlayerView_use_texture_view, false);
                iArr = obtainStyledAttributes.getInt(C1586e.SimpleExoPlayerView_resize_mode, 0);
                z = obtainStyledAttributes.getInt(C1586e.SimpleExoPlayerView_rewind_increment, 5000);
                i6 = obtainStyledAttributes.getInt(C1586e.SimpleExoPlayerView_fastforward_increment, 15000);
                int i7 = obtainStyledAttributes.getInt(C1586e.SimpleExoPlayerView_show_timeout, 5000);
                i3 = i2;
                i2 = iArr;
                boolean z2 = z;
                i4 = i6;
                i6 = i7;
            } finally {
                obtainStyledAttributes.recycle();
            }
        } else {
            i4 = 15000;
            i5 = 5000;
            i2 = 0;
            i3 = 0;
            i6 = 5000;
        }
        LayoutInflater.from(context).inflate(C1584c.exo_simple_player_view, this);
        this.f3767f = new C1676a();
        this.f3765d = (AspectRatioFrameLayout) findViewById(C1583b.video_frame);
        this.f3765d.m4128a(i2);
        this.f3763b = findViewById(C1583b.shutter);
        this.f3764c = (SubtitleView) findViewById(C1583b.subtitles);
        this.f3764c.m4183b();
        this.f3764c.m4178a();
        this.f3766e = (PlaybackControlView) findViewById(C1583b.control);
        this.f3766e.m4166c();
        this.f3766e.m4163a(i5);
        this.f3766e.m4165b(i4);
        this.f3770i = i6;
        View textureView = i3 != 0 ? new TextureView(context) : new SurfaceView(context);
        textureView.setLayoutParams(new LayoutParams(-1, -1));
        this.f3762a = textureView;
        this.f3765d.addView(this.f3762a, 0);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (!this.f3769h || this.f3768g == null || motionEvent.getActionMasked() != 0) {
            return false;
        }
        if (this.f3766e.m4168d()) {
            this.f3766e.m4166c();
            return true;
        }
        m4172a(true);
        return true;
    }

    public boolean onTrackballEvent(MotionEvent motionEvent) {
        if (!this.f3769h || this.f3768g == null) {
            return false;
        }
        m4172a(true);
        return true;
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return this.f3769h ? this.f3766e.dispatchKeyEvent(keyEvent) : super.dispatchKeyEvent(keyEvent);
    }

    private void m4172a(boolean z) {
        int i = 1;
        int i2 = 0;
        if (this.f3769h && this.f3768g != null) {
            int a = this.f3768g.mo2214a();
            if (a == 1 || a == 4 || !this.f3768g.mo2222b()) {
                a = 1;
            } else {
                a = 0;
            }
            if (!this.f3766e.m4168d() || this.f3766e.m4162a() > 0) {
                i = 0;
            }
            PlaybackControlView playbackControlView = this.f3766e;
            if (a == 0) {
                i2 = this.f3770i;
            }
            playbackControlView.m4167c(i2);
            if (z || a != 0 || r2 != 0) {
                this.f3766e.m4164b();
            }
        }
    }
}
