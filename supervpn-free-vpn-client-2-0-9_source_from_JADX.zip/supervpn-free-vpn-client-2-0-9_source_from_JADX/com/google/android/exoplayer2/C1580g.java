package com.google.android.exoplayer2;

import android.os.Handler;
import android.os.Handler.Callback;
import android.os.HandlerThread;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import android.util.Pair;
import com.google.android.exoplayer2.C1434d.C1418c;
import com.google.android.exoplayer2.C1613n.C1611a;
import com.google.android.exoplayer2.C1613n.C1612b;
import com.google.android.exoplayer2.p031c.C1371g;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1406n;
import com.google.android.exoplayer2.p031c.C1411p;
import com.google.android.exoplayer2.p031c.C1414r;
import com.google.android.exoplayer2.p032b.C1375f;
import com.google.android.exoplayer2.p032b.C1381h;
import com.google.android.exoplayer2.p032b.C1381h.C1390b;
import com.google.android.exoplayer2.p032b.C1387g;
import com.google.android.exoplayer2.source.C1615c;
import com.google.android.exoplayer2.source.C1615c.C1579a;
import com.google.android.exoplayer2.source.C1623d;
import com.google.android.exoplayer2.source.C1625e;
import com.google.android.exoplayer2.source.C1626b;
import com.google.android.exoplayer2.source.C1626b.C1578a;
import java.io.IOException;

final class C1580g implements Callback, C1390b, C1578a, C1579a {
    private int f3388A;
    private C1575a f3389B;
    private C1575a f3390C;
    private C1575a f3391D;
    private C1613n f3392E;
    private final C1352k[] f3393a;
    private final C1353l[] f3394b;
    private final C1381h f3395c;
    private final C1416i f3396d;
    private final C1411p f3397e;
    private final Handler f3398f;
    private final HandlerThread f3399g;
    private final Handler f3400h;
    private final C1612b f3401i;
    private final C1611a f3402j;
    private C1576b f3403k;
    private C1352k f3404l;
    private C1371g f3405m;
    private C1615c f3406n;
    private C1352k[] f3407o;
    private boolean f3408p;
    private boolean f3409q;
    private boolean f3410r;
    private boolean f3411s;
    private int f3412t = 1;
    private int f3413u;
    private int f3414v;
    private long f3415w;
    private long f3416x;
    private boolean f3417y;
    private boolean f3418z;

    private static final class C1575a {
        public final C1626b f3366a;
        public final Object f3367b;
        public final C1623d[] f3368c;
        public final boolean[] f3369d;
        public int f3370e;
        public long f3371f;
        public boolean f3372g;
        public boolean f3373h;
        public boolean f3374i;
        public long f3375j;
        public C1575a f3376k;
        public boolean f3377l;
        private final C1352k[] f3378m;
        private final C1353l[] f3379n;
        private final C1381h f3380o;
        private final C1615c f3381p;
        private C1387g f3382q;
        private C1387g f3383r;

        public C1575a(C1352k[] c1352kArr, C1353l[] c1353lArr, C1381h c1381h, C1615c c1615c, C1626b c1626b, Object obj, long j) {
            this.f3378m = c1352kArr;
            this.f3379n = c1353lArr;
            this.f3380o = c1381h;
            this.f3381p = c1615c;
            this.f3366a = c1626b;
            this.f3367b = C1392a.m2707a(obj);
            this.f3368c = new C1623d[c1352kArr.length];
            this.f3369d = new boolean[c1352kArr.length];
            this.f3371f = j;
        }

        public void m3602a(C1575a c1575a) {
            this.f3376k = c1575a;
        }

        public void m3603a(C1613n c1613n, C1612b c1612b, int i) {
            this.f3370e = i;
            boolean z = this.f3370e == c1613n.mo2291b() + -1 && !c1612b.f3495e;
            this.f3372g = z;
        }

        public boolean m3604a() {
            return this.f3373h && (!this.f3374i || this.f3366a.mo2286g() == Long.MIN_VALUE);
        }

        public void m3601a(long j, C1416i c1416i) {
            this.f3373h = true;
            m3605b();
            this.f3371f = m3599a(j, c1416i, false);
        }

        public boolean m3605b() {
            C1387g a = this.f3380o.mo2144a(this.f3379n, this.f3366a.mo2283d());
            if (a.equals(this.f3383r)) {
                return false;
            }
            this.f3382q = a;
            return true;
        }

        public long m3599a(long j, C1416i c1416i, boolean z) {
            return m3600a(j, c1416i, z, new boolean[this.f3378m.length]);
        }

        public long m3600a(long j, C1416i c1416i, boolean z, boolean[] zArr) {
            int i;
            for (i = 0; i < this.f3382q.f2431b; i++) {
                boolean z2;
                boolean[] zArr2 = this.f3369d;
                if (!z) {
                    Object obj;
                    if (this.f3383r == null) {
                        obj = null;
                    } else {
                        obj = this.f3383r.m2701a(i);
                    }
                    if (C1414r.m2823a(obj, this.f3382q.m2701a(i))) {
                        z2 = true;
                        zArr2[i] = z2;
                    }
                }
                z2 = false;
                zArr2[i] = z2;
            }
            long a = this.f3366a.mo2272a(this.f3382q.m2702a(), this.f3369d, this.f3368c, zArr, j);
            this.f3383r = this.f3382q;
            this.f3374i = false;
            for (i = 0; i < this.f3368c.length; i++) {
                if (this.f3368c[i] != null) {
                    if (this.f3382q.m2701a(i) != null) {
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                    C1392a.m2711b(z2);
                    this.f3374i = true;
                } else {
                    C1392a.m2711b(this.f3382q.m2701a(i) == null);
                }
            }
            c1416i.mo2147a(this.f3378m, this.f3366a.mo2283d(), this.f3382q);
            return a;
        }

        public void m3606c() {
            try {
                this.f3381p.mo2261a(this.f3366a);
            } catch (Throwable e) {
                Log.e("ExoPlayerImplInternal", "Period release failed.", e);
            }
        }
    }

    public static final class C1576b {
        public final int f3384a;
        public final long f3385b;
        public volatile long f3386c;
        public volatile long f3387d;

        public C1576b(int i, long j) {
            this.f3384a = i;
            this.f3385b = j;
            this.f3386c = j;
            this.f3387d = j;
        }
    }

    public /* synthetic */ void mo2234a(C1625e c1625e) {
        m3650b((C1626b) c1625e);
    }

    public C1580g(C1352k[] c1352kArr, C1381h c1381h, C1416i c1416i, boolean z, Handler handler, C1576b c1576b) {
        this.f3393a = c1352kArr;
        this.f3395c = c1381h;
        this.f3396d = c1416i;
        this.f3409q = z;
        this.f3400h = handler;
        this.f3403k = c1576b;
        this.f3394b = new C1353l[c1352kArr.length];
        for (int i = 0; i < c1352kArr.length; i++) {
            c1352kArr[i].mo2097a(i);
            this.f3394b[i] = c1352kArr[i].mo2102b();
        }
        this.f3397e = new C1411p();
        this.f3407o = new C1352k[0];
        this.f3401i = new C1612b();
        this.f3402j = new C1611a();
        c1381h.m2678a((C1390b) this);
        this.f3399g = new C1406n("ExoPlayerImplInternal:Handler", -16);
        this.f3399g.start();
        this.f3398f = new Handler(this.f3399g.getLooper(), this);
    }

    public void m3645a(C1615c c1615c, boolean z) {
        int i;
        Handler handler = this.f3398f;
        if (z) {
            i = 1;
        } else {
            i = 0;
        }
        handler.obtainMessage(0, i, 0, c1615c).sendToTarget();
    }

    public void m3647a(boolean z) {
        int i;
        Handler handler = this.f3398f;
        if (z) {
            i = 1;
        } else {
            i = 0;
        }
        handler.obtainMessage(1, i, 0).sendToTarget();
    }

    public void m3642a(int i, long j) {
        this.f3398f.obtainMessage(3, i, 0, Long.valueOf(j)).sendToTarget();
    }

    public void m3641a() {
        this.f3398f.sendEmptyMessage(4);
    }

    public void m3648a(C1418c... c1418cArr) {
        if (this.f3408p) {
            Log.w("ExoPlayerImplInternal", "Ignoring messages sent after release.");
            return;
        }
        this.f3413u++;
        this.f3398f.obtainMessage(10, c1418cArr).sendToTarget();
    }

    public synchronized void m3651b(C1418c... c1418cArr) {
        if (this.f3408p) {
            Log.w("ExoPlayerImplInternal", "Ignoring messages sent after release.");
        } else {
            int i = this.f3413u;
            this.f3413u = i + 1;
            this.f3398f.obtainMessage(10, c1418cArr).sendToTarget();
            while (this.f3414v <= i) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }

    public synchronized void m3649b() {
        if (!this.f3408p) {
            this.f3398f.sendEmptyMessage(5);
            while (!this.f3408p) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            this.f3399g.quit();
        }
    }

    public void mo2232a(C1613n c1613n, Object obj) {
        this.f3398f.obtainMessage(6, Pair.create(c1613n, obj)).sendToTarget();
    }

    public void mo2233a(C1626b c1626b) {
        this.f3398f.obtainMessage(7, c1626b).sendToTarget();
    }

    public void m3650b(C1626b c1626b) {
        this.f3398f.obtainMessage(8, c1626b).sendToTarget();
    }

    public boolean handleMessage(Message message) {
        boolean z = false;
        try {
            switch (message.what) {
                case 0:
                    C1615c c1615c = (C1615c) message.obj;
                    if (message.arg1 != 0) {
                        z = true;
                    }
                    m3621b(c1615c, z);
                    return true;
                case 1:
                    if (message.arg1 != 0) {
                        z = true;
                    }
                    m3626c(z);
                    return true;
                case 2:
                    m3632f();
                    return true;
                case 3:
                    m3619b(message.arg1, ((Long) message.obj).longValue());
                    return true;
                case 4:
                    m3633g();
                    return true;
                case 5:
                    m3634h();
                    return true;
                case 6:
                    m3613a((Pair) message.obj);
                    return true;
                case 7:
                    m3625c((C1626b) message.obj);
                    return true;
                case 8:
                    m3629d((C1626b) message.obj);
                    return true;
                case 9:
                    m3636j();
                    return true;
                case 10:
                    m3627c((C1418c[]) message.obj);
                    return true;
                default:
                    return false;
            }
        } catch (Throwable e) {
            Log.e("ExoPlayerImplInternal", "Renderer error.", e);
            this.f3400h.obtainMessage(6, e).sendToTarget();
            m3633g();
            return true;
        } catch (IOException e2) {
            Log.e("ExoPlayerImplInternal", "Source error.", e2);
            this.f3400h.obtainMessage(6, ExoPlaybackException.m2398a(e2)).sendToTarget();
            m3633g();
            return true;
        } catch (RuntimeException e3) {
            Log.e("ExoPlayerImplInternal", "Internal runtime error.", e3);
            this.f3400h.obtainMessage(6, ExoPlaybackException.m2400a(e3)).sendToTarget();
            m3633g();
            return true;
        }
    }

    private void m3610a(int i) {
        if (this.f3412t != i) {
            this.f3412t = i;
            this.f3400h.obtainMessage(1, i, 0).sendToTarget();
        }
    }

    private void m3622b(boolean z) {
        if (this.f3411s != z) {
            int i;
            this.f3411s = z;
            Handler handler = this.f3400h;
            if (z) {
                i = 1;
            } else {
                i = 0;
            }
            handler.obtainMessage(2, i, 0).sendToTarget();
        }
    }

    private void m3621b(C1615c c1615c, boolean z) {
        m3635i();
        this.f3396d.mo2146a();
        if (z) {
            this.f3403k = new C1576b(0, -9223372036854775807L);
        }
        this.f3406n = c1615c;
        c1615c.mo2262a((C1579a) this);
        m3610a(2);
        this.f3398f.sendEmptyMessage(2);
    }

    private void m3626c(boolean z) {
        this.f3410r = false;
        this.f3409q = z;
        if (!z) {
            m3628d();
            m3631e();
        } else if (this.f3412t == 3) {
            m3624c();
            this.f3398f.sendEmptyMessage(2);
        } else if (this.f3412t == 2) {
            this.f3398f.sendEmptyMessage(2);
        }
    }

    private void m3624c() {
        int i = 0;
        this.f3410r = false;
        this.f3397e.m2804a();
        C1352k[] c1352kArr = this.f3407o;
        int length = c1352kArr.length;
        while (i < length) {
            c1352kArr[i].mo2105e();
            i++;
        }
    }

    private void m3628d() {
        this.f3397e.m2806b();
        for (C1352k a : this.f3407o) {
            m3615a(a);
        }
    }

    private void m3631e() {
        if (this.f3389B != null) {
            long f = this.f3389B.f3366a.mo2285f();
            if (f != -9223372036854775807L) {
                m3611a(f);
            } else {
                if (this.f3404l == null || this.f3404l.mo2127s()) {
                    this.f3416x = this.f3397e.mo2136t();
                } else {
                    this.f3416x = this.f3405m.mo2136t();
                    this.f3397e.m2805a(this.f3416x);
                }
                f = this.f3416x - this.f3389B.f3375j;
            }
            this.f3403k.f3386c = f;
            this.f3415w = SystemClock.elapsedRealtime() * 1000;
            if (this.f3407o.length == 0) {
                f = Long.MIN_VALUE;
            } else {
                f = this.f3389B.f3366a.mo2286g();
            }
            C1576b c1576b = this.f3403k;
            if (f == Long.MIN_VALUE) {
                f = this.f3392E.m3788a(this.f3389B.f3370e, this.f3402j).m3779b();
            }
            c1576b.f3387d = f;
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m3632f() {
        /*
        r15 = this;
        r4 = android.os.SystemClock.elapsedRealtime();
        r15.m3638l();
        r0 = r15.f3389B;
        if (r0 != 0) goto L_0x0014;
    L_0x000b:
        r15.m3637k();
        r0 = 10;
        r15.m3612a(r4, r0);
    L_0x0013:
        return;
    L_0x0014:
        r0 = "doSomeWork";
        com.google.android.exoplayer2.p031c.C1412q.m2809a(r0);
        r15.m3631e();
        r2 = 1;
        r1 = 1;
        r6 = r15.f3407o;
        r7 = r6.length;
        r0 = 0;
        r3 = r1;
        r14 = r0;
        r0 = r2;
        r2 = r14;
    L_0x0027:
        if (r2 >= r7) goto L_0x005c;
    L_0x0029:
        r8 = r6[r2];
        r10 = r15.f3416x;
        r12 = r15.f3415w;
        r8.mo2120a(r10, r12);
        if (r0 == 0) goto L_0x0056;
    L_0x0034:
        r0 = r8.mo2127s();
        if (r0 == 0) goto L_0x0056;
    L_0x003a:
        r0 = 1;
    L_0x003b:
        r1 = r8.mo2126r();
        if (r1 != 0) goto L_0x0047;
    L_0x0041:
        r1 = r8.mo2127s();
        if (r1 == 0) goto L_0x0058;
    L_0x0047:
        r1 = 1;
    L_0x0048:
        if (r1 != 0) goto L_0x004d;
    L_0x004a:
        r8.mo2109i();
    L_0x004d:
        if (r3 == 0) goto L_0x005a;
    L_0x004f:
        if (r1 == 0) goto L_0x005a;
    L_0x0051:
        r1 = 1;
    L_0x0052:
        r2 = r2 + 1;
        r3 = r1;
        goto L_0x0027;
    L_0x0056:
        r0 = 0;
        goto L_0x003b;
    L_0x0058:
        r1 = 0;
        goto L_0x0048;
    L_0x005a:
        r1 = 0;
        goto L_0x0052;
    L_0x005c:
        if (r3 != 0) goto L_0x0061;
    L_0x005e:
        r15.m3637k();
    L_0x0061:
        r1 = r15.f3392E;
        r2 = r15.f3389B;
        r2 = r2.f3370e;
        r6 = r15.f3402j;
        r1 = r1.m3788a(r2, r6);
        r6 = r1.m3779b();
        if (r0 == 0) goto L_0x00a2;
    L_0x0073:
        r0 = -9223372036854775807; // 0x8000000000000001 float:1.4E-45 double:-4.9E-324;
        r0 = (r6 > r0 ? 1 : (r6 == r0 ? 0 : -1));
        if (r0 == 0) goto L_0x0084;
    L_0x007c:
        r0 = r15.f3403k;
        r0 = r0.f3386c;
        r0 = (r6 > r0 ? 1 : (r6 == r0 ? 0 : -1));
        if (r0 > 0) goto L_0x00a2;
    L_0x0084:
        r0 = r15.f3418z;
        if (r0 == 0) goto L_0x00a2;
    L_0x0088:
        r0 = 4;
        r15.m3610a(r0);
        r15.m3628d();
    L_0x008f:
        r0 = r15.f3412t;
        r1 = 2;
        if (r0 != r1) goto L_0x00e4;
    L_0x0094:
        r1 = r15.f3407o;
        r2 = r1.length;
        r0 = 0;
    L_0x0098:
        if (r0 >= r2) goto L_0x00e4;
    L_0x009a:
        r3 = r1[r0];
        r3.mo2109i();
        r0 = r0 + 1;
        goto L_0x0098;
    L_0x00a2:
        r0 = r15.f3412t;
        r1 = 2;
        if (r0 != r1) goto L_0x00c7;
    L_0x00a7:
        r0 = r15.f3407o;
        r0 = r0.length;
        if (r0 <= 0) goto L_0x00c2;
    L_0x00ac:
        if (r3 == 0) goto L_0x008f;
    L_0x00ae:
        r0 = r15.f3410r;
        r0 = r15.m3630d(r0);
        if (r0 == 0) goto L_0x008f;
    L_0x00b6:
        r0 = 3;
        r15.m3610a(r0);
        r0 = r15.f3409q;
        if (r0 == 0) goto L_0x008f;
    L_0x00be:
        r15.m3624c();
        goto L_0x008f;
    L_0x00c2:
        r0 = r15.f3417y;
        if (r0 == 0) goto L_0x008f;
    L_0x00c6:
        goto L_0x00b6;
    L_0x00c7:
        r0 = r15.f3412t;
        r1 = 3;
        if (r0 != r1) goto L_0x008f;
    L_0x00cc:
        r0 = r15.f3407o;
        r0 = r0.length;
        if (r0 <= 0) goto L_0x00df;
    L_0x00d1:
        if (r3 != 0) goto L_0x008f;
    L_0x00d3:
        r0 = r15.f3409q;
        r15.f3410r = r0;
        r0 = 2;
        r15.m3610a(r0);
        r15.m3628d();
        goto L_0x008f;
    L_0x00df:
        r0 = r15.f3417y;
        if (r0 != 0) goto L_0x008f;
    L_0x00e3:
        goto L_0x00d3;
    L_0x00e4:
        r0 = r15.f3409q;
        if (r0 == 0) goto L_0x00ed;
    L_0x00e8:
        r0 = r15.f3412t;
        r1 = 3;
        if (r0 == r1) goto L_0x00f2;
    L_0x00ed:
        r0 = r15.f3412t;
        r1 = 2;
        if (r0 != r1) goto L_0x00fc;
    L_0x00f2:
        r0 = 10;
        r15.m3612a(r4, r0);
    L_0x00f7:
        com.google.android.exoplayer2.p031c.C1412q.m2808a();
        goto L_0x0013;
    L_0x00fc:
        r0 = r15.f3407o;
        r0 = r0.length;
        if (r0 == 0) goto L_0x0107;
    L_0x0101:
        r0 = 1000; // 0x3e8 float:1.401E-42 double:4.94E-321;
        r15.m3612a(r4, r0);
        goto L_0x00f7;
    L_0x0107:
        r0 = r15.f3398f;
        r1 = 2;
        r0.removeMessages(r1);
        goto L_0x00f7;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.g.f():void");
    }

    private void m3612a(long j, long j2) {
        this.f3398f.removeMessages(2);
        long elapsedRealtime = (j + j2) - SystemClock.elapsedRealtime();
        if (elapsedRealtime <= 0) {
            this.f3398f.sendEmptyMessage(2);
        } else {
            this.f3398f.sendEmptyMessageDelayed(2, elapsedRealtime);
        }
    }

    private void m3619b(int i, long j) {
        if (j == -9223372036854775807L) {
            try {
                if (this.f3392E != null && i < this.f3392E.mo2291b()) {
                    Pair b = m3618b(i);
                    i = ((Integer) b.first).intValue();
                    j = ((Long) b.second).longValue();
                }
            } catch (Throwable th) {
                this.f3403k = new C1576b(i, j);
                this.f3400h.obtainMessage(3, this.f3403k).sendToTarget();
            }
        }
        if (i == this.f3403k.f3384a && ((j == -9223372036854775807L && this.f3403k.f3386c == -9223372036854775807L) || j / 1000 == this.f3403k.f3386c / 1000)) {
            this.f3403k = new C1576b(i, j);
            this.f3400h.obtainMessage(3, this.f3403k).sendToTarget();
            return;
        }
        this.f3403k = new C1576b(i, m3623c(i, j));
        this.f3400h.obtainMessage(3, this.f3403k).sendToTarget();
    }

    private long m3623c(int i, long j) {
        if (this.f3406n != null) {
            C1575a c1575a;
            m3628d();
            this.f3410r = false;
            m3610a(2);
            if (j == -9223372036854775807L || (this.f3390C != this.f3389B && (i == this.f3389B.f3370e || i == this.f3390C.f3370e))) {
                i = -1;
            }
            if (this.f3389B != null) {
                C1575a c1575a2 = this.f3389B;
                c1575a = null;
                while (c1575a2 != null) {
                    if (c1575a2.f3370e == i && c1575a2.f3373h) {
                        c1575a = c1575a2;
                    } else {
                        c1575a2.m3606c();
                    }
                    c1575a2 = c1575a2.f3376k;
                }
            } else if (this.f3391D != null) {
                this.f3391D.m3606c();
                c1575a = null;
            } else {
                c1575a = null;
            }
            if (c1575a != this.f3389B) {
                for (C1352k k : this.f3407o) {
                    k.mo2111k();
                }
                this.f3407o = new C1352k[0];
                this.f3405m = null;
                this.f3404l = null;
            }
            this.f3388A = 0;
            if (c1575a != null) {
                c1575a.f3376k = null;
                m3620b(c1575a);
                m3640n();
                this.f3390C = this.f3389B;
                this.f3391D = this.f3389B;
                if (this.f3389B.f3374i) {
                    j = this.f3389B.f3366a.mo2281b(j);
                }
                m3611a(j);
                m3639m();
            } else {
                this.f3389B = null;
                this.f3390C = null;
                this.f3391D = null;
                if (j != -9223372036854775807L) {
                    m3611a(j);
                }
            }
            m3631e();
            this.f3398f.sendEmptyMessage(2);
        } else if (j != -9223372036854775807L) {
            m3611a(j);
        }
        return j;
    }

    private void m3611a(long j) {
        this.f3416x = (this.f3389B == null ? 0 : this.f3389B.f3375j) + j;
        this.f3397e.m2805a(this.f3416x);
        for (C1352k a : this.f3407o) {
            a.mo2099a(this.f3416x);
        }
    }

    private void m3633g() {
        m3635i();
        this.f3396d.mo2150b();
        m3610a(1);
    }

    private void m3634h() {
        m3635i();
        this.f3396d.mo2151c();
        m3610a(1);
        synchronized (this) {
            this.f3408p = true;
            notifyAll();
        }
    }

    private void m3635i() {
        Throwable e;
        this.f3398f.removeMessages(2);
        this.f3410r = false;
        this.f3397e.m2806b();
        this.f3405m = null;
        this.f3404l = null;
        for (C1352k c1352k : this.f3407o) {
            try {
                m3615a(c1352k);
                c1352k.mo2111k();
            } catch (ExoPlaybackException e2) {
                e = e2;
            } catch (RuntimeException e3) {
                e = e3;
            }
        }
        this.f3407o = new C1352k[0];
        m3614a(this.f3389B != null ? this.f3389B : this.f3391D);
        if (this.f3406n != null) {
            this.f3406n.mo2263b();
            this.f3406n = null;
        }
        this.f3417y = false;
        this.f3418z = false;
        this.f3389B = null;
        this.f3390C = null;
        this.f3391D = null;
        this.f3392E = null;
        this.f3388A = 0;
        m3622b(false);
        return;
        Log.e("ExoPlayerImplInternal", "Stop failed.", e);
    }

    private void m3627c(C1418c[] c1418cArr) {
        try {
            for (C1418c c1418c : c1418cArr) {
                c1418c.f2519a.mo2098a(c1418c.f2520b, c1418c.f2521c);
            }
            if (this.f3406n != null) {
                this.f3398f.sendEmptyMessage(2);
            }
            synchronized (this) {
                this.f3414v++;
                notifyAll();
            }
        } catch (Throwable th) {
            synchronized (this) {
                this.f3414v++;
                notifyAll();
            }
        }
    }

    private void m3615a(C1352k c1352k) {
        if (c1352k.mo2104d() == 2) {
            c1352k.mo2110j();
        }
    }

    private void m3636j() {
        if (this.f3389B != null) {
            C1575a c1575a = this.f3389B;
            boolean z = true;
            while (c1575a != null && c1575a.f3373h) {
                if (c1575a.m3605b()) {
                    if (z) {
                        boolean z2;
                        if (this.f3390C != this.f3389B) {
                            z2 = true;
                        } else {
                            z2 = false;
                        }
                        m3614a(this.f3389B.f3376k);
                        this.f3389B.f3376k = null;
                        this.f3390C = this.f3389B;
                        this.f3391D = this.f3389B;
                        this.f3388A = 0;
                        boolean[] zArr = new boolean[this.f3393a.length];
                        long a = this.f3389B.m3600a(this.f3403k.f3386c, this.f3396d, z2, zArr);
                        if (a != this.f3403k.f3386c) {
                            this.f3403k.f3386c = a;
                            m3611a(a);
                        }
                        boolean[] zArr2 = new boolean[this.f3393a.length];
                        int i = 0;
                        for (int i2 = 0; i2 < this.f3393a.length; i2++) {
                            C1352k c1352k = this.f3393a[i2];
                            zArr2[i2] = c1352k.mo2104d() != 0;
                            C1623d c1623d = this.f3389B.f3368c[i2];
                            if (c1623d != null) {
                                i++;
                            }
                            if (zArr2[i2]) {
                                if (c1623d != c1352k.mo2106f()) {
                                    if (c1352k == this.f3404l) {
                                        if (c1623d == null) {
                                            this.f3397e.m2805a(this.f3405m.mo2136t());
                                        }
                                        this.f3405m = null;
                                        this.f3404l = null;
                                    }
                                    m3615a(c1352k);
                                    c1352k.mo2111k();
                                } else if (zArr[i2]) {
                                    c1352k.mo2099a(this.f3403k.f3386c);
                                }
                            }
                        }
                        this.f3395c.m2676a(this.f3389B.f3382q);
                        m3617a(zArr2, i);
                    } else {
                        this.f3391D = c1575a;
                        C1575a c1575a2 = this.f3391D.f3376k;
                        while (c1575a2 != null) {
                            c1575a2.m3606c();
                            c1575a2 = c1575a2.f3376k;
                            this.f3388A--;
                        }
                        this.f3391D.f3376k = null;
                        this.f3391D.m3599a(Math.max(0, this.f3416x - this.f3391D.f3375j), this.f3396d, false);
                    }
                    m3639m();
                    m3631e();
                    this.f3398f.sendEmptyMessage(2);
                    return;
                }
                if (c1575a == this.f3390C) {
                    z = false;
                }
                c1575a = c1575a.f3376k;
            }
        }
    }

    private boolean m3630d(boolean z) {
        if (this.f3391D == null) {
            return false;
        }
        long g;
        long j = this.f3416x - this.f3391D.f3375j;
        if (this.f3391D.f3373h) {
            g = this.f3391D.f3366a.mo2286g();
        } else {
            g = 0;
        }
        if (g == Long.MIN_VALUE) {
            if (this.f3391D.f3372g) {
                return true;
            }
            g = this.f3392E.m3788a(this.f3391D.f3370e, this.f3402j).m3779b();
        }
        return this.f3396d.mo2149a(g - j, z);
    }

    private void m3637k() {
        if (this.f3391D != null && !this.f3391D.f3373h) {
            if (this.f3390C == null || this.f3390C.f3376k == this.f3391D) {
                C1352k[] c1352kArr = this.f3407o;
                int length = c1352kArr.length;
                int i = 0;
                while (i < length) {
                    if (c1352kArr[i].mo2107g()) {
                        i++;
                    } else {
                        return;
                    }
                }
                this.f3391D.f3366a.mo2282c();
            }
        }
    }

    private void m3613a(Pair pair) {
        int i;
        this.f3400h.obtainMessage(5, pair).sendToTarget();
        C1613n c1613n = this.f3392E;
        this.f3392E = (C1613n) pair.first;
        if (this.f3389B != null) {
            int a = this.f3392E.mo2288a(this.f3389B.f3367b);
            if (a == -1) {
                m3616a(this.f3392E, c1613n, this.f3389B.f3370e);
                return;
            }
            this.f3392E.mo2289a(a, this.f3402j, true);
            this.f3389B.m3603a(this.f3392E, this.f3392E.m3790a(this.f3402j.f3488c, this.f3401i), a);
            C1575a c1575a = this.f3389B;
            this.f3388A = 0;
            int i2 = a;
            C1575a c1575a2 = c1575a;
            i = 0;
            C1575a c1575a3 = c1575a2;
            while (c1575a3.f3376k != null) {
                C1575a c1575a4 = c1575a3.f3376k;
                i2++;
                this.f3392E.mo2289a(i2, this.f3402j, true);
                if (c1575a4.f3367b.equals(this.f3402j.f3487b)) {
                    this.f3388A++;
                    c1575a4.m3603a(this.f3392E, this.f3392E.m3790a(this.f3392E.m3788a(i2, this.f3402j).f3488c, this.f3401i), i2);
                    if (c1575a4 == this.f3390C) {
                        i = true;
                    }
                    c1575a3 = c1575a4;
                } else if (i == 0) {
                    i = this.f3389B.f3370e;
                    m3614a(this.f3389B);
                    this.f3389B = null;
                    this.f3390C = null;
                    this.f3391D = null;
                    long c = m3623c(i, this.f3403k.f3386c);
                    if (c != this.f3403k.f3386c) {
                        this.f3403k = new C1576b(i, c);
                        this.f3400h.obtainMessage(4, this.f3403k).sendToTarget();
                        return;
                    }
                    return;
                } else {
                    this.f3391D = c1575a3;
                    this.f3391D.f3376k = null;
                    m3614a(c1575a4);
                }
            }
        } else if (this.f3391D != null) {
            i = this.f3392E.mo2288a(this.f3391D.f3367b);
            if (i == -1) {
                m3616a(this.f3392E, c1613n, this.f3391D.f3370e);
                return;
            }
            this.f3391D.m3603a(this.f3392E, this.f3392E.m3790a(this.f3392E.m3788a(i, this.f3402j).f3488c, this.f3401i), i);
        }
        if (c1613n != null) {
            i = this.f3389B != null ? this.f3389B.f3370e : this.f3391D != null ? this.f3391D.f3370e : -1;
            if (i != -1 && i != this.f3403k.f3384a) {
                this.f3403k = new C1576b(i, this.f3403k.f3386c);
                m3631e();
                this.f3400h.obtainMessage(4, this.f3403k).sendToTarget();
            }
        }
    }

    private void m3616a(C1613n c1613n, C1613n c1613n2, int i) {
        int i2 = -1;
        while (i2 == -1 && i < c1613n2.mo2291b() - 1) {
            i++;
            i2 = c1613n.mo2288a(c1613n2.mo2289a(i, this.f3402j, true).f3487b);
        }
        if (i2 == -1) {
            m3633g();
            return;
        }
        m3614a(this.f3389B != null ? this.f3389B : this.f3391D);
        this.f3388A = 0;
        this.f3389B = null;
        this.f3390C = null;
        this.f3391D = null;
        Pair b = m3618b(i2);
        this.f3403k = new C1576b(((Integer) b.first).intValue(), ((Long) b.second).longValue());
        this.f3400h.obtainMessage(4, this.f3403k).sendToTarget();
    }

    private Pair m3618b(int i) {
        this.f3392E.m3788a(i, this.f3402j);
        this.f3392E.m3790a(this.f3402j.f3488c, this.f3401i);
        int i2 = this.f3401i.f3496f;
        long d = this.f3401i.m3785d() + this.f3401i.m3781a();
        this.f3392E.m3788a(i2, this.f3402j);
        while (i2 < this.f3401i.f3497g && d > this.f3402j.m3777a()) {
            d -= this.f3402j.m3779b();
            int i3 = i2 + 1;
            this.f3392E.m3788a(i2, this.f3402j);
            i2 = i3;
        }
        return Pair.create(Integer.valueOf(i2), Long.valueOf(d));
    }

    private void m3638l() {
        int i = 0;
        if (this.f3392E == null) {
            this.f3406n.mo2260a();
            return;
        }
        int i2;
        if (this.f3391D == null || (this.f3391D.m3604a() && !this.f3391D.f3372g && this.f3388A < 100)) {
            i2 = this.f3391D == null ? this.f3403k.f3384a : this.f3391D.f3370e + 1;
            if (i2 >= this.f3392E.mo2291b()) {
                this.f3406n.mo2260a();
            } else {
                int i3 = this.f3392E.m3788a(i2, this.f3402j).f3488c;
                long j = this.f3391D == null ? this.f3403k.f3386c : i2 == this.f3392E.m3790a(i3, this.f3401i).f3496f ? -9223372036854775807L : 0;
                if (j == -9223372036854775807L) {
                    Pair b = m3618b(i2);
                    int intValue = ((Integer) b.first).intValue();
                    j = ((Long) b.second).longValue();
                    i2 = intValue;
                }
                Object obj = this.f3392E.mo2289a(i2, this.f3402j, true).f3487b;
                C1626b a = this.f3406n.mo2259a(i2, this.f3396d.mo2152d(), j);
                a.mo2277a(this);
                C1575a c1575a = new C1575a(this.f3393a, this.f3394b, this.f3395c, this.f3406n, a, obj, j);
                this.f3392E.m3790a(i3, this.f3401i);
                c1575a.m3603a(this.f3392E, this.f3401i, i2);
                if (this.f3391D != null) {
                    this.f3391D.m3602a(c1575a);
                    c1575a.f3375j = this.f3391D.f3375j + this.f3392E.m3788a(this.f3391D.f3370e, this.f3402j).m3779b();
                }
                this.f3388A++;
                this.f3391D = c1575a;
                m3622b(true);
            }
        }
        if (this.f3391D == null || this.f3391D.m3604a()) {
            m3622b(false);
        } else if (this.f3391D != null && this.f3391D.f3377l) {
            m3639m();
        }
        if (this.f3389B != null) {
            while (this.f3389B != this.f3390C && this.f3389B.f3376k != null && this.f3416x >= this.f3389B.f3376k.f3375j) {
                this.f3389B.m3606c();
                m3620b(this.f3389B.f3376k);
                this.f3388A--;
                this.f3403k = new C1576b(this.f3389B.f3370e, this.f3389B.f3371f);
                m3631e();
                this.f3400h.obtainMessage(4, this.f3403k).sendToTarget();
            }
            m3640n();
            if (this.f3390C.f3372g) {
                C1352k[] c1352kArr = this.f3407o;
                intValue = c1352kArr.length;
                while (i < intValue) {
                    c1352kArr[i].mo2108h();
                    i++;
                }
                return;
            }
            C1352k[] c1352kArr2 = this.f3407o;
            int length = c1352kArr2.length;
            i2 = 0;
            while (i2 < length) {
                if (c1352kArr2[i2].mo2107g()) {
                    i2++;
                } else {
                    return;
                }
            }
            if (this.f3390C.f3376k != null && this.f3390C.f3376k.f3373h) {
                C1387g b2 = this.f3390C.f3382q;
                this.f3390C = this.f3390C.f3376k;
                C1387g b3 = this.f3390C.f3382q;
                for (i2 = 0; i2 < this.f3393a.length; i2++) {
                    C1352k c1352k = this.f3393a[i2];
                    C1375f a2 = b2.m2701a(i2);
                    C1375f a3 = b3.m2701a(i2);
                    if (a2 != null) {
                        if (a3 != null) {
                            Format[] formatArr = new Format[a3.mo2142b()];
                            for (intValue = 0; intValue < formatArr.length; intValue++) {
                                formatArr[intValue] = a3.mo2140a(intValue);
                            }
                            c1352k.mo2100a(formatArr, this.f3390C.f3368c[i2], this.f3390C.f3375j);
                        } else {
                            c1352k.mo2108h();
                        }
                    }
                }
            }
        }
    }

    private void m3625c(C1626b c1626b) {
        if (this.f3391D != null && this.f3391D.f3366a == c1626b) {
            this.f3391D.m3601a(this.f3391D.f3371f, this.f3396d);
            if (this.f3389B == null) {
                this.f3390C = this.f3391D;
                m3620b(this.f3390C);
                if (this.f3403k.f3385b == -9223372036854775807L) {
                    this.f3403k = new C1576b(this.f3389B.f3370e, this.f3389B.f3371f);
                    m3611a(this.f3403k.f3385b);
                    m3631e();
                    this.f3400h.obtainMessage(4, this.f3403k).sendToTarget();
                }
                m3640n();
            }
            m3639m();
        }
    }

    private void m3629d(C1626b c1626b) {
        if (this.f3391D != null && this.f3391D.f3366a == c1626b) {
            m3639m();
        }
    }

    private void m3639m() {
        long e = this.f3391D.f3366a.mo2284e();
        if (e != Long.MIN_VALUE) {
            long j = this.f3416x - this.f3391D.f3375j;
            boolean a = this.f3396d.mo2148a(e - j);
            m3622b(a);
            if (a) {
                this.f3391D.f3377l = false;
                this.f3391D.f3366a.mo2280a(j);
                return;
            }
            this.f3391D.f3377l = true;
            return;
        }
        m3622b(false);
    }

    private void m3614a(C1575a c1575a) {
        while (c1575a != null) {
            c1575a.m3606c();
            c1575a = c1575a.f3376k;
        }
    }

    private void m3620b(C1575a c1575a) {
        boolean[] zArr = new boolean[this.f3393a.length];
        int i = 0;
        for (int i2 = 0; i2 < this.f3393a.length; i2++) {
            boolean z;
            C1352k c1352k = this.f3393a[i2];
            if (c1352k.mo2104d() != 0) {
                z = true;
            } else {
                z = false;
            }
            zArr[i2] = z;
            if (c1575a.f3382q.m2701a(i2) != null) {
                i++;
            } else if (zArr[i2]) {
                if (c1352k == this.f3404l) {
                    this.f3397e.m2805a(this.f3405m.mo2136t());
                    this.f3405m = null;
                    this.f3404l = null;
                }
                m3615a(c1352k);
                c1352k.mo2111k();
            }
        }
        this.f3395c.m2676a(c1575a.f3382q);
        this.f3389B = c1575a;
        m3617a(zArr, i);
    }

    private void m3640n() {
        long b = this.f3392E.m3788a(this.f3389B.f3370e, this.f3402j).m3779b();
        boolean z = b == -9223372036854775807L || this.f3403k.f3386c < b || (this.f3389B.f3376k != null && this.f3389B.f3376k.f3373h);
        this.f3417y = z;
        this.f3418z = this.f3389B.f3372g;
    }

    private void m3617a(boolean[] zArr, int i) {
        this.f3407o = new C1352k[i];
        int i2 = 0;
        for (int i3 = 0; i3 < this.f3393a.length; i3++) {
            C1352k c1352k = this.f3393a[i3];
            C1375f a = this.f3389B.f3382q.m2701a(i3);
            if (a != null) {
                int i4 = i2 + 1;
                this.f3407o[i2] = c1352k;
                if (c1352k.mo2104d() == 0) {
                    boolean z;
                    Object obj = (this.f3409q && this.f3412t == 3) ? 1 : null;
                    if (zArr[i3] || obj == null) {
                        z = false;
                    } else {
                        z = true;
                    }
                    Format[] formatArr = new Format[a.mo2142b()];
                    for (int i5 = 0; i5 < formatArr.length; i5++) {
                        formatArr[i5] = a.mo2140a(i5);
                    }
                    c1352k.mo2101a(formatArr, this.f3389B.f3368c[i3], this.f3416x, z, this.f3389B.f3375j);
                    C1371g c = c1352k.mo2103c();
                    if (c != null) {
                        if (this.f3405m != null) {
                            throw ExoPlaybackException.m2400a(new IllegalStateException("Multiple renderer media clocks enabled."));
                        }
                        this.f3405m = c;
                        this.f3404l = c1352k;
                    }
                    if (obj != null) {
                        c1352k.mo2105e();
                    }
                }
                i2 = i4;
            }
        }
    }
}
