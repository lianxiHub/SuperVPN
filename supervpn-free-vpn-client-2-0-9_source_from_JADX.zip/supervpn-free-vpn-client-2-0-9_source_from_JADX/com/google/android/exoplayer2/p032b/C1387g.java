package com.google.android.exoplayer2.p032b;

import java.util.Arrays;

public final class C1387g {
    public final Object f2430a;
    public final int f2431b;
    private final C1375f[] f2432c;
    private int f2433d;

    public C1387g(Object obj, C1375f... c1375fArr) {
        this.f2430a = obj;
        this.f2432c = c1375fArr;
        this.f2431b = c1375fArr.length;
    }

    public C1375f m2701a(int i) {
        return this.f2432c[i];
    }

    public C1375f[] m2702a() {
        return (C1375f[]) this.f2432c.clone();
    }

    public int hashCode() {
        if (this.f2433d == 0) {
            this.f2433d = Arrays.hashCode(this.f2432c) + 527;
        }
        return this.f2433d;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return Arrays.equals(this.f2432c, ((C1387g) obj).f2432c);
    }
}
