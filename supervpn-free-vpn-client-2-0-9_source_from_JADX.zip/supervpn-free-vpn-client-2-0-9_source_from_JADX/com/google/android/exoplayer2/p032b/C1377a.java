package com.google.android.exoplayer2.p032b;

import com.google.android.exoplayer2.p032b.C1375f.C1373a;
import com.google.android.exoplayer2.source.C1630g;
import com.google.android.exoplayer2.upstream.C1686c;

public class C1377a extends C1376b {
    private final C1686c f2392d;
    private final int f2393e;
    private final long f2394f;
    private final long f2395g;
    private final long f2396h;
    private final float f2397i;
    private int f2398j = m2671a(Long.MIN_VALUE);
    private int f2399k = 1;

    public static final class C1374a implements C1373a {
        private final C1686c f2380a;
        private final int f2381b;
        private final int f2382c;
        private final int f2383d;
        private final int f2384e;
        private final float f2385f;

        public /* synthetic */ C1375f mo2139b(C1630g c1630g, int[] iArr) {
            return m2660a(c1630g, iArr);
        }

        public C1374a(C1686c c1686c) {
            this(c1686c, 800000, 10000, 25000, 25000, 0.75f);
        }

        public C1374a(C1686c c1686c, int i, int i2, int i3, int i4, float f) {
            this.f2380a = c1686c;
            this.f2381b = i;
            this.f2382c = i2;
            this.f2383d = i3;
            this.f2384e = i4;
            this.f2385f = f;
        }

        public C1377a m2660a(C1630g c1630g, int... iArr) {
            return new C1377a(c1630g, iArr, this.f2380a, this.f2381b, (long) this.f2382c, (long) this.f2383d, (long) this.f2384e, this.f2385f);
        }
    }

    public C1377a(C1630g c1630g, int[] iArr, C1686c c1686c, int i, long j, long j2, long j3, float f) {
        super(c1630g, iArr);
        this.f2392d = c1686c;
        this.f2393e = i;
        this.f2394f = j * 1000;
        this.f2395g = j2 * 1000;
        this.f2396h = j3 * 1000;
        this.f2397i = f;
    }

    private int m2671a(long j) {
        int i = 0;
        long a = this.f2392d.mo2322a();
        a = a == -1 ? (long) this.f2393e : (long) (((float) a) * this.f2397i);
        int i2 = 0;
        while (i < this.b) {
            if (j == Long.MIN_VALUE || !m2668a(i, j)) {
                if (((long) mo2140a(i).f2180b) <= a) {
                    return i;
                }
                i2 = i;
            }
            i++;
        }
        return i2;
    }
}
