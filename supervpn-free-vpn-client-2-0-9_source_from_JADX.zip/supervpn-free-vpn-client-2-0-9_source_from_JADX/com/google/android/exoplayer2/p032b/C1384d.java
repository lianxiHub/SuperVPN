package com.google.android.exoplayer2.p032b;

import com.google.android.exoplayer2.source.C1630g;

public final class C1384d extends C1376b {
    private final int f2419d;
    private final Object f2420e;

    public C1384d(C1630g c1630g, int i) {
        this(c1630g, i, 0, null);
    }

    public C1384d(C1630g c1630g, int i, int i2, Object obj) {
        super(c1630g, i);
        this.f2419d = i2;
        this.f2420e = obj;
    }
}
