package com.google.android.exoplayer2.p032b;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.source.C1630g;

public interface C1375f {

    public interface C1373a {
        C1375f mo2139b(C1630g c1630g, int... iArr);
    }

    Format mo2140a(int i);

    C1630g mo2141a();

    int mo2142b();

    int mo2143b(int i);
}
