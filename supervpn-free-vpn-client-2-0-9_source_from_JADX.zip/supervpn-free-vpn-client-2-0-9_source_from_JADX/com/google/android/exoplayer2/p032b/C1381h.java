package com.google.android.exoplayer2.p032b;

import android.os.Handler;
import com.google.android.exoplayer2.C1353l;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.source.C1631h;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArraySet;

public abstract class C1381h {
    private final Handler f2410a;
    private final CopyOnWriteArraySet f2411b = new CopyOnWriteArraySet();
    private C1390b f2412c;
    private C1387g f2413d;

    public interface C1389a {
        void mo2242a(C1387g c1387g);
    }

    public interface C1390b {
    }

    public abstract C1387g mo2144a(C1353l[] c1353lArr, C1631h c1631h);

    public C1381h(Handler handler) {
        this.f2410a = (Handler) C1392a.m2707a((Object) handler);
    }

    public final void m2677a(C1389a c1389a) {
        this.f2411b.add(c1389a);
    }

    public final void m2678a(C1390b c1390b) {
        this.f2412c = c1390b;
    }

    public final void m2676a(C1387g c1387g) {
        this.f2413d = c1387g;
        m2674b(c1387g);
    }

    private void m2674b(final C1387g c1387g) {
        if (this.f2410a != null) {
            this.f2410a.post(new Runnable(this) {
                final /* synthetic */ C1381h f2435b;

                public void run() {
                    Iterator it = this.f2435b.f2411b.iterator();
                    while (it.hasNext()) {
                        ((C1389a) it.next()).mo2242a(c1387g);
                    }
                }
            });
        }
    }
}
