package com.google.android.exoplayer2.p032b;

import android.os.Handler;
import android.util.SparseArray;
import android.util.SparseBooleanArray;
import com.google.android.exoplayer2.C1353l;
import com.google.android.exoplayer2.p032b.C1375f.C1373a;
import com.google.android.exoplayer2.source.C1630g;
import com.google.android.exoplayer2.source.C1631h;
import java.util.Arrays;
import java.util.Map;

public abstract class C1382e extends C1381h {
    private final SparseArray f2414a = new SparseArray();
    private final SparseBooleanArray f2415b = new SparseBooleanArray();

    public static final class C1385a {
        private final int[] f2421a;
        private final C1631h[] f2422b;
        private final int[] f2423c;
        private final int[][][] f2424d;
        private final C1631h f2425e;
        private final int f2426f;

        C1385a(int[] iArr, C1631h[] c1631hArr, int[] iArr2, int[][][] iArr3, C1631h c1631h) {
            this.f2421a = iArr;
            this.f2422b = c1631hArr;
            this.f2424d = iArr3;
            this.f2423c = iArr2;
            this.f2425e = c1631h;
            this.f2426f = c1631hArr.length;
        }
    }

    public static final class C1386b {
        public final C1373a f2427a;
        public final int f2428b;
        public final int[] f2429c;

        public C1375f m2700a(C1631h c1631h) {
            return this.f2427a.mo2139b(c1631h.m3883a(this.f2428b), this.f2429c);
        }
    }

    protected abstract C1375f[] mo2145a(C1353l[] c1353lArr, C1631h[] c1631hArr, int[][][] iArr);

    public C1382e(Handler handler) {
        super(handler);
    }

    public final C1387g mo2144a(C1353l[] c1353lArr, C1631h c1631h) {
        int i;
        int[] iArr;
        int i2 = 0;
        int[] iArr2 = new int[(c1353lArr.length + 1)];
        C1630g[][] c1630gArr = new C1630g[(c1353lArr.length + 1)][];
        int[][][] iArr3 = new int[(c1353lArr.length + 1)][][];
        for (i = 0; i < c1630gArr.length; i++) {
            c1630gArr[i] = new C1630g[c1631h.f3571a];
            iArr3[i] = new int[c1631h.f3571a][];
        }
        int[] a = C1382e.m2681a(c1353lArr);
        for (i = 0; i < c1631h.f3571a; i++) {
            C1630g a2 = c1631h.m3883a(i);
            int a3 = C1382e.m2679a(c1353lArr, a2);
            if (a3 == c1353lArr.length) {
                iArr = new int[a2.f3568a];
            } else {
                iArr = C1382e.m2680a(c1353lArr[a3], a2);
            }
            int i3 = iArr2[a3];
            c1630gArr[a3][i3] = a2;
            iArr3[a3][i3] = iArr;
            iArr2[a3] = iArr2[a3] + 1;
        }
        C1631h[] c1631hArr = new C1631h[c1353lArr.length];
        iArr = new int[c1353lArr.length];
        for (a3 = 0; a3 < c1353lArr.length; a3++) {
            i3 = iArr2[a3];
            c1631hArr[a3] = new C1631h((C1630g[]) Arrays.copyOf(c1630gArr[a3], i3));
            iArr3[a3] = (int[][]) Arrays.copyOf(iArr3[a3], i3);
            iArr[a3] = c1353lArr[a3].mo2096a();
        }
        C1631h c1631h2 = new C1631h((C1630g[]) Arrays.copyOf(c1630gArr[c1353lArr.length], iArr2[c1353lArr.length]));
        C1375f[] a4 = mo2145a(c1353lArr, c1631hArr, iArr3);
        while (i2 < c1353lArr.length) {
            if (this.f2415b.get(i2)) {
                a4[i2] = null;
            } else {
                C1631h c1631h3 = c1631hArr[i2];
                Map map = (Map) this.f2414a.get(i2);
                C1386b c1386b = map == null ? null : (C1386b) map.get(c1631h3);
                if (c1386b != null) {
                    a4[i2] = c1386b.m2700a(c1631h3);
                }
            }
            i2++;
        }
        return new C1387g(new C1385a(iArr, c1631hArr, a, iArr3, c1631h2), a4);
    }

    private static int m2679a(C1353l[] c1353lArr, C1630g c1630g) {
        int i = 0;
        int length = c1353lArr.length;
        for (int i2 = 0; i2 < c1353lArr.length; i2++) {
            C1353l c1353l = c1353lArr[i2];
            int i3 = 0;
            while (i3 < c1630g.f3568a) {
                int a = c1353l.mo2119a(c1630g.m3881a(i3));
                if (a <= i) {
                    a = length;
                    length = i;
                } else if (a == 3) {
                    return i2;
                } else {
                    length = a;
                    a = i2;
                }
                i3++;
                i = length;
                length = a;
            }
        }
        return length;
    }

    private static int[] m2680a(C1353l c1353l, C1630g c1630g) {
        int[] iArr = new int[c1630g.f3568a];
        for (int i = 0; i < c1630g.f3568a; i++) {
            iArr[i] = c1353l.mo2119a(c1630g.m3881a(i));
        }
        return iArr;
    }

    private static int[] m2681a(C1353l[] c1353lArr) {
        int[] iArr = new int[c1353lArr.length];
        for (int i = 0; i < iArr.length; i++) {
            iArr[i] = c1353lArr[i].mo2112l();
        }
        return iArr;
    }
}
