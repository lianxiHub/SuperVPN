package com.google.android.exoplayer2.p032b;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.source.C1630g;
import java.util.Arrays;
import java.util.Comparator;

public abstract class C1376b implements C1375f {
    protected final C1630g f2386a;
    protected final int f2387b;
    protected final int[] f2388c;
    private final Format[] f2389d;
    private final long[] f2390e;
    private int f2391f;

    private static final class C1379a implements Comparator {
        private C1379a() {
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m2672a((Format) obj, (Format) obj2);
        }

        public int m2672a(Format format, Format format2) {
            return format2.f2180b - format.f2180b;
        }
    }

    public C1376b(C1630g c1630g, int... iArr) {
        int i = 0;
        C1392a.m2711b(iArr.length > 0);
        this.f2386a = (C1630g) C1392a.m2707a((Object) c1630g);
        this.f2387b = iArr.length;
        this.f2389d = new Format[this.f2387b];
        for (int i2 = 0; i2 < iArr.length; i2++) {
            this.f2389d[i2] = c1630g.m3881a(iArr[i2]);
        }
        Arrays.sort(this.f2389d, new C1379a());
        this.f2388c = new int[this.f2387b];
        while (i < this.f2387b) {
            this.f2388c[i] = c1630g.m3880a(this.f2389d[i]);
            i++;
        }
        this.f2390e = new long[this.f2387b];
    }

    public final C1630g mo2141a() {
        return this.f2386a;
    }

    public final int mo2142b() {
        return this.f2388c.length;
    }

    public final Format mo2140a(int i) {
        return this.f2389d[i];
    }

    public final int mo2143b(int i) {
        return this.f2388c[i];
    }

    protected final boolean m2668a(int i, long j) {
        return this.f2390e[i] > j;
    }

    public int hashCode() {
        if (this.f2391f == 0) {
            this.f2391f = (System.identityHashCode(this.f2386a) * 31) + Arrays.hashCode(this.f2388c);
        }
        return this.f2391f;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        C1376b c1376b = (C1376b) obj;
        if (this.f2386a == c1376b.f2386a && Arrays.equals(this.f2388c, c1376b.f2388c)) {
            return true;
        }
        return false;
    }
}
