package com.google.android.exoplayer2.p032b;

import android.graphics.Point;
import android.os.Handler;
import android.text.TextUtils;
import com.google.android.exoplayer2.C1353l;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.p031c.C1414r;
import com.google.android.exoplayer2.p032b.C1375f.C1373a;
import com.google.android.exoplayer2.source.C1630g;
import com.google.android.exoplayer2.source.C1631h;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

public class C1383c extends C1382e {
    private static final int[] f2416a = new int[0];
    private final C1373a f2417b;
    private final AtomicReference f2418c = new AtomicReference(new C1380a());

    public static final class C1380a {
        public final String f2400a;
        public final String f2401b;
        public final boolean f2402c;
        public final boolean f2403d;
        public final int f2404e;
        public final int f2405f;
        public final boolean f2406g;
        public final int f2407h;
        public final int f2408i;
        public final boolean f2409j;

        public C1380a() {
            this(null, null, false, true, Integer.MAX_VALUE, Integer.MAX_VALUE, true, Integer.MAX_VALUE, Integer.MAX_VALUE, true);
        }

        public C1380a(String str, String str2, boolean z, boolean z2, int i, int i2, boolean z3, int i3, int i4, boolean z4) {
            this.f2400a = str;
            this.f2401b = str2;
            this.f2402c = z;
            this.f2403d = z2;
            this.f2404e = i;
            this.f2405f = i2;
            this.f2406g = z3;
            this.f2407h = i3;
            this.f2408i = i4;
            this.f2409j = z4;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            C1380a c1380a = (C1380a) obj;
            if (this.f2402c == c1380a.f2402c && this.f2403d == c1380a.f2403d && this.f2404e == c1380a.f2404e && this.f2405f == c1380a.f2405f && this.f2406g == c1380a.f2406g && this.f2409j == c1380a.f2409j && this.f2407h == c1380a.f2407h && this.f2408i == c1380a.f2408i && TextUtils.equals(this.f2400a, c1380a.f2400a) && TextUtils.equals(this.f2401b, c1380a.f2401b)) {
                return true;
            }
            return false;
        }

        public int hashCode() {
            int i;
            int i2 = 1;
            int hashCode = ((this.f2402c ? 1 : 0) + (((this.f2400a.hashCode() * 31) + this.f2401b.hashCode()) * 31)) * 31;
            if (this.f2403d) {
                i = 1;
            } else {
                i = 0;
            }
            hashCode = (((((i + hashCode) * 31) + this.f2404e) * 31) + this.f2405f) * 31;
            if (this.f2406g) {
                i = 1;
            } else {
                i = 0;
            }
            i = (i + hashCode) * 31;
            if (!this.f2409j) {
                i2 = 0;
            }
            return ((((i + i2) * 31) + this.f2407h) * 31) + this.f2408i;
        }
    }

    public C1383c(Handler handler, C1373a c1373a) {
        super(handler);
        this.f2417b = c1373a;
    }

    protected C1375f[] mo2145a(C1353l[] c1353lArr, C1631h[] c1631hArr, int[][][] iArr) {
        C1375f[] c1375fArr = new C1375f[c1353lArr.length];
        C1380a c1380a = (C1380a) this.f2418c.get();
        for (int i = 0; i < c1353lArr.length; i++) {
            switch (c1353lArr[i].mo2096a()) {
                case 1:
                    c1375fArr[i] = m2697a(c1631hArr[i], iArr[i], c1380a.f2400a);
                    break;
                case 2:
                    c1375fArr[i] = m2696a(c1353lArr[i], c1631hArr[i], iArr[i], c1380a.f2404e, c1380a.f2405f, c1380a.f2403d, c1380a.f2402c, c1380a.f2407h, c1380a.f2408i, c1380a.f2409j, this.f2417b, c1380a.f2406g);
                    break;
                case 3:
                    c1375fArr[i] = m2698a(c1631hArr[i], iArr[i], c1380a.f2401b, c1380a.f2400a);
                    break;
                default:
                    c1375fArr[i] = m2695a(c1353lArr[i].mo2096a(), c1631hArr[i], iArr[i]);
                    break;
            }
        }
        return c1375fArr;
    }

    protected C1375f m2696a(C1353l c1353l, C1631h c1631h, int[][] iArr, int i, int i2, boolean z, boolean z2, int i3, int i4, boolean z3, C1373a c1373a, boolean z4) {
        C1375f c1375f = null;
        if (c1373a != null) {
            c1375f = C1383c.m2687a(c1353l, c1631h, iArr, i, i2, z, z2, i3, i4, z3, c1373a);
        }
        if (c1375f == null) {
            return C1383c.m2688a(c1631h, iArr, i, i2, i3, i4, z3, z4);
        }
        return c1375f;
    }

    private static C1375f m2687a(C1353l c1353l, C1631h c1631h, int[][] iArr, int i, int i2, boolean z, boolean z2, int i3, int i4, boolean z3, C1373a c1373a) {
        int i5 = z ? 12 : 8;
        boolean z4 = z2 && (c1353l.mo2112l() & i5) != 0;
        for (int i6 = 0; i6 < c1631h.f3571a; i6++) {
            C1630g a = c1631h.m3883a(i6);
            int[] a2 = C1383c.m2693a(a, iArr[i6], z4, i5, i, i2, i3, i4, z3);
            if (a2.length > 0) {
                return c1373a.mo2139b(a, a2);
            }
        }
        return null;
    }

    private static int[] m2693a(C1630g c1630g, int[] iArr, boolean z, int i, int i2, int i3, int i4, int i5, boolean z2) {
        if (c1630g.f3568a < 2) {
            return f2416a;
        }
        List a = C1383c.m2689a(c1630g, i4, i5, z2);
        if (a.size() < 2) {
            return f2416a;
        }
        String str;
        String str2 = null;
        if (z) {
            str = null;
        } else {
            HashSet hashSet = new HashSet();
            int i6 = 0;
            int i7 = 0;
            while (i7 < a.size()) {
                int a2;
                str = c1630g.m3881a(((Integer) a.get(i7)).intValue()).f2183e;
                if (!hashSet.contains(str)) {
                    hashSet.add(str);
                    a2 = C1383c.m2685a(c1630g, iArr, i, str, i2, i3, a);
                    if (a2 > i6) {
                        i7++;
                        i6 = a2;
                        str2 = str;
                    }
                }
                a2 = i6;
                str = str2;
                i7++;
                i6 = a2;
                str2 = str;
            }
            str = str2;
        }
        C1383c.m2694b(c1630g, iArr, i, str, i2, i3, a);
        return a.size() < 2 ? f2416a : C1414r.m2824a(a);
    }

    private static int m2685a(C1630g c1630g, int[] iArr, int i, String str, int i2, int i3, List list) {
        int i4 = 0;
        int i5 = 0;
        while (i4 < list.size()) {
            int intValue = ((Integer) list.get(i4)).intValue();
            if (C1383c.m2692a(c1630g.m3881a(intValue), str, iArr[intValue], i, i2, i3)) {
                intValue = i5 + 1;
            } else {
                intValue = i5;
            }
            i4++;
            i5 = intValue;
        }
        return i5;
    }

    private static void m2694b(C1630g c1630g, int[] iArr, int i, String str, int i2, int i3, List list) {
        for (int size = list.size() - 1; size >= 0; size--) {
            int intValue = ((Integer) list.get(size)).intValue();
            if (!C1383c.m2692a(c1630g.m3881a(intValue), str, iArr[intValue], i, i2, i3)) {
                list.remove(size);
            }
        }
    }

    private static boolean m2692a(Format format, String str, int i, int i2, int i3, int i4) {
        return C1383c.m2690a(i) && (i & i2) != 0 && ((str == null || C1414r.m2823a(format.f2183e, (Object) str)) && ((format.f2187i == -1 || format.f2187i <= i3) && (format.f2188j == -1 || format.f2188j <= i4)));
    }

    private static C1375f m2688a(C1631h c1631h, int[][] iArr, int i, int i2, int i3, int i4, boolean z, boolean z2) {
        C1630g c1630g = null;
        int i5 = 0;
        int i6 = -1;
        Object obj = null;
        for (int i7 = 0; i7 < c1631h.f3571a; i7++) {
            C1630g a = c1631h.m3883a(i7);
            List a2 = C1383c.m2689a(a, i3, i4, z);
            int[] iArr2 = iArr[i7];
            int i8 = 0;
            while (i8 < a.f3568a) {
                Object obj2;
                int a3;
                int i9;
                C1630g c1630g2;
                if (C1383c.m2690a(iArr2[i8])) {
                    Format a4 = a.m3881a(i8);
                    obj2 = (!a2.contains(Integer.valueOf(i8)) || ((a4.f2187i != -1 && a4.f2187i > i) || (a4.f2188j != -1 && a4.f2188j > i2))) ? null : 1;
                    a3 = a4.m2415a();
                    Object obj3 = obj != null ? (obj2 == null || C1383c.m2684a(a3, i6) <= 0) ? null : 1 : (obj2 != null || (z2 && (c1630g == null || C1383c.m2684a(a3, i6) < 0))) ? 1 : null;
                    if (obj3 != null) {
                        i9 = a3;
                        c1630g2 = a;
                        a3 = i8;
                        i8++;
                        i5 = a3;
                        c1630g = c1630g2;
                        i6 = i9;
                        obj = obj2;
                    }
                }
                obj2 = obj;
                a3 = i5;
                i9 = i6;
                c1630g2 = c1630g;
                i8++;
                i5 = a3;
                c1630g = c1630g2;
                i6 = i9;
                obj = obj2;
            }
        }
        return c1630g == null ? null : new C1384d(c1630g, i5);
    }

    private static int m2684a(int i, int i2) {
        return i == -1 ? i2 == -1 ? 0 : -1 : i2 == -1 ? 1 : i - i2;
    }

    protected C1375f m2697a(C1631h c1631h, int[][] iArr, String str) {
        Object obj = null;
        int i = 0;
        C1630g c1630g = null;
        for (int i2 = 0; i2 < c1631h.f3571a; i2++) {
            C1630g a = c1631h.m3883a(i2);
            int[] iArr2 = iArr[i2];
            int i3 = 0;
            while (i3 < a.f3568a) {
                Object obj2;
                int i4;
                C1630g c1630g2;
                if (C1383c.m2690a(iArr2[i3])) {
                    Format a2 = a.m3881a(i3);
                    if ((a2.f2200v & 1) != 0) {
                        obj2 = 1;
                    } else {
                        obj2 = null;
                    }
                    if (C1383c.m2691a(a2, str)) {
                        obj2 = obj2 != null ? 4 : 3;
                    } else if (obj2 != null) {
                        obj2 = 2;
                    } else {
                        int i5 = 1;
                    }
                    if (obj2 > obj) {
                        i4 = i3;
                        c1630g2 = a;
                        i3++;
                        c1630g = c1630g2;
                        i = i4;
                        obj = obj2;
                    }
                }
                obj2 = obj;
                i4 = i;
                c1630g2 = c1630g;
                i3++;
                c1630g = c1630g2;
                i = i4;
                obj = obj2;
            }
        }
        if (c1630g == null) {
            return null;
        }
        return new C1384d(c1630g, i);
    }

    protected C1375f m2698a(C1631h c1631h, int[][] iArr, String str, String str2) {
        C1630g c1630g = null;
        int i = 0;
        Object obj = null;
        for (int i2 = 0; i2 < c1631h.f3571a; i2++) {
            C1630g a = c1631h.m3883a(i2);
            int[] iArr2 = iArr[i2];
            int i3 = 0;
            while (i3 < a.f3568a) {
                Object obj2;
                int i4;
                C1630g c1630g2;
                if (C1383c.m2690a(iArr2[i3])) {
                    Format a2 = a.m3881a(i3);
                    obj2 = (a2.f2200v & 1) != 0 ? 1 : null;
                    Object obj3 = (a2.f2200v & 2) != 0 ? 1 : null;
                    if (C1383c.m2691a(a2, str)) {
                        if (obj2 != null) {
                            obj2 = 6;
                        } else if (obj3 == null) {
                            obj2 = 5;
                        } else {
                            obj2 = 4;
                        }
                    } else if (obj2 != null) {
                        obj2 = 3;
                    } else if (obj3 == null) {
                        obj2 = null;
                    } else if (C1383c.m2691a(a2, str2)) {
                        obj2 = 2;
                    } else {
                        obj2 = 1;
                    }
                    if (obj2 > obj) {
                        i4 = i3;
                        c1630g2 = a;
                        i3++;
                        c1630g = c1630g2;
                        i = i4;
                        obj = obj2;
                    }
                }
                obj2 = obj;
                i4 = i;
                c1630g2 = c1630g;
                i3++;
                c1630g = c1630g2;
                i = i4;
                obj = obj2;
            }
        }
        return c1630g == null ? null : new C1384d(c1630g, i);
    }

    protected C1375f m2695a(int i, C1631h c1631h, int[][] iArr) {
        Object obj = null;
        int i2 = 0;
        C1630g c1630g = null;
        for (int i3 = 0; i3 < c1631h.f3571a; i3++) {
            C1630g a = c1631h.m3883a(i3);
            int[] iArr2 = iArr[i3];
            int i4 = 0;
            while (i4 < a.f3568a) {
                Object obj2;
                int i5;
                C1630g c1630g2;
                if (C1383c.m2690a(iArr2[i4])) {
                    if ((a.m3881a(i4).f2200v & 1) != 0) {
                        obj2 = 1;
                    } else {
                        obj2 = null;
                    }
                    if (obj2 != null) {
                        obj2 = 2;
                    } else {
                        int i6 = 1;
                    }
                    if (obj2 > obj) {
                        i5 = i4;
                        c1630g2 = a;
                        i4++;
                        c1630g = c1630g2;
                        i2 = i5;
                        obj = obj2;
                    }
                }
                obj2 = obj;
                i5 = i2;
                c1630g2 = c1630g;
                i4++;
                c1630g = c1630g2;
                i2 = i5;
                obj = obj2;
            }
        }
        if (c1630g == null) {
            return null;
        }
        return new C1384d(c1630g, i2);
    }

    private static boolean m2690a(int i) {
        return (i & 3) == 3;
    }

    private static boolean m2691a(Format format, String str) {
        return str != null && str.equals(C1414r.m2827b(format.f2201w));
    }

    private static List m2689a(C1630g c1630g, int i, int i2, boolean z) {
        int i3;
        int i4 = 0;
        ArrayList arrayList = new ArrayList(c1630g.f3568a);
        for (i3 = 0; i3 < c1630g.f3568a; i3++) {
            arrayList.add(Integer.valueOf(i3));
        }
        if (i == Integer.MAX_VALUE || i2 == Integer.MAX_VALUE) {
            return arrayList;
        }
        int i5 = Integer.MAX_VALUE;
        while (i4 < c1630g.f3568a) {
            Format a = c1630g.m3881a(i4);
            if (a.f2187i > 0 && a.f2188j > 0) {
                Point a2 = C1383c.m2686a(z, i, i2, a.f2187i, a.f2188j);
                i3 = a.f2187i * a.f2188j;
                if (a.f2187i >= ((int) (((float) a2.x) * 0.98f)) && a.f2188j >= ((int) (((float) a2.y) * 0.98f)) && i3 < i5) {
                    i4++;
                    i5 = i3;
                }
            }
            i3 = i5;
            i4++;
            i5 = i3;
        }
        if (i5 != Integer.MAX_VALUE) {
            for (i4 = arrayList.size() - 1; i4 >= 0; i4--) {
                i3 = c1630g.m3881a(((Integer) arrayList.get(i4)).intValue()).m2415a();
                if (i3 == -1 || i3 > i5) {
                    arrayList.remove(i4);
                }
            }
        }
        return arrayList;
    }

    private static Point m2686a(boolean z, int i, int i2, int i3, int i4) {
        Object obj = 1;
        if (z) {
            Object obj2 = i3 > i4 ? 1 : null;
            if (i <= i2) {
                obj = null;
            }
            if (obj2 != obj) {
                int i5 = i;
                i = i2;
                i2 = i5;
            }
        }
        if (i3 * i2 >= i4 * i) {
            return new Point(i, C1414r.m2813a(i * i4, i3));
        }
        return new Point(C1414r.m2813a(i2 * i3, i4), i2);
    }
}
