package com.google.android.exoplayer2;

import com.google.android.exoplayer2.C1434d.C1351b;
import com.google.android.exoplayer2.p031c.C1371g;
import com.google.android.exoplayer2.source.C1623d;

public interface C1352k extends C1351b {
    int mo2096a();

    void mo2097a(int i);

    void mo2099a(long j);

    void mo2120a(long j, long j2);

    void mo2100a(Format[] formatArr, C1623d c1623d, long j);

    void mo2101a(Format[] formatArr, C1623d c1623d, long j, boolean z, long j2);

    C1353l mo2102b();

    C1371g mo2103c();

    int mo2104d();

    void mo2105e();

    C1623d mo2106f();

    boolean mo2107g();

    void mo2108h();

    void mo2109i();

    void mo2110j();

    void mo2111k();

    boolean mo2126r();

    boolean mo2127s();
}
