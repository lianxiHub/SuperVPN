package com.google.android.exoplayer2;

import com.jrzheng.supervpnfree.R;

public final class C1587j {

    public static final class C1582a {
        public static final int exo_controls_fastforward = 2130837659;
        public static final int exo_controls_next = 2130837660;
        public static final int exo_controls_pause = 2130837661;
        public static final int exo_controls_play = 2130837662;
        public static final int exo_controls_previous = 2130837663;
        public static final int exo_controls_rewind = 2130837664;
    }

    public static final class C1583b {
        public static final int control = 2131361952;
        public static final int ffwd = 2131361944;
        public static final int fit = 2131361808;
        public static final int fixed_height = 2131361809;
        public static final int fixed_width = 2131361810;
        public static final int mediacontroller_progress = 2131361947;
        public static final int next = 2131361945;
        public static final int play = 2131361943;
        public static final int prev = 2131361941;
        public static final int rew = 2131361942;
        public static final int shutter = 2131361950;
        public static final int subtitles = 2131361951;
        public static final int time = 2131361948;
        public static final int time_current = 2131361946;
        public static final int video_frame = 2131361949;
    }

    public static final class C1584c {
        public static final int exo_playback_control_view = 2130903073;
        public static final int exo_simple_player_view = 2130903074;
    }

    public static final class C1585d {
        public static final int exo_controls_fastforward_description = 2131034169;
        public static final int exo_controls_next_description = 2131034170;
        public static final int exo_controls_pause_description = 2131034171;
        public static final int exo_controls_play_description = 2131034172;
        public static final int exo_controls_previous_description = 2131034173;
        public static final int exo_controls_rewind_description = 2131034174;
        public static final int exo_controls_stop_description = 2131034175;
    }

    public static final class C1586e {
        public static final int[] AspectRatioFrameLayout = new int[]{R.attr.resize_mode};
        public static final int AspectRatioFrameLayout_resize_mode = 0;
        public static final int[] PlaybackControlView = new int[]{R.attr.fastforward_increment, R.attr.rewind_increment, R.attr.show_timeout};
        public static final int PlaybackControlView_fastforward_increment = 0;
        public static final int PlaybackControlView_rewind_increment = 1;
        public static final int PlaybackControlView_show_timeout = 2;
        public static final int[] SimpleExoPlayerView = new int[]{R.attr.fastforward_increment, R.attr.resize_mode, R.attr.rewind_increment, R.attr.show_timeout, R.attr.use_controller, R.attr.use_texture_view};
        public static final int SimpleExoPlayerView_fastforward_increment = 0;
        public static final int SimpleExoPlayerView_resize_mode = 1;
        public static final int SimpleExoPlayerView_rewind_increment = 2;
        public static final int SimpleExoPlayerView_show_timeout = 3;
        public static final int SimpleExoPlayerView_use_controller = 4;
        public static final int SimpleExoPlayerView_use_texture_view = 5;
    }
}
