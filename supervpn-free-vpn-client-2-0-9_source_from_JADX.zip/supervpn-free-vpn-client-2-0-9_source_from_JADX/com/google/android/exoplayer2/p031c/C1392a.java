package com.google.android.exoplayer2.p031c;

import android.text.TextUtils;

public final class C1392a {
    public static void m2709a(boolean z) {
        if (!z) {
            throw new IllegalArgumentException();
        }
    }

    public static void m2710a(boolean z, Object obj) {
        if (!z) {
            throw new IllegalArgumentException(String.valueOf(obj));
        }
    }

    public static int m2706a(int i, int i2, int i3) {
        if (i >= i2 && i < i3) {
            return i;
        }
        throw new IndexOutOfBoundsException();
    }

    public static void m2711b(boolean z) {
        if (!z) {
            throw new IllegalStateException();
        }
    }

    public static void m2712b(boolean z, Object obj) {
        if (!z) {
            throw new IllegalStateException(String.valueOf(obj));
        }
    }

    public static Object m2707a(Object obj) {
        if (obj != null) {
            return obj;
        }
        throw new NullPointerException();
    }

    public static String m2708a(String str) {
        if (!TextUtils.isEmpty(str)) {
            return str;
        }
        throw new IllegalArgumentException();
    }
}
