package com.google.android.exoplayer2.p031c;

import android.support.v4.internal.view.SupportMenu;
import android.support.v4.view.InputDeviceCompat;
import android.text.TextUtils;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class C1394c {
    private static final Pattern f2443a = Pattern.compile("^rgb\\((\\d{1,3}),(\\d{1,3}),(\\d{1,3})\\)$");
    private static final Pattern f2444b = Pattern.compile("^rgba\\((\\d{1,3}),(\\d{1,3}),(\\d{1,3}),(\\d{1,3})\\)$");
    private static final Pattern f2445c = Pattern.compile("^rgba\\((\\d{1,3}),(\\d{1,3}),(\\d{1,3}),(\\d*\\.?\\d*?)\\)$");
    private static final Map f2446d = new HashMap();

    static {
        f2446d.put("aliceblue", Integer.valueOf(-984833));
        f2446d.put("antiquewhite", Integer.valueOf(-332841));
        f2446d.put("aqua", Integer.valueOf(-16711681));
        f2446d.put("aquamarine", Integer.valueOf(-8388652));
        f2446d.put("azure", Integer.valueOf(-983041));
        f2446d.put("beige", Integer.valueOf(-657956));
        f2446d.put("bisque", Integer.valueOf(-6972));
        f2446d.put("black", Integer.valueOf(-16777216));
        f2446d.put("blanchedalmond", Integer.valueOf(-5171));
        f2446d.put("blue", Integer.valueOf(-16776961));
        f2446d.put("blueviolet", Integer.valueOf(-7722014));
        f2446d.put("brown", Integer.valueOf(-5952982));
        f2446d.put("burlywood", Integer.valueOf(-2180985));
        f2446d.put("cadetblue", Integer.valueOf(-10510688));
        f2446d.put("chartreuse", Integer.valueOf(-8388864));
        f2446d.put("chocolate", Integer.valueOf(-2987746));
        f2446d.put("coral", Integer.valueOf(-32944));
        f2446d.put("cornflowerblue", Integer.valueOf(-10185235));
        f2446d.put("cornsilk", Integer.valueOf(-1828));
        f2446d.put("crimson", Integer.valueOf(-2354116));
        f2446d.put("cyan", Integer.valueOf(-16711681));
        f2446d.put("darkblue", Integer.valueOf(-16777077));
        f2446d.put("darkcyan", Integer.valueOf(-16741493));
        f2446d.put("darkgoldenrod", Integer.valueOf(-4684277));
        f2446d.put("darkgray", Integer.valueOf(-5658199));
        f2446d.put("darkgreen", Integer.valueOf(-16751616));
        f2446d.put("darkgrey", Integer.valueOf(-5658199));
        f2446d.put("darkkhaki", Integer.valueOf(-4343957));
        f2446d.put("darkmagenta", Integer.valueOf(-7667573));
        f2446d.put("darkolivegreen", Integer.valueOf(-11179217));
        f2446d.put("darkorange", Integer.valueOf(-29696));
        f2446d.put("darkorchid", Integer.valueOf(-6737204));
        f2446d.put("darkred", Integer.valueOf(-7667712));
        f2446d.put("darksalmon", Integer.valueOf(-1468806));
        f2446d.put("darkseagreen", Integer.valueOf(-7357297));
        f2446d.put("darkslateblue", Integer.valueOf(-12042869));
        f2446d.put("darkslategray", Integer.valueOf(-13676721));
        f2446d.put("darkslategrey", Integer.valueOf(-13676721));
        f2446d.put("darkturquoise", Integer.valueOf(-16724271));
        f2446d.put("darkviolet", Integer.valueOf(-7077677));
        f2446d.put("deeppink", Integer.valueOf(-60269));
        f2446d.put("deepskyblue", Integer.valueOf(-16728065));
        f2446d.put("dimgray", Integer.valueOf(-9868951));
        f2446d.put("dimgrey", Integer.valueOf(-9868951));
        f2446d.put("dodgerblue", Integer.valueOf(-14774017));
        f2446d.put("firebrick", Integer.valueOf(-5103070));
        f2446d.put("floralwhite", Integer.valueOf(-1296));
        f2446d.put("forestgreen", Integer.valueOf(-14513374));
        f2446d.put("fuchsia", Integer.valueOf(-65281));
        f2446d.put("gainsboro", Integer.valueOf(-2302756));
        f2446d.put("ghostwhite", Integer.valueOf(-460545));
        f2446d.put("gold", Integer.valueOf(-10496));
        f2446d.put("goldenrod", Integer.valueOf(-2448096));
        f2446d.put("gray", Integer.valueOf(-8355712));
        f2446d.put("green", Integer.valueOf(-16744448));
        f2446d.put("greenyellow", Integer.valueOf(-5374161));
        f2446d.put("grey", Integer.valueOf(-8355712));
        f2446d.put("honeydew", Integer.valueOf(-983056));
        f2446d.put("hotpink", Integer.valueOf(-38476));
        f2446d.put("indianred", Integer.valueOf(-3318692));
        f2446d.put("indigo", Integer.valueOf(-11861886));
        f2446d.put("ivory", Integer.valueOf(-16));
        f2446d.put("khaki", Integer.valueOf(-989556));
        f2446d.put("lavender", Integer.valueOf(-1644806));
        f2446d.put("lavenderblush", Integer.valueOf(-3851));
        f2446d.put("lawngreen", Integer.valueOf(-8586240));
        f2446d.put("lemonchiffon", Integer.valueOf(-1331));
        f2446d.put("lightblue", Integer.valueOf(-5383962));
        f2446d.put("lightcoral", Integer.valueOf(-1015680));
        f2446d.put("lightcyan", Integer.valueOf(-2031617));
        f2446d.put("lightgoldenrodyellow", Integer.valueOf(-329006));
        f2446d.put("lightgray", Integer.valueOf(-2894893));
        f2446d.put("lightgreen", Integer.valueOf(-7278960));
        f2446d.put("lightgrey", Integer.valueOf(-2894893));
        f2446d.put("lightpink", Integer.valueOf(-18751));
        f2446d.put("lightsalmon", Integer.valueOf(-24454));
        f2446d.put("lightseagreen", Integer.valueOf(-14634326));
        f2446d.put("lightskyblue", Integer.valueOf(-7876870));
        f2446d.put("lightslategray", Integer.valueOf(-8943463));
        f2446d.put("lightslategrey", Integer.valueOf(-8943463));
        f2446d.put("lightsteelblue", Integer.valueOf(-5192482));
        f2446d.put("lightyellow", Integer.valueOf(-32));
        f2446d.put("lime", Integer.valueOf(-16711936));
        f2446d.put("limegreen", Integer.valueOf(-13447886));
        f2446d.put("linen", Integer.valueOf(-331546));
        f2446d.put("magenta", Integer.valueOf(-65281));
        f2446d.put("maroon", Integer.valueOf(-8388608));
        f2446d.put("mediumaquamarine", Integer.valueOf(-10039894));
        f2446d.put("mediumblue", Integer.valueOf(-16777011));
        f2446d.put("mediumorchid", Integer.valueOf(-4565549));
        f2446d.put("mediumpurple", Integer.valueOf(-7114533));
        f2446d.put("mediumseagreen", Integer.valueOf(-12799119));
        f2446d.put("mediumslateblue", Integer.valueOf(-8689426));
        f2446d.put("mediumspringgreen", Integer.valueOf(-16713062));
        f2446d.put("mediumturquoise", Integer.valueOf(-12004916));
        f2446d.put("mediumvioletred", Integer.valueOf(-3730043));
        f2446d.put("midnightblue", Integer.valueOf(-15132304));
        f2446d.put("mintcream", Integer.valueOf(-655366));
        f2446d.put("mistyrose", Integer.valueOf(-6943));
        f2446d.put("moccasin", Integer.valueOf(-6987));
        f2446d.put("navajowhite", Integer.valueOf(-8531));
        f2446d.put("navy", Integer.valueOf(-16777088));
        f2446d.put("oldlace", Integer.valueOf(-133658));
        f2446d.put("olive", Integer.valueOf(-8355840));
        f2446d.put("olivedrab", Integer.valueOf(-9728477));
        f2446d.put("orange", Integer.valueOf(-23296));
        f2446d.put("orangered", Integer.valueOf(-47872));
        f2446d.put("orchid", Integer.valueOf(-2461482));
        f2446d.put("palegoldenrod", Integer.valueOf(-1120086));
        f2446d.put("palegreen", Integer.valueOf(-6751336));
        f2446d.put("paleturquoise", Integer.valueOf(-5247250));
        f2446d.put("palevioletred", Integer.valueOf(-2396013));
        f2446d.put("papayawhip", Integer.valueOf(-4139));
        f2446d.put("peachpuff", Integer.valueOf(-9543));
        f2446d.put("peru", Integer.valueOf(-3308225));
        f2446d.put("pink", Integer.valueOf(-16181));
        f2446d.put("plum", Integer.valueOf(-2252579));
        f2446d.put("powderblue", Integer.valueOf(-5185306));
        f2446d.put("purple", Integer.valueOf(-8388480));
        f2446d.put("rebeccapurple", Integer.valueOf(-10079335));
        f2446d.put("red", Integer.valueOf(SupportMenu.CATEGORY_MASK));
        f2446d.put("rosybrown", Integer.valueOf(-4419697));
        f2446d.put("royalblue", Integer.valueOf(-12490271));
        f2446d.put("saddlebrown", Integer.valueOf(-7650029));
        f2446d.put("salmon", Integer.valueOf(-360334));
        f2446d.put("sandybrown", Integer.valueOf(-744352));
        f2446d.put("seagreen", Integer.valueOf(-13726889));
        f2446d.put("seashell", Integer.valueOf(-2578));
        f2446d.put("sienna", Integer.valueOf(-6270419));
        f2446d.put("silver", Integer.valueOf(-4144960));
        f2446d.put("skyblue", Integer.valueOf(-7876885));
        f2446d.put("slateblue", Integer.valueOf(-9807155));
        f2446d.put("slategray", Integer.valueOf(-9404272));
        f2446d.put("slategrey", Integer.valueOf(-9404272));
        f2446d.put("snow", Integer.valueOf(-1286));
        f2446d.put("springgreen", Integer.valueOf(-16711809));
        f2446d.put("steelblue", Integer.valueOf(-12156236));
        f2446d.put("tan", Integer.valueOf(-2968436));
        f2446d.put("teal", Integer.valueOf(-16744320));
        f2446d.put("thistle", Integer.valueOf(-2572328));
        f2446d.put("tomato", Integer.valueOf(-40121));
        f2446d.put("transparent", Integer.valueOf(0));
        f2446d.put("turquoise", Integer.valueOf(-12525360));
        f2446d.put("violet", Integer.valueOf(-1146130));
        f2446d.put("wheat", Integer.valueOf(-663885));
        f2446d.put("white", Integer.valueOf(-1));
        f2446d.put("whitesmoke", Integer.valueOf(-657931));
        f2446d.put("yellow", Integer.valueOf(InputDeviceCompat.SOURCE_ANY));
        f2446d.put("yellowgreen", Integer.valueOf(-6632142));
    }

    public static int m2718a(String str) {
        return C1394c.m2719a(str, false);
    }

    public static int m2720b(String str) {
        return C1394c.m2719a(str, true);
    }

    private static int m2719a(String str, boolean z) {
        C1392a.m2709a(!TextUtils.isEmpty(str));
        Object replace = str.replace(" ", "");
        int parseLong;
        if (replace.charAt(0) == '#') {
            parseLong = (int) Long.parseLong(replace.substring(1), 16);
            if (replace.length() == 7) {
                return parseLong | -16777216;
            }
            if (replace.length() == 9) {
                return (parseLong >>> 8) | ((parseLong & 255) << 24);
            }
            throw new IllegalArgumentException();
        }
        if (replace.startsWith("rgba")) {
            Matcher matcher = (z ? f2445c : f2444b).matcher(replace);
            if (matcher.matches()) {
                if (z) {
                    parseLong = (int) (255.0f * Float.parseFloat(matcher.group(4)));
                } else {
                    parseLong = Integer.parseInt(matcher.group(4), 10);
                }
                return C1394c.m2717a(parseLong, Integer.parseInt(matcher.group(1), 10), Integer.parseInt(matcher.group(2), 10), Integer.parseInt(matcher.group(3), 10));
            }
        } else if (replace.startsWith("rgb")) {
            Matcher matcher2 = f2443a.matcher(replace);
            if (matcher2.matches()) {
                return C1394c.m2716a(Integer.parseInt(matcher2.group(1), 10), Integer.parseInt(matcher2.group(2), 10), Integer.parseInt(matcher2.group(3), 10));
            }
        } else {
            Integer num = (Integer) f2446d.get(C1414r.m2829d(replace));
            if (num != null) {
                return num.intValue();
            }
        }
        throw new IllegalArgumentException();
    }

    private static int m2717a(int i, int i2, int i3, int i4) {
        return (((i << 24) | (i2 << 16)) | (i3 << 8)) | i4;
    }

    private static int m2716a(int i, int i2, int i3) {
        return C1394c.m2717a(255, i, i2, i3);
    }
}
