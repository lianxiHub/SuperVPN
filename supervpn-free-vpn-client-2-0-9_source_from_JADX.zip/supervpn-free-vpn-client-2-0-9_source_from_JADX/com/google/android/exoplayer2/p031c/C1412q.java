package com.google.android.exoplayer2.p031c;

import android.annotation.TargetApi;
import android.os.Trace;

public final class C1412q {
    public static void m2809a(String str) {
        if (C1414r.f2503a >= 18) {
            C1412q.m2811b(str);
        }
    }

    public static void m2808a() {
        if (C1414r.f2503a >= 18) {
            C1412q.m2810b();
        }
    }

    @TargetApi(18)
    private static void m2811b(String str) {
        Trace.beginSection(str);
    }

    @TargetApi(18)
    private static void m2810b() {
        Trace.endSection();
    }
}
