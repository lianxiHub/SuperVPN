package com.google.android.exoplayer2.p031c;

import android.util.Pair;

public final class C1393b {
    private static final byte[] f2440a = new byte[]{(byte) 0, (byte) 0, (byte) 0, (byte) 1};
    private static final int[] f2441b = new int[]{96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350};
    private static final int[] f2442c = new int[]{0, 1, 2, 3, 4, 5, 6, 8, -1, -1, -1, 7, 8, -1, 8, -1};

    public static Pair m2713a(byte[] bArr) {
        int c;
        boolean z;
        boolean z2 = true;
        C1402j c1402j = new C1402j(bArr);
        int c2 = c1402j.m2750c(5);
        int c3 = c1402j.m2750c(4);
        if (c3 == 15) {
            c = c1402j.m2750c(24);
        } else {
            if (c3 < 13) {
                z = true;
            } else {
                z = false;
            }
            C1392a.m2709a(z);
            c = f2441b[c3];
        }
        c3 = c1402j.m2750c(4);
        if (c2 == 5 || c2 == 29) {
            c2 = c1402j.m2750c(4);
            if (c2 == 15) {
                c = c1402j.m2750c(24);
            } else {
                if (c2 < 13) {
                    z = true;
                } else {
                    z = false;
                }
                C1392a.m2709a(z);
                c = f2441b[c2];
            }
            if (c1402j.m2750c(5) == 22) {
                c3 = c;
                c = c1402j.m2750c(4);
                c = f2442c[c];
                if (c == -1) {
                    z2 = false;
                }
                C1392a.m2709a(z2);
                return Pair.create(Integer.valueOf(c3), Integer.valueOf(c));
            }
        }
        int i = c3;
        c3 = c;
        c = i;
        c = f2442c[c];
        if (c == -1) {
            z2 = false;
        }
        C1392a.m2709a(z2);
        return Pair.create(Integer.valueOf(c3), Integer.valueOf(c));
    }

    public static byte[] m2714a(int i, int i2, int i3) {
        return new byte[]{(byte) (((i << 3) & 248) | ((i2 >> 1) & 7)), (byte) (((i2 << 7) & 128) | ((i3 << 3) & 120))};
    }

    public static byte[] m2715a(byte[] bArr, int i, int i2) {
        Object obj = new byte[(f2440a.length + i2)];
        System.arraycopy(f2440a, 0, obj, 0, f2440a.length);
        System.arraycopy(bArr, i, obj, f2440a.length, i2);
        return obj;
    }
}
