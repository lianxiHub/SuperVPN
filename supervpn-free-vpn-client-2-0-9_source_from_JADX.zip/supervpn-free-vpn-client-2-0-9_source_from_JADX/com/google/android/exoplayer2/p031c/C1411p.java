package com.google.android.exoplayer2.p031c;

import android.os.SystemClock;

public final class C1411p implements C1371g {
    private boolean f2499a;
    private long f2500b;
    private long f2501c;

    public void m2804a() {
        if (!this.f2499a) {
            this.f2499a = true;
            this.f2501c = m2803b(this.f2500b);
        }
    }

    public void m2806b() {
        if (this.f2499a) {
            this.f2500b = m2803b(this.f2501c);
            this.f2499a = false;
        }
    }

    public void m2805a(long j) {
        this.f2500b = j;
        this.f2501c = m2803b(j);
    }

    public long mo2136t() {
        return this.f2499a ? m2803b(this.f2501c) : this.f2500b;
    }

    private long m2803b(long j) {
        return (SystemClock.elapsedRealtime() * 1000) - j;
    }
}
