package com.google.android.exoplayer2.p031c;

public final class C1404l {
    private byte[] f2482a;
    private int f2483b;
    private int f2484c;
    private int f2485d;

    public C1404l(byte[] bArr, int i, int i2) {
        m2789a(bArr, i, i2);
    }

    public void m2789a(byte[] bArr, int i, int i2) {
        this.f2482a = bArr;
        this.f2484c = i;
        this.f2483b = i2;
        this.f2485d = 0;
        m2787f();
    }

    public void m2788a(int i) {
        int i2 = this.f2484c;
        this.f2484c += i / 8;
        this.f2485d += i % 8;
        if (this.f2485d > 7) {
            this.f2484c++;
            this.f2485d -= 8;
        }
        i2++;
        while (i2 <= this.f2484c) {
            if (m2785d(i2)) {
                this.f2484c++;
                i2 += 2;
            }
            i2++;
        }
        m2787f();
    }

    public boolean m2792b(int i) {
        int i2 = this.f2484c;
        int i3 = (i / 8) + this.f2484c;
        int i4 = this.f2485d + (i % 8);
        if (i4 > 7) {
            i3++;
            i4 -= 8;
        }
        int i5 = i2 + 1;
        i2 = i3;
        i3 = i5;
        while (i3 <= i2 && i2 < this.f2483b) {
            if (m2785d(i3)) {
                i2++;
                i3 += 2;
            }
            i3++;
        }
        return i2 < this.f2483b || (i2 == this.f2483b && i4 == 0);
    }

    public boolean m2790a() {
        return m2794c(1) == 1;
    }

    public int m2794c(int i) {
        int i2 = 0;
        if (i != 0) {
            int i3;
            int i4;
            int i5 = i / 8;
            int i6 = 0;
            for (i3 = 0; i3 < i5; i3++) {
                i2 = m2785d(this.f2484c + 1) ? this.f2484c + 2 : this.f2484c + 1;
                if (this.f2485d != 0) {
                    i4 = ((this.f2482a[this.f2484c] & 255) << this.f2485d) | ((this.f2482a[i2] & 255) >>> (8 - this.f2485d));
                } else {
                    i4 = this.f2482a[this.f2484c];
                }
                i -= 8;
                i6 |= (i4 & 255) << i;
                this.f2484c = i2;
            }
            if (i > 0) {
                i3 = this.f2485d + i;
                byte b = (byte) (255 >> (8 - i));
                i4 = m2785d(this.f2484c + 1) ? this.f2484c + 2 : this.f2484c + 1;
                if (i3 > 8) {
                    i2 = ((((this.f2482a[this.f2484c] & 255) << (i3 - 8)) | ((this.f2482a[i4] & 255) >> (16 - i3))) & b) | i6;
                    this.f2484c = i4;
                } else {
                    i2 = (((this.f2482a[this.f2484c] & 255) >> (8 - i3)) & b) | i6;
                    if (i3 == 8) {
                        this.f2484c = i4;
                    }
                }
                this.f2485d = i3 % 8;
            } else {
                i2 = i6;
            }
            m2787f();
        }
        return i2;
    }

    public boolean m2791b() {
        boolean z;
        int i = this.f2484c;
        int i2 = this.f2485d;
        int i3 = 0;
        while (this.f2484c < this.f2483b && !m2790a()) {
            i3++;
        }
        if (this.f2484c == this.f2483b) {
            z = true;
        } else {
            z = false;
        }
        this.f2484c = i;
        this.f2485d = i2;
        if (z || !m2792b((i3 * 2) + 1)) {
            return false;
        }
        return true;
    }

    public int m2793c() {
        return m2786e();
    }

    public int m2795d() {
        int e = m2786e();
        return (e % 2 == 0 ? -1 : 1) * ((e + 1) / 2);
    }

    private int m2786e() {
        int i = 0;
        int i2 = 0;
        while (!m2790a()) {
            i2++;
        }
        int i3 = (1 << i2) - 1;
        if (i2 > 0) {
            i = m2794c(i2);
        }
        return i3 + i;
    }

    private boolean m2785d(int i) {
        return 2 <= i && i < this.f2483b && this.f2482a[i] == (byte) 3 && this.f2482a[i - 2] == (byte) 0 && this.f2482a[i - 1] == (byte) 0;
    }

    private void m2787f() {
        boolean z = this.f2484c >= 0 && this.f2485d >= 0 && this.f2485d < 8 && (this.f2484c < this.f2483b || (this.f2484c == this.f2483b && this.f2485d == 0));
        C1392a.m2711b(z);
    }
}
