package com.google.android.exoplayer2.p031c;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public final class C1410o {
    private static final Comparator f2490a = new C14071();
    private static final Comparator f2491b = new C14082();
    private final int f2492c;
    private final ArrayList f2493d = new ArrayList();
    private final C1409a[] f2494e = new C1409a[5];
    private int f2495f = -1;
    private int f2496g;
    private int f2497h;
    private int f2498i;

    static class C14071 implements Comparator {
        C14071() {
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m2797a((C1409a) obj, (C1409a) obj2);
        }

        public int m2797a(C1409a c1409a, C1409a c1409a2) {
            return c1409a.f2487a - c1409a2.f2487a;
        }
    }

    static class C14082 implements Comparator {
        C14082() {
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m2798a((C1409a) obj, (C1409a) obj2);
        }

        public int m2798a(C1409a c1409a, C1409a c1409a2) {
            if (c1409a.f2489c < c1409a2.f2489c) {
                return -1;
            }
            return c1409a2.f2489c < c1409a.f2489c ? 1 : 0;
        }
    }

    private static class C1409a {
        public int f2487a;
        public int f2488b;
        public float f2489c;

        private C1409a() {
        }
    }

    public C1410o(int i) {
        this.f2492c = i;
    }

    public void m2802a(int i, float f) {
        int i2;
        C1409a c1409a;
        m2799a();
        if (this.f2498i > 0) {
            C1409a[] c1409aArr = this.f2494e;
            i2 = this.f2498i - 1;
            this.f2498i = i2;
            c1409a = c1409aArr[i2];
        } else {
            c1409a = new C1409a();
        }
        i2 = this.f2496g;
        this.f2496g = i2 + 1;
        c1409a.f2487a = i2;
        c1409a.f2488b = i;
        c1409a.f2489c = f;
        this.f2493d.add(c1409a);
        this.f2497h += i;
        while (this.f2497h > this.f2492c) {
            i2 = this.f2497h - this.f2492c;
            c1409a = (C1409a) this.f2493d.get(0);
            if (c1409a.f2488b <= i2) {
                this.f2497h -= c1409a.f2488b;
                this.f2493d.remove(0);
                if (this.f2498i < 5) {
                    C1409a[] c1409aArr2 = this.f2494e;
                    int i3 = this.f2498i;
                    this.f2498i = i3 + 1;
                    c1409aArr2[i3] = c1409a;
                }
            } else {
                c1409a.f2488b -= i2;
                this.f2497h -= i2;
            }
        }
    }

    public float m2801a(float f) {
        m2800b();
        float f2 = f * ((float) this.f2497h);
        int i = 0;
        for (int i2 = 0; i2 < this.f2493d.size(); i2++) {
            C1409a c1409a = (C1409a) this.f2493d.get(i2);
            i += c1409a.f2488b;
            if (((float) i) >= f2) {
                return c1409a.f2489c;
            }
        }
        return this.f2493d.isEmpty() ? Float.NaN : ((C1409a) this.f2493d.get(this.f2493d.size() - 1)).f2489c;
    }

    private void m2799a() {
        if (this.f2495f != 1) {
            Collections.sort(this.f2493d, f2490a);
            this.f2495f = 1;
        }
    }

    private void m2800b() {
        if (this.f2495f != 0) {
            Collections.sort(this.f2493d, f2491b);
            this.f2495f = 0;
        }
    }
}
