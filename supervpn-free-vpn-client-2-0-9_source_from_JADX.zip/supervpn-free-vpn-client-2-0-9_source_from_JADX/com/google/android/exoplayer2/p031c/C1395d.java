package com.google.android.exoplayer2.p031c;

public final class C1395d {
    private boolean f2447a;

    public synchronized boolean m2721a() {
        boolean z = true;
        synchronized (this) {
            if (this.f2447a) {
                z = false;
            } else {
                this.f2447a = true;
                notifyAll();
            }
        }
        return z;
    }

    public synchronized boolean m2722b() {
        boolean z;
        z = this.f2447a;
        this.f2447a = false;
        return z;
    }

    public synchronized void m2723c() {
        while (!this.f2447a) {
            wait();
        }
    }
}
