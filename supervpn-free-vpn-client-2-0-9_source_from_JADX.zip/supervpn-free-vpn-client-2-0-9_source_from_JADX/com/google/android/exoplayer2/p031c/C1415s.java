package com.google.android.exoplayer2.p031c;

import org.xmlpull.v1.XmlPullParser;

public final class C1415s {
    public static boolean m2834a(XmlPullParser xmlPullParser, String str) {
        return C1415s.m2833a(xmlPullParser) && xmlPullParser.getName().equals(str);
    }

    public static boolean m2833a(XmlPullParser xmlPullParser) {
        return xmlPullParser.getEventType() == 3;
    }

    public static boolean m2836b(XmlPullParser xmlPullParser, String str) {
        return C1415s.m2835b(xmlPullParser) && xmlPullParser.getName().equals(str);
    }

    public static boolean m2835b(XmlPullParser xmlPullParser) {
        return xmlPullParser.getEventType() == 2;
    }

    public static String m2837c(XmlPullParser xmlPullParser, String str) {
        int attributeCount = xmlPullParser.getAttributeCount();
        for (int i = 0; i < attributeCount; i++) {
            if (str.equals(xmlPullParser.getAttributeName(i))) {
                return xmlPullParser.getAttributeValue(i);
            }
        }
        return null;
    }
}
