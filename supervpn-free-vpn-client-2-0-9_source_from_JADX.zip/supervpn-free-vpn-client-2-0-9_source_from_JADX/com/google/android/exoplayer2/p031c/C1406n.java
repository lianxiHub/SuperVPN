package com.google.android.exoplayer2.p031c;

import android.os.HandlerThread;
import android.os.Process;

public final class C1406n extends HandlerThread {
    private final int f2486a;

    public C1406n(String str, int i) {
        super(str);
        this.f2486a = i;
    }

    public void run() {
        Process.setThreadPriority(this.f2486a);
        super.run();
    }
}
