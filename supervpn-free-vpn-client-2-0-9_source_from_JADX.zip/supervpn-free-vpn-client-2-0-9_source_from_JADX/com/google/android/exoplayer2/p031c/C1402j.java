package com.google.android.exoplayer2.p031c;

public final class C1402j {
    public byte[] f2475a;
    private int f2476b;
    private int f2477c;
    private int f2478d;

    public C1402j(byte[] bArr) {
        this(bArr, bArr.length);
    }

    public C1402j(byte[] bArr, int i) {
        this.f2475a = bArr;
        this.f2478d = i;
    }

    public int m2746a() {
        return (this.f2476b * 8) + this.f2477c;
    }

    public void m2747a(int i) {
        this.f2476b = i / 8;
        this.f2477c = i - (this.f2476b * 8);
        m2745c();
    }

    public void m2748b(int i) {
        this.f2476b += i / 8;
        this.f2477c += i % 8;
        if (this.f2477c > 7) {
            this.f2476b++;
            this.f2477c -= 8;
        }
        m2745c();
    }

    public boolean m2749b() {
        return m2750c(1) == 1;
    }

    public int m2750c(int i) {
        int i2 = 0;
        if (i != 0) {
            int i3;
            int i4 = i / 8;
            int i5 = 0;
            for (i3 = 0; i3 < i4; i3++) {
                if (this.f2477c != 0) {
                    i2 = ((this.f2475a[this.f2476b] & 255) << this.f2477c) | ((this.f2475a[this.f2476b + 1] & 255) >>> (8 - this.f2477c));
                } else {
                    i2 = this.f2475a[this.f2476b];
                }
                i -= 8;
                i5 |= (i2 & 255) << i;
                this.f2476b++;
            }
            if (i > 0) {
                i3 = this.f2477c + i;
                byte b = (byte) (255 >> (8 - i));
                if (i3 > 8) {
                    i2 = (b & (((this.f2475a[this.f2476b] & 255) << (i3 - 8)) | ((this.f2475a[this.f2476b + 1] & 255) >> (16 - i3)))) | i5;
                    this.f2476b++;
                } else {
                    i2 = (b & ((this.f2475a[this.f2476b] & 255) >> (8 - i3))) | i5;
                    if (i3 == 8) {
                        this.f2476b++;
                    }
                }
                this.f2477c = i3 % 8;
            } else {
                i2 = i5;
            }
            m2745c();
        }
        return i2;
    }

    private void m2745c() {
        boolean z = this.f2476b >= 0 && this.f2477c >= 0 && this.f2477c < 8 && (this.f2476b < this.f2478d || (this.f2476b == this.f2478d && this.f2477c == 0));
        C1392a.m2711b(z);
    }
}
