package com.google.android.exoplayer2.p031c;

public interface C1405m {
    boolean mo2316a(Object obj);
}
