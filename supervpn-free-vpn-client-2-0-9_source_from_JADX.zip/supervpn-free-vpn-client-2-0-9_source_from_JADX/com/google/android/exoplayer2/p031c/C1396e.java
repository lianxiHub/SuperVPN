package com.google.android.exoplayer2.p031c;

public final class C1396e {
    public final int f2448a;
    public final int f2449b;
    public final int f2450c;
    public final int f2451d;
    public final int f2452e;
    public final int f2453f;
    public final int f2454g;
    public final long f2455h;

    public C1396e(byte[] bArr, int i) {
        C1402j c1402j = new C1402j(bArr);
        c1402j.m2747a(i * 8);
        this.f2448a = c1402j.m2750c(16);
        this.f2449b = c1402j.m2750c(16);
        this.f2450c = c1402j.m2750c(24);
        this.f2451d = c1402j.m2750c(24);
        this.f2452e = c1402j.m2750c(20);
        this.f2453f = c1402j.m2750c(3) + 1;
        this.f2454g = c1402j.m2750c(5) + 1;
        this.f2455h = (long) c1402j.m2750c(36);
    }

    public int m2724a() {
        return this.f2454g * this.f2452e;
    }

    public long m2725b() {
        return (this.f2455h * 1000000) / ((long) this.f2452e);
    }
}
