package com.google.android.exoplayer2.p031c;

import java.nio.charset.Charset;

public final class C1403k {
    public byte[] f2479a;
    private int f2480b;
    private int f2481c;

    public C1403k(int i) {
        this.f2479a = new byte[i];
        this.f2481c = i;
    }

    public C1403k(byte[] bArr) {
        this.f2479a = bArr;
        this.f2481c = bArr.length;
    }

    public C1403k(byte[] bArr, int i) {
        this.f2479a = bArr;
        this.f2481c = i;
    }

    public void m2753a(int i) {
        m2755a(m2763e() < i ? new byte[i] : this.f2479a, i);
    }

    public void m2755a(byte[] bArr, int i) {
        this.f2479a = bArr;
        this.f2481c = i;
        this.f2480b = 0;
    }

    public void m2752a() {
        this.f2480b = 0;
        this.f2481c = 0;
    }

    public int m2757b() {
        return this.f2481c - this.f2480b;
    }

    public int m2759c() {
        return this.f2481c;
    }

    public void m2758b(int i) {
        boolean z = i >= 0 && i <= this.f2479a.length;
        C1392a.m2709a(z);
        this.f2481c = i;
    }

    public int m2761d() {
        return this.f2480b;
    }

    public int m2763e() {
        return this.f2479a == null ? 0 : this.f2479a.length;
    }

    public void m2760c(int i) {
        boolean z = i >= 0 && i <= this.f2481c;
        C1392a.m2709a(z);
        this.f2480b = i;
    }

    public void m2762d(int i) {
        m2760c(this.f2480b + i);
    }

    public void m2754a(C1402j c1402j, int i) {
        m2756a(c1402j.f2475a, 0, i);
        c1402j.m2747a(0);
    }

    public void m2756a(byte[] bArr, int i, int i2) {
        System.arraycopy(this.f2479a, this.f2480b, bArr, i, i2);
        this.f2480b += i2;
    }

    public int m2765f() {
        return this.f2479a[this.f2480b] & 255;
    }

    public int m2766g() {
        byte[] bArr = this.f2479a;
        int i = this.f2480b;
        this.f2480b = i + 1;
        return bArr[i] & 255;
    }

    public int m2767h() {
        byte[] bArr = this.f2479a;
        int i = this.f2480b;
        this.f2480b = i + 1;
        int i2 = (bArr[i] & 255) << 8;
        byte[] bArr2 = this.f2479a;
        int i3 = this.f2480b;
        this.f2480b = i3 + 1;
        return i2 | (bArr2[i3] & 255);
    }

    public int m2768i() {
        byte[] bArr = this.f2479a;
        int i = this.f2480b;
        this.f2480b = i + 1;
        int i2 = bArr[i] & 255;
        byte[] bArr2 = this.f2479a;
        int i3 = this.f2480b;
        this.f2480b = i3 + 1;
        return i2 | ((bArr2[i3] & 255) << 8);
    }

    public short m2769j() {
        byte[] bArr = this.f2479a;
        int i = this.f2480b;
        this.f2480b = i + 1;
        int i2 = (bArr[i] & 255) << 8;
        byte[] bArr2 = this.f2479a;
        int i3 = this.f2480b;
        this.f2480b = i3 + 1;
        return (short) (i2 | (bArr2[i3] & 255));
    }

    public int m2770k() {
        byte[] bArr = this.f2479a;
        int i = this.f2480b;
        this.f2480b = i + 1;
        int i2 = (bArr[i] & 255) << 16;
        byte[] bArr2 = this.f2479a;
        int i3 = this.f2480b;
        this.f2480b = i3 + 1;
        i2 |= (bArr2[i3] & 255) << 8;
        bArr2 = this.f2479a;
        i3 = this.f2480b;
        this.f2480b = i3 + 1;
        return i2 | (bArr2[i3] & 255);
    }

    public long m2771l() {
        byte[] bArr = this.f2479a;
        int i = this.f2480b;
        this.f2480b = i + 1;
        long j = (((long) bArr[i]) & 255) << 24;
        byte[] bArr2 = this.f2479a;
        int i2 = this.f2480b;
        this.f2480b = i2 + 1;
        j |= (((long) bArr2[i2]) & 255) << 16;
        bArr2 = this.f2479a;
        i2 = this.f2480b;
        this.f2480b = i2 + 1;
        j |= (((long) bArr2[i2]) & 255) << 8;
        bArr2 = this.f2479a;
        i2 = this.f2480b;
        this.f2480b = i2 + 1;
        return j | (((long) bArr2[i2]) & 255);
    }

    public long m2772m() {
        byte[] bArr = this.f2479a;
        int i = this.f2480b;
        this.f2480b = i + 1;
        long j = ((long) bArr[i]) & 255;
        byte[] bArr2 = this.f2479a;
        int i2 = this.f2480b;
        this.f2480b = i2 + 1;
        j |= (((long) bArr2[i2]) & 255) << 8;
        bArr2 = this.f2479a;
        i2 = this.f2480b;
        this.f2480b = i2 + 1;
        j |= (((long) bArr2[i2]) & 255) << 16;
        bArr2 = this.f2479a;
        i2 = this.f2480b;
        this.f2480b = i2 + 1;
        return j | ((((long) bArr2[i2]) & 255) << 24);
    }

    public int m2773n() {
        byte[] bArr = this.f2479a;
        int i = this.f2480b;
        this.f2480b = i + 1;
        int i2 = (bArr[i] & 255) << 24;
        byte[] bArr2 = this.f2479a;
        int i3 = this.f2480b;
        this.f2480b = i3 + 1;
        i2 |= (bArr2[i3] & 255) << 16;
        bArr2 = this.f2479a;
        i3 = this.f2480b;
        this.f2480b = i3 + 1;
        i2 |= (bArr2[i3] & 255) << 8;
        bArr2 = this.f2479a;
        i3 = this.f2480b;
        this.f2480b = i3 + 1;
        return i2 | (bArr2[i3] & 255);
    }

    public int m2774o() {
        byte[] bArr = this.f2479a;
        int i = this.f2480b;
        this.f2480b = i + 1;
        int i2 = bArr[i] & 255;
        byte[] bArr2 = this.f2479a;
        int i3 = this.f2480b;
        this.f2480b = i3 + 1;
        i2 |= (bArr2[i3] & 255) << 8;
        bArr2 = this.f2479a;
        i3 = this.f2480b;
        this.f2480b = i3 + 1;
        i2 |= (bArr2[i3] & 255) << 16;
        bArr2 = this.f2479a;
        i3 = this.f2480b;
        this.f2480b = i3 + 1;
        return i2 | ((bArr2[i3] & 255) << 24);
    }

    public long m2775p() {
        byte[] bArr = this.f2479a;
        int i = this.f2480b;
        this.f2480b = i + 1;
        long j = (((long) bArr[i]) & 255) << 56;
        byte[] bArr2 = this.f2479a;
        int i2 = this.f2480b;
        this.f2480b = i2 + 1;
        j |= (((long) bArr2[i2]) & 255) << 48;
        bArr2 = this.f2479a;
        i2 = this.f2480b;
        this.f2480b = i2 + 1;
        j |= (((long) bArr2[i2]) & 255) << 40;
        bArr2 = this.f2479a;
        i2 = this.f2480b;
        this.f2480b = i2 + 1;
        j |= (((long) bArr2[i2]) & 255) << 32;
        bArr2 = this.f2479a;
        i2 = this.f2480b;
        this.f2480b = i2 + 1;
        j |= (((long) bArr2[i2]) & 255) << 24;
        bArr2 = this.f2479a;
        i2 = this.f2480b;
        this.f2480b = i2 + 1;
        j |= (((long) bArr2[i2]) & 255) << 16;
        bArr2 = this.f2479a;
        i2 = this.f2480b;
        this.f2480b = i2 + 1;
        j |= (((long) bArr2[i2]) & 255) << 8;
        bArr2 = this.f2479a;
        i2 = this.f2480b;
        this.f2480b = i2 + 1;
        return j | (((long) bArr2[i2]) & 255);
    }

    public long m2776q() {
        byte[] bArr = this.f2479a;
        int i = this.f2480b;
        this.f2480b = i + 1;
        long j = ((long) bArr[i]) & 255;
        byte[] bArr2 = this.f2479a;
        int i2 = this.f2480b;
        this.f2480b = i2 + 1;
        j |= (((long) bArr2[i2]) & 255) << 8;
        bArr2 = this.f2479a;
        i2 = this.f2480b;
        this.f2480b = i2 + 1;
        j |= (((long) bArr2[i2]) & 255) << 16;
        bArr2 = this.f2479a;
        i2 = this.f2480b;
        this.f2480b = i2 + 1;
        j |= (((long) bArr2[i2]) & 255) << 24;
        bArr2 = this.f2479a;
        i2 = this.f2480b;
        this.f2480b = i2 + 1;
        j |= (((long) bArr2[i2]) & 255) << 32;
        bArr2 = this.f2479a;
        i2 = this.f2480b;
        this.f2480b = i2 + 1;
        j |= (((long) bArr2[i2]) & 255) << 40;
        bArr2 = this.f2479a;
        i2 = this.f2480b;
        this.f2480b = i2 + 1;
        j |= (((long) bArr2[i2]) & 255) << 48;
        bArr2 = this.f2479a;
        i2 = this.f2480b;
        this.f2480b = i2 + 1;
        return j | ((((long) bArr2[i2]) & 255) << 56);
    }

    public int m2777r() {
        byte[] bArr = this.f2479a;
        int i = this.f2480b;
        this.f2480b = i + 1;
        int i2 = (bArr[i] & 255) << 8;
        byte[] bArr2 = this.f2479a;
        int i3 = this.f2480b;
        this.f2480b = i3 + 1;
        i2 |= bArr2[i3] & 255;
        this.f2480b += 2;
        return i2;
    }

    public int m2778s() {
        return (((m2766g() << 21) | (m2766g() << 14)) | (m2766g() << 7)) | m2766g();
    }

    public int m2779t() {
        int n = m2773n();
        if (n >= 0) {
            return n;
        }
        throw new IllegalStateException("Top bit not zero: " + n);
    }

    public int m2780u() {
        int o = m2774o();
        if (o >= 0) {
            return o;
        }
        throw new IllegalStateException("Top bit not zero: " + o);
    }

    public long m2781v() {
        long p = m2775p();
        if (p >= 0) {
            return p;
        }
        throw new IllegalStateException("Top bit not zero: " + p);
    }

    public double m2782w() {
        return Double.longBitsToDouble(m2775p());
    }

    public String m2764e(int i) {
        return m2751a(i, Charset.defaultCharset());
    }

    public String m2751a(int i, Charset charset) {
        String str = new String(this.f2479a, this.f2480b, i, charset);
        this.f2480b += i;
        return str;
    }

    public String m2783x() {
        if (m2757b() == 0) {
            return null;
        }
        int i = this.f2480b;
        while (i < this.f2481c && this.f2479a[i] != (byte) 10 && this.f2479a[i] != (byte) 13) {
            i++;
        }
        if (i - this.f2480b >= 3 && this.f2479a[this.f2480b] == (byte) -17 && this.f2479a[this.f2480b + 1] == (byte) -69 && this.f2479a[this.f2480b + 2] == (byte) -65) {
            this.f2480b += 3;
        }
        String str = new String(this.f2479a, this.f2480b, i - this.f2480b);
        this.f2480b = i;
        if (this.f2480b == this.f2481c) {
            return str;
        }
        if (this.f2479a[this.f2480b] == (byte) 13) {
            this.f2480b++;
            if (this.f2480b == this.f2481c) {
                return str;
            }
        }
        if (this.f2479a[this.f2480b] == (byte) 10) {
            this.f2480b++;
        }
        return str;
    }

    public long m2784y() {
        int i = 1;
        int i2 = 0;
        long j = (long) this.f2479a[this.f2480b];
        for (int i3 = 7; i3 >= 0; i3--) {
            byte b;
            if ((((long) (1 << i3)) & j) == 0) {
                if (i3 < 6) {
                    j &= (long) ((1 << i3) - 1);
                    i2 = 7 - i3;
                } else if (i3 == 7) {
                    i2 = 1;
                }
                if (i2 != 0) {
                    throw new NumberFormatException("Invalid UTF-8 sequence first byte: " + j);
                }
                while (i < i2) {
                    b = this.f2479a[this.f2480b + i];
                    if ((b & 192) == 128) {
                        throw new NumberFormatException("Invalid UTF-8 sequence continuation byte: " + j);
                    }
                    j = (j << 6) | ((long) (b & 63));
                    i++;
                }
                this.f2480b += i2;
                return j;
            }
        }
        if (i2 != 0) {
            while (i < i2) {
                b = this.f2479a[this.f2480b + i];
                if ((b & 192) == 128) {
                    j = (j << 6) | ((long) (b & 63));
                    i++;
                } else {
                    throw new NumberFormatException("Invalid UTF-8 sequence continuation byte: " + j);
                }
            }
            this.f2480b += i2;
            return j;
        }
        throw new NumberFormatException("Invalid UTF-8 sequence first byte: " + j);
    }
}
