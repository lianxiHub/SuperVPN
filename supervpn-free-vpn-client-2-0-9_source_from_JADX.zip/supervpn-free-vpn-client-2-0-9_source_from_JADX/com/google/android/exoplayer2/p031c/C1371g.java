package com.google.android.exoplayer2.p031c;

public interface C1371g {
    long mo2136t();
}
