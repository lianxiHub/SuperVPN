package com.google.android.exoplayer2.p031c;

import java.util.Arrays;

public final class C1397f {
    private int f2456a;
    private long[] f2457b;

    public C1397f() {
        this(32);
    }

    public C1397f(int i) {
        this.f2457b = new long[i];
    }

    public void m2728a(long j) {
        if (this.f2456a == this.f2457b.length) {
            this.f2457b = Arrays.copyOf(this.f2457b, this.f2456a * 2);
        }
        long[] jArr = this.f2457b;
        int i = this.f2456a;
        this.f2456a = i + 1;
        jArr[i] = j;
    }

    public long m2727a(int i) {
        if (i >= 0 && i < this.f2456a) {
            return this.f2457b[i];
        }
        throw new IndexOutOfBoundsException("Invalid index " + i + ", size is " + this.f2456a);
    }

    public int m2726a() {
        return this.f2456a;
    }

    public long[] m2729b() {
        return Arrays.copyOf(this.f2457b, this.f2456a);
    }
}
