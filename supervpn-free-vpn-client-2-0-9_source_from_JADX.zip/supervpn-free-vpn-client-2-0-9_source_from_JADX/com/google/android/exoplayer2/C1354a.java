package com.google.android.exoplayer2;

import com.google.android.exoplayer2.p030a.C1347e;
import com.google.android.exoplayer2.p031c.C1371g;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.source.C1623d;

public abstract class C1354a implements C1352k, C1353l {
    private final int f2239a;
    private int f2240b;
    private int f2241c;
    private C1623d f2242d;
    private long f2243e;
    private boolean f2244f = true;
    private boolean f2245g;

    public C1354a(int i) {
        this.f2239a = i;
    }

    public final int mo2096a() {
        return this.f2239a;
    }

    public final C1353l mo2102b() {
        return this;
    }

    public final void mo2097a(int i) {
        this.f2240b = i;
    }

    public C1371g mo2103c() {
        return null;
    }

    public final int mo2104d() {
        return this.f2241c;
    }

    public final void mo2101a(Format[] formatArr, C1623d c1623d, long j, boolean z, long j2) {
        C1392a.m2711b(this.f2241c == 0);
        this.f2241c = 1;
        mo2122a(z);
        mo2100a(formatArr, c1623d, j2);
        mo2121a(j, z);
    }

    public final void mo2105e() {
        boolean z = true;
        if (this.f2241c != 1) {
            z = false;
        }
        C1392a.m2711b(z);
        this.f2241c = 2;
        mo2123m();
    }

    public final void mo2100a(Format[] formatArr, C1623d c1623d, long j) {
        C1392a.m2711b(!this.f2245g);
        this.f2242d = c1623d;
        this.f2244f = false;
        this.f2243e = j;
        mo2153a(formatArr);
    }

    public final C1623d mo2106f() {
        return this.f2242d;
    }

    public final boolean mo2107g() {
        return this.f2244f;
    }

    public final void mo2108h() {
        this.f2245g = true;
    }

    public final void mo2109i() {
        this.f2242d.mo2270b();
    }

    public final void mo2099a(long j) {
        this.f2245g = false;
        mo2121a(j, false);
    }

    public final void mo2110j() {
        C1392a.m2711b(this.f2241c == 2);
        this.f2241c = 1;
        mo2124n();
    }

    public final void mo2111k() {
        boolean z = true;
        if (this.f2241c != 1) {
            z = false;
        }
        C1392a.m2711b(z);
        this.f2241c = 0;
        mo2125o();
        this.f2242d = null;
        this.f2245g = false;
    }

    public int mo2112l() {
        return 0;
    }

    public void mo2098a(int i, Object obj) {
    }

    protected void mo2122a(boolean z) {
    }

    protected void mo2153a(Format[] formatArr) {
    }

    protected void mo2121a(long j, boolean z) {
    }

    protected void mo2123m() {
    }

    protected void mo2124n() {
    }

    protected void mo2125o() {
    }

    protected final int m2509p() {
        return this.f2240b;
    }

    protected final int m2485a(C1581h c1581h, C1347e c1347e) {
        int a = this.f2242d.mo2267a(c1581h, c1347e);
        if (a == -4) {
            if (c1347e.m2424c()) {
                this.f2244f = true;
                if (this.f2245g) {
                    return -4;
                }
                return -3;
            }
            c1347e.f2221c += this.f2243e;
        }
        return a;
    }

    protected final boolean m2510q() {
        return this.f2244f ? this.f2245g : this.f2242d.mo2269a();
    }

    protected void m2495b(long j) {
        this.f2242d.mo2268a(j);
    }
}
