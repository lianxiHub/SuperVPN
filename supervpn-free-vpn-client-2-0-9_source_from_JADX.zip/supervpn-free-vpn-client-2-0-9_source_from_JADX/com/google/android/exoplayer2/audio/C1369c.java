package com.google.android.exoplayer2.audio;

import android.os.Handler;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.p030a.C1346d;
import com.google.android.exoplayer2.p031c.C1392a;

public interface C1369c {

    public static final class C1368a {
        private final Handler f2329a;
        private final C1369c f2330b;

        public C1368a(Handler handler, C1369c c1369c) {
            this.f2329a = c1369c != null ? (Handler) C1392a.m2707a((Object) handler) : null;
            this.f2330b = c1369c;
        }

        public void m2582a(final C1346d c1346d) {
            if (this.f2330b != null) {
                this.f2329a.post(new Runnable(this) {
                    final /* synthetic */ C1368a f2314b;

                    public void run() {
                        this.f2314b.f2330b.mo2249c(c1346d);
                    }
                });
            }
        }

        public void m2583a(String str, long j, long j2) {
            if (this.f2330b != null) {
                final String str2 = str;
                final long j3 = j;
                final long j4 = j2;
                this.f2329a.post(new Runnable(this) {
                    final /* synthetic */ C1368a f2318d;

                    public void run() {
                        this.f2318d.f2330b.mo2248b(str2, j3, j4);
                    }
                });
            }
        }

        public void m2581a(final Format format) {
            if (this.f2330b != null) {
                this.f2329a.post(new Runnable(this) {
                    final /* synthetic */ C1368a f2320b;

                    public void run() {
                        this.f2320b.f2330b.mo2246b(format);
                    }
                });
            }
        }

        public void m2580a(int i, long j, long j2) {
            if (this.f2330b != null) {
                final int i2 = i;
                final long j3 = j;
                final long j4 = j2;
                this.f2329a.post(new Runnable(this) {
                    final /* synthetic */ C1368a f2324d;

                    public void run() {
                        this.f2324d.f2330b.mo2238a(i2, j3, j4);
                    }
                });
            }
        }

        public void m2584b(final C1346d c1346d) {
            if (this.f2330b != null) {
                this.f2329a.post(new Runnable(this) {
                    final /* synthetic */ C1368a f2326b;

                    public void run() {
                        c1346d.m2435a();
                        this.f2326b.f2330b.mo2250d(c1346d);
                    }
                });
            }
        }

        public void m2579a(final int i) {
            if (this.f2330b != null) {
                this.f2329a.post(new Runnable(this) {
                    final /* synthetic */ C1368a f2328b;

                    public void run() {
                        this.f2328b.f2330b.mo2235a(i);
                    }
                });
            }
        }
    }

    void mo2235a(int i);

    void mo2238a(int i, long j, long j2);

    void mo2246b(Format format);

    void mo2248b(String str, long j, long j2);

    void mo2249c(C1346d c1346d);

    void mo2250d(C1346d c1346d);
}
