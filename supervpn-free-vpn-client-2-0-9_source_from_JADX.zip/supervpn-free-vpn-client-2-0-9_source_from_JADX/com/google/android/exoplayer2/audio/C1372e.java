package com.google.android.exoplayer2.audio;

import android.annotation.TargetApi;
import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.media.PlaybackParams;
import android.os.Handler;
import android.os.SystemClock;
import com.google.android.exoplayer2.C1391b;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.audio.C1369c.C1368a;
import com.google.android.exoplayer2.drm.C1438b;
import com.google.android.exoplayer2.mediacodec.C1598a;
import com.google.android.exoplayer2.mediacodec.C1599b;
import com.google.android.exoplayer2.mediacodec.MediaCodecRenderer;
import com.google.android.exoplayer2.p031c.C1371g;
import com.google.android.exoplayer2.p031c.C1398h;
import com.google.android.exoplayer2.p031c.C1414r;
import java.nio.ByteBuffer;

@TargetApi(16)
public class C1372e extends MediaCodecRenderer implements C1371g {
    private final C1368a f2370b;
    private final AudioTrack f2371c;
    private boolean f2372d;
    private MediaFormat f2373e;
    private int f2374f;
    private int f2375g = 0;
    private long f2376h;
    private boolean f2377i;
    private boolean f2378j;
    private long f2379k;

    public C1372e(C1599b c1599b, C1438b c1438b, boolean z, Handler handler, C1369c c1369c, C1361b c1361b, int i) {
        super(1, c1599b, c1438b, z);
        this.f2371c = new AudioTrack(c1361b, i);
        this.f2370b = new C1368a(handler, c1369c);
    }

    protected int mo2128a(C1599b c1599b, Format format) {
        boolean z = false;
        String str = format.f2183e;
        if (!C1398h.m2730a(str)) {
            return 0;
        }
        if (mo2134a(str) && c1599b.mo2255a() != null) {
            return 7;
        }
        C1598a a = c1599b.mo2256a(str, false);
        if (a == null) {
            return 1;
        }
        if (C1414r.f2503a < 21 || ((format.f2195q == -1 || a.m3743a(format.f2195q)) && (format.f2194p == -1 || a.m3747b(format.f2194p)))) {
            z = true;
        }
        return (z ? 3 : 2) | 4;
    }

    protected C1598a mo2129a(C1599b c1599b, Format format, boolean z) {
        if (mo2134a(format.f2183e)) {
            C1598a a = c1599b.mo2255a();
            if (a != null) {
                this.f2372d = true;
                return a;
            }
        }
        this.f2372d = false;
        return super.mo2129a(c1599b, format, z);
    }

    protected boolean mo2134a(String str) {
        return this.f2371c.m2555a(str);
    }

    protected void mo2131a(MediaCodec mediaCodec, Format format, MediaCrypto mediaCrypto) {
        if (this.f2372d) {
            this.f2373e = format.m2420b();
            this.f2373e.setString("mime", "audio/raw");
            mediaCodec.configure(this.f2373e, null, mediaCrypto, 0);
            this.f2373e.setString("mime", format.f2183e);
            return;
        }
        mediaCodec.configure(format.m2420b(), null, mediaCrypto, 0);
        this.f2373e = null;
    }

    public C1371g mo2103c() {
        return this;
    }

    protected void mo2132a(String str, long j, long j2) {
        this.f2370b.m2583a(str, j, j2);
    }

    protected void mo2135b(Format format) {
        super.mo2135b(format);
        this.f2370b.m2581a(format);
        this.f2374f = "audio/raw".equals(format.f2183e) ? format.f2196r : 2;
    }

    protected void mo2130a(MediaCodec mediaCodec, MediaFormat mediaFormat) {
        int i = this.f2373e != null ? 1 : 0;
        String string = i != 0 ? this.f2373e.getString("mime") : "audio/raw";
        if (i != 0) {
            mediaFormat = this.f2373e;
        }
        this.f2371c.m2553a(string, mediaFormat.getInteger("channel-count"), mediaFormat.getInteger("sample-rate"), this.f2374f, 0);
    }

    protected void m2648b(int i) {
    }

    protected void mo2122a(boolean z) {
        super.mo2122a(z);
        this.f2370b.m2582a(this.a);
    }

    protected void mo2121a(long j, boolean z) {
        super.mo2121a(j, z);
        this.f2371c.m2563i();
        this.f2376h = j;
        this.f2377i = true;
    }

    protected void mo2123m() {
        super.mo2123m();
        this.f2371c.m2558d();
    }

    protected void mo2124n() {
        this.f2371c.m2562h();
        super.mo2124n();
    }

    protected void mo2125o() {
        this.f2375g = 0;
        try {
            this.f2371c.m2564j();
            try {
                super.mo2125o();
            } finally {
                this.a.m2435a();
                this.f2370b.m2584b(this.a);
            }
        } catch (Throwable th) {
            super.mo2125o();
        } finally {
            this.a.m2435a();
            this.f2370b.m2584b(this.a);
        }
    }

    public boolean mo2127s() {
        return super.mo2127s() && !this.f2371c.m2561g();
    }

    public boolean mo2126r() {
        return this.f2371c.m2561g() || super.mo2126r();
    }

    public long mo2136t() {
        long a = this.f2371c.m2550a(mo2127s());
        if (a != Long.MIN_VALUE) {
            if (!this.f2377i) {
                a = Math.max(this.f2376h, a);
            }
            this.f2376h = a;
            this.f2377i = false;
        }
        return this.f2376h;
    }

    protected boolean mo2133a(long j, long j2, MediaCodec mediaCodec, ByteBuffer byteBuffer, int i, int i2, long j3, boolean z) {
        if (this.f2372d && (i2 & 2) != 0) {
            mediaCodec.releaseOutputBuffer(i, false);
            return true;
        } else if (z) {
            mediaCodec.releaseOutputBuffer(i, false);
            r2 = this.a;
            r2.f2216e++;
            this.f2371c.m2559e();
            return true;
        } else {
            if (this.f2371c.m2554a()) {
                boolean z2 = this.f2378j;
                this.f2378j = this.f2371c.m2561g();
                if (z2 && !this.f2378j && mo2104d() == 2) {
                    long elapsedRealtime = SystemClock.elapsedRealtime() - this.f2379k;
                    this.f2370b.m2580a(this.f2371c.m2556b(), C1391b.m2704a(this.f2371c.m2557c()), elapsedRealtime);
                }
            } else {
                try {
                    if (this.f2375g == 0) {
                        this.f2375g = this.f2371c.m2548a(0);
                        this.f2370b.m2579a(this.f2375g);
                        m2648b(this.f2375g);
                    } else {
                        this.f2371c.m2548a(this.f2375g);
                    }
                    this.f2378j = false;
                    if (mo2104d() == 2) {
                        this.f2371c.m2558d();
                    }
                } catch (Exception e) {
                    throw ExoPlaybackException.m2399a(e, m2509p());
                }
            }
            try {
                int a = this.f2371c.m2549a(byteBuffer, j3);
                this.f2379k = SystemClock.elapsedRealtime();
                if ((a & 1) != 0) {
                    mo2138v();
                    this.f2377i = true;
                }
                if ((a & 2) == 0) {
                    return false;
                }
                mediaCodec.releaseOutputBuffer(i, false);
                r2 = this.a;
                r2.f2215d++;
                return true;
            } catch (Exception e2) {
                throw ExoPlaybackException.m2399a(e2, m2509p());
            }
        }
    }

    protected void mo2137u() {
        this.f2371c.m2560f();
    }

    protected void mo2138v() {
    }

    public void mo2098a(int i, Object obj) {
        switch (i) {
            case 2:
                this.f2371c.m2551a(((Float) obj).floatValue());
                return;
            case 3:
                this.f2371c.m2552a((PlaybackParams) obj);
                return;
            default:
                super.mo2098a(i, obj);
                return;
        }
    }
}
