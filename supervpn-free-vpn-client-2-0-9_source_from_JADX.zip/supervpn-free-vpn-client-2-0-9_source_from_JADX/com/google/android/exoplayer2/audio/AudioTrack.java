package com.google.android.exoplayer2.audio;

import android.annotation.TargetApi;
import android.media.AudioTimestamp;
import android.media.PlaybackParams;
import android.os.ConditionVariable;
import android.os.SystemClock;
import android.util.Log;
import com.google.android.exoplayer2.C1391b;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1414r;
import com.mopub.volley.DefaultRetryPolicy;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;

public final class AudioTrack {
    public static boolean f2267a = false;
    public static boolean f2268b = false;
    private int f2269A;
    private int f2270B;
    private long f2271C;
    private long f2272D;
    private long f2273E;
    private float f2274F;
    private byte[] f2275G;
    private int f2276H;
    private ByteBuffer f2277I;
    private ByteBuffer f2278J;
    private boolean f2279K;
    private final C1361b f2280c;
    private final int f2281d;
    private final ConditionVariable f2282e = new ConditionVariable(true);
    private final long[] f2283f;
    private final C1357a f2284g;
    private android.media.AudioTrack f2285h;
    private android.media.AudioTrack f2286i;
    private int f2287j;
    private int f2288k;
    private int f2289l;
    private int f2290m;
    private boolean f2291n;
    private int f2292o;
    private int f2293p;
    private long f2294q;
    private int f2295r;
    private int f2296s;
    private long f2297t;
    private long f2298u;
    private boolean f2299v;
    private long f2300w;
    private Method f2301x;
    private long f2302y;
    private long f2303z;

    public static final class InitializationException extends Exception {
        public final int f2250a;

        public InitializationException(int i, int i2, int i3, int i4) {
            super("AudioTrack init failed: " + i + ", Config(" + i2 + ", " + i3 + ", " + i4 + ")");
            this.f2250a = i;
        }
    }

    public static final class InvalidAudioTrackTimestampException extends RuntimeException {
        public InvalidAudioTrackTimestampException(String str) {
            super(str);
        }
    }

    public static final class WriteException extends Exception {
        public final int f2251a;

        public WriteException(int i) {
            super("AudioTrack write failed: " + i);
            this.f2251a = i;
        }
    }

    private static class C1357a {
        protected android.media.AudioTrack f2252a;
        private boolean f2253b;
        private int f2254c;
        private long f2255d;
        private long f2256e;
        private long f2257f;
        private long f2258g;
        private long f2259h;
        private long f2260i;

        private C1357a() {
        }

        public void mo2113a(android.media.AudioTrack audioTrack, boolean z) {
            this.f2252a = audioTrack;
            this.f2253b = z;
            this.f2258g = -9223372036854775807L;
            this.f2255d = 0;
            this.f2256e = 0;
            this.f2257f = 0;
            if (audioTrack != null) {
                this.f2254c = audioTrack.getSampleRate();
            }
        }

        public void m2512a(long j) {
            this.f2259h = m2515b();
            this.f2258g = SystemClock.elapsedRealtime() * 1000;
            this.f2260i = j;
            this.f2252a.stop();
        }

        public void m2511a() {
            if (this.f2258g == -9223372036854775807L) {
                this.f2252a.pause();
            }
        }

        public long m2515b() {
            if (this.f2258g != -9223372036854775807L) {
                return Math.min(this.f2260i, ((((SystemClock.elapsedRealtime() * 1000) - this.f2258g) * ((long) this.f2254c)) / 1000000) + this.f2259h);
            }
            int playState = this.f2252a.getPlayState();
            if (playState == 1) {
                return 0;
            }
            long playbackHeadPosition = 4294967295L & ((long) this.f2252a.getPlaybackHeadPosition());
            if (this.f2253b) {
                if (playState == 2 && playbackHeadPosition == 0) {
                    this.f2257f = this.f2255d;
                }
                playbackHeadPosition += this.f2257f;
            }
            if (this.f2255d > playbackHeadPosition) {
                this.f2256e++;
            }
            this.f2255d = playbackHeadPosition;
            return playbackHeadPosition + (this.f2256e << 32);
        }

        public long m2516c() {
            return (m2515b() * 1000000) / ((long) this.f2254c);
        }

        public boolean mo2114d() {
            return false;
        }

        public long mo2115e() {
            throw new UnsupportedOperationException();
        }

        public long mo2116f() {
            throw new UnsupportedOperationException();
        }

        public void mo2117a(PlaybackParams playbackParams) {
            throw new UnsupportedOperationException();
        }

        public float mo2118g() {
            return DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;
        }
    }

    @TargetApi(19)
    private static class C1358b extends C1357a {
        private final AudioTimestamp f2261b = new AudioTimestamp();
        private long f2262c;
        private long f2263d;
        private long f2264e;

        public C1358b() {
            super();
        }

        public void mo2113a(android.media.AudioTrack audioTrack, boolean z) {
            super.mo2113a(audioTrack, z);
            this.f2262c = 0;
            this.f2263d = 0;
            this.f2264e = 0;
        }

        public boolean mo2114d() {
            boolean timestamp = this.a.getTimestamp(this.f2261b);
            if (timestamp) {
                long j = this.f2261b.framePosition;
                if (this.f2263d > j) {
                    this.f2262c++;
                }
                this.f2263d = j;
                this.f2264e = j + (this.f2262c << 32);
            }
            return timestamp;
        }

        public long mo2115e() {
            return this.f2261b.nanoTime;
        }

        public long mo2116f() {
            return this.f2264e;
        }
    }

    @TargetApi(23)
    private static class C1359c extends C1358b {
        private PlaybackParams f2265b;
        private float f2266c = DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;

        public void mo2113a(android.media.AudioTrack audioTrack, boolean z) {
            super.mo2113a(audioTrack, z);
            m2525h();
        }

        public void mo2117a(PlaybackParams playbackParams) {
            if (playbackParams == null) {
                playbackParams = new PlaybackParams();
            }
            PlaybackParams allowDefaults = playbackParams.allowDefaults();
            this.f2265b = allowDefaults;
            this.f2266c = allowDefaults.getSpeed();
            m2525h();
        }

        public float mo2118g() {
            return this.f2266c;
        }

        private void m2525h() {
            if (this.a != null && this.f2265b != null) {
                this.a.setPlaybackParams(this.f2265b);
            }
        }
    }

    public AudioTrack(C1361b c1361b, int i) {
        this.f2280c = c1361b;
        this.f2281d = i;
        if (C1414r.f2503a >= 18) {
            try {
                this.f2301x = android.media.AudioTrack.class.getMethod("getLatency", (Class[]) null);
            } catch (NoSuchMethodException e) {
            }
        }
        if (C1414r.f2503a >= 23) {
            this.f2284g = new C1359c();
        } else if (C1414r.f2503a >= 19) {
            this.f2284g = new C1358b();
        } else {
            this.f2284g = new C1357a();
        }
        this.f2283f = new long[10];
        this.f2274F = DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;
        this.f2270B = 0;
    }

    public boolean m2555a(String str) {
        return this.f2280c != null && this.f2280c.m2577a(m2535b(str));
    }

    public boolean m2554a() {
        return this.f2286i != null;
    }

    public long m2550a(boolean z) {
        if (!m2541m()) {
            return Long.MIN_VALUE;
        }
        if (this.f2286i.getPlayState() == 3) {
            m2542n();
        }
        long nanoTime = System.nanoTime() / 1000;
        if (this.f2299v) {
            return m2536b(m2538c((long) (((float) (nanoTime - (this.f2284g.mo2115e() / 1000))) * this.f2284g.mo2118g())) + this.f2284g.mo2116f()) + this.f2271C;
        }
        if (this.f2296s == 0) {
            nanoTime = this.f2284g.m2516c() + this.f2271C;
        } else {
            nanoTime = (nanoTime + this.f2297t) + this.f2271C;
        }
        if (z) {
            return nanoTime;
        }
        return nanoTime - this.f2273E;
    }

    public void m2553a(String str, int i, int i2, int i3, int i4) {
        int i5;
        switch (i) {
            case 1:
                i5 = 4;
                break;
            case 2:
                i5 = 12;
                break;
            case 3:
                i5 = 28;
                break;
            case 4:
                i5 = 204;
                break;
            case 5:
                i5 = 220;
                break;
            case 6:
                i5 = 252;
                break;
            case 7:
                i5 = 1276;
                break;
            case 8:
                i5 = C1391b.f2436a;
                break;
            default:
                throw new IllegalArgumentException("Unsupported channel count: " + i);
        }
        boolean z = !"audio/raw".equals(str);
        if (z) {
            i3 = m2535b(str);
        } else if (!(i3 == 3 || i3 == 2 || i3 == Integer.MIN_VALUE || i3 == 1073741824)) {
            throw new IllegalArgumentException("Unsupported PCM encoding: " + i3);
        }
        if (!m2554a() || this.f2289l != i3 || this.f2287j != i2 || this.f2288k != i5) {
            long j;
            m2563i();
            this.f2289l = i3;
            this.f2291n = z;
            this.f2287j = i2;
            this.f2288k = i5;
            if (!z) {
                i3 = 2;
            }
            this.f2290m = i3;
            this.f2292o = i * 2;
            if (i4 != 0) {
                this.f2293p = i4;
            } else if (!z) {
                int minBufferSize = android.media.AudioTrack.getMinBufferSize(i2, i5, this.f2290m);
                C1392a.m2711b(minBufferSize != -2);
                int i6 = minBufferSize * 4;
                i5 = ((int) m2538c(250000)) * this.f2292o;
                minBufferSize = (int) Math.max((long) minBufferSize, m2538c(750000) * ((long) this.f2292o));
                if (i6 >= i5) {
                    i5 = i6 > minBufferSize ? minBufferSize : i6;
                }
                this.f2293p = i5;
            } else if (this.f2290m == 5 || this.f2290m == 6) {
                this.f2293p = 20480;
            } else {
                this.f2293p = 49152;
            }
            if (z) {
                j = -9223372036854775807L;
            } else {
                j = m2536b(m2531a((long) this.f2293p));
            }
            this.f2294q = j;
        }
    }

    public int m2548a(int i) {
        this.f2282e.block();
        if (i == 0) {
            this.f2286i = new android.media.AudioTrack(this.f2281d, this.f2287j, this.f2288k, this.f2290m, this.f2293p, 1);
        } else {
            this.f2286i = new android.media.AudioTrack(this.f2281d, this.f2287j, this.f2288k, this.f2290m, this.f2293p, 1, i);
        }
        m2543o();
        int audioSessionId = this.f2286i.getAudioSessionId();
        if (f2267a && C1414r.f2503a < 21) {
            if (!(this.f2285h == null || audioSessionId == this.f2285h.getAudioSessionId())) {
                m2540l();
            }
            if (this.f2285h == null) {
                this.f2285h = new android.media.AudioTrack(this.f2281d, 4000, 4, 2, 2, 0, audioSessionId);
            }
        }
        this.f2284g.mo2113a(this.f2286i, m2546r());
        m2539k();
        return audioSessionId;
    }

    public int m2556b() {
        return this.f2293p;
    }

    public long m2557c() {
        return this.f2294q;
    }

    public void m2558d() {
        if (m2554a()) {
            this.f2272D = System.nanoTime() / 1000;
            this.f2286i.play();
        }
    }

    public void m2559e() {
        if (this.f2270B == 1) {
            this.f2270B = 2;
        }
    }

    public int m2549a(ByteBuffer byteBuffer, long j) {
        boolean z;
        int remaining;
        int i = 1;
        int i2 = 0;
        int i3 = this.f2277I == null ? 1 : 0;
        if (i3 != 0 || this.f2277I == byteBuffer) {
            z = true;
        } else {
            z = false;
        }
        C1392a.m2711b(z);
        this.f2277I = byteBuffer;
        if (m2546r()) {
            if (this.f2286i.getPlayState() == 2) {
                return 0;
            }
            if (this.f2286i.getPlayState() == 1 && this.f2284g.m2515b() != 0) {
                return 0;
            }
        }
        if (i3 == 0) {
            i = 0;
        } else if (this.f2277I.hasRemaining()) {
            this.f2279K = this.f2290m != this.f2289l;
            if (this.f2279K) {
                if (this.f2290m == 2) {
                    z = true;
                } else {
                    z = false;
                }
                C1392a.m2711b(z);
                this.f2278J = m2533a(this.f2277I, this.f2289l, this.f2278J);
                byteBuffer = this.f2278J;
            }
            if (this.f2291n && this.f2269A == 0) {
                this.f2269A = m2529a(this.f2290m, byteBuffer);
            }
            if (this.f2270B == 0) {
                this.f2271C = Math.max(0, j);
                this.f2270B = 1;
                i = 0;
            } else {
                long b = this.f2271C + m2536b(m2544p());
                if (this.f2270B == 1 && Math.abs(b - j) > 200000) {
                    Log.e("AudioTrack", "Discontinuity detected [expected " + b + ", got " + j + "]");
                    this.f2270B = 2;
                }
                if (this.f2270B == 2) {
                    this.f2271C = (j - b) + this.f2271C;
                    this.f2270B = 1;
                } else {
                    i = 0;
                }
            }
            if (C1414r.f2503a < 21) {
                remaining = byteBuffer.remaining();
                if (this.f2275G == null || this.f2275G.length < remaining) {
                    this.f2275G = new byte[remaining];
                }
                int position = byteBuffer.position();
                byteBuffer.get(this.f2275G, 0, remaining);
                byteBuffer.position(position);
                this.f2276H = 0;
            }
        } else {
            this.f2277I = null;
            return 2;
        }
        if (this.f2279K) {
            byteBuffer = this.f2278J;
        }
        remaining = byteBuffer.remaining();
        if (C1414r.f2503a < 21) {
            position = this.f2293p - ((int) (this.f2302y - (this.f2284g.m2515b() * ((long) this.f2292o))));
            if (position > 0) {
                i2 = this.f2286i.write(this.f2275G, this.f2276H, Math.min(remaining, position));
                if (i2 >= 0) {
                    this.f2276H += i2;
                }
                byteBuffer.position(byteBuffer.position() + i2);
            }
        } else {
            i2 = m2530a(this.f2286i, byteBuffer, remaining);
        }
        if (i2 < 0) {
            throw new WriteException(i2);
        }
        if (!this.f2291n) {
            this.f2302y += (long) i2;
        }
        if (i2 == remaining) {
            if (this.f2291n) {
                this.f2303z += (long) this.f2269A;
            }
            this.f2277I = null;
            i |= 2;
        }
        return i;
    }

    public void m2560f() {
        if (m2554a()) {
            this.f2284g.m2512a(m2544p());
        }
    }

    public boolean m2561g() {
        return m2554a() && (m2544p() > this.f2284g.m2515b() || m2547s());
    }

    public void m2552a(PlaybackParams playbackParams) {
        this.f2284g.mo2117a(playbackParams);
    }

    public void m2551a(float f) {
        if (this.f2274F != f) {
            this.f2274F = f;
            m2539k();
        }
    }

    private void m2539k() {
        if (!m2554a()) {
            return;
        }
        if (C1414r.f2503a >= 21) {
            m2534a(this.f2286i, this.f2274F);
        } else {
            m2537b(this.f2286i, this.f2274F);
        }
    }

    public void m2562h() {
        if (m2554a()) {
            m2545q();
            this.f2284g.m2511a();
        }
    }

    public void m2563i() {
        if (m2554a()) {
            this.f2302y = 0;
            this.f2303z = 0;
            this.f2269A = 0;
            this.f2277I = null;
            this.f2270B = 0;
            this.f2273E = 0;
            m2545q();
            if (this.f2286i.getPlayState() == 3) {
                this.f2286i.pause();
            }
            final android.media.AudioTrack audioTrack = this.f2286i;
            this.f2286i = null;
            this.f2284g.mo2113a(null, false);
            this.f2282e.close();
            new Thread(this) {
                final /* synthetic */ AudioTrack f2247b;

                public void run() {
                    try {
                        audioTrack.flush();
                        audioTrack.release();
                    } finally {
                        this.f2247b.f2282e.open();
                    }
                }
            }.start();
        }
    }

    public void m2564j() {
        m2563i();
        m2540l();
    }

    private void m2540l() {
        if (this.f2285h != null) {
            final android.media.AudioTrack audioTrack = this.f2285h;
            this.f2285h = null;
            new Thread(this) {
                final /* synthetic */ AudioTrack f2249b;

                public void run() {
                    audioTrack.release();
                }
            }.start();
        }
    }

    private boolean m2541m() {
        return m2554a() && this.f2270B != 0;
    }

    private void m2542n() {
        long c = this.f2284g.m2516c();
        if (c != 0) {
            long nanoTime = System.nanoTime() / 1000;
            if (nanoTime - this.f2298u >= 30000) {
                this.f2283f[this.f2295r] = c - nanoTime;
                this.f2295r = (this.f2295r + 1) % 10;
                if (this.f2296s < 10) {
                    this.f2296s++;
                }
                this.f2298u = nanoTime;
                this.f2297t = 0;
                for (int i = 0; i < this.f2296s; i++) {
                    this.f2297t += this.f2283f[i] / ((long) this.f2296s);
                }
            }
            if (!m2546r() && nanoTime - this.f2300w >= 500000) {
                this.f2299v = this.f2284g.mo2114d();
                if (this.f2299v) {
                    long e = this.f2284g.mo2115e() / 1000;
                    long f = this.f2284g.mo2116f();
                    if (e < this.f2272D) {
                        this.f2299v = false;
                    } else if (Math.abs(e - nanoTime) > 5000000) {
                        r0 = "Spurious audio timestamp (system clock mismatch): " + f + ", " + e + ", " + nanoTime + ", " + c;
                        if (f2268b) {
                            throw new InvalidAudioTrackTimestampException(r0);
                        }
                        Log.w("AudioTrack", r0);
                        this.f2299v = false;
                    } else if (Math.abs(m2536b(f) - c) > 5000000) {
                        r0 = "Spurious audio timestamp (frame position mismatch): " + f + ", " + e + ", " + nanoTime + ", " + c;
                        if (f2268b) {
                            throw new InvalidAudioTrackTimestampException(r0);
                        }
                        Log.w("AudioTrack", r0);
                        this.f2299v = false;
                    }
                }
                if (!(this.f2301x == null || this.f2291n)) {
                    try {
                        this.f2273E = (((long) ((Integer) this.f2301x.invoke(this.f2286i, (Object[]) null)).intValue()) * 1000) - this.f2294q;
                        this.f2273E = Math.max(this.f2273E, 0);
                        if (this.f2273E > 5000000) {
                            Log.w("AudioTrack", "Ignoring impossibly large audio latency: " + this.f2273E);
                            this.f2273E = 0;
                        }
                    } catch (Exception e2) {
                        this.f2301x = null;
                    }
                }
                this.f2300w = nanoTime;
            }
        }
    }

    private void m2543o() {
        int state = this.f2286i.getState();
        if (state != 1) {
            try {
                this.f2286i.release();
            } catch (Exception e) {
            } finally {
                this.f2286i = null;
            }
            throw new InitializationException(state, this.f2287j, this.f2288k, this.f2293p);
        }
    }

    private long m2531a(long j) {
        return j / ((long) this.f2292o);
    }

    private long m2536b(long j) {
        return (1000000 * j) / ((long) this.f2287j);
    }

    private long m2538c(long j) {
        return (((long) this.f2287j) * j) / 1000000;
    }

    private long m2544p() {
        return this.f2291n ? this.f2303z : m2531a(this.f2302y);
    }

    private void m2545q() {
        this.f2297t = 0;
        this.f2296s = 0;
        this.f2295r = 0;
        this.f2298u = 0;
        this.f2299v = false;
        this.f2300w = 0;
    }

    private boolean m2546r() {
        return C1414r.f2503a < 23 && (this.f2290m == 5 || this.f2290m == 6);
    }

    private boolean m2547s() {
        return m2546r() && this.f2286i.getPlayState() == 2 && this.f2286i.getPlaybackHeadPosition() == 0;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static java.nio.ByteBuffer m2533a(java.nio.ByteBuffer r5, int r6, java.nio.ByteBuffer r7) {
        /*
        r4 = 0;
        r0 = r5.position();
        r2 = r5.limit();
        r1 = r2 - r0;
        switch(r6) {
            case -2147483648: goto L_0x0031;
            case 3: goto L_0x0014;
            case 1073741824: goto L_0x0036;
            default: goto L_0x000e;
        };
    L_0x000e:
        r0 = new java.lang.IllegalStateException;
        r0.<init>();
        throw r0;
    L_0x0014:
        r1 = r1 * 2;
    L_0x0016:
        if (r7 == 0) goto L_0x001e;
    L_0x0018:
        r3 = r7.capacity();
        if (r3 >= r1) goto L_0x0022;
    L_0x001e:
        r7 = java.nio.ByteBuffer.allocateDirect(r1);
    L_0x0022:
        r7.position(r4);
        r7.limit(r1);
        switch(r6) {
            case -2147483648: goto L_0x004d;
            case 3: goto L_0x0039;
            case 1073741824: goto L_0x0064;
            default: goto L_0x002b;
        };
    L_0x002b:
        r0 = new java.lang.IllegalStateException;
        r0.<init>();
        throw r0;
    L_0x0031:
        r1 = r1 / 3;
        r1 = r1 * 2;
        goto L_0x0016;
    L_0x0036:
        r1 = r1 / 2;
        goto L_0x0016;
    L_0x0039:
        if (r0 >= r2) goto L_0x007b;
    L_0x003b:
        r7.put(r4);
        r1 = r5.get(r0);
        r1 = r1 & 255;
        r1 = r1 + -128;
        r1 = (byte) r1;
        r7.put(r1);
        r0 = r0 + 1;
        goto L_0x0039;
    L_0x004d:
        if (r0 >= r2) goto L_0x007b;
    L_0x004f:
        r1 = r0 + 1;
        r1 = r5.get(r1);
        r7.put(r1);
        r1 = r0 + 2;
        r1 = r5.get(r1);
        r7.put(r1);
        r0 = r0 + 3;
        goto L_0x004d;
    L_0x0064:
        if (r0 >= r2) goto L_0x007b;
    L_0x0066:
        r1 = r0 + 2;
        r1 = r5.get(r1);
        r7.put(r1);
        r1 = r0 + 3;
        r1 = r5.get(r1);
        r7.put(r1);
        r0 = r0 + 4;
        goto L_0x0064;
    L_0x007b:
        r7.position(r4);
        return r7;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.audio.AudioTrack.a(java.nio.ByteBuffer, int, java.nio.ByteBuffer):java.nio.ByteBuffer");
    }

    private static int m2535b(String str) {
        int i = -1;
        switch (str.hashCode()) {
            case -1095064472:
                if (str.equals("audio/vnd.dts")) {
                    i = 2;
                    break;
                }
                break;
            case 187078296:
                if (str.equals("audio/ac3")) {
                    i = 0;
                    break;
                }
                break;
            case 1504578661:
                if (str.equals("audio/eac3")) {
                    i = 1;
                    break;
                }
                break;
            case 1505942594:
                if (str.equals("audio/vnd.dts.hd")) {
                    i = 3;
                    break;
                }
                break;
        }
        switch (i) {
            case 0:
                return 5;
            case 1:
                return 6;
            case 2:
                return 7;
            case 3:
                return 8;
            default:
                return 0;
        }
    }

    private static int m2529a(int i, ByteBuffer byteBuffer) {
        if (i == 7 || i == 8) {
            return C1370d.m2591a(byteBuffer);
        }
        if (i == 5) {
            return C1360a.m2565a();
        }
        if (i == 6) {
            return C1360a.m2567a(byteBuffer);
        }
        throw new IllegalStateException("Unexpected audio encoding: " + i);
    }

    @TargetApi(21)
    private static int m2530a(android.media.AudioTrack audioTrack, ByteBuffer byteBuffer, int i) {
        return audioTrack.write(byteBuffer, i, 1);
    }

    @TargetApi(21)
    private static void m2534a(android.media.AudioTrack audioTrack, float f) {
        audioTrack.setVolume(f);
    }

    private static void m2537b(android.media.AudioTrack audioTrack, float f) {
        audioTrack.setStereoVolume(f, f);
    }
}
