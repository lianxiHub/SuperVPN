package com.google.android.exoplayer2.audio;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.drm.DrmInitData;
import com.google.android.exoplayer2.p031c.C1402j;
import com.google.android.exoplayer2.p031c.C1403k;
import java.nio.ByteBuffer;

public final class C1360a {
    private static final int[] f2304a = new int[]{1, 2, 3, 6};
    private static final int[] f2305b = new int[]{48000, 44100, 32000};
    private static final int[] f2306c = new int[]{24000, 22050, 16000};
    private static final int[] f2307d = new int[]{2, 1, 2, 3, 3, 4, 4, 5};
    private static final int[] f2308e = new int[]{32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384, 448, 512, 576, 640};
    private static final int[] f2309f = new int[]{69, 87, 104, 121, 139, 174, 208, 243, 278, 348, 417, 487, 557, 696, 835, 975, 1114, 1253, 1393};

    public static Format m2570a(C1403k c1403k, String str, String str2, DrmInitData drmInitData) {
        int i = f2305b[(c1403k.m2766g() & 192) >> 6];
        int g = c1403k.m2766g();
        int i2 = f2307d[(g & 56) >> 3];
        if ((g & 4) != 0) {
            i2++;
        }
        return Format.m2407a(str, "audio/ac3", null, -1, -1, i2, i, null, drmInitData, 0, str2);
    }

    public static Format m2573b(C1403k c1403k, String str, String str2, DrmInitData drmInitData) {
        c1403k.m2762d(2);
        int i = f2305b[(c1403k.m2766g() & 192) >> 6];
        int g = c1403k.m2766g();
        int i2 = f2307d[(g & 14) >> 1];
        if ((g & 1) != 0) {
            i2++;
        }
        return Format.m2407a(str, "audio/eac3", null, -1, -1, i2, i, null, drmInitData, 0, str2);
    }

    public static Format m2569a(C1402j c1402j, String str, String str2, DrmInitData drmInitData) {
        int i = 1;
        c1402j.m2748b(32);
        int c = c1402j.m2750c(2);
        c1402j.m2748b(14);
        int c2 = c1402j.m2750c(3);
        if (!((c2 & 1) == 0 || c2 == 1)) {
            c1402j.m2748b(2);
        }
        if ((c2 & 4) != 0) {
            c1402j.m2748b(2);
        }
        if (c2 == 2) {
            c1402j.m2748b(2);
        }
        boolean b = c1402j.m2749b();
        String str3 = "audio/ac3";
        c2 = f2307d[c2];
        if (!b) {
            i = 0;
        }
        return Format.m2407a(str, str3, null, -1, -1, c2 + i, f2305b[c], null, drmInitData, 0, str2);
    }

    public static Format m2572b(C1402j c1402j, String str, String str2, DrmInitData drmInitData) {
        int i;
        c1402j.m2748b(32);
        int c = c1402j.m2750c(2);
        if (c == 3) {
            i = f2306c[c1402j.m2750c(2)];
        } else {
            c1402j.m2748b(2);
            i = f2305b[c];
        }
        c = c1402j.m2750c(3);
        boolean b = c1402j.m2749b();
        String str3 = "audio/eac3";
        int i2 = f2307d[c];
        if (b) {
            c = 1;
        } else {
            c = 0;
        }
        return Format.m2407a(str, str3, null, -1, -1, i2 + c, i, null, drmInitData, 0, str2);
    }

    public static int m2568a(byte[] bArr) {
        if (bArr.length < 5) {
            return -1;
        }
        return C1360a.m2566a((bArr[4] & 192) >> 6, bArr[4] & 63);
    }

    public static int m2571b(byte[] bArr) {
        return ((((bArr[2] & 7) << 8) + (bArr[3] & 255)) + 1) * 2;
    }

    public static int m2565a() {
        return 1536;
    }

    public static int m2574c(byte[] bArr) {
        return (((bArr[4] & 192) >> 6) == 3 ? 6 : f2304a[(bArr[4] & 48) >> 4]) * 256;
    }

    public static int m2567a(ByteBuffer byteBuffer) {
        int i;
        if (((byteBuffer.get(byteBuffer.position() + 4) & 192) >> 6) == 3) {
            i = 6;
        } else {
            i = f2304a[(byteBuffer.get(byteBuffer.position() + 4) & 48) >> 4];
        }
        return i * 256;
    }

    private static int m2566a(int i, int i2) {
        int i3 = i2 / 2;
        if (i < 0 || i >= f2305b.length || i2 < 0 || i3 >= f2309f.length) {
            return -1;
        }
        int i4 = f2305b[i];
        if (i4 == 44100) {
            return (f2309f[i3] + (i2 % 2)) * 2;
        }
        i3 = f2308e[i3];
        if (i4 == 32000) {
            return i3 * 6;
        }
        return i3 * 4;
    }
}
