package com.google.android.exoplayer2.audio;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.drm.DrmInitData;
import com.google.android.exoplayer2.p031c.C1402j;
import java.nio.ByteBuffer;

public final class C1370d {
    private static final int[] f2331a = new int[]{1, 2, 2, 2, 2, 3, 3, 4, 4, 5, 6, 6, 6, 7, 8, 8};
    private static final int[] f2332b = new int[]{-1, 8000, 16000, 32000, -1, -1, 11025, 22050, 44100, -1, -1, 12000, 24000, 48000, -1, -1};
    private static final int[] f2333c = new int[]{64, 112, 128, 192, 224, 256, 384, 448, 512, 640, 768, 896, 1024, 1152, 1280, 1536, 1920, 2048, 2304, 2560, 2688, 2816, 2823, 2944, 3072, 3840, 4096, 6144, 7680};

    public static Format m2593a(byte[] bArr, String str, String str2, DrmInitData drmInitData) {
        int i;
        C1402j c1402j = new C1402j(bArr);
        c1402j.m2748b(60);
        int i2 = f2331a[c1402j.m2750c(6)];
        int i3 = f2332b[c1402j.m2750c(4)];
        int c = c1402j.m2750c(5);
        c = c >= f2333c.length ? -1 : (f2333c[c] * 1000) / 2;
        c1402j.m2748b(10);
        if (c1402j.m2750c(2) > 0) {
            i = 1;
        } else {
            i = 0;
        }
        return Format.m2407a(str, "audio/vnd.dts", null, c, -1, i2 + i, i3, null, drmInitData, 0, str2);
    }

    public static int m2592a(byte[] bArr) {
        return ((((bArr[4] & 1) << 6) | ((bArr[5] & 252) >> 2)) + 1) * 32;
    }

    public static int m2591a(ByteBuffer byteBuffer) {
        int position = byteBuffer.position();
        return ((((byteBuffer.get(position + 5) & 252) >> 2) | ((byteBuffer.get(position + 4) & 1) << 6)) + 1) * 32;
    }

    public static int m2594b(byte[] bArr) {
        return ((((bArr[5] & 2) << 12) | ((bArr[6] & 255) << 4)) | ((bArr[7] & 240) >> 4)) + 1;
    }
}
