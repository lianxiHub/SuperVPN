package com.google.android.exoplayer2.audio;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import java.util.Arrays;

@TargetApi(21)
public final class C1361b {
    public static final C1361b f2310a = new C1361b(new int[]{2}, 2);
    private final int[] f2311b;
    private final int f2312c;

    public static C1361b m2575a(Context context) {
        return C1361b.m2576a(context.registerReceiver(null, new IntentFilter("android.media.action.HDMI_AUDIO_PLUG")));
    }

    @SuppressLint({"InlinedApi"})
    static C1361b m2576a(Intent intent) {
        if (intent == null || intent.getIntExtra("android.media.extra.AUDIO_PLUG_STATE", 0) == 0) {
            return f2310a;
        }
        return new C1361b(intent.getIntArrayExtra("android.media.extra.ENCODINGS"), intent.getIntExtra("android.media.extra.MAX_CHANNEL_COUNT", 0));
    }

    C1361b(int[] iArr, int i) {
        if (iArr != null) {
            this.f2311b = Arrays.copyOf(iArr, iArr.length);
            Arrays.sort(this.f2311b);
        } else {
            this.f2311b = new int[0];
        }
        this.f2312c = i;
    }

    public boolean m2577a(int i) {
        return Arrays.binarySearch(this.f2311b, i) >= 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C1361b)) {
            return false;
        }
        C1361b c1361b = (C1361b) obj;
        if (Arrays.equals(this.f2311b, c1361b.f2311b) && this.f2312c == c1361b.f2312c) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return this.f2312c + (Arrays.hashCode(this.f2311b) * 31);
    }

    public String toString() {
        return "AudioCapabilities[maxChannelCount=" + this.f2312c + ", supportedEncodings=" + Arrays.toString(this.f2311b) + "]";
    }
}
