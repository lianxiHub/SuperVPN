package com.google.android.exoplayer2.p033d;

import com.google.android.exoplayer2.ParserException;
import com.google.android.exoplayer2.p031c.C1393b;
import com.google.android.exoplayer2.p031c.C1401i;
import com.google.android.exoplayer2.p031c.C1401i.C1400b;
import com.google.android.exoplayer2.p031c.C1403k;
import com.mopub.volley.DefaultRetryPolicy;
import java.util.ArrayList;
import java.util.List;

public final class C1419a {
    public final List f2522a;
    public final int f2523b;
    public final int f2524c;
    public final int f2525d;
    public final float f2526e;

    public static C1419a m2854a(C1403k c1403k) {
        int i = -1;
        int i2 = 0;
        try {
            c1403k.m2762d(4);
            int g = (c1403k.m2766g() & 3) + 1;
            if (g == 3) {
                throw new IllegalStateException();
            }
            int i3;
            List arrayList = new ArrayList();
            int g2 = c1403k.m2766g() & 31;
            for (i3 = 0; i3 < g2; i3++) {
                arrayList.add(C1419a.m2855b(c1403k));
            }
            i3 = c1403k.m2766g();
            while (i2 < i3) {
                arrayList.add(C1419a.m2855b(c1403k));
                i2++;
            }
            float f = DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;
            if (g2 > 0) {
                C1400b a = C1401i.m2737a((byte[]) arrayList.get(0), g, ((byte[]) arrayList.get(0)).length);
                i3 = a.f2462b;
                i = a.f2463c;
                f = a.f2464d;
            } else {
                i3 = -1;
            }
            return new C1419a(arrayList, g, i3, i, f);
        } catch (Throwable e) {
            throw new ParserException("Error parsing AVC config", e);
        }
    }

    private C1419a(List list, int i, int i2, int i3, float f) {
        this.f2522a = list;
        this.f2523b = i;
        this.f2524c = i2;
        this.f2525d = i3;
        this.f2526e = f;
    }

    private static byte[] m2855b(C1403k c1403k) {
        int h = c1403k.m2767h();
        int d = c1403k.m2761d();
        c1403k.m2762d(h);
        return C1393b.m2715a(c1403k.f2479a, d, h);
    }
}
