package com.google.android.exoplayer2.p033d;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.HandlerThread;
import android.os.Message;
import android.view.Choreographer;
import android.view.Choreographer.FrameCallback;
import android.view.WindowManager;

@TargetApi(16)
public final class C1424d {
    private final C1423a f2562a;
    private final boolean f2563b;
    private final long f2564c;
    private final long f2565d;
    private long f2566e;
    private long f2567f;
    private long f2568g;
    private boolean f2569h;
    private long f2570i;
    private long f2571j;
    private long f2572k;

    private static final class C1423a implements Callback, FrameCallback {
        private static final C1423a f2556b = new C1423a();
        public volatile long f2557a;
        private final Handler f2558c;
        private final HandlerThread f2559d = new HandlerThread("ChoreographerOwner:Handler");
        private Choreographer f2560e;
        private int f2561f;

        public static C1423a m2887a() {
            return f2556b;
        }

        private C1423a() {
            this.f2559d.start();
            this.f2558c = new Handler(this.f2559d.getLooper(), this);
            this.f2558c.sendEmptyMessage(0);
        }

        public void m2891b() {
            this.f2558c.sendEmptyMessage(1);
        }

        public void m2892c() {
            this.f2558c.sendEmptyMessage(2);
        }

        public void doFrame(long j) {
            this.f2557a = j;
            this.f2560e.postFrameCallbackDelayed(this, 500);
        }

        public boolean handleMessage(Message message) {
            switch (message.what) {
                case 0:
                    m2888d();
                    return true;
                case 1:
                    m2889e();
                    return true;
                case 2:
                    m2890f();
                    return true;
                default:
                    return false;
            }
        }

        private void m2888d() {
            this.f2560e = Choreographer.getInstance();
        }

        private void m2889e() {
            this.f2561f++;
            if (this.f2561f == 1) {
                this.f2560e.postFrameCallback(this);
            }
        }

        private void m2890f() {
            this.f2561f--;
            if (this.f2561f == 0) {
                this.f2560e.removeFrameCallback(this);
                this.f2557a = 0;
            }
        }
    }

    public C1424d() {
        this(-1.0d, false);
    }

    public C1424d(Context context) {
        this((double) C1424d.m2893a(context), true);
    }

    private C1424d(double d, boolean z) {
        this.f2563b = z;
        if (z) {
            this.f2562a = C1423a.m2887a();
            this.f2564c = (long) (1.0E9d / d);
            this.f2565d = (this.f2564c * 80) / 100;
            return;
        }
        this.f2562a = null;
        this.f2564c = -1;
        this.f2565d = -1;
    }

    public void m2897a() {
        this.f2569h = false;
        if (this.f2563b) {
            this.f2562a.m2891b();
        }
    }

    public void m2898b() {
        if (this.f2563b) {
            this.f2562a.m2892c();
        }
    }

    public long m2896a(long j, long j2) {
        long j3;
        long j4;
        long j5 = j * 1000;
        if (this.f2569h) {
            if (j != this.f2566e) {
                this.f2572k++;
                this.f2567f = this.f2568g;
            }
            if (this.f2572k >= 6) {
                j3 = this.f2567f + ((j5 - this.f2571j) / this.f2572k);
                if (m2895b(j3, j2)) {
                    this.f2569h = false;
                    j4 = j2;
                    j3 = j5;
                } else {
                    j4 = (this.f2570i + j3) - this.f2571j;
                }
                if (!this.f2569h) {
                    this.f2571j = j5;
                    this.f2570i = j2;
                    this.f2572k = 0;
                    this.f2569h = true;
                    m2899c();
                }
                this.f2566e = j;
                this.f2568g = j3;
                return (this.f2562a == null || this.f2562a.f2557a == 0) ? j4 : C1424d.m2894a(j4, this.f2562a.f2557a, this.f2564c) - this.f2565d;
            } else if (m2895b(j5, j2)) {
                this.f2569h = false;
            }
        }
        j4 = j2;
        j3 = j5;
        if (this.f2569h) {
            this.f2571j = j5;
            this.f2570i = j2;
            this.f2572k = 0;
            this.f2569h = true;
            m2899c();
        }
        this.f2566e = j;
        this.f2568g = j3;
        if (this.f2562a == null) {
            return j4;
        }
    }

    protected void m2899c() {
    }

    private boolean m2895b(long j, long j2) {
        return Math.abs((j2 - this.f2570i) - (j - this.f2571j)) > 20000000;
    }

    private static long m2894a(long j, long j2, long j3) {
        long j4;
        long j5 = (((j - j2) / j3) * j3) + j2;
        if (j <= j5) {
            j4 = j5 - j3;
        } else {
            j4 = j5;
            j5 += j3;
        }
        if (j5 - j < j - j4) {
            return j5;
        }
        return j4;
    }

    private static float m2893a(Context context) {
        return ((WindowManager) context.getSystemService("window")).getDefaultDisplay().getRefreshRate();
    }
}
