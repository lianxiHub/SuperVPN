package com.google.android.exoplayer2.p033d;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.os.Handler;
import android.os.SystemClock;
import android.view.Surface;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.drm.C1438b;
import com.google.android.exoplayer2.drm.DrmInitData;
import com.google.android.exoplayer2.mediacodec.C1598a;
import com.google.android.exoplayer2.mediacodec.C1599b;
import com.google.android.exoplayer2.mediacodec.MediaCodecRenderer;
import com.google.android.exoplayer2.mediacodec.MediaCodecUtil;
import com.google.android.exoplayer2.p030a.C1346d;
import com.google.android.exoplayer2.p031c.C1398h;
import com.google.android.exoplayer2.p031c.C1412q;
import com.google.android.exoplayer2.p031c.C1414r;
import com.google.android.exoplayer2.p033d.C1433e.C1432a;
import com.mopub.mobileads.VastIconXmlManager;
import com.mopub.volley.DefaultRetryPolicy;
import java.nio.ByteBuffer;

@TargetApi(16)
public class C1422c extends MediaCodecRenderer {
    private final C1424d f2532b;
    private final C1432a f2533c;
    private final long f2534d;
    private final int f2535e;
    private final int f2536f;
    private final boolean f2537g = C1422c.m2857B();
    private Format[] f2538h;
    private C1421a f2539i;
    private Surface f2540j;
    private boolean f2541k;
    private long f2542l = -9223372036854775807L;
    private long f2543m;
    private int f2544n;
    private int f2545o;
    private int f2546p;
    private float f2547q = -1.0f;
    private int f2548r = -1;
    private int f2549s = -1;
    private int f2550t;
    private float f2551u = -1.0f;
    private int f2552v = -1;
    private int f2553w = -1;
    private int f2554x;
    private float f2555y = -1.0f;

    private static final class C1421a {
        public final int f2529a;
        public final int f2530b;
        public final int f2531c;

        public C1421a(int i, int i2, int i3) {
            this.f2529a = i;
            this.f2530b = i2;
            this.f2531c = i3;
        }
    }

    public C1422c(Context context, C1599b c1599b, int i, long j, C1438b c1438b, boolean z, Handler handler, C1433e c1433e, int i2) {
        super(2, c1599b, c1438b, z);
        this.f2535e = i;
        this.f2534d = j;
        this.f2536f = i2;
        this.f2532b = new C1424d(context);
        this.f2533c = new C1432a(handler, c1433e);
    }

    protected int mo2128a(C1599b c1599b, Format format) {
        boolean z = false;
        String str = format.f2183e;
        if (!C1398h.m2731b(str)) {
            return 0;
        }
        boolean z2;
        DrmInitData drmInitData = format.f2186h;
        if (drmInitData != null) {
            z2 = false;
            for (int i = 0; i < drmInitData.f2600a; i++) {
                z2 |= drmInitData.m2939a(i).f2597c;
            }
        } else {
            z2 = false;
        }
        C1598a a = c1599b.mo2256a(str, z2);
        if (a == null) {
            return 1;
        }
        boolean b = a.m3748b(format.f2181c);
        if (!b || format.f2187i <= 0 || format.f2188j <= 0) {
            z = b;
        } else if (C1414r.f2503a >= 21) {
            if (format.f2189k > 0.0f) {
                z = a.m3745a(format.f2187i, format.f2188j, (double) format.f2189k);
            } else {
                z = a.m3744a(format.f2187i, format.f2188j);
            }
        } else if (format.f2187i * format.f2188j <= MediaCodecUtil.m3736b()) {
            z = true;
        }
        return (a.f3459b ? 8 : 4) | (z ? 3 : 2);
    }

    protected void mo2122a(boolean z) {
        super.mo2122a(z);
        this.f2533c.m2905a(this.a);
        this.f2532b.m2897a();
    }

    protected void mo2153a(Format[] formatArr) {
        this.f2538h = formatArr;
        super.mo2153a(formatArr);
    }

    protected void mo2121a(long j, boolean z) {
        super.mo2121a(j, z);
        this.f2541k = false;
        this.f2545o = 0;
        long elapsedRealtime = (!z || this.f2534d <= 0) ? -9223372036854775807L : SystemClock.elapsedRealtime() + this.f2534d;
        this.f2542l = elapsedRealtime;
    }

    public boolean mo2126r() {
        if ((this.f2541k || super.mo2155x()) && super.mo2126r()) {
            this.f2542l = -9223372036854775807L;
            return true;
        } else if (this.f2542l == -9223372036854775807L) {
            return false;
        } else {
            if (SystemClock.elapsedRealtime() < this.f2542l) {
                return true;
            }
            this.f2542l = -9223372036854775807L;
            return false;
        }
    }

    protected void mo2123m() {
        super.mo2123m();
        this.f2544n = 0;
        this.f2543m = SystemClock.elapsedRealtime();
    }

    protected void mo2124n() {
        this.f2542l = -9223372036854775807L;
        m2870v();
        super.mo2124n();
    }

    protected void mo2125o() {
        this.f2548r = -1;
        this.f2549s = -1;
        this.f2551u = -1.0f;
        this.f2547q = -1.0f;
        this.f2552v = -1;
        this.f2553w = -1;
        this.f2555y = -1.0f;
        this.f2532b.m2898b();
        try {
            super.mo2125o();
        } finally {
            this.a.m2435a();
            this.f2533c.m2907b(this.a);
        }
    }

    public void mo2098a(int i, Object obj) {
        if (i == 1) {
            m2862a((Surface) obj);
        } else {
            super.mo2098a(i, obj);
        }
    }

    private void m2862a(Surface surface) {
        if (this.f2540j != surface) {
            this.f2541k = false;
            this.f2540j = surface;
            int d = mo2104d();
            if (d == 1 || d == 2) {
                m2635y();
                m2633w();
            }
        }
    }

    protected boolean mo2155x() {
        return super.mo2155x() && this.f2540j != null && this.f2540j.isValid();
    }

    protected void mo2131a(MediaCodec mediaCodec, Format format, MediaCrypto mediaCrypto) {
        this.f2539i = C1422c.m2859a(format, this.f2538h);
        mediaCodec.configure(C1422c.m2858a(format, this.f2539i, this.f2537g), this.f2540j, mediaCrypto, 0);
    }

    protected void mo2132a(String str, long j, long j2) {
        this.f2533c.m2906a(str, j, j2);
    }

    protected void mo2135b(Format format) {
        super.mo2135b(format);
        this.f2533c.m2904a(format);
        this.f2547q = C1422c.m2867d(format);
        this.f2546p = C1422c.m2868e(format);
    }

    protected void mo2130a(MediaCodec mediaCodec, MediaFormat mediaFormat) {
        int integer;
        Object obj = (mediaFormat.containsKey("crop-right") && mediaFormat.containsKey("crop-left") && mediaFormat.containsKey("crop-bottom") && mediaFormat.containsKey("crop-top")) ? 1 : null;
        if (obj != null) {
            integer = (mediaFormat.getInteger("crop-right") - mediaFormat.getInteger("crop-left")) + 1;
        } else {
            integer = mediaFormat.getInteger(VastIconXmlManager.WIDTH);
        }
        this.f2548r = integer;
        if (obj != null) {
            integer = (mediaFormat.getInteger("crop-bottom") - mediaFormat.getInteger("crop-top")) + 1;
        } else {
            integer = mediaFormat.getInteger(VastIconXmlManager.HEIGHT);
        }
        this.f2549s = integer;
        this.f2551u = this.f2547q;
        if (C1414r.f2503a < 21) {
            this.f2550t = this.f2546p;
        } else if (this.f2546p == 90 || this.f2546p == 270) {
            integer = this.f2548r;
            this.f2548r = this.f2549s;
            this.f2549s = integer;
            this.f2551u = DefaultRetryPolicy.DEFAULT_BACKOFF_MULT / this.f2551u;
        }
        mediaCodec.setVideoScalingMode(this.f2535e);
    }

    protected boolean mo2154a(MediaCodec mediaCodec, boolean z, Format format, Format format2) {
        return C1422c.m2863a(format, format2) && format2.f2187i <= this.f2539i.f2529a && format2.f2188j <= this.f2539i.f2530b && format2.f2184f <= this.f2539i.f2531c && (z || (format.f2187i == format2.f2187i && format.f2188j == format2.f2188j));
    }

    protected boolean mo2133a(long j, long j2, MediaCodec mediaCodec, ByteBuffer byteBuffer, int i, int i2, long j3, boolean z) {
        if (z) {
            m2860a(mediaCodec, i);
            return true;
        } else if (!this.f2541k) {
            if (C1414r.f2503a >= 21) {
                m2861a(mediaCodec, i, System.nanoTime());
            } else {
                m2866c(mediaCodec, i);
            }
            return true;
        } else if (mo2104d() != 2) {
            return false;
        } else {
            long elapsedRealtime = (j3 - j) - ((SystemClock.elapsedRealtime() * 1000) - j2);
            long nanoTime = System.nanoTime();
            elapsedRealtime = this.f2532b.m2896a(j3, (elapsedRealtime * 1000) + nanoTime);
            nanoTime = (elapsedRealtime - nanoTime) / 1000;
            if (nanoTime < -30000) {
                m2864b(mediaCodec, i);
                return true;
            }
            if (C1414r.f2503a >= 21) {
                if (nanoTime < 50000) {
                    m2861a(mediaCodec, i, elapsedRealtime);
                    return true;
                }
            } else if (nanoTime < 30000) {
                if (nanoTime > 11000) {
                    try {
                        Thread.sleep((nanoTime - 10000) / 1000);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }
                m2866c(mediaCodec, i);
                return true;
            }
            return false;
        }
    }

    private void m2860a(MediaCodec mediaCodec, int i) {
        C1412q.m2809a("skipVideoBuffer");
        mediaCodec.releaseOutputBuffer(i, false);
        C1412q.m2808a();
        C1346d c1346d = this.a;
        c1346d.f2216e++;
    }

    private void m2864b(MediaCodec mediaCodec, int i) {
        C1412q.m2809a("dropVideoBuffer");
        mediaCodec.releaseOutputBuffer(i, false);
        C1412q.m2808a();
        C1346d c1346d = this.a;
        c1346d.f2217f++;
        this.f2544n++;
        this.f2545o++;
        this.a.f2218g = Math.max(this.f2545o, this.a.f2218g);
        if (this.f2544n == this.f2536f) {
            m2870v();
        }
    }

    private void m2866c(MediaCodec mediaCodec, int i) {
        m2869t();
        C1412q.m2809a("releaseOutputBuffer");
        mediaCodec.releaseOutputBuffer(i, true);
        C1412q.m2808a();
        C1346d c1346d = this.a;
        c1346d.f2215d++;
        this.f2545o = 0;
        if (!this.f2541k) {
            this.f2541k = true;
            this.f2533c.m2903a(this.f2540j);
        }
    }

    @TargetApi(21)
    private void m2861a(MediaCodec mediaCodec, int i, long j) {
        m2869t();
        C1412q.m2809a("releaseOutputBuffer");
        mediaCodec.releaseOutputBuffer(i, j);
        C1412q.m2808a();
        C1346d c1346d = this.a;
        c1346d.f2215d++;
        this.f2545o = 0;
        if (!this.f2541k) {
            this.f2541k = true;
            this.f2533c.m2903a(this.f2540j);
        }
    }

    @SuppressLint({"InlinedApi"})
    private static MediaFormat m2858a(Format format, C1421a c1421a, boolean z) {
        MediaFormat b = format.m2420b();
        b.setInteger("max-width", c1421a.f2529a);
        b.setInteger("max-height", c1421a.f2530b);
        if (c1421a.f2531c != -1) {
            b.setInteger("max-input-size", c1421a.f2531c);
        }
        if (z) {
            b.setInteger("auto-frc", 0);
        }
        return b;
    }

    private static C1421a m2859a(Format format, Format[] formatArr) {
        int i = format.f2187i;
        int i2 = format.f2188j;
        int c = C1422c.m2865c(format);
        int i3 = c;
        c = i2;
        i2 = i;
        for (Format format2 : formatArr) {
            if (C1422c.m2863a(format, format2)) {
                i2 = Math.max(i2, format2.f2187i);
                c = Math.max(c, format2.f2188j);
                i3 = Math.max(i3, C1422c.m2865c(format2));
            }
        }
        return new C1421a(i2, c, i3);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static int m2865c(com.google.android.exoplayer2.Format r6) {
        /*
        r1 = 4;
        r0 = 2;
        r2 = -1;
        r3 = r6.f2184f;
        if (r3 == r2) goto L_0x000a;
    L_0x0007:
        r0 = r6.f2184f;
    L_0x0009:
        return r0;
    L_0x000a:
        r3 = r6.f2187i;
        if (r3 == r2) goto L_0x0012;
    L_0x000e:
        r3 = r6.f2188j;
        if (r3 != r2) goto L_0x0014;
    L_0x0012:
        r0 = r2;
        goto L_0x0009;
    L_0x0014:
        r3 = r6.f2183e;
        r4 = r3.hashCode();
        switch(r4) {
            case -1664118616: goto L_0x0023;
            case -1662541442: goto L_0x004f;
            case 1187890754: goto L_0x002e;
            case 1331836730: goto L_0x0039;
            case 1599127256: goto L_0x0044;
            case 1599127257: goto L_0x005a;
            default: goto L_0x001d;
        };
    L_0x001d:
        r3 = r2;
    L_0x001e:
        switch(r3) {
            case 0: goto L_0x0065;
            case 1: goto L_0x0065;
            case 2: goto L_0x0071;
            case 3: goto L_0x0090;
            case 4: goto L_0x0096;
            case 5: goto L_0x0096;
            default: goto L_0x0021;
        };
    L_0x0021:
        r0 = r2;
        goto L_0x0009;
    L_0x0023:
        r4 = "video/3gpp";
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x001d;
    L_0x002c:
        r3 = 0;
        goto L_0x001e;
    L_0x002e:
        r4 = "video/mp4v-es";
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x001d;
    L_0x0037:
        r3 = 1;
        goto L_0x001e;
    L_0x0039:
        r4 = "video/avc";
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x001d;
    L_0x0042:
        r3 = r0;
        goto L_0x001e;
    L_0x0044:
        r4 = "video/x-vnd.on2.vp8";
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x001d;
    L_0x004d:
        r3 = 3;
        goto L_0x001e;
    L_0x004f:
        r4 = "video/hevc";
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x001d;
    L_0x0058:
        r3 = r1;
        goto L_0x001e;
    L_0x005a:
        r4 = "video/x-vnd.on2.vp9";
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x001d;
    L_0x0063:
        r3 = 5;
        goto L_0x001e;
    L_0x0065:
        r1 = r6.f2187i;
        r2 = r6.f2188j;
        r1 = r1 * r2;
    L_0x006a:
        r1 = r1 * 3;
        r0 = r0 * 2;
        r0 = r1 / r0;
        goto L_0x0009;
    L_0x0071:
        r1 = "BRAVIA 4K 2015";
        r3 = com.google.android.exoplayer2.p031c.C1414r.f2506d;
        r1 = r1.equals(r3);
        if (r1 == 0) goto L_0x007e;
    L_0x007c:
        r0 = r2;
        goto L_0x0009;
    L_0x007e:
        r1 = r6.f2187i;
        r1 = r1 + 15;
        r1 = r1 / 16;
        r2 = r6.f2188j;
        r2 = r2 + 15;
        r2 = r2 / 16;
        r1 = r1 * r2;
        r1 = r1 * 16;
        r1 = r1 * 16;
        goto L_0x006a;
    L_0x0090:
        r1 = r6.f2187i;
        r2 = r6.f2188j;
        r1 = r1 * r2;
        goto L_0x006a;
    L_0x0096:
        r0 = r6.f2187i;
        r2 = r6.f2188j;
        r0 = r0 * r2;
        r5 = r1;
        r1 = r0;
        r0 = r5;
        goto L_0x006a;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.d.c.c(com.google.android.exoplayer2.Format):int");
    }

    private void m2869t() {
        if (this.f2552v != this.f2548r || this.f2553w != this.f2549s || this.f2554x != this.f2550t || this.f2555y != this.f2551u) {
            this.f2533c.m2901a(this.f2548r, this.f2549s, this.f2550t, this.f2551u);
            this.f2552v = this.f2548r;
            this.f2553w = this.f2549s;
            this.f2554x = this.f2550t;
            this.f2555y = this.f2551u;
        }
    }

    private void m2870v() {
        if (this.f2544n > 0) {
            long elapsedRealtime = SystemClock.elapsedRealtime();
            this.f2533c.m2902a(this.f2544n, elapsedRealtime - this.f2543m);
            this.f2544n = 0;
            this.f2543m = elapsedRealtime;
        }
    }

    private static boolean m2857B() {
        return C1414r.f2503a <= 22 && "foster".equals(C1414r.f2504b) && "NVIDIA".equals(C1414r.f2505c);
    }

    private static boolean m2863a(Format format, Format format2) {
        return format.f2183e.equals(format2.f2183e) && C1422c.m2868e(format) == C1422c.m2868e(format2);
    }

    private static float m2867d(Format format) {
        return format.f2191m == -1.0f ? DefaultRetryPolicy.DEFAULT_BACKOFF_MULT : format.f2191m;
    }

    private static int m2868e(Format format) {
        return format.f2190l == -1 ? 0 : format.f2190l;
    }
}
