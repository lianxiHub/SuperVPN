package com.google.android.exoplayer2.p033d;

import com.google.android.exoplayer2.ParserException;
import com.google.android.exoplayer2.p031c.C1401i;
import com.google.android.exoplayer2.p031c.C1403k;
import java.util.Collections;
import java.util.List;

public final class C1420b {
    public final List f2527a;
    public final int f2528b;

    public static C1420b m2856a(C1403k c1403k) {
        try {
            int h;
            int i;
            int i2;
            c1403k.m2762d(21);
            int g = c1403k.m2766g() & 3;
            int g2 = c1403k.m2766g();
            int d = c1403k.m2761d();
            int i3 = 0;
            int i4 = 0;
            while (i3 < g2) {
                c1403k.m2762d(1);
                h = c1403k.m2767h();
                i = i4;
                for (i2 = 0; i2 < h; i2++) {
                    i4 = c1403k.m2767h();
                    i += i4 + 4;
                    c1403k.m2762d(i4);
                }
                i3++;
                i4 = i;
            }
            c1403k.m2760c(d);
            Object obj = new byte[i4];
            i3 = 0;
            i2 = 0;
            while (i3 < g2) {
                c1403k.m2762d(1);
                h = c1403k.m2767h();
                i = i2;
                for (i2 = 0; i2 < h; i2++) {
                    int h2 = c1403k.m2767h();
                    System.arraycopy(C1401i.f2471a, 0, obj, i, C1401i.f2471a.length);
                    i += C1401i.f2471a.length;
                    System.arraycopy(c1403k.f2479a, c1403k.m2761d(), obj, i, h2);
                    i += h2;
                    c1403k.m2762d(h2);
                }
                i3++;
                i2 = i;
            }
            return new C1420b(i4 == 0 ? null : Collections.singletonList(obj), g + 1);
        } catch (Throwable e) {
            throw new ParserException("Error parsing HEVC config", e);
        }
    }

    private C1420b(List list, int i) {
        this.f2527a = list;
        this.f2528b = i;
    }
}
