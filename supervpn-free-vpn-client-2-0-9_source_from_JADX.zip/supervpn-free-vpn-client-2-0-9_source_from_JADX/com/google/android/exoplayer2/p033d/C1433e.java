package com.google.android.exoplayer2.p033d;

import android.os.Handler;
import android.view.Surface;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.p030a.C1346d;
import com.google.android.exoplayer2.p031c.C1392a;

public interface C1433e {

    public static final class C1432a {
        private final Handler f2593a;
        private final C1433e f2594b;

        public C1432a(Handler handler, C1433e c1433e) {
            this.f2593a = c1433e != null ? (Handler) C1392a.m2707a((Object) handler) : null;
            this.f2594b = c1433e;
        }

        public void m2905a(final C1346d c1346d) {
            if (this.f2594b != null) {
                this.f2593a.post(new Runnable(this) {
                    final /* synthetic */ C1432a f2574b;

                    public void run() {
                        this.f2574b.f2594b.mo2241a(c1346d);
                    }
                });
            }
        }

        public void m2906a(String str, long j, long j2) {
            if (this.f2594b != null) {
                final String str2 = str;
                final long j3 = j;
                final long j4 = j2;
                this.f2593a.post(new Runnable(this) {
                    final /* synthetic */ C1432a f2578d;

                    public void run() {
                        this.f2578d.f2594b.mo2244a(str2, j3, j4);
                    }
                });
            }
        }

        public void m2904a(final Format format) {
            if (this.f2594b != null) {
                this.f2593a.post(new Runnable(this) {
                    final /* synthetic */ C1432a f2580b;

                    public void run() {
                        this.f2580b.f2594b.mo2240a(format);
                    }
                });
            }
        }

        public void m2902a(final int i, final long j) {
            if (this.f2594b != null) {
                this.f2593a.post(new Runnable(this) {
                    final /* synthetic */ C1432a f2583c;

                    public void run() {
                        this.f2583c.f2594b.mo2237a(i, j);
                    }
                });
            }
        }

        public void m2901a(int i, int i2, int i3, float f) {
            if (this.f2594b != null) {
                final int i4 = i;
                final int i5 = i2;
                final int i6 = i3;
                final float f2 = f;
                this.f2593a.post(new Runnable(this) {
                    final /* synthetic */ C1432a f2588e;

                    public void run() {
                        this.f2588e.f2594b.mo2236a(i4, i5, i6, f2);
                    }
                });
            }
        }

        public void m2903a(final Surface surface) {
            if (this.f2594b != null) {
                this.f2593a.post(new Runnable(this) {
                    final /* synthetic */ C1432a f2590b;

                    public void run() {
                        this.f2590b.f2594b.mo2239a(surface);
                    }
                });
            }
        }

        public void m2907b(final C1346d c1346d) {
            if (this.f2594b != null) {
                this.f2593a.post(new Runnable(this) {
                    final /* synthetic */ C1432a f2592b;

                    public void run() {
                        c1346d.m2435a();
                        this.f2592b.f2594b.mo2247b(c1346d);
                    }
                });
            }
        }
    }

    void mo2236a(int i, int i2, int i3, float f);

    void mo2237a(int i, long j);

    void mo2239a(Surface surface);

    void mo2240a(Format format);

    void mo2241a(C1346d c1346d);

    void mo2244a(String str, long j, long j2);

    void mo2247b(C1346d c1346d);
}
