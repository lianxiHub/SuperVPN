package com.google.android.exoplayer2;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.SurfaceTexture;
import android.os.Handler;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.TextureView;
import android.view.TextureView.SurfaceTextureListener;
import com.google.android.exoplayer2.C1434d.C0507a;
import com.google.android.exoplayer2.C1434d.C1351b;
import com.google.android.exoplayer2.C1434d.C1418c;
import com.google.android.exoplayer2.audio.C1361b;
import com.google.android.exoplayer2.audio.C1369c;
import com.google.android.exoplayer2.audio.C1372e;
import com.google.android.exoplayer2.drm.C1438b;
import com.google.android.exoplayer2.mediacodec.C1599b;
import com.google.android.exoplayer2.metadata.C1610b;
import com.google.android.exoplayer2.metadata.C1610b.C1589a;
import com.google.android.exoplayer2.metadata.p040a.C1606d;
import com.google.android.exoplayer2.p030a.C1346d;
import com.google.android.exoplayer2.p032b.C1381h;
import com.google.android.exoplayer2.p032b.C1381h.C1389a;
import com.google.android.exoplayer2.p032b.C1387g;
import com.google.android.exoplayer2.p033d.C1422c;
import com.google.android.exoplayer2.p033d.C1433e;
import com.google.android.exoplayer2.source.C1615c;
import com.google.android.exoplayer2.text.C1670j;
import com.google.android.exoplayer2.text.C1670j.C1590a;
import com.mopub.volley.DefaultRetryPolicy;
import java.util.ArrayList;
import java.util.List;

@TargetApi(16)
public final class C1592m implements C1434d {
    private final C1434d f3421a;
    private final C1352k[] f3422b;
    private final C1591a f3423c = new C1591a();
    private final Handler f3424d = new Handler();
    private final int f3425e;
    private final int f3426f;
    private boolean f3427g;
    private Format f3428h;
    private Format f3429i;
    private Surface f3430j;
    private boolean f3431k;
    private SurfaceHolder f3432l;
    private TextureView f3433m;
    private C1590a f3434n;
    private C1589a f3435o;
    private C0508b f3436p;
    private C1369c f3437q;
    private C1433e f3438r;
    private C1346d f3439s;
    private C1346d f3440t;
    private int f3441u;
    private float f3442v;

    public interface C0508b {
        void onRenderedFirstFrame();

        void onVideoSizeChanged(int i, int i2, int i3, float f);

        void onVideoTracksDisabled();
    }

    private final class C1591a implements Callback, SurfaceTextureListener, C1369c, C1389a, C1433e, C1589a, C1590a {
        final /* synthetic */ C1592m f3420a;

        private C1591a(C1592m c1592m) {
            this.f3420a = c1592m;
        }

        public /* synthetic */ void mo2243a(Object obj) {
            m3668b((List) obj);
        }

        public void mo2241a(C1346d c1346d) {
            this.f3420a.f3439s = c1346d;
            if (this.f3420a.f3438r != null) {
                this.f3420a.f3438r.mo2241a(c1346d);
            }
        }

        public void mo2244a(String str, long j, long j2) {
            if (this.f3420a.f3438r != null) {
                this.f3420a.f3438r.mo2244a(str, j, j2);
            }
        }

        public void mo2240a(Format format) {
            this.f3420a.f3428h = format;
            if (this.f3420a.f3438r != null) {
                this.f3420a.f3438r.mo2240a(format);
            }
        }

        public void mo2237a(int i, long j) {
            if (this.f3420a.f3438r != null) {
                this.f3420a.f3438r.mo2237a(i, j);
            }
        }

        public void mo2236a(int i, int i2, int i3, float f) {
            if (this.f3420a.f3436p != null) {
                this.f3420a.f3436p.onVideoSizeChanged(i, i2, i3, f);
            }
            if (this.f3420a.f3438r != null) {
                this.f3420a.f3438r.mo2236a(i, i2, i3, f);
            }
        }

        public void mo2239a(Surface surface) {
            if (this.f3420a.f3436p != null && this.f3420a.f3430j == surface) {
                this.f3420a.f3436p.onRenderedFirstFrame();
            }
            if (this.f3420a.f3438r != null) {
                this.f3420a.f3438r.mo2239a(surface);
            }
        }

        public void mo2247b(C1346d c1346d) {
            if (this.f3420a.f3438r != null) {
                this.f3420a.f3438r.mo2247b(c1346d);
            }
            this.f3420a.f3428h = null;
            this.f3420a.f3439s = null;
        }

        public void mo2249c(C1346d c1346d) {
            this.f3420a.f3440t = c1346d;
            if (this.f3420a.f3437q != null) {
                this.f3420a.f3437q.mo2249c(c1346d);
            }
        }

        public void mo2235a(int i) {
            this.f3420a.f3441u = i;
            if (this.f3420a.f3437q != null) {
                this.f3420a.f3437q.mo2235a(i);
            }
        }

        public void mo2248b(String str, long j, long j2) {
            if (this.f3420a.f3437q != null) {
                this.f3420a.f3437q.mo2248b(str, j, j2);
            }
        }

        public void mo2246b(Format format) {
            this.f3420a.f3429i = format;
            if (this.f3420a.f3437q != null) {
                this.f3420a.f3437q.mo2246b(format);
            }
        }

        public void mo2238a(int i, long j, long j2) {
            if (this.f3420a.f3437q != null) {
                this.f3420a.f3437q.mo2238a(i, j, j2);
            }
        }

        public void mo2250d(C1346d c1346d) {
            if (this.f3420a.f3437q != null) {
                this.f3420a.f3437q.mo2250d(c1346d);
            }
            this.f3420a.f3429i = null;
            this.f3420a.f3440t = null;
            this.f3420a.f3441u = 0;
        }

        public void mo2245a(List list) {
            if (this.f3420a.f3434n != null) {
                this.f3420a.f3434n.mo2245a(list);
            }
        }

        public void m3668b(List list) {
            if (this.f3420a.f3435o != null) {
                this.f3420a.f3435o.mo2243a(list);
            }
        }

        public void surfaceCreated(SurfaceHolder surfaceHolder) {
            this.f3420a.m3676a(surfaceHolder.getSurface(), false);
        }

        public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
        }

        public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
            this.f3420a.m3676a(null, false);
        }

        public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i2) {
            this.f3420a.m3676a(new Surface(surfaceTexture), true);
        }

        public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i2) {
        }

        public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
            this.f3420a.m3676a(null, true);
            return true;
        }

        public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
        }

        public void mo2242a(C1387g c1387g) {
            boolean z = false;
            int i = 0;
            while (i < this.f3420a.f3422b.length) {
                if (this.f3420a.f3422b[i].mo2096a() == 2 && c1387g.m2701a(i) != null) {
                    z = true;
                    break;
                }
                i++;
            }
            if (!(this.f3420a.f3436p == null || !this.f3420a.f3427g || z)) {
                this.f3420a.f3436p.onVideoTracksDisabled();
            }
            this.f3420a.f3427g = z;
        }
    }

    C1592m(Context context, C1381h c1381h, C1416i c1416i, C1438b c1438b, boolean z, long j) {
        c1381h.m2677a(this.f3423c);
        ArrayList arrayList = new ArrayList();
        if (z) {
            m3678a(arrayList, j);
            m3675a(context, c1438b, arrayList, j);
        } else {
            m3675a(context, c1438b, arrayList, j);
            m3678a(arrayList, j);
        }
        this.f3422b = (C1352k[]) arrayList.toArray(new C1352k[arrayList.size()]);
        int i = 0;
        int i2 = 0;
        for (C1352k a : this.f3422b) {
            switch (a.mo2096a()) {
                case 1:
                    i++;
                    break;
                case 2:
                    i2++;
                    break;
                default:
                    break;
            }
        }
        this.f3425e = i2;
        this.f3426f = i;
        this.f3441u = 0;
        this.f3442v = DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;
        this.f3421a = new C1574f(this.f3422b, c1381h, c1416i);
    }

    public void m3694a(Surface surface) {
        m3689n();
        m3676a(surface, false);
    }

    public void m3695a(TextureView textureView) {
        Surface surface = null;
        m3689n();
        this.f3433m = textureView;
        if (textureView == null) {
            m3676a(null, true);
            return;
        }
        if (textureView.getSurfaceTextureListener() != null) {
            Log.w("SimpleExoPlayer", "Replacing existing SurfaceTextureListener.");
        }
        SurfaceTexture surfaceTexture = textureView.getSurfaceTexture();
        if (surfaceTexture != null) {
            surface = new Surface(surfaceTexture);
        }
        m3676a(surface, true);
        textureView.setSurfaceTextureListener(this.f3423c);
    }

    public void m3691a(float f) {
        this.f3442v = f;
        C1418c[] c1418cArr = new C1418c[this.f3426f];
        C1352k[] c1352kArr = this.f3422b;
        int length = c1352kArr.length;
        int i = 0;
        int i2 = 0;
        while (i < length) {
            int i3;
            C1351b c1351b = c1352kArr[i];
            if (c1351b.mo2096a() == 1) {
                i3 = i2 + 1;
                c1418cArr[i2] = new C1418c(c1351b, 2, Float.valueOf(f));
            } else {
                i3 = i2;
            }
            i++;
            i2 = i3;
        }
        this.f3421a.mo2220a(c1418cArr);
    }

    public Format m3712l() {
        return this.f3429i;
    }

    public int m3713m() {
        return this.f3441u;
    }

    public void m3697a(C0508b c0508b) {
        this.f3436p = c0508b;
    }

    public void mo2217a(C0507a c0507a) {
        this.f3421a.mo2217a(c0507a);
    }

    public int mo2214a() {
        return this.f3421a.mo2214a();
    }

    public void mo2218a(C1615c c1615c) {
        this.f3421a.mo2218a(c1615c);
    }

    public void mo2219a(boolean z) {
        this.f3421a.mo2219a(z);
    }

    public boolean mo2222b() {
        return this.f3421a.mo2222b();
    }

    public void mo2223c() {
        this.f3421a.mo2223c();
    }

    public void mo2215a(int i) {
        this.f3421a.mo2215a(i);
    }

    public void mo2216a(long j) {
        this.f3421a.mo2216a(j);
    }

    public void mo2224d() {
        this.f3421a.mo2224d();
    }

    public void mo2225e() {
        this.f3421a.mo2225e();
        m3689n();
        if (this.f3430j != null) {
            if (this.f3431k) {
                this.f3430j.release();
            }
            this.f3430j = null;
        }
    }

    public void mo2220a(C1418c... c1418cArr) {
        this.f3421a.mo2220a(c1418cArr);
    }

    public void mo2221b(C1418c... c1418cArr) {
        this.f3421a.mo2221b(c1418cArr);
    }

    public int mo2227g() {
        return this.f3421a.mo2227g();
    }

    public long mo2228h() {
        return this.f3421a.mo2228h();
    }

    public long mo2229i() {
        return this.f3421a.mo2229i();
    }

    public long mo2230j() {
        return this.f3421a.mo2230j();
    }

    public int mo2231k() {
        return this.f3421a.mo2231k();
    }

    public C1613n mo2226f() {
        return this.f3421a.mo2226f();
    }

    private void m3675a(Context context, C1438b c1438b, ArrayList arrayList, long j) {
        arrayList.add(new C1422c(context, C1599b.f3462a, 1, j, c1438b, false, this.f3424d, this.f3423c, 50));
        arrayList.add(new C1372e(C1599b.f3462a, c1438b, true, this.f3424d, this.f3423c, C1361b.m2575a(context), 3));
        arrayList.add(new C1670j(this.f3423c, this.f3424d.getLooper()));
        arrayList.add(new C1610b(this.f3423c, this.f3424d.getLooper(), new C1606d()));
    }

    private void m3678a(ArrayList arrayList, long j) {
        try {
            arrayList.add((C1352k) Class.forName("com.google.android.exoplayer2.ext.vp9.LibvpxVideoRenderer").getConstructor(new Class[]{Boolean.TYPE, Long.TYPE, Handler.class, C1433e.class, Integer.TYPE}).newInstance(new Object[]{Boolean.valueOf(true), Long.valueOf(j), this.f3424d, this.f3423c, Integer.valueOf(50)}));
            Log.i("SimpleExoPlayer", "Loaded LibvpxVideoRenderer.");
        } catch (ClassNotFoundException e) {
        } catch (Throwable e2) {
            throw new RuntimeException(e2);
        }
        try {
            arrayList.add((C1352k) Class.forName("com.google.android.exoplayer2.ext.opus.LibopusAudioRenderer").getConstructor(new Class[]{Handler.class, C1369c.class}).newInstance(new Object[]{this.f3424d, this.f3423c}));
            Log.i("SimpleExoPlayer", "Loaded LibopusAudioRenderer.");
        } catch (ClassNotFoundException e3) {
        } catch (Throwable e22) {
            throw new RuntimeException(e22);
        }
        try {
            arrayList.add((C1352k) Class.forName("com.google.android.exoplayer2.ext.flac.LibflacAudioRenderer").getConstructor(new Class[]{Handler.class, C1369c.class}).newInstance(new Object[]{this.f3424d, this.f3423c}));
            Log.i("SimpleExoPlayer", "Loaded LibflacAudioRenderer.");
        } catch (ClassNotFoundException e4) {
        } catch (Throwable e222) {
            throw new RuntimeException(e222);
        }
        try {
            arrayList.add((C1352k) Class.forName("com.google.android.exoplayer2.ext.ffmpeg.FfmpegAudioRenderer").getConstructor(new Class[]{Handler.class, C1369c.class}).newInstance(new Object[]{this.f3424d, this.f3423c}));
            Log.i("SimpleExoPlayer", "Loaded FfmpegAudioRenderer.");
        } catch (ClassNotFoundException e5) {
        } catch (Throwable e2222) {
            throw new RuntimeException(e2222);
        }
    }

    private void m3689n() {
        if (this.f3433m != null) {
            if (this.f3433m.getSurfaceTextureListener() != this.f3423c) {
                Log.w("SimpleExoPlayer", "SurfaceTextureListener already unset or replaced.");
            } else {
                this.f3433m.setSurfaceTextureListener(null);
            }
            this.f3433m = null;
        }
        if (this.f3432l != null) {
            this.f3432l.removeCallback(this.f3423c);
            this.f3432l = null;
        }
    }

    private void m3676a(Surface surface, boolean z) {
        C1418c[] c1418cArr = new C1418c[this.f3425e];
        C1352k[] c1352kArr = this.f3422b;
        int length = c1352kArr.length;
        int i = 0;
        int i2 = 0;
        while (i < length) {
            int i3;
            C1351b c1351b = c1352kArr[i];
            if (c1351b.mo2096a() == 2) {
                i3 = i2 + 1;
                c1418cArr[i2] = new C1418c(c1351b, 1, surface);
            } else {
                i3 = i2;
            }
            i++;
            i2 = i3;
        }
        if (this.f3430j == null || this.f3430j == surface) {
            this.f3421a.mo2220a(c1418cArr);
        } else {
            if (this.f3431k) {
                this.f3430j.release();
            }
            this.f3421a.mo2221b(c1418cArr);
        }
        this.f3430j = surface;
        this.f3431k = z;
    }
}
