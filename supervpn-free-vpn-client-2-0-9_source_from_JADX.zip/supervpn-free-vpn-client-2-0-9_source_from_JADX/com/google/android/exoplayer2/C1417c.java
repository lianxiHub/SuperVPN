package com.google.android.exoplayer2;

import com.google.android.exoplayer2.p031c.C1414r;
import com.google.android.exoplayer2.p032b.C1387g;
import com.google.android.exoplayer2.source.C1631h;
import com.google.android.exoplayer2.upstream.C1684b;
import com.google.android.exoplayer2.upstream.C1688f;

public final class C1417c implements C1416i {
    private final C1688f f2512a;
    private final long f2513b;
    private final long f2514c;
    private final long f2515d;
    private final long f2516e;
    private int f2517f;
    private boolean f2518g;

    public C1417c() {
        this(new C1688f(true, 65536));
    }

    public C1417c(C1688f c1688f) {
        this(c1688f, 15000, 30000, 2500, 5000);
    }

    public C1417c(C1688f c1688f, int i, int i2, long j, long j2) {
        this.f2512a = c1688f;
        this.f2513b = ((long) i) * 1000;
        this.f2514c = ((long) i2) * 1000;
        this.f2515d = j * 1000;
        this.f2516e = j2 * 1000;
    }

    public void mo2146a() {
        m2845a(false);
    }

    public void mo2147a(C1352k[] c1352kArr, C1631h c1631h, C1387g c1387g) {
        int i = 0;
        this.f2517f = 0;
        while (i < c1352kArr.length) {
            if (c1387g.m2701a(i) != null) {
                this.f2517f += C1414r.m2825b(c1352kArr[i].mo2096a());
            }
            i++;
        }
        this.f2512a.m4228a(this.f2517f);
    }

    public void mo2150b() {
        m2845a(true);
    }

    public void mo2151c() {
        m2845a(true);
    }

    public C1684b mo2152d() {
        return this.f2512a;
    }

    public boolean mo2149a(long j, boolean z) {
        long j2 = z ? this.f2516e : this.f2515d;
        return j2 <= 0 || j >= j2;
    }

    public boolean mo2148a(long j) {
        boolean z = false;
        int b = m2846b(j);
        boolean z2;
        if (this.f2512a.m4234e() >= this.f2517f) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (b == 2 || (b == 1 && this.f2518g && !r2)) {
            z = true;
        }
        this.f2518g = z;
        return this.f2518g;
    }

    private int m2846b(long j) {
        if (j > this.f2514c) {
            return 0;
        }
        return j < this.f2513b ? 2 : 1;
    }

    private void m2845a(boolean z) {
        this.f2517f = 0;
        this.f2518g = false;
        if (z) {
            this.f2512a.m4233d();
        }
    }
}
