package com.google.android.exoplayer2;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.util.Pair;
import com.google.android.exoplayer2.C1434d.C0507a;
import com.google.android.exoplayer2.C1434d.C1418c;
import com.google.android.exoplayer2.C1580g.C1576b;
import com.google.android.exoplayer2.C1613n.C1611a;
import com.google.android.exoplayer2.C1613n.C1612b;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p032b.C1381h;
import com.google.android.exoplayer2.source.C1615c;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArraySet;

final class C1574f implements C1434d {
    private final Handler f3351a;
    private final C1580g f3352b;
    private final CopyOnWriteArraySet f3353c;
    private final C1612b f3354d;
    private final C1611a f3355e;
    private boolean f3356f;
    private boolean f3357g;
    private int f3358h;
    private int f3359i;
    private boolean f3360j;
    private C1613n f3361k;
    private Object f3362l;
    private C1576b f3363m;
    private int f3364n;
    private long f3365o;

    class C15731 extends Handler {
        final /* synthetic */ C1574f f3350a;

        C15731(C1574f c1574f) {
            this.f3350a = c1574f;
        }

        public void handleMessage(Message message) {
            this.f3350a.m3581a(message);
        }
    }

    @SuppressLint({"HandlerLeak"})
    public C1574f(C1352k[] c1352kArr, C1381h c1381h, C1416i c1416i) {
        Log.i("ExoPlayerImpl", "Init 2.0.3");
        C1392a.m2707a((Object) c1352kArr);
        C1392a.m2711b(c1352kArr.length > 0);
        this.f3357g = false;
        this.f3358h = 1;
        this.f3353c = new CopyOnWriteArraySet();
        this.f3354d = new C1612b();
        this.f3355e = new C1611a();
        this.f3351a = new C15731(this);
        this.f3363m = new C1576b(0, 0);
        this.f3352b = new C1580g(c1352kArr, c1381h, c1416i, this.f3357g, this.f3351a, this.f3363m);
    }

    public void mo2217a(C0507a c0507a) {
        this.f3353c.add(c0507a);
    }

    public int mo2214a() {
        return this.f3358h;
    }

    public void mo2218a(C1615c c1615c) {
        m3584a(c1615c, true, true);
    }

    public void m3584a(C1615c c1615c, boolean z, boolean z2) {
        if (z2 && !(this.f3361k == null && this.f3362l == null)) {
            this.f3361k = null;
            this.f3362l = null;
            Iterator it = this.f3353c.iterator();
            while (it.hasNext()) {
                ((C0507a) it.next()).onTimelineChanged(null, null);
            }
        }
        this.f3352b.m3645a(c1615c, z);
    }

    public void mo2219a(boolean z) {
        if (this.f3357g != z) {
            this.f3357g = z;
            this.f3352b.m3647a(z);
            Iterator it = this.f3353c.iterator();
            while (it.hasNext()) {
                ((C0507a) it.next()).onPlayerStateChanged(z, this.f3358h);
            }
        }
    }

    public boolean mo2222b() {
        return this.f3357g;
    }

    public void mo2223c() {
        mo2215a(mo2227g());
    }

    public void mo2215a(int i) {
        if (this.f3361k == null) {
            this.f3364n = i;
            this.f3365o = -9223372036854775807L;
            this.f3356f = true;
            return;
        }
        C1392a.m2706a(i, 0, this.f3361k.mo2287a());
        this.f3359i++;
        this.f3364n = i;
        this.f3365o = 0;
        this.f3352b.m3642a(this.f3361k.m3790a(i, this.f3354d).f3496f, -9223372036854775807L);
    }

    public void mo2216a(long j) {
        m3579a(mo2227g(), j);
    }

    public void m3579a(int i, long j) {
        if (j == -9223372036854775807L) {
            mo2215a(i);
        } else if (this.f3361k == null) {
            this.f3364n = i;
            this.f3365o = j;
            this.f3356f = true;
        } else {
            C1392a.m2706a(i, 0, this.f3361k.mo2287a());
            this.f3359i++;
            this.f3364n = i;
            this.f3365o = j;
            this.f3361k.m3790a(i, this.f3354d);
            int i2 = this.f3354d.f3496f;
            long c = this.f3354d.m3784c() + j;
            long a = this.f3361k.m3788a(i2, this.f3355e).m3777a();
            while (a != -9223372036854775807L && c >= a && i2 < this.f3354d.f3497g) {
                c -= a;
                i2++;
                a = this.f3361k.m3788a(i2, this.f3355e).m3777a();
            }
            this.f3352b.m3642a(i2, C1391b.m2705b(c));
            Iterator it = this.f3353c.iterator();
            while (it.hasNext()) {
                ((C0507a) it.next()).onPositionDiscontinuity();
            }
        }
    }

    public void mo2224d() {
        this.f3352b.m3641a();
    }

    public void mo2225e() {
        this.f3352b.m3649b();
        this.f3351a.removeCallbacksAndMessages(null);
    }

    public void mo2220a(C1418c... c1418cArr) {
        this.f3352b.m3648a(c1418cArr);
    }

    public void mo2221b(C1418c... c1418cArr) {
        this.f3352b.m3651b(c1418cArr);
    }

    public int mo2227g() {
        if (this.f3361k == null || this.f3359i > 0) {
            return this.f3364n;
        }
        return this.f3361k.m3788a(this.f3363m.f3384a, this.f3355e).f3488c;
    }

    public long mo2228h() {
        if (this.f3361k == null) {
            return -9223372036854775807L;
        }
        return this.f3361k.m3790a(mo2227g(), this.f3354d).m3783b();
    }

    public long mo2229i() {
        if (this.f3361k == null || this.f3359i > 0) {
            return this.f3365o;
        }
        this.f3361k.m3788a(this.f3363m.f3384a, this.f3355e);
        return this.f3355e.m3780c() + C1391b.m2704a(this.f3363m.f3386c);
    }

    public long mo2230j() {
        if (this.f3361k == null || this.f3359i > 0) {
            return this.f3365o;
        }
        this.f3361k.m3788a(this.f3363m.f3384a, this.f3355e);
        return this.f3355e.m3780c() + C1391b.m2704a(this.f3363m.f3387d);
    }

    public int mo2231k() {
        long j = 100;
        if (this.f3361k == null) {
            return 0;
        }
        int i;
        long j2 = mo2230j();
        long h = mo2228h();
        if (j2 == -9223372036854775807L || h == -9223372036854775807L) {
            i = 0;
        } else {
            if (h != 0) {
                j = (100 * j2) / h;
            }
            i = (int) j;
        }
        return i;
    }

    public C1613n mo2226f() {
        return this.f3361k;
    }

    void m3581a(Message message) {
        Iterator it;
        switch (message.what) {
            case 1:
                this.f3358h = message.arg1;
                it = this.f3353c.iterator();
                while (it.hasNext()) {
                    ((C0507a) it.next()).onPlayerStateChanged(this.f3357g, this.f3358h);
                }
                return;
            case 2:
                boolean z;
                if (message.arg1 != 0) {
                    z = true;
                } else {
                    z = false;
                }
                this.f3360j = z;
                it = this.f3353c.iterator();
                while (it.hasNext()) {
                    ((C0507a) it.next()).onLoadingChanged(this.f3360j);
                }
                return;
            case 3:
                int i = this.f3359i - 1;
                this.f3359i = i;
                if (i == 0) {
                    this.f3363m = (C1576b) message.obj;
                    it = this.f3353c.iterator();
                    while (it.hasNext()) {
                        ((C0507a) it.next()).onPositionDiscontinuity();
                    }
                    return;
                }
                return;
            case 4:
                if (this.f3359i == 0) {
                    this.f3363m = (C1576b) message.obj;
                    it = this.f3353c.iterator();
                    while (it.hasNext()) {
                        ((C0507a) it.next()).onPositionDiscontinuity();
                    }
                    return;
                }
                return;
            case 5:
                Pair pair = (Pair) message.obj;
                this.f3361k = (C1613n) pair.first;
                this.f3362l = pair.second;
                if (this.f3356f) {
                    this.f3356f = false;
                    m3579a(this.f3364n, this.f3365o);
                }
                it = this.f3353c.iterator();
                while (it.hasNext()) {
                    ((C0507a) it.next()).onTimelineChanged(this.f3361k, this.f3362l);
                }
                return;
            case 6:
                ExoPlaybackException exoPlaybackException = (ExoPlaybackException) message.obj;
                Iterator it2 = this.f3353c.iterator();
                while (it2.hasNext()) {
                    ((C0507a) it2.next()).onPlayerError(exoPlaybackException);
                }
                return;
            default:
                return;
        }
    }
}
