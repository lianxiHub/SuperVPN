package com.google.android.exoplayer2.drm;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.google.android.exoplayer2.C1391b;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1414r;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

public final class DrmInitData implements Parcelable, Comparator {
    public static final Creator CREATOR = new C14351();
    public final int f2600a;
    private final SchemeData[] f2601b;
    private int f2602c;

    static class C14351 implements Creator {
        C14351() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m2933a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m2934a(i);
        }

        public DrmInitData m2933a(Parcel parcel) {
            return new DrmInitData(parcel);
        }

        public DrmInitData[] m2934a(int i) {
            return new DrmInitData[i];
        }
    }

    public static final class SchemeData implements Parcelable {
        public static final Creator CREATOR = new C14361();
        public final String f2595a;
        public final byte[] f2596b;
        public final boolean f2597c;
        private int f2598d;
        private final UUID f2599e;

        static class C14361 implements Creator {
            C14361() {
            }

            public /* synthetic */ Object createFromParcel(Parcel parcel) {
                return m2935a(parcel);
            }

            public /* synthetic */ Object[] newArray(int i) {
                return m2936a(i);
            }

            public SchemeData m2935a(Parcel parcel) {
                return new SchemeData(parcel);
            }

            public SchemeData[] m2936a(int i) {
                return new SchemeData[i];
            }
        }

        public SchemeData(UUID uuid, String str, byte[] bArr) {
            this(uuid, str, bArr, false);
        }

        public SchemeData(UUID uuid, String str, byte[] bArr, boolean z) {
            this.f2599e = (UUID) C1392a.m2707a((Object) uuid);
            this.f2595a = (String) C1392a.m2707a((Object) str);
            this.f2596b = (byte[]) C1392a.m2707a((Object) bArr);
            this.f2597c = z;
        }

        SchemeData(Parcel parcel) {
            this.f2599e = new UUID(parcel.readLong(), parcel.readLong());
            this.f2595a = parcel.readString();
            this.f2596b = parcel.createByteArray();
            this.f2597c = parcel.readByte() != (byte) 0;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof SchemeData)) {
                return false;
            }
            if (obj == this) {
                return true;
            }
            SchemeData schemeData = (SchemeData) obj;
            if (this.f2595a.equals(schemeData.f2595a) && C1414r.m2823a(this.f2599e, schemeData.f2599e) && Arrays.equals(this.f2596b, schemeData.f2596b)) {
                return true;
            }
            return false;
        }

        public int hashCode() {
            if (this.f2598d == 0) {
                this.f2598d = (((this.f2599e.hashCode() * 31) + this.f2595a.hashCode()) * 31) + Arrays.hashCode(this.f2596b);
            }
            return this.f2598d;
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeLong(this.f2599e.getMostSignificantBits());
            parcel.writeLong(this.f2599e.getLeastSignificantBits());
            parcel.writeString(this.f2595a);
            parcel.writeByteArray(this.f2596b);
            parcel.writeByte((byte) (this.f2597c ? 1 : 0));
        }
    }

    public /* synthetic */ int compare(Object obj, Object obj2) {
        return m2938a((SchemeData) obj, (SchemeData) obj2);
    }

    public DrmInitData(List list) {
        this(false, (SchemeData[]) list.toArray(new SchemeData[list.size()]));
    }

    public DrmInitData(SchemeData... schemeDataArr) {
        this(true, schemeDataArr);
    }

    private DrmInitData(boolean z, SchemeData... schemeDataArr) {
        SchemeData[] schemeDataArr2;
        if (z) {
            schemeDataArr2 = (SchemeData[]) schemeDataArr.clone();
        } else {
            schemeDataArr2 = schemeDataArr;
        }
        Arrays.sort(schemeDataArr2, this);
        for (int i = 1; i < schemeDataArr2.length; i++) {
            if (schemeDataArr2[i - 1].f2599e.equals(schemeDataArr2[i].f2599e)) {
                throw new IllegalArgumentException("Duplicate data for uuid: " + schemeDataArr2[i].f2599e);
            }
        }
        this.f2601b = schemeDataArr2;
        this.f2600a = schemeDataArr2.length;
    }

    DrmInitData(Parcel parcel) {
        this.f2601b = (SchemeData[]) parcel.createTypedArray(SchemeData.CREATOR);
        this.f2600a = this.f2601b.length;
    }

    public SchemeData m2939a(int i) {
        return this.f2601b[i];
    }

    public int hashCode() {
        if (this.f2602c == 0) {
            this.f2602c = Arrays.hashCode(this.f2601b);
        }
        return this.f2602c;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return Arrays.equals(this.f2601b, ((DrmInitData) obj).f2601b);
    }

    public int m2938a(SchemeData schemeData, SchemeData schemeData2) {
        if (C1391b.f2437b.equals(schemeData.f2599e)) {
            return C1391b.f2437b.equals(schemeData2.f2599e) ? 0 : 1;
        } else {
            return schemeData.f2599e.compareTo(schemeData2.f2599e);
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeTypedArray(this.f2601b, 0);
    }
}
