package com.google.android.exoplayer2.drm;

import android.annotation.TargetApi;
import android.media.MediaCrypto;

@TargetApi(16)
public final class C1440d implements C1439c {
    private final MediaCrypto f2603a;

    public MediaCrypto m2946a() {
        return this.f2603a;
    }
}
