package com.google.android.exoplayer2.drm;

import android.annotation.TargetApi;
import android.os.Looper;

@TargetApi(16)
public interface C1438b {
    C1437a m2944a(Looper looper, DrmInitData drmInitData);

    void m2945a(C1437a c1437a);
}
