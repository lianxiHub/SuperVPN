package com.google.android.exoplayer2;

public abstract class C1613n {

    public static final class C1611a {
        public Object f3486a;
        public Object f3487b;
        public int f3488c;
        private long f3489d;
        private long f3490e;

        public C1611a m3778a(Object obj, Object obj2, int i, long j, long j2) {
            this.f3486a = obj;
            this.f3487b = obj2;
            this.f3488c = i;
            this.f3489d = j;
            this.f3490e = j2;
            return this;
        }

        public long m3777a() {
            return C1391b.m2704a(this.f3489d);
        }

        public long m3779b() {
            return this.f3489d;
        }

        public long m3780c() {
            return C1391b.m2704a(this.f3490e);
        }
    }

    public static final class C1612b {
        public Object f3491a;
        public long f3492b;
        public long f3493c;
        public boolean f3494d;
        public boolean f3495e;
        public int f3496f;
        public int f3497g;
        private long f3498h;
        private long f3499i;
        private long f3500j;

        public C1612b m3782a(Object obj, long j, long j2, boolean z, boolean z2, long j3, long j4, int i, int i2, long j5) {
            this.f3491a = obj;
            this.f3492b = j;
            this.f3493c = j2;
            this.f3494d = z;
            this.f3495e = z2;
            this.f3498h = j3;
            this.f3499i = j4;
            this.f3496f = i;
            this.f3497g = i2;
            this.f3500j = j5;
            return this;
        }

        public long m3781a() {
            return this.f3498h;
        }

        public long m3783b() {
            return C1391b.m2704a(this.f3499i);
        }

        public long m3784c() {
            return C1391b.m2704a(this.f3500j);
        }

        public long m3785d() {
            return this.f3500j;
        }
    }

    public abstract int mo2287a();

    public abstract int mo2288a(Object obj);

    public abstract C1611a mo2289a(int i, C1611a c1611a, boolean z);

    public abstract C1612b mo2290a(int i, C1612b c1612b, boolean z);

    public abstract int mo2291b();

    public final C1612b m3790a(int i, C1612b c1612b) {
        return mo2290a(i, c1612b, false);
    }

    public final C1611a m3788a(int i, C1611a c1611a) {
        return mo2289a(i, c1611a, false);
    }
}
