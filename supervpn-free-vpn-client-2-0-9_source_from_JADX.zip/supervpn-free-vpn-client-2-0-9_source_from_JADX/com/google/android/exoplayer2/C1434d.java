package com.google.android.exoplayer2;

import com.google.android.exoplayer2.source.C1615c;

public interface C1434d {

    public interface C0507a {
        void onLoadingChanged(boolean z);

        void onPlayerError(ExoPlaybackException exoPlaybackException);

        void onPlayerStateChanged(boolean z, int i);

        void onPositionDiscontinuity();

        void onTimelineChanged(C1613n c1613n, Object obj);
    }

    public interface C1351b {
        void mo2098a(int i, Object obj);
    }

    public static final class C1418c {
        public final C1351b f2519a;
        public final int f2520b;
        public final Object f2521c;

        public C1418c(C1351b c1351b, int i, Object obj) {
            this.f2519a = c1351b;
            this.f2520b = i;
            this.f2521c = obj;
        }
    }

    int mo2214a();

    void mo2215a(int i);

    void mo2216a(long j);

    void mo2217a(C0507a c0507a);

    void mo2218a(C1615c c1615c);

    void mo2219a(boolean z);

    void mo2220a(C1418c... c1418cArr);

    void mo2221b(C1418c... c1418cArr);

    boolean mo2222b();

    void mo2223c();

    void mo2224d();

    void mo2225e();

    C1613n mo2226f();

    int mo2227g();

    long mo2228h();

    long mo2229i();

    long mo2230j();

    int mo2231k();
}
