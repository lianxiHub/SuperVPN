package com.google.android.exoplayer2;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.media.MediaFormat;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.google.android.exoplayer2.drm.DrmInitData;
import com.google.android.exoplayer2.p031c.C1414r;
import com.mopub.mobileads.VastIconXmlManager;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class Format implements Parcelable {
    public static final Creator CREATOR = new C13421();
    public final String f2179a;
    public final int f2180b;
    public final String f2181c;
    public final String f2182d;
    public final String f2183e;
    public final int f2184f;
    public final List f2185g;
    public final DrmInitData f2186h;
    public final int f2187i;
    public final int f2188j;
    public final float f2189k;
    public final int f2190l;
    public final float f2191m;
    public final int f2192n;
    public final byte[] f2193o;
    public final int f2194p;
    public final int f2195q;
    public final int f2196r;
    public final int f2197s;
    public final int f2198t;
    public final long f2199u;
    public final int f2200v;
    public final String f2201w;
    private int f2202x;
    private MediaFormat f2203y;

    static class C13421 implements Creator {
        C13421() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m2401a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m2402a(i);
        }

        public Format m2401a(Parcel parcel) {
            return new Format(parcel);
        }

        public Format[] m2402a(int i) {
            return new Format[i];
        }
    }

    public static Format m2403a(String str, String str2, String str3, int i, int i2, int i3, int i4, float f, List list, int i5, float f2, DrmInitData drmInitData) {
        return m2404a(str, str2, str3, i, i2, i3, i4, f, list, i5, f2, null, -1, drmInitData);
    }

    public static Format m2404a(String str, String str2, String str3, int i, int i2, int i3, int i4, float f, List list, int i5, float f2, byte[] bArr, int i6, DrmInitData drmInitData) {
        return new Format(str, null, str2, str3, i, i2, i3, i4, f, i5, f2, bArr, i6, -1, -1, -1, -1, -1, 0, null, Long.MAX_VALUE, list, drmInitData);
    }

    public static Format m2407a(String str, String str2, String str3, int i, int i2, int i3, int i4, List list, DrmInitData drmInitData, int i5, String str4) {
        return m2406a(str, str2, str3, i, i2, i3, i4, -1, list, drmInitData, i5, str4);
    }

    public static Format m2406a(String str, String str2, String str3, int i, int i2, int i3, int i4, int i5, List list, DrmInitData drmInitData, int i6, String str4) {
        return m2405a(str, str2, str3, i, i2, i3, i4, i5, -1, -1, list, drmInitData, i6, str4);
    }

    public static Format m2405a(String str, String str2, String str3, int i, int i2, int i3, int i4, int i5, int i6, int i7, List list, DrmInitData drmInitData, int i8, String str4) {
        return new Format(str, null, str2, str3, i, i2, -1, -1, -1.0f, -1, -1.0f, null, -1, i3, i4, i5, i6, i7, i8, str4, Long.MAX_VALUE, list, drmInitData);
    }

    public static Format m2408a(String str, String str2, String str3, int i, int i2, String str4, DrmInitData drmInitData) {
        return m2409a(str, str2, str3, i, i2, str4, drmInitData, Long.MAX_VALUE);
    }

    public static Format m2409a(String str, String str2, String str3, int i, int i2, String str4, DrmInitData drmInitData, long j) {
        return new Format(str, null, str2, str3, i, -1, -1, -1, -1.0f, -1, -1.0f, null, -1, -1, -1, -1, -1, -1, i2, str4, j, null, drmInitData);
    }

    public static Format m2411a(String str, String str2, String str3, int i, List list, String str4, DrmInitData drmInitData) {
        return new Format(str, null, str2, str3, i, -1, -1, -1, -1.0f, -1, -1.0f, null, -1, -1, -1, -1, -1, -1, 0, str4, Long.MAX_VALUE, list, drmInitData);
    }

    public static Format m2410a(String str, String str2, String str3, int i, DrmInitData drmInitData) {
        return new Format(str, null, str2, str3, i, -1, -1, -1, -1.0f, -1, -1.0f, null, -1, -1, -1, -1, -1, -1, 0, null, Long.MAX_VALUE, null, drmInitData);
    }

    Format(String str, String str2, String str3, String str4, int i, int i2, int i3, int i4, float f, int i5, float f2, byte[] bArr, int i6, int i7, int i8, int i9, int i10, int i11, int i12, String str5, long j, List list, DrmInitData drmInitData) {
        this.f2179a = str;
        this.f2182d = str2;
        this.f2183e = str3;
        this.f2181c = str4;
        this.f2180b = i;
        this.f2184f = i2;
        this.f2187i = i3;
        this.f2188j = i4;
        this.f2189k = f;
        this.f2190l = i5;
        this.f2191m = f2;
        this.f2193o = bArr;
        this.f2192n = i6;
        this.f2194p = i7;
        this.f2195q = i8;
        this.f2196r = i9;
        this.f2197s = i10;
        this.f2198t = i11;
        this.f2200v = i12;
        this.f2201w = str5;
        this.f2199u = j;
        if (list == null) {
            list = Collections.emptyList();
        }
        this.f2185g = list;
        this.f2186h = drmInitData;
    }

    Format(Parcel parcel) {
        this.f2179a = parcel.readString();
        this.f2182d = parcel.readString();
        this.f2183e = parcel.readString();
        this.f2181c = parcel.readString();
        this.f2180b = parcel.readInt();
        this.f2184f = parcel.readInt();
        this.f2187i = parcel.readInt();
        this.f2188j = parcel.readInt();
        this.f2189k = parcel.readFloat();
        this.f2190l = parcel.readInt();
        this.f2191m = parcel.readFloat();
        this.f2193o = (parcel.readInt() != 0 ? 1 : null) != null ? parcel.createByteArray() : null;
        this.f2192n = parcel.readInt();
        this.f2194p = parcel.readInt();
        this.f2195q = parcel.readInt();
        this.f2196r = parcel.readInt();
        this.f2197s = parcel.readInt();
        this.f2198t = parcel.readInt();
        this.f2200v = parcel.readInt();
        this.f2201w = parcel.readString();
        this.f2199u = parcel.readLong();
        int readInt = parcel.readInt();
        this.f2185g = new ArrayList(readInt);
        for (int i = 0; i < readInt; i++) {
            this.f2185g.add(parcel.createByteArray());
        }
        this.f2186h = (DrmInitData) parcel.readParcelable(DrmInitData.class.getClassLoader());
    }

    public Format m2416a(int i) {
        return new Format(this.f2179a, this.f2182d, this.f2183e, this.f2181c, this.f2180b, i, this.f2187i, this.f2188j, this.f2189k, this.f2190l, this.f2191m, this.f2193o, this.f2192n, this.f2194p, this.f2195q, this.f2196r, this.f2197s, this.f2198t, this.f2200v, this.f2201w, this.f2199u, this.f2185g, this.f2186h);
    }

    public Format m2418a(long j) {
        return new Format(this.f2179a, this.f2182d, this.f2183e, this.f2181c, this.f2180b, this.f2184f, this.f2187i, this.f2188j, this.f2189k, this.f2190l, this.f2191m, this.f2193o, this.f2192n, this.f2194p, this.f2195q, this.f2196r, this.f2197s, this.f2198t, this.f2200v, this.f2201w, j, this.f2185g, this.f2186h);
    }

    public Format m2417a(int i, int i2) {
        return new Format(this.f2179a, this.f2182d, this.f2183e, this.f2181c, this.f2180b, this.f2184f, this.f2187i, this.f2188j, this.f2189k, this.f2190l, this.f2191m, this.f2193o, this.f2192n, this.f2194p, this.f2195q, this.f2196r, i, i2, this.f2200v, this.f2201w, this.f2199u, this.f2185g, this.f2186h);
    }

    public Format m2419a(DrmInitData drmInitData) {
        return new Format(this.f2179a, this.f2182d, this.f2183e, this.f2181c, this.f2180b, this.f2184f, this.f2187i, this.f2188j, this.f2189k, this.f2190l, this.f2191m, this.f2193o, this.f2192n, this.f2194p, this.f2195q, this.f2196r, this.f2197s, this.f2198t, this.f2200v, this.f2201w, this.f2199u, this.f2185g, drmInitData);
    }

    public int m2415a() {
        return (this.f2187i == -1 || this.f2188j == -1) ? -1 : this.f2187i * this.f2188j;
    }

    @SuppressLint({"InlinedApi"})
    @TargetApi(16)
    public final MediaFormat m2420b() {
        if (this.f2203y == null) {
            MediaFormat mediaFormat = new MediaFormat();
            mediaFormat.setString("mime", this.f2183e);
            m2414a(mediaFormat, "language", this.f2201w);
            m2413a(mediaFormat, "max-input-size", this.f2184f);
            m2413a(mediaFormat, VastIconXmlManager.WIDTH, this.f2187i);
            m2413a(mediaFormat, VastIconXmlManager.HEIGHT, this.f2188j);
            m2412a(mediaFormat, "frame-rate", this.f2189k);
            m2413a(mediaFormat, "rotation-degrees", this.f2190l);
            m2413a(mediaFormat, "channel-count", this.f2194p);
            m2413a(mediaFormat, "sample-rate", this.f2195q);
            m2413a(mediaFormat, "encoder-delay", this.f2197s);
            m2413a(mediaFormat, "encoder-padding", this.f2198t);
            for (int i = 0; i < this.f2185g.size(); i++) {
                mediaFormat.setByteBuffer("csd-" + i, ByteBuffer.wrap((byte[]) this.f2185g.get(i)));
            }
            this.f2203y = mediaFormat;
        }
        return this.f2203y;
    }

    public String toString() {
        return "Format(" + this.f2179a + ", " + this.f2182d + ", " + this.f2183e + ", " + this.f2180b + ", , " + this.f2201w + ", [" + this.f2187i + ", " + this.f2188j + ", " + this.f2189k + "], [" + this.f2194p + ", " + this.f2195q + "])";
    }

    public int hashCode() {
        int i = 0;
        if (this.f2202x == 0) {
            int hashCode = ((this.f2201w == null ? 0 : this.f2201w.hashCode()) + (((((((((((((this.f2181c == null ? 0 : this.f2181c.hashCode()) + (((this.f2183e == null ? 0 : this.f2183e.hashCode()) + (((this.f2182d == null ? 0 : this.f2182d.hashCode()) + (((this.f2179a == null ? 0 : this.f2179a.hashCode()) + 527) * 31)) * 31)) * 31)) * 31) + this.f2180b) * 31) + this.f2187i) * 31) + this.f2188j) * 31) + this.f2194p) * 31) + this.f2195q) * 31)) * 31;
            if (this.f2186h != null) {
                i = this.f2186h.hashCode();
            }
            this.f2202x = hashCode + i;
        }
        return this.f2202x;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Format format = (Format) obj;
        if (this.f2180b != format.f2180b || this.f2184f != format.f2184f || this.f2187i != format.f2187i || this.f2188j != format.f2188j || this.f2189k != format.f2189k || this.f2190l != format.f2190l || this.f2191m != format.f2191m || this.f2192n != format.f2192n || this.f2194p != format.f2194p || this.f2195q != format.f2195q || this.f2196r != format.f2196r || this.f2197s != format.f2197s || this.f2198t != format.f2198t || this.f2199u != format.f2199u || this.f2200v != format.f2200v || !C1414r.m2823a(this.f2179a, format.f2179a) || !C1414r.m2823a(this.f2201w, format.f2201w) || !C1414r.m2823a(this.f2182d, format.f2182d) || !C1414r.m2823a(this.f2183e, format.f2183e) || !C1414r.m2823a(this.f2181c, format.f2181c) || !C1414r.m2823a(this.f2186h, format.f2186h) || !Arrays.equals(this.f2193o, format.f2193o) || this.f2185g.size() != format.f2185g.size()) {
            return false;
        }
        for (int i = 0; i < this.f2185g.size(); i++) {
            if (!Arrays.equals((byte[]) this.f2185g.get(i), (byte[]) format.f2185g.get(i))) {
                return false;
            }
        }
        return true;
    }

    @TargetApi(16)
    private static void m2414a(MediaFormat mediaFormat, String str, String str2) {
        if (str2 != null) {
            mediaFormat.setString(str, str2);
        }
    }

    @TargetApi(16)
    private static void m2413a(MediaFormat mediaFormat, String str, int i) {
        if (i != -1) {
            mediaFormat.setInteger(str, i);
        }
    }

    @TargetApi(16)
    private static void m2412a(MediaFormat mediaFormat, String str, float f) {
        if (f != -1.0f) {
            mediaFormat.setFloat(str, f);
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.f2179a);
        parcel.writeString(this.f2182d);
        parcel.writeString(this.f2183e);
        parcel.writeString(this.f2181c);
        parcel.writeInt(this.f2180b);
        parcel.writeInt(this.f2184f);
        parcel.writeInt(this.f2187i);
        parcel.writeInt(this.f2188j);
        parcel.writeFloat(this.f2189k);
        parcel.writeInt(this.f2190l);
        parcel.writeFloat(this.f2191m);
        parcel.writeInt(this.f2193o != null ? 1 : 0);
        if (this.f2193o != null) {
            parcel.writeByteArray(this.f2193o);
        }
        parcel.writeInt(this.f2192n);
        parcel.writeInt(this.f2194p);
        parcel.writeInt(this.f2195q);
        parcel.writeInt(this.f2196r);
        parcel.writeInt(this.f2197s);
        parcel.writeInt(this.f2198t);
        parcel.writeInt(this.f2200v);
        parcel.writeString(this.f2201w);
        parcel.writeLong(this.f2199u);
        int size = this.f2185g.size();
        parcel.writeInt(size);
        for (int i2 = 0; i2 < size; i2++) {
            parcel.writeByteArray((byte[]) this.f2185g.get(i2));
        }
        parcel.writeParcelable(this.f2186h, 0);
    }
}
