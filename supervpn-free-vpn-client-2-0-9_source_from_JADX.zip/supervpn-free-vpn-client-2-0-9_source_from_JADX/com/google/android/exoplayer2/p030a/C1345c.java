package com.google.android.exoplayer2.p030a;

public interface C1345c {
    Object mo2091a();

    void mo2092a(Object obj);

    Object mo2093b();

    void mo2094c();

    void mo2095d();
}
