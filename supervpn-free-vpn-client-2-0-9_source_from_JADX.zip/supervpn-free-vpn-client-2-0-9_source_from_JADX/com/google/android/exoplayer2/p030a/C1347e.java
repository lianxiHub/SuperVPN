package com.google.android.exoplayer2.p030a;

import java.nio.ByteBuffer;

public class C1347e extends C1343a {
    public final C1344b f2219a = new C1344b();
    public ByteBuffer f2220b;
    public long f2221c;
    private final int f2222d;

    public C1347e(int i) {
        this.f2222d = i;
    }

    public void m2440e(int i) {
        if (this.f2220b == null) {
            this.f2220b = m2436f(i);
            return;
        }
        int capacity = this.f2220b.capacity();
        int position = this.f2220b.position();
        int i2 = position + i;
        if (capacity < i2) {
            ByteBuffer f = m2436f(i2);
            if (position > 0) {
                this.f2220b.position(0);
                this.f2220b.limit(position);
                f.put(this.f2220b);
            }
            this.f2220b = f;
        }
    }

    public final boolean m2438d() {
        return m2425d(1073741824);
    }

    public final void m2439e() {
        this.f2220b.flip();
    }

    public void mo2090a() {
        super.mo2090a();
        if (this.f2220b != null) {
            this.f2220b.clear();
        }
    }

    private ByteBuffer m2436f(int i) {
        if (this.f2222d == 1) {
            return ByteBuffer.allocate(i);
        }
        if (this.f2222d == 2) {
            return ByteBuffer.allocateDirect(i);
        }
        throw new IllegalStateException("Buffer too small (" + (this.f2220b == null ? 0 : this.f2220b.capacity()) + " < " + i + ")");
    }
}
