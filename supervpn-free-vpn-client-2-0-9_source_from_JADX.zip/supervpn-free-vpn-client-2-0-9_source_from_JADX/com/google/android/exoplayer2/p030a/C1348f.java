package com.google.android.exoplayer2.p030a;

public abstract class C1348f extends C1343a {
    public long f2223a;
    public int f2224b;
}
