package com.google.android.exoplayer2.p030a;

import com.google.android.exoplayer2.p031c.C1392a;
import java.util.LinkedList;

public abstract class C1350g implements C1345c {
    private final Thread f2226a;
    private final Object f2227b = new Object();
    private final LinkedList f2228c = new LinkedList();
    private final LinkedList f2229d = new LinkedList();
    private final C1347e[] f2230e;
    private final C1348f[] f2231f;
    private int f2232g;
    private int f2233h;
    private C1347e f2234i;
    private Exception f2235j;
    private boolean f2236k;
    private boolean f2237l;
    private int f2238m;

    class C13491 extends Thread {
        final /* synthetic */ C1350g f2225a;

        C13491(C1350g c1350g) {
            this.f2225a = c1350g;
        }

        public void run() {
            this.f2225a.m2446k();
        }
    }

    protected abstract Exception mo2304a(C1347e c1347e, C1348f c1348f, boolean z);

    protected abstract C1347e mo2306g();

    protected abstract C1348f mo2307h();

    public /* synthetic */ Object mo2091a() {
        return m2458e();
    }

    public /* synthetic */ Object mo2093b() {
        return m2459f();
    }

    protected C1350g(C1347e[] c1347eArr, C1348f[] c1348fArr) {
        int i = 0;
        this.f2230e = c1347eArr;
        this.f2232g = c1347eArr.length;
        for (int i2 = 0; i2 < this.f2232g; i2++) {
            this.f2230e[i2] = mo2306g();
        }
        this.f2231f = c1348fArr;
        this.f2233h = c1348fArr.length;
        while (i < this.f2233h) {
            this.f2231f[i] = mo2307h();
            i++;
        }
        this.f2226a = new C13491(this);
        this.f2226a.start();
    }

    protected final void m2451a(int i) {
        boolean z;
        int i2 = 0;
        if (this.f2232g == this.f2230e.length) {
            z = true;
        } else {
            z = false;
        }
        C1392a.m2711b(z);
        C1347e[] c1347eArr = this.f2230e;
        int length = c1347eArr.length;
        while (i2 < length) {
            c1347eArr[i2].m2440e(i);
            i2++;
        }
    }

    public final C1347e m2458e() {
        C1347e c1347e;
        synchronized (this.f2227b) {
            mo2308i();
            C1392a.m2711b(this.f2234i == null);
            if (this.f2232g == 0) {
                c1347e = null;
            } else {
                C1347e[] c1347eArr = this.f2230e;
                int i = this.f2232g - 1;
                this.f2232g = i;
                c1347e = c1347eArr[i];
            }
            this.f2234i = c1347e;
            c1347e = this.f2234i;
        }
        return c1347e;
    }

    public final void m2452a(C1347e c1347e) {
        synchronized (this.f2227b) {
            mo2308i();
            C1392a.m2709a(c1347e == this.f2234i);
            this.f2228c.addLast(c1347e);
            mo2309j();
            this.f2234i = null;
        }
    }

    public final C1348f m2459f() {
        C1348f c1348f;
        synchronized (this.f2227b) {
            mo2308i();
            if (this.f2229d.isEmpty()) {
                c1348f = null;
            } else {
                c1348f = (C1348f) this.f2229d.removeFirst();
            }
        }
        return c1348f;
    }

    protected void mo2305a(C1348f c1348f) {
        synchronized (this.f2227b) {
            m2443b(c1348f);
            mo2309j();
        }
    }

    public final void mo2094c() {
        synchronized (this.f2227b) {
            this.f2236k = true;
            this.f2238m = 0;
            if (this.f2234i != null) {
                m2442b(this.f2234i);
                this.f2234i = null;
            }
            while (!this.f2228c.isEmpty()) {
                m2442b((C1347e) this.f2228c.removeFirst());
            }
            while (!this.f2229d.isEmpty()) {
                m2443b((C1348f) this.f2229d.removeFirst());
            }
        }
    }

    public void mo2095d() {
        synchronized (this.f2227b) {
            this.f2237l = true;
            this.f2227b.notify();
        }
        try {
            this.f2226a.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void mo2308i() {
        if (this.f2235j != null) {
            throw this.f2235j;
        }
    }

    private void mo2309j() {
        if (m2448m()) {
            this.f2227b.notify();
        }
    }

    private void m2446k() {
        do {
            try {
            } catch (Throwable e) {
                throw new IllegalStateException(e);
            }
        } while (m2447l());
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean m2447l() {
        /*
        r6 = this;
        r1 = 0;
        r2 = r6.f2227b;
        monitor-enter(r2);
    L_0x0004:
        r0 = r6.f2237l;	 Catch:{ all -> 0x0014 }
        if (r0 != 0) goto L_0x0017;
    L_0x0008:
        r0 = r6.m2448m();	 Catch:{ all -> 0x0014 }
        if (r0 != 0) goto L_0x0017;
    L_0x000e:
        r0 = r6.f2227b;	 Catch:{ all -> 0x0014 }
        r0.wait();	 Catch:{ all -> 0x0014 }
        goto L_0x0004;
    L_0x0014:
        r0 = move-exception;
        monitor-exit(r2);	 Catch:{ all -> 0x0014 }
        throw r0;
    L_0x0017:
        r0 = r6.f2237l;	 Catch:{ all -> 0x0014 }
        if (r0 == 0) goto L_0x001e;
    L_0x001b:
        monitor-exit(r2);	 Catch:{ all -> 0x0014 }
        r0 = r1;
    L_0x001d:
        return r0;
    L_0x001e:
        r0 = r6.f2228c;	 Catch:{ all -> 0x0014 }
        r0 = r0.removeFirst();	 Catch:{ all -> 0x0014 }
        r0 = (com.google.android.exoplayer2.p030a.C1347e) r0;	 Catch:{ all -> 0x0014 }
        r3 = r6.f2231f;	 Catch:{ all -> 0x0014 }
        r4 = r6.f2233h;	 Catch:{ all -> 0x0014 }
        r4 = r4 + -1;
        r6.f2233h = r4;	 Catch:{ all -> 0x0014 }
        r3 = r3[r4];	 Catch:{ all -> 0x0014 }
        r4 = r6.f2236k;	 Catch:{ all -> 0x0014 }
        r5 = 0;
        r6.f2236k = r5;	 Catch:{ all -> 0x0014 }
        monitor-exit(r2);	 Catch:{ all -> 0x0014 }
        r2 = r0.m2424c();
        if (r2 == 0) goto L_0x0050;
    L_0x003c:
        r1 = 4;
        r3.m2422b(r1);
    L_0x0040:
        r1 = r6.f2227b;
        monitor-enter(r1);
        r2 = r6.f2236k;	 Catch:{ all -> 0x007e }
        if (r2 == 0) goto L_0x006e;
    L_0x0047:
        r6.m2443b(r3);	 Catch:{ all -> 0x007e }
    L_0x004a:
        r6.m2442b(r0);	 Catch:{ all -> 0x007e }
        monitor-exit(r1);	 Catch:{ all -> 0x007e }
        r0 = 1;
        goto L_0x001d;
    L_0x0050:
        r2 = r0.b_();
        if (r2 == 0) goto L_0x005b;
    L_0x0056:
        r2 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r3.m2422b(r2);
    L_0x005b:
        r2 = r6.mo2304a(r0, r3, r4);
        r6.f2235j = r2;
        r2 = r6.f2235j;
        if (r2 == 0) goto L_0x0040;
    L_0x0065:
        r2 = r6.f2227b;
        monitor-enter(r2);
        monitor-exit(r2);	 Catch:{ all -> 0x006b }
        r0 = r1;
        goto L_0x001d;
    L_0x006b:
        r0 = move-exception;
        monitor-exit(r2);	 Catch:{ all -> 0x006b }
        throw r0;
    L_0x006e:
        r2 = r3.b_();	 Catch:{ all -> 0x007e }
        if (r2 == 0) goto L_0x0081;
    L_0x0074:
        r2 = r6.f2238m;	 Catch:{ all -> 0x007e }
        r2 = r2 + 1;
        r6.f2238m = r2;	 Catch:{ all -> 0x007e }
        r6.m2443b(r3);	 Catch:{ all -> 0x007e }
        goto L_0x004a;
    L_0x007e:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x007e }
        throw r0;
    L_0x0081:
        r2 = r6.f2238m;	 Catch:{ all -> 0x007e }
        r3.f2224b = r2;	 Catch:{ all -> 0x007e }
        r2 = 0;
        r6.f2238m = r2;	 Catch:{ all -> 0x007e }
        r2 = r6.f2229d;	 Catch:{ all -> 0x007e }
        r2.addLast(r3);	 Catch:{ all -> 0x007e }
        goto L_0x004a;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.a.g.l():boolean");
    }

    private boolean m2448m() {
        return !this.f2228c.isEmpty() && this.f2233h > 0;
    }

    private void m2442b(C1347e c1347e) {
        c1347e.mo2090a();
        C1347e[] c1347eArr = this.f2230e;
        int i = this.f2232g;
        this.f2232g = i + 1;
        c1347eArr[i] = c1347e;
    }

    private void m2443b(C1348f c1348f) {
        c1348f.mo2090a();
        C1348f[] c1348fArr = this.f2231f;
        int i = this.f2233h;
        this.f2233h = i + 1;
        c1348fArr[i] = c1348f;
    }
}
