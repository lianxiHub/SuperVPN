package com.google.android.exoplayer2.p030a;

import android.annotation.TargetApi;
import android.media.MediaCodec.CryptoInfo;
import com.google.android.exoplayer2.p031c.C1414r;

public final class C1344b {
    public byte[] f2205a;
    public byte[] f2206b;
    public int f2207c;
    public int[] f2208d;
    public int[] f2209e;
    public int f2210f;
    private final CryptoInfo f2211g;

    public C1344b() {
        this.f2211g = C1414r.f2503a >= 16 ? m2426b() : null;
    }

    public void m2429a(int i, int[] iArr, int[] iArr2, byte[] bArr, byte[] bArr2, int i2) {
        this.f2210f = i;
        this.f2208d = iArr;
        this.f2209e = iArr2;
        this.f2206b = bArr;
        this.f2205a = bArr2;
        this.f2207c = i2;
        if (C1414r.f2503a >= 16) {
            m2427c();
        }
    }

    @TargetApi(16)
    public CryptoInfo m2428a() {
        return this.f2211g;
    }

    @TargetApi(16)
    private CryptoInfo m2426b() {
        return new CryptoInfo();
    }

    @TargetApi(16)
    private void m2427c() {
        this.f2211g.set(this.f2210f, this.f2208d, this.f2209e, this.f2206b, this.f2205a, this.f2207c);
    }
}
