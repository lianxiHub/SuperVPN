package com.google.android.exoplayer2.p030a;

public abstract class C1343a {
    private int f2204a;

    public void mo2090a() {
        this.f2204a = 0;
    }

    public final boolean b_() {
        return m2425d(Integer.MIN_VALUE);
    }

    public final boolean m2424c() {
        return m2425d(4);
    }

    public final void a_(int i) {
        this.f2204a = i;
    }

    public final void m2422b(int i) {
        this.f2204a |= i;
    }

    public final void m2423c(int i) {
        this.f2204a &= i ^ -1;
    }

    protected final boolean m2425d(int i) {
        return (this.f2204a & i) == i;
    }
}
