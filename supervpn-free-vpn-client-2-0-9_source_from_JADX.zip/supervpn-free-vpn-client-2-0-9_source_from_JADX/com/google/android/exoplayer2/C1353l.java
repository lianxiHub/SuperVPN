package com.google.android.exoplayer2;

public interface C1353l {
    int mo2096a();

    int mo2119a(Format format);

    int mo2112l();
}
