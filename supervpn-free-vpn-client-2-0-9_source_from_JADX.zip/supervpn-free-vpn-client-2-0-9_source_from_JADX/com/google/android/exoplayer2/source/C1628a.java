package com.google.android.exoplayer2.source;

import android.net.Uri;
import android.os.Handler;
import android.support.v4.media.session.PlaybackStateCompat;
import android.util.SparseArray;
import com.google.android.exoplayer2.C1581h;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.extractor.C1451f;
import com.google.android.exoplayer2.extractor.C1455m;
import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.extractor.C1465b;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.extractor.C1522d;
import com.google.android.exoplayer2.extractor.C1522d.C1496c;
import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.extractor.C1570l;
import com.google.android.exoplayer2.p030a.C1347e;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1395d;
import com.google.android.exoplayer2.p031c.C1414r;
import com.google.android.exoplayer2.source.C1615c.C1579a;
import com.google.android.exoplayer2.source.C1626b.C1578a;
import com.google.android.exoplayer2.source.ExtractorMediaSource.C1614a;
import com.google.android.exoplayer2.source.ExtractorMediaSource.UnrecognizedInputFormatException;
import com.google.android.exoplayer2.upstream.C1678d;
import com.google.android.exoplayer2.upstream.C1684b;
import com.google.android.exoplayer2.upstream.C1687e;
import com.google.android.exoplayer2.upstream.Loader;
import com.google.android.exoplayer2.upstream.Loader.C1620c;
import com.google.android.exoplayer2.upstream.Loader.C1627a;
import java.io.EOFException;
import java.io.IOException;

final class C1628a implements C1496c, C1567h, C1626b, C1627a {
    private long f3531A;
    private int f3532B;
    private boolean f3533C;
    private boolean f3534D;
    private final Uri f3535a;
    private final C1678d f3536b;
    private final int f3537c;
    private final Handler f3538d;
    private final C1614a f3539e;
    private final C1579a f3540f;
    private final C1684b f3541g;
    private final Loader f3542h = new Loader("Loader:ExtractorMediaPeriod");
    private final C1622b f3543i;
    private final C1395d f3544j;
    private final Runnable f3545k;
    private final Runnable f3546l;
    private final Handler f3547m;
    private final SparseArray f3548n;
    private C1578a f3549o;
    private C1455m f3550p;
    private boolean f3551q;
    private boolean f3552r;
    private boolean f3553s;
    private boolean f3554t;
    private int f3555u;
    private C1631h f3556v;
    private long f3557w;
    private boolean[] f3558x;
    private long f3559y;
    private long f3560z;

    class C16161 implements Runnable {
        final /* synthetic */ C1628a f3511a;

        C16161(C1628a c1628a) {
            this.f3511a = c1628a;
        }

        public void run() {
            this.f3511a.m3847i();
        }
    }

    class C16172 implements Runnable {
        final /* synthetic */ C1628a f3512a;

        C16172(C1628a c1628a) {
            this.f3512a = c1628a;
        }

        public void run() {
            if (!this.f3512a.f3534D) {
                this.f3512a.f3549o.mo2234a(this.f3512a);
            }
        }
    }

    final class C1621a implements C1620c {
        final /* synthetic */ C1628a f3517a;
        private final Uri f3518b;
        private final C1678d f3519c;
        private final C1622b f3520d;
        private final C1395d f3521e;
        private final C1570l f3522f = new C1570l();
        private volatile boolean f3523g;
        private boolean f3524h = true;
        private long f3525i = -1;

        public C1621a(C1628a c1628a, Uri uri, C1678d c1678d, C1622b c1622b, C1395d c1395d) {
            this.f3517a = c1628a;
            this.f3518b = (Uri) C1392a.m2707a((Object) uri);
            this.f3519c = (C1678d) C1392a.m2707a((Object) c1678d);
            this.f3520d = (C1622b) C1392a.m2707a((Object) c1622b);
            this.f3521e = c1395d;
        }

        public void m3810a(long j) {
            this.f3522f.f3345a = j;
            this.f3524h = true;
        }

        public void mo2264a() {
            this.f3523g = true;
        }

        public boolean mo2265b() {
            return this.f3523g;
        }

        public void mo2266c() {
            Throwable th;
            C1464g c1464g;
            Throwable th2;
            int i = 0;
            while (i == 0 && !this.f3523g) {
                int a;
                try {
                    long j = this.f3522f.f3345a;
                    this.f3525i = this.f3519c.mo2314a(new C1687e(this.f3518b, j, -1, C1414r.m2832g(this.f3518b.toString())));
                    if (this.f3525i != -1) {
                        this.f3525i += j;
                    }
                    C1464g c1465b = new C1465b(this.f3519c, j, this.f3525i);
                    try {
                        int i2;
                        C1451f a2 = this.f3520d.m3813a(c1465b);
                        if (this.f3524h) {
                            a2.mo2169a(j);
                            this.f3524h = false;
                        }
                        long j2 = j;
                        int i3 = i;
                        while (i3 == 0) {
                            try {
                                if (this.f3523g) {
                                    break;
                                }
                                this.f3521e.m2723c();
                                a = a2.mo2168a(c1465b, this.f3522f);
                                try {
                                    if (c1465b.mo2185c() > PlaybackStateCompat.ACTION_SET_CAPTIONING_ENABLED + j2) {
                                        j2 = c1465b.mo2185c();
                                        this.f3521e.m2722b();
                                        this.f3517a.f3547m.post(this.f3517a.f3546l);
                                        i3 = a;
                                    } else {
                                        i3 = a;
                                    }
                                } catch (Throwable th3) {
                                    th = th3;
                                    c1464g = c1465b;
                                    th2 = th;
                                }
                            } catch (Throwable th4) {
                                th = th4;
                                a = i3;
                                c1464g = c1465b;
                                th2 = th;
                            }
                        }
                        if (i3 == 1) {
                            i2 = 0;
                        } else {
                            if (c1465b != null) {
                                this.f3522f.f3345a = c1465b.mo2185c();
                            }
                            i2 = i3;
                        }
                        this.f3519c.mo2315a();
                        i = i2;
                    } catch (Throwable th32) {
                        a = i;
                        C1464g c1464g2 = c1465b;
                        th2 = th32;
                        c1464g = c1464g2;
                    }
                } catch (Throwable th5) {
                    th2 = th5;
                    c1464g = null;
                    a = i;
                }
            }
            return;
            if (!(a == 1 || c1464g == null)) {
                this.f3522f.f3345a = c1464g.mo2185c();
            }
            this.f3519c.mo2315a();
            throw th2;
        }
    }

    private static final class C1622b {
        private final C1451f[] f3526a;
        private final C1567h f3527b;
        private C1451f f3528c;

        public C1622b(C1451f[] c1451fArr, C1567h c1567h) {
            this.f3526a = c1451fArr;
            this.f3527b = c1567h;
        }

        public C1451f m3813a(C1464g c1464g) {
            if (this.f3528c != null) {
                return this.f3528c;
            }
            C1451f[] c1451fArr = this.f3526a;
            int length = c1451fArr.length;
            int i = 0;
            loop0:
            while (i < length) {
                C1451f c1451f = c1451fArr[i];
                try {
                    if (c1451f.mo2171a(c1464g)) {
                        this.f3528c = c1451f;
                        c1464g.mo2179a();
                        break loop0;
                    }
                    i++;
                } catch (EOFException e) {
                    i++;
                } finally {
                    c1464g.mo2179a();
                }
            }
            if (this.f3528c == null) {
                throw new UnrecognizedInputFormatException(this.f3526a);
            }
            this.f3528c.mo2170a(this.f3527b);
            return this.f3528c;
        }

        public void m3814a() {
            if (this.f3528c != null) {
                this.f3528c.mo2172c();
                this.f3528c = null;
            }
        }
    }

    private final class C1624c implements C1623d {
        final /* synthetic */ C1628a f3529a;
        private final int f3530b;

        public C1624c(C1628a c1628a, int i) {
            this.f3529a = c1628a;
            this.f3530b = i;
        }

        public boolean mo2269a() {
            return this.f3529a.m3868b(this.f3530b);
        }

        public void mo2270b() {
            this.f3529a.m3874h();
        }

        public int mo2267a(C1581h c1581h, C1347e c1347e) {
            return this.f3529a.m3852a(this.f3530b, c1581h, c1347e);
        }

        public void mo2268a(long j) {
            ((C1522d) this.f3529a.f3548n.valueAt(this.f3530b)).m3338a(j);
        }
    }

    public C1628a(Uri uri, C1678d c1678d, C1451f[] c1451fArr, int i, Handler handler, C1614a c1614a, C1579a c1579a, C1684b c1684b) {
        this.f3535a = uri;
        this.f3536b = c1678d;
        this.f3537c = i;
        this.f3538d = handler;
        this.f3539e = c1614a;
        this.f3540f = c1579a;
        this.f3541g = c1684b;
        this.f3543i = new C1622b(c1451fArr, this);
        this.f3544j = new C1395d();
        this.f3545k = new C16161(this);
        this.f3546l = new C16172(this);
        this.f3547m = new Handler();
        this.f3531A = -9223372036854775807L;
        this.f3548n = new SparseArray();
        this.f3559y = -1;
    }

    public void m3867b() {
        final C1622b c1622b = this.f3543i;
        this.f3542h.m4215a(new Runnable(this) {
            final /* synthetic */ C1628a f3514b;

            public void run() {
                c1622b.m3814a();
                int size = this.f3514b.f3548n.size();
                for (int i = 0; i < size; i++) {
                    ((C1522d) this.f3514b.f3548n.valueAt(i)).m3339b();
                }
            }
        });
        this.f3547m.removeCallbacksAndMessages(null);
        this.f3534D = true;
    }

    public void mo2277a(C1578a c1578a) {
        this.f3549o = c1578a;
        this.f3544j.m2721a();
        m3848j();
    }

    public void mo2282c() {
        m3874h();
    }

    public C1631h mo2283d() {
        return this.f3556v;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public long mo2272a(com.google.android.exoplayer2.p032b.C1375f[] r8, boolean[] r9, com.google.android.exoplayer2.source.C1623d[] r10, boolean[] r11, long r12) {
        /*
        r7 = this;
        r3 = 1;
        r2 = 0;
        r0 = r7.f3552r;
        com.google.android.exoplayer2.p031c.C1392a.m2711b(r0);
        r1 = r2;
    L_0x0008:
        r0 = r8.length;
        if (r1 >= r0) goto L_0x0042;
    L_0x000b:
        r0 = r10[r1];
        if (r0 == 0) goto L_0x003e;
    L_0x000f:
        r0 = r8[r1];
        if (r0 == 0) goto L_0x0017;
    L_0x0013:
        r0 = r9[r1];
        if (r0 != 0) goto L_0x003e;
    L_0x0017:
        r0 = r10[r1];
        r0 = (com.google.android.exoplayer2.source.C1628a.C1624c) r0;
        r0 = r0.f3530b;
        r4 = r7.f3558x;
        r4 = r4[r0];
        com.google.android.exoplayer2.p031c.C1392a.m2711b(r4);
        r4 = r7.f3555u;
        r4 = r4 + -1;
        r7.f3555u = r4;
        r4 = r7.f3558x;
        r4[r0] = r2;
        r4 = r7.f3548n;
        r0 = r4.valueAt(r0);
        r0 = (com.google.android.exoplayer2.extractor.C1522d) r0;
        r0.m3339b();
        r0 = 0;
        r10[r1] = r0;
    L_0x003e:
        r0 = r1 + 1;
        r1 = r0;
        goto L_0x0008;
    L_0x0042:
        r0 = r2;
        r1 = r2;
    L_0x0044:
        r4 = r8.length;
        if (r0 >= r4) goto L_0x0096;
    L_0x0047:
        r4 = r10[r0];
        if (r4 != 0) goto L_0x008d;
    L_0x004b:
        r4 = r8[r0];
        if (r4 == 0) goto L_0x008d;
    L_0x004f:
        r4 = r8[r0];
        r1 = r4.mo2142b();
        if (r1 != r3) goto L_0x0090;
    L_0x0057:
        r1 = r3;
    L_0x0058:
        com.google.android.exoplayer2.p031c.C1392a.m2711b(r1);
        r1 = r4.mo2143b(r2);
        if (r1 != 0) goto L_0x0092;
    L_0x0061:
        r1 = r3;
    L_0x0062:
        com.google.android.exoplayer2.p031c.C1392a.m2711b(r1);
        r1 = r7.f3556v;
        r4 = r4.mo2141a();
        r4 = r1.m3882a(r4);
        r1 = r7.f3558x;
        r1 = r1[r4];
        if (r1 != 0) goto L_0x0094;
    L_0x0075:
        r1 = r3;
    L_0x0076:
        com.google.android.exoplayer2.p031c.C1392a.m2711b(r1);
        r1 = r7.f3555u;
        r1 = r1 + 1;
        r7.f3555u = r1;
        r1 = r7.f3558x;
        r1[r4] = r3;
        r1 = new com.google.android.exoplayer2.source.a$c;
        r1.<init>(r7, r4);
        r10[r0] = r1;
        r11[r0] = r3;
        r1 = r3;
    L_0x008d:
        r0 = r0 + 1;
        goto L_0x0044;
    L_0x0090:
        r1 = r2;
        goto L_0x0058;
    L_0x0092:
        r1 = r2;
        goto L_0x0062;
    L_0x0094:
        r1 = r2;
        goto L_0x0076;
    L_0x0096:
        r0 = r7.f3553s;
        if (r0 != 0) goto L_0x00b8;
    L_0x009a:
        r0 = r7.f3548n;
        r5 = r0.size();
        r4 = r2;
    L_0x00a1:
        if (r4 >= r5) goto L_0x00b8;
    L_0x00a3:
        r0 = r7.f3558x;
        r0 = r0[r4];
        if (r0 != 0) goto L_0x00b4;
    L_0x00a9:
        r0 = r7.f3548n;
        r0 = r0.valueAt(r4);
        r0 = (com.google.android.exoplayer2.extractor.C1522d) r0;
        r0.m3339b();
    L_0x00b4:
        r0 = r4 + 1;
        r4 = r0;
        goto L_0x00a1;
    L_0x00b8:
        r0 = r7.f3555u;
        if (r0 != 0) goto L_0x00ce;
    L_0x00bc:
        r7.f3554t = r2;
        r0 = r7.f3542h;
        r0 = r0.m4216a();
        if (r0 == 0) goto L_0x00cb;
    L_0x00c6:
        r0 = r7.f3542h;
        r0.m4217b();
    L_0x00cb:
        r7.f3553s = r3;
        return r12;
    L_0x00ce:
        r0 = r7.f3553s;
        if (r0 == 0) goto L_0x00e4;
    L_0x00d2:
        if (r1 == 0) goto L_0x00cb;
    L_0x00d4:
        r12 = r7.mo2281b(r12);
    L_0x00d8:
        r0 = r10.length;
        if (r2 >= r0) goto L_0x00cb;
    L_0x00db:
        r0 = r10[r2];
        if (r0 == 0) goto L_0x00e1;
    L_0x00df:
        r11[r2] = r3;
    L_0x00e1:
        r2 = r2 + 1;
        goto L_0x00d8;
    L_0x00e4:
        r0 = 0;
        r0 = (r12 > r0 ? 1 : (r12 == r0 ? 0 : -1));
        if (r0 == 0) goto L_0x00cb;
    L_0x00ea:
        goto L_0x00d4;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.source.a.a(com.google.android.exoplayer2.b.f[], boolean[], com.google.android.exoplayer2.source.d[], boolean[], long):long");
    }

    public boolean mo2280a(long j) {
        if (this.f3533C) {
            return false;
        }
        boolean a = this.f3544j.m2721a();
        if (this.f3542h.m4216a()) {
            return a;
        }
        m3848j();
        return true;
    }

    public long mo2284e() {
        return mo2286g();
    }

    public long mo2285f() {
        if (!this.f3554t) {
            return -9223372036854775807L;
        }
        this.f3554t = false;
        return this.f3560z;
    }

    public long mo2286g() {
        if (this.f3533C) {
            return Long.MIN_VALUE;
        }
        if (m3851m()) {
            return this.f3531A;
        }
        long l = m3850l();
        return l == Long.MIN_VALUE ? this.f3560z : l;
    }

    public long mo2281b(long j) {
        boolean z;
        if (!this.f3550p.mo2173a()) {
            j = 0;
        }
        this.f3560z = j;
        int size = this.f3548n.size();
        if (m3851m()) {
            z = false;
        } else {
            z = true;
        }
        int i = 0;
        while (z && i < size) {
            if (this.f3558x[i]) {
                z = ((C1522d) this.f3548n.valueAt(i)).m3338a(j);
            }
            i++;
        }
        if (!z) {
            this.f3531A = j;
            this.f3533C = false;
            if (this.f3542h.m4216a()) {
                this.f3542h.m4217b();
            } else {
                for (i = 0; i < size; i++) {
                    ((C1522d) this.f3548n.valueAt(i)).m3337a(this.f3558x[i]);
                }
            }
        }
        this.f3554t = false;
        return j;
    }

    boolean m3868b(int i) {
        return this.f3533C || !(m3851m() || ((C1522d) this.f3548n.valueAt(i)).m3340c());
    }

    void m3874h() {
        this.f3542h.m4218c();
    }

    int m3852a(int i, C1581h c1581h, C1347e c1347e) {
        if (this.f3554t || m3851m()) {
            return -3;
        }
        return ((C1522d) this.f3548n.valueAt(i)).m3332a(c1581h, c1347e, this.f3533C, this.f3560z);
    }

    public void m3860a(C1621a c1621a, long j, long j2) {
        m3836a(c1621a);
        this.f3533C = true;
        if (this.f3557w == -9223372036854775807L) {
            long l = m3850l();
            this.f3557w = l == Long.MIN_VALUE ? 0 : l + 10000;
            this.f3540f.mo2232a(new C1629f(this.f3557w, this.f3550p.mo2173a()), null);
        }
    }

    public void m3861a(C1621a c1621a, long j, long j2, boolean z) {
        m3836a(c1621a);
        if (!z && this.f3555u > 0) {
            int size = this.f3548n.size();
            for (int i = 0; i < size; i++) {
                ((C1522d) this.f3548n.valueAt(i)).m3337a(this.f3558x[i]);
            }
            this.f3549o.mo2234a(this);
        }
    }

    public int m3853a(C1621a c1621a, long j, long j2, IOException iOException) {
        m3836a(c1621a);
        m3840b(iOException);
        if (m3838a(iOException)) {
            return 3;
        }
        int i;
        if (m3849k() > this.f3532B) {
            i = 1;
        } else {
            i = 0;
        }
        m3839b(c1621a);
        this.f3532B = m3849k();
        if (i == 0) {
            return 0;
        }
        return 1;
    }

    public C1521o mo2273a(int i) {
        C1522d c1522d = (C1522d) this.f3548n.get(i);
        if (c1522d != null) {
            return c1522d;
        }
        C1521o c1522d2 = new C1522d(this.f3541g);
        c1522d2.m3336a((C1496c) this);
        this.f3548n.put(i, c1522d2);
        return c1522d2;
    }

    public void mo2274a() {
        this.f3551q = true;
        this.f3547m.post(this.f3545k);
    }

    public void mo2276a(C1455m c1455m) {
        this.f3550p = c1455m;
        this.f3547m.post(this.f3545k);
    }

    public void mo2275a(Format format) {
        this.f3547m.post(this.f3545k);
    }

    private void m3847i() {
        if (!this.f3534D && !this.f3552r && this.f3550p != null && this.f3551q) {
            int size = this.f3548n.size();
            int i = 0;
            while (i < size) {
                if (((C1522d) this.f3548n.valueAt(i)).m3341d() != null) {
                    i++;
                } else {
                    return;
                }
            }
            this.f3544j.m2722b();
            C1630g[] c1630gArr = new C1630g[size];
            this.f3558x = new boolean[size];
            this.f3557w = this.f3550p.mo2174b();
            for (i = 0; i < size; i++) {
                c1630gArr[i] = new C1630g(((C1522d) this.f3548n.valueAt(i)).m3341d());
            }
            this.f3556v = new C1631h(c1630gArr);
            this.f3552r = true;
            this.f3540f.mo2232a(new C1629f(this.f3557w, this.f3550p.mo2173a()), null);
            this.f3549o.mo2233a(this);
        }
    }

    private void m3836a(C1621a c1621a) {
        if (this.f3559y == -1) {
            this.f3559y = c1621a.f3525i;
        }
    }

    private void m3848j() {
        C1620c c1621a = new C1621a(this, this.f3535a, this.f3536b, this.f3543i, this.f3544j);
        if (this.f3552r) {
            C1392a.m2711b(m3851m());
            if (this.f3557w == -9223372036854775807L || this.f3531A < this.f3557w) {
                c1621a.m3810a(this.f3550p.mo2175b(this.f3531A));
                this.f3531A = -9223372036854775807L;
            } else {
                this.f3533C = true;
                this.f3531A = -9223372036854775807L;
                return;
            }
        }
        this.f3532B = m3849k();
        int i = this.f3537c;
        if (i == -1) {
            i = (this.f3552r && this.f3559y == -1 && (this.f3550p == null || this.f3550p.mo2174b() == -9223372036854775807L)) ? 6 : 3;
        }
        this.f3542h.m4213a(c1621a, this, i);
    }

    private void m3839b(C1621a c1621a) {
        if (this.f3559y != -1) {
            return;
        }
        if (this.f3550p == null || this.f3550p.mo2174b() == -9223372036854775807L) {
            this.f3560z = 0;
            this.f3554t = this.f3552r;
            int size = this.f3548n.size();
            int i = 0;
            while (i < size) {
                boolean z;
                C1522d c1522d = (C1522d) this.f3548n.valueAt(i);
                if (!this.f3552r || this.f3558x[i]) {
                    z = true;
                } else {
                    z = false;
                }
                c1522d.m3337a(z);
                i++;
            }
            c1621a.m3810a(0);
        }
    }

    private int m3849k() {
        int i = 0;
        for (int i2 = 0; i2 < this.f3548n.size(); i2++) {
            i += ((C1522d) this.f3548n.valueAt(i2)).m3330a();
        }
        return i;
    }

    private long m3850l() {
        long j = Long.MIN_VALUE;
        int size = this.f3548n.size();
        for (int i = 0; i < size; i++) {
            j = Math.max(j, ((C1522d) this.f3548n.valueAt(i)).m3342e());
        }
        return j;
    }

    private boolean m3851m() {
        return this.f3531A != -9223372036854775807L;
    }

    private boolean m3838a(IOException iOException) {
        return iOException instanceof UnrecognizedInputFormatException;
    }

    private void m3840b(final IOException iOException) {
        if (this.f3538d != null && this.f3539e != null) {
            this.f3538d.post(new Runnable(this) {
                final /* synthetic */ C1628a f3516b;

                public void run() {
                    this.f3516b.f3539e.m3793a(iOException);
                }
            });
        }
    }
}
