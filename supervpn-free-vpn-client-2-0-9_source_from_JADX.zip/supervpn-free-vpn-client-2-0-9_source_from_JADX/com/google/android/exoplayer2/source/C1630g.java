package com.google.android.exoplayer2.source;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.p031c.C1392a;
import java.util.Arrays;

public final class C1630g {
    public final int f3568a;
    private final Format[] f3569b;
    private int f3570c;

    public C1630g(Format... formatArr) {
        C1392a.m2711b(formatArr.length > 0);
        this.f3569b = formatArr;
        this.f3568a = formatArr.length;
    }

    public Format m3881a(int i) {
        return this.f3569b[i];
    }

    public int m3880a(Format format) {
        for (int i = 0; i < this.f3569b.length; i++) {
            if (format == this.f3569b[i]) {
                return i;
            }
        }
        return -1;
    }

    public int hashCode() {
        if (this.f3570c == 0) {
            this.f3570c = Arrays.hashCode(this.f3569b) + 527;
        }
        return this.f3570c;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        C1630g c1630g = (C1630g) obj;
        if (this.f3568a == c1630g.f3568a && Arrays.equals(this.f3569b, c1630g.f3569b)) {
            return true;
        }
        return false;
    }
}
