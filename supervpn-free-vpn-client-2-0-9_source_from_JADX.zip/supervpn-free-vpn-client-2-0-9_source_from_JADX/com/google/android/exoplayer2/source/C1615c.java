package com.google.android.exoplayer2.source;

import com.google.android.exoplayer2.C1613n;
import com.google.android.exoplayer2.upstream.C1684b;

public interface C1615c {

    public interface C1579a {
        void mo2232a(C1613n c1613n, Object obj);
    }

    C1626b mo2259a(int i, C1684b c1684b, long j);

    void mo2260a();

    void mo2261a(C1626b c1626b);

    void mo2262a(C1579a c1579a);

    void mo2263b();
}
