package com.google.android.exoplayer2.source;

import android.net.Uri;
import android.os.Handler;
import com.google.android.exoplayer2.C1613n;
import com.google.android.exoplayer2.C1613n.C1611a;
import com.google.android.exoplayer2.ParserException;
import com.google.android.exoplayer2.extractor.C1447i;
import com.google.android.exoplayer2.extractor.C1451f;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1414r;
import com.google.android.exoplayer2.source.C1615c.C1579a;
import com.google.android.exoplayer2.upstream.C1678d.C1680a;
import com.google.android.exoplayer2.upstream.C1684b;
import java.io.IOException;

public final class ExtractorMediaSource implements C1615c, C1579a {
    private final Uri f3501a;
    private final C1680a f3502b;
    private final C1447i f3503c;
    private final int f3504d;
    private final Handler f3505e;
    private final C1614a f3506f;
    private final C1611a f3507g;
    private C1579a f3508h;
    private C1613n f3509i;
    private boolean f3510j;

    public static final class UnrecognizedInputFormatException extends ParserException {
        public UnrecognizedInputFormatException(C1451f[] c1451fArr) {
            super("None of the available extractors (" + C1414r.m2819a((Object[]) c1451fArr) + ") could read the stream.");
        }
    }

    public interface C1614a {
        void m3793a(IOException iOException);
    }

    public ExtractorMediaSource(Uri uri, C1680a c1680a, C1447i c1447i, Handler handler, C1614a c1614a) {
        this(uri, c1680a, c1447i, -1, handler, c1614a);
    }

    public ExtractorMediaSource(Uri uri, C1680a c1680a, C1447i c1447i, int i, Handler handler, C1614a c1614a) {
        this.f3501a = uri;
        this.f3502b = c1680a;
        this.f3503c = c1447i;
        this.f3504d = i;
        this.f3505e = handler;
        this.f3506f = c1614a;
        this.f3507g = new C1611a();
    }

    public void mo2262a(C1579a c1579a) {
        this.f3508h = c1579a;
        this.f3509i = new C1629f(-9223372036854775807L, false);
        c1579a.mo2232a(this.f3509i, null);
    }

    public void mo2260a() {
    }

    public C1626b mo2259a(int i, C1684b c1684b, long j) {
        C1392a.m2709a(i == 0);
        return new C1628a(this.f3501a, this.f3502b.mo2326a(), this.f3503c.mo2159a(), this.f3504d, this.f3505e, this.f3506f, this, c1684b);
    }

    public void mo2261a(C1626b c1626b) {
        ((C1628a) c1626b).m3867b();
    }

    public void mo2263b() {
        this.f3508h = null;
    }

    public void mo2232a(C1613n c1613n, Object obj) {
        boolean z = false;
        if (c1613n.m3788a(0, this.f3507g).m3779b() != -9223372036854775807L) {
            z = true;
        }
        if (!this.f3510j || z) {
            this.f3509i = c1613n;
            this.f3510j = z;
            this.f3508h.mo2232a(this.f3509i, null);
        }
    }
}
