package com.google.android.exoplayer2.source;

import com.google.android.exoplayer2.C1613n;
import com.google.android.exoplayer2.C1613n.C1611a;
import com.google.android.exoplayer2.C1613n.C1612b;
import com.google.android.exoplayer2.p031c.C1392a;

public final class C1629f extends C1613n {
    private static final Object f3561a = new Object();
    private final long f3562b;
    private final long f3563c;
    private final long f3564d;
    private final long f3565e;
    private final boolean f3566f;
    private final boolean f3567g;

    public C1629f(long j, boolean z) {
        this(j, j, 0, 0, z, false);
    }

    public C1629f(long j, long j2, long j3, long j4, boolean z, boolean z2) {
        this.f3562b = j;
        this.f3563c = j2;
        this.f3564d = j3;
        this.f3565e = j4;
        this.f3566f = z;
        this.f3567g = z2;
    }

    public int mo2287a() {
        return 1;
    }

    public C1612b mo2290a(int i, C1612b c1612b, boolean z) {
        C1392a.m2706a(i, 0, 1);
        return c1612b.m3782a(z ? f3561a : null, -9223372036854775807L, -9223372036854775807L, this.f3566f, this.f3567g, this.f3565e, this.f3563c, 0, 0, this.f3564d);
    }

    public int mo2291b() {
        return 1;
    }

    public C1611a mo2289a(int i, C1611a c1611a, boolean z) {
        C1392a.m2706a(i, 0, 1);
        Object obj = z ? f3561a : null;
        return c1611a.m3778a(obj, obj, 0, this.f3562b, -this.f3564d);
    }

    public int mo2288a(Object obj) {
        return f3561a.equals(obj) ? 0 : -1;
    }
}
