package com.google.android.exoplayer2.source;

import java.util.Arrays;

public final class C1631h {
    public final int f3571a;
    private final C1630g[] f3572b;
    private int f3573c;

    public C1631h(C1630g... c1630gArr) {
        this.f3572b = c1630gArr;
        this.f3571a = c1630gArr.length;
    }

    public C1630g m3883a(int i) {
        return this.f3572b[i];
    }

    public int m3882a(C1630g c1630g) {
        for (int i = 0; i < this.f3571a; i++) {
            if (this.f3572b[i] == c1630g) {
                return i;
            }
        }
        return -1;
    }

    public int hashCode() {
        if (this.f3573c == 0) {
            this.f3573c = Arrays.hashCode(this.f3572b);
        }
        return this.f3573c;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        C1631h c1631h = (C1631h) obj;
        if (this.f3571a == c1631h.f3571a && Arrays.equals(this.f3572b, c1631h.f3572b)) {
            return true;
        }
        return false;
    }
}
