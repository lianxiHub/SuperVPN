package com.google.android.exoplayer2.source;

import com.google.android.exoplayer2.C1581h;
import com.google.android.exoplayer2.p030a.C1347e;

public interface C1623d {
    int mo2267a(C1581h c1581h, C1347e c1347e);

    void mo2268a(long j);

    boolean mo2269a();

    void mo2270b();
}
