package com.google.android.exoplayer2.source;

public interface C1625e {

    public interface C1577a {
        void mo2234a(C1625e c1625e);
    }

    boolean mo2280a(long j);

    long mo2284e();
}
