package com.google.android.exoplayer2.source;

import com.google.android.exoplayer2.p032b.C1375f;
import com.google.android.exoplayer2.source.C1625e.C1577a;

public interface C1626b extends C1625e {

    public interface C1578a extends C1577a {
        void mo2233a(C1626b c1626b);
    }

    long mo2272a(C1375f[] c1375fArr, boolean[] zArr, C1623d[] c1623dArr, boolean[] zArr2, long j);

    void mo2277a(C1578a c1578a);

    long mo2281b(long j);

    void mo2282c();

    C1631h mo2283d();

    long mo2285f();

    long mo2286g();
}
