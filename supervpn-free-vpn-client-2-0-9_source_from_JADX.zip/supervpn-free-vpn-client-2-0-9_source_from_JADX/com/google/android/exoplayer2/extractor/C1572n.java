package com.google.android.exoplayer2.extractor;

public final class C1572n {
    private final long f3347a;
    private long f3348b;
    private volatile long f3349c = -9223372036854775807L;

    public C1572n(long j) {
        this.f3347a = j;
    }

    public void m3575a() {
        this.f3349c = -9223372036854775807L;
    }

    public long m3574a(long j) {
        long j2;
        if (this.f3349c != -9223372036854775807L) {
            long d = C1572n.m3573d(this.f3349c);
            long j3 = (4294967296L + d) / 8589934592L;
            j2 = ((j3 - 1) * 8589934592L) + j;
            j3 = (j3 * 8589934592L) + j;
            if (Math.abs(j2 - d) >= Math.abs(j3 - d)) {
                j2 = j3;
            }
        } else {
            j2 = j;
        }
        return m3576b(C1572n.m3572c(j2));
    }

    public long m3576b(long j) {
        if (this.f3349c != -9223372036854775807L) {
            this.f3349c = j;
        } else {
            if (this.f3347a != Long.MAX_VALUE) {
                this.f3348b = this.f3347a - j;
            }
            synchronized (this) {
                this.f3349c = j;
                notifyAll();
            }
        }
        return this.f3348b + j;
    }

    public static long m3572c(long j) {
        return (1000000 * j) / 90000;
    }

    public static long m3573d(long j) {
        return (90000 * j) / 1000000;
    }
}
