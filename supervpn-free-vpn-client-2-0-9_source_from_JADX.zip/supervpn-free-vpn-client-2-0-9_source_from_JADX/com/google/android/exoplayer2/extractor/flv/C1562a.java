package com.google.android.exoplayer2.extractor.flv;

import android.util.Pair;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.extractor.flv.TagPayloadReader.UnsupportedFormatException;
import com.google.android.exoplayer2.p031c.C1393b;
import com.google.android.exoplayer2.p031c.C1403k;
import java.util.Collections;

final class C1562a extends TagPayloadReader {
    private static final int[] f3304b = new int[]{5500, 11000, 22000, 44000};
    private boolean f3305c;
    private boolean f3306d;

    public C1562a(C1521o c1521o) {
        super(c1521o);
    }

    protected boolean mo2213a(C1403k c1403k) {
        if (this.f3305c) {
            c1403k.m2762d(1);
        } else {
            int g = c1403k.m2766g();
            int i = (g >> 4) & 15;
            g = (g >> 2) & 3;
            if (g < 0 || g >= f3304b.length) {
                throw new UnsupportedFormatException("Invalid sample rate index: " + g);
            } else if (i != 10) {
                throw new UnsupportedFormatException("Audio format not supported: " + i);
            } else {
                this.f3305c = true;
            }
        }
        return true;
    }

    protected void mo2212a(C1403k c1403k, long j) {
        int g = c1403k.m2766g();
        if (g == 0 && !this.f3306d) {
            Object obj = new byte[c1403k.m2757b()];
            c1403k.m2756a(obj, 0, obj.length);
            Pair a = C1393b.m2713a(obj);
            this.a.mo2202a(Format.m2407a(null, "audio/mp4a-latm", null, -1, -1, ((Integer) a.second).intValue(), ((Integer) a.first).intValue(), Collections.singletonList(obj), null, 0, null));
            this.f3306d = true;
        } else if (g == 1) {
            int b = c1403k.m2757b();
            this.a.mo2203a(c1403k, b);
            this.a.mo2201a(j, 1, b, 0, null);
        }
    }
}
