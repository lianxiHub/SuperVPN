package com.google.android.exoplayer2.extractor.flv;

import com.google.android.exoplayer2.ParserException;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.p031c.C1403k;
import com.mopub.mobileads.VastIconXmlManager;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

final class C1565c extends TagPayloadReader {
    private long f3322b = -9223372036854775807L;

    public C1565c(C1521o c1521o) {
        super(c1521o);
    }

    public long m3555a() {
        return this.f3322b;
    }

    protected boolean mo2213a(C1403k c1403k) {
        return true;
    }

    protected void mo2212a(C1403k c1403k, long j) {
        if (C1565c.m3547b(c1403k) != 2) {
            throw new ParserException();
        }
        if (!"onMetaData".equals(C1565c.m3550e(c1403k))) {
            return;
        }
        if (C1565c.m3547b(c1403k) != 8) {
            throw new ParserException();
        }
        Map h = C1565c.m3553h(c1403k);
        if (h.containsKey(VastIconXmlManager.DURATION)) {
            double doubleValue = ((Double) h.get(VastIconXmlManager.DURATION)).doubleValue();
            if (doubleValue > 0.0d) {
                this.f3322b = (long) (doubleValue * 1000000.0d);
            }
        }
    }

    private static int m3547b(C1403k c1403k) {
        return c1403k.m2766g();
    }

    private static Boolean m3548c(C1403k c1403k) {
        boolean z = true;
        if (c1403k.m2766g() != 1) {
            z = false;
        }
        return Boolean.valueOf(z);
    }

    private static Double m3549d(C1403k c1403k) {
        return Double.valueOf(Double.longBitsToDouble(c1403k.m2775p()));
    }

    private static String m3550e(C1403k c1403k) {
        int h = c1403k.m2767h();
        int d = c1403k.m2761d();
        c1403k.m2762d(h);
        return new String(c1403k.f2479a, d, h);
    }

    private static ArrayList m3551f(C1403k c1403k) {
        int t = c1403k.m2779t();
        ArrayList arrayList = new ArrayList(t);
        for (int i = 0; i < t; i++) {
            arrayList.add(C1565c.m3546a(c1403k, C1565c.m3547b(c1403k)));
        }
        return arrayList;
    }

    private static HashMap m3552g(C1403k c1403k) {
        HashMap hashMap = new HashMap();
        while (true) {
            String e = C1565c.m3550e(c1403k);
            int b = C1565c.m3547b(c1403k);
            if (b == 9) {
                return hashMap;
            }
            hashMap.put(e, C1565c.m3546a(c1403k, b));
        }
    }

    private static HashMap m3553h(C1403k c1403k) {
        int t = c1403k.m2779t();
        HashMap hashMap = new HashMap(t);
        for (int i = 0; i < t; i++) {
            hashMap.put(C1565c.m3550e(c1403k), C1565c.m3546a(c1403k, C1565c.m3547b(c1403k)));
        }
        return hashMap;
    }

    private static Date m3554i(C1403k c1403k) {
        Date date = new Date((long) C1565c.m3549d(c1403k).doubleValue());
        c1403k.m2762d(2);
        return date;
    }

    private static Object m3546a(C1403k c1403k, int i) {
        switch (i) {
            case 0:
                return C1565c.m3549d(c1403k);
            case 1:
                return C1565c.m3548c(c1403k);
            case 2:
                return C1565c.m3550e(c1403k);
            case 3:
                return C1565c.m3552g(c1403k);
            case 8:
                return C1565c.m3553h(c1403k);
            case 10:
                return C1565c.m3551f(c1403k);
            case 11:
                return C1565c.m3554i(c1403k);
            default:
                return null;
        }
    }
}
