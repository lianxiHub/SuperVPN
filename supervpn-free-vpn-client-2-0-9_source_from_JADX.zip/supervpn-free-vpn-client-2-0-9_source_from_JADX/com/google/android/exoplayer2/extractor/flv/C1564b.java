package com.google.android.exoplayer2.extractor.flv;

import android.support.v7.widget.helper.ItemTouchHelper.Callback;
import com.google.android.exoplayer2.extractor.C1447i;
import com.google.android.exoplayer2.extractor.C1451f;
import com.google.android.exoplayer2.extractor.C1455m;
import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.extractor.C1570l;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1414r;

public final class C1564b implements C1451f, C1455m {
    public static final C1447i f3307a = new C15631();
    private static final int f3308e = C1414r.m2830e("FLV");
    public int f3309b;
    public int f3310c;
    public long f3311d;
    private final C1403k f3312f = new C1403k(4);
    private final C1403k f3313g = new C1403k(9);
    private final C1403k f3314h = new C1403k(11);
    private final C1403k f3315i = new C1403k();
    private C1567h f3316j;
    private int f3317k = 1;
    private int f3318l;
    private C1562a f3319m;
    private C1566d f3320n;
    private C1565c f3321o;

    static class C15631 implements C1447i {
        C15631() {
        }

        public C1451f[] mo2159a() {
            return new C1451f[]{new C1564b()};
        }
    }

    public boolean mo2171a(C1464g c1464g) {
        c1464g.mo2187c(this.f3312f.f2479a, 0, 3);
        this.f3312f.m2760c(0);
        if (this.f3312f.m2770k() != f3308e) {
            return false;
        }
        c1464g.mo2187c(this.f3312f.f2479a, 0, 2);
        this.f3312f.m2760c(0);
        if ((this.f3312f.m2767h() & Callback.DEFAULT_SWIPE_ANIMATION_DURATION) != 0) {
            return false;
        }
        c1464g.mo2187c(this.f3312f.f2479a, 0, 4);
        this.f3312f.m2760c(0);
        int n = this.f3312f.m2773n();
        c1464g.mo2179a();
        c1464g.mo2186c(n);
        c1464g.mo2187c(this.f3312f.f2479a, 0, 4);
        this.f3312f.m2760c(0);
        if (this.f3312f.m2773n() == 0) {
            return true;
        }
        return false;
    }

    public void mo2170a(C1567h c1567h) {
        this.f3316j = c1567h;
    }

    public void mo2169a(long j) {
        this.f3317k = 1;
        this.f3318l = 0;
    }

    public void mo2172c() {
    }

    public int mo2168a(C1464g c1464g, C1570l c1570l) {
        while (true) {
            switch (this.f3317k) {
                case 1:
                    if (m3533b(c1464g)) {
                        break;
                    }
                    return -1;
                case 2:
                    m3534c(c1464g);
                    break;
                case 3:
                    if (m3535d(c1464g)) {
                        break;
                    }
                    return -1;
                case 4:
                    if (!m3536e(c1464g)) {
                        break;
                    }
                    return 0;
                default:
                    break;
            }
        }
    }

    private boolean m3533b(C1464g c1464g) {
        boolean z = false;
        if (!c1464g.mo2180a(this.f3313g.f2479a, 0, 9, true)) {
            return false;
        }
        this.f3313g.m2760c(0);
        this.f3313g.m2762d(4);
        int g = this.f3313g.m2766g();
        boolean z2 = (g & 4) != 0;
        if ((g & 1) != 0) {
            z = true;
        }
        if (z2 && this.f3319m == null) {
            this.f3319m = new C1562a(this.f3316j.mo2273a(8));
        }
        if (z && this.f3320n == null) {
            this.f3320n = new C1566d(this.f3316j.mo2273a(9));
        }
        if (this.f3321o == null) {
            this.f3321o = new C1565c(null);
        }
        this.f3316j.mo2274a();
        this.f3316j.mo2276a((C1455m) this);
        this.f3318l = (this.f3313g.m2773n() - 9) + 4;
        this.f3317k = 2;
        return true;
    }

    private void m3534c(C1464g c1464g) {
        c1464g.mo2182b(this.f3318l);
        this.f3318l = 0;
        this.f3317k = 3;
    }

    private boolean m3535d(C1464g c1464g) {
        if (!c1464g.mo2180a(this.f3314h.f2479a, 0, 11, true)) {
            return false;
        }
        this.f3314h.m2760c(0);
        this.f3309b = this.f3314h.m2766g();
        this.f3310c = this.f3314h.m2770k();
        this.f3311d = (long) this.f3314h.m2770k();
        this.f3311d = (((long) (this.f3314h.m2766g() << 24)) | this.f3311d) * 1000;
        this.f3314h.m2762d(3);
        this.f3317k = 4;
        return true;
    }

    private boolean m3536e(C1464g c1464g) {
        boolean z = true;
        if (this.f3309b == 8 && this.f3319m != null) {
            this.f3319m.m3529b(m3537f(c1464g), this.f3311d);
        } else if (this.f3309b == 9 && this.f3320n != null) {
            this.f3320n.m3529b(m3537f(c1464g), this.f3311d);
        } else if (this.f3309b != 18 || this.f3321o == null) {
            c1464g.mo2182b(this.f3310c);
            z = false;
        } else {
            this.f3321o.m3529b(m3537f(c1464g), this.f3311d);
        }
        this.f3318l = 4;
        this.f3317k = 2;
        return z;
    }

    private C1403k m3537f(C1464g c1464g) {
        if (this.f3310c > this.f3315i.m2763e()) {
            this.f3315i.m2755a(new byte[Math.max(this.f3315i.m2763e() * 2, this.f3310c)], 0);
        } else {
            this.f3315i.m2760c(0);
        }
        this.f3315i.m2758b(this.f3310c);
        c1464g.mo2183b(this.f3315i.f2479a, 0, this.f3310c);
        return this.f3315i;
    }

    public boolean mo2173a() {
        return false;
    }

    public long mo2174b() {
        return this.f3321o.m3555a();
    }

    public long mo2175b(long j) {
        return 0;
    }
}
