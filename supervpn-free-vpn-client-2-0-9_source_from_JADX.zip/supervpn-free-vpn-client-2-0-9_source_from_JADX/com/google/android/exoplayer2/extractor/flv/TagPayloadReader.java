package com.google.android.exoplayer2.extractor.flv;

import com.google.android.exoplayer2.ParserException;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.p031c.C1403k;

abstract class TagPayloadReader {
    protected final C1521o f3303a;

    public static final class UnsupportedFormatException extends ParserException {
        public UnsupportedFormatException(String str) {
            super(str);
        }
    }

    protected abstract void mo2212a(C1403k c1403k, long j);

    protected abstract boolean mo2213a(C1403k c1403k);

    protected TagPayloadReader(C1521o c1521o) {
        this.f3303a = c1521o;
    }

    public final void m3529b(C1403k c1403k, long j) {
        if (mo2213a(c1403k)) {
            mo2212a(c1403k, j);
        }
    }
}
