package com.google.android.exoplayer2.extractor.flv;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.extractor.flv.TagPayloadReader.UnsupportedFormatException;
import com.google.android.exoplayer2.p031c.C1401i;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p033d.C1419a;

final class C1566d extends TagPayloadReader {
    private final C1403k f3323b = new C1403k(C1401i.f2471a);
    private final C1403k f3324c = new C1403k(4);
    private int f3325d;
    private boolean f3326e;
    private int f3327f;

    public C1566d(C1521o c1521o) {
        super(c1521o);
    }

    protected boolean mo2213a(C1403k c1403k) {
        int g = c1403k.m2766g();
        int i = (g >> 4) & 15;
        g &= 15;
        if (g != 7) {
            throw new UnsupportedFormatException("Video format not supported: " + g);
        }
        this.f3327f = i;
        return i != 5;
    }

    protected void mo2212a(C1403k c1403k, long j) {
        int g = c1403k.m2766g();
        long k = (((long) c1403k.m2770k()) * 1000) + j;
        if (g == 0 && !this.f3326e) {
            C1403k c1403k2 = new C1403k(new byte[c1403k.m2757b()]);
            c1403k.m2756a(c1403k2.f2479a, 0, c1403k.m2757b());
            C1419a a = C1419a.m2854a(c1403k2);
            this.f3325d = a.f2523b;
            this.a.mo2202a(Format.m2403a(null, "video/avc", null, -1, -1, a.f2524c, a.f2525d, -1.0f, a.f2522a, -1, a.f2526e, null));
            this.f3326e = true;
        } else if (g == 1) {
            byte[] bArr = this.f3324c.f2479a;
            bArr[0] = (byte) 0;
            bArr[1] = (byte) 0;
            bArr[2] = (byte) 0;
            g = 4 - this.f3325d;
            int i = 0;
            while (c1403k.m2757b() > 0) {
                c1403k.m2756a(this.f3324c.f2479a, g, this.f3325d);
                this.f3324c.m2760c(0);
                int t = this.f3324c.m2779t();
                this.f3323b.m2760c(0);
                this.a.mo2203a(this.f3323b, 4);
                int i2 = i + 4;
                this.a.mo2203a(c1403k, t);
                i = i2 + t;
            }
            this.a.mo2201a(k, this.f3327f == 1 ? 1 : 0, i, 0, null);
        }
    }
}
