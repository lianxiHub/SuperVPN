package com.google.android.exoplayer2.extractor;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.p031c.C1403k;
import java.io.EOFException;

public final class C1556e implements C1521o {
    public void mo2202a(Format format) {
    }

    public int mo2200a(C1464g c1464g, int i, boolean z) {
        int a = c1464g.mo2177a(i);
        if (a != -1) {
            return a;
        }
        if (z) {
            return -1;
        }
        throw new EOFException();
    }

    public void mo2203a(C1403k c1403k, int i) {
        c1403k.m2762d(i);
    }

    public void mo2201a(long j, int i, int i2, int i3, byte[] bArr) {
    }
}
