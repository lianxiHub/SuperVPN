package com.google.android.exoplayer2.extractor;

import com.google.android.exoplayer2.C1581h;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.p030a.C1347e;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1414r;
import com.google.android.exoplayer2.upstream.C1683a;
import com.google.android.exoplayer2.upstream.C1684b;
import java.io.EOFException;
import java.nio.ByteBuffer;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.atomic.AtomicInteger;

public final class C1522d implements C1521o {
    private final C1684b f3044a;
    private final int f3045b;
    private final C1495b f3046c = new C1495b();
    private final LinkedBlockingDeque f3047d = new LinkedBlockingDeque();
    private final C1494a f3048e = new C1494a();
    private final C1403k f3049f = new C1403k(32);
    private final AtomicInteger f3050g = new AtomicInteger();
    private long f3051h;
    private Format f3052i;
    private long f3053j;
    private long f3054k;
    private C1683a f3055l;
    private int f3056m = this.f3045b;
    private boolean f3057n = true;
    private boolean f3058o;
    private C1496c f3059p;

    private static final class C1494a {
        public int f2927a;
        public long f2928b;
        public long f2929c;
        public byte[] f2930d;

        private C1494a() {
        }
    }

    private static final class C1495b {
        private int f2931a = 1000;
        private int[] f2932b = new int[this.f2931a];
        private long[] f2933c = new long[this.f2931a];
        private int[] f2934d = new int[this.f2931a];
        private int[] f2935e = new int[this.f2931a];
        private long[] f2936f = new long[this.f2931a];
        private byte[][] f2937g = new byte[this.f2931a][];
        private Format[] f2938h = new Format[this.f2931a];
        private int f2939i;
        private int f2940j;
        private int f2941k;
        private int f2942l;
        private long f2943m = Long.MIN_VALUE;
        private long f2944n = Long.MIN_VALUE;
        private boolean f2945o = true;
        private Format f2946p;
        private int f2947q;

        public void m3215a() {
            this.f2940j = 0;
            this.f2941k = 0;
            this.f2942l = 0;
            this.f2939i = 0;
        }

        public void m3218b() {
            this.f2943m = Long.MIN_VALUE;
            this.f2944n = Long.MIN_VALUE;
        }

        public int m3220c() {
            return this.f2940j + this.f2939i;
        }

        public long m3213a(int i) {
            int c = m3220c() - i;
            boolean z = c >= 0 && c <= this.f2939i;
            C1392a.m2709a(z);
            int i2;
            if (c != 0) {
                this.f2939i -= c;
                this.f2942l = ((this.f2942l + this.f2931a) - c) % this.f2931a;
                this.f2944n = Long.MIN_VALUE;
                for (i2 = this.f2939i - 1; i2 >= 0; i2--) {
                    c = (this.f2941k + i2) % this.f2931a;
                    this.f2944n = Math.max(this.f2944n, this.f2936f[c]);
                    if ((this.f2935e[c] & 1) != 0) {
                        break;
                    }
                }
                return this.f2933c[this.f2942l];
            } else if (this.f2940j == 0) {
                return 0;
            } else {
                i2 = (this.f2942l == 0 ? this.f2931a : this.f2942l) - 1;
                return ((long) this.f2934d[i2]) + this.f2933c[i2];
            }
        }

        public synchronized boolean m3222d() {
            return this.f2939i == 0;
        }

        public synchronized Format m3223e() {
            return this.f2945o ? null : this.f2946p;
        }

        public synchronized long m3224f() {
            return Math.max(this.f2943m, this.f2944n);
        }

        public synchronized int m3212a(C1581h c1581h, C1347e c1347e, Format format, C1494a c1494a) {
            int i = -5;
            synchronized (this) {
                if (this.f2939i == 0) {
                    if (this.f2946p == null || this.f2946p == format) {
                        i = -3;
                    } else {
                        c1581h.f3419a = this.f2946p;
                    }
                } else if (this.f2938h[this.f2941k] != format) {
                    c1581h.f3419a = this.f2938h[this.f2941k];
                } else {
                    c1347e.f2221c = this.f2936f[this.f2941k];
                    c1347e.a_(this.f2935e[this.f2941k]);
                    c1494a.f2927a = this.f2934d[this.f2941k];
                    c1494a.f2928b = this.f2933c[this.f2941k];
                    c1494a.f2930d = this.f2937g[this.f2941k];
                    this.f2943m = Math.max(this.f2943m, c1347e.f2221c);
                    this.f2939i--;
                    this.f2941k++;
                    this.f2940j++;
                    if (this.f2941k == this.f2931a) {
                        this.f2941k = 0;
                    }
                    c1494a.f2929c = this.f2939i > 0 ? this.f2933c[this.f2941k] : c1494a.f2928b + ((long) c1494a.f2927a);
                    i = -4;
                }
            }
            return i;
        }

        public synchronized long m3214a(long j) {
            long j2 = -1;
            synchronized (this) {
                if (this.f2939i != 0 && j >= this.f2936f[this.f2941k]) {
                    if (j <= this.f2936f[(this.f2942l == 0 ? this.f2931a : this.f2942l) - 1]) {
                        int i = 0;
                        int i2 = this.f2941k;
                        int i3 = -1;
                        while (i2 != this.f2942l && this.f2936f[i2] <= j) {
                            if ((this.f2935e[i2] & 1) != 0) {
                                i3 = i;
                            }
                            i2 = (i2 + 1) % this.f2931a;
                            i++;
                        }
                        if (i3 != -1) {
                            this.f2939i -= i3;
                            this.f2941k = (this.f2941k + i3) % this.f2931a;
                            this.f2940j += i3;
                            j2 = this.f2933c[this.f2941k];
                        }
                    }
                }
            }
            return j2;
        }

        public synchronized boolean m3217a(Format format) {
            boolean z = false;
            synchronized (this) {
                if (format == null) {
                    this.f2945o = true;
                } else {
                    this.f2945o = false;
                    if (!C1414r.m2823a((Object) format, this.f2946p)) {
                        this.f2946p = format;
                        z = true;
                    }
                }
            }
            return z;
        }

        public synchronized void m3216a(long j, int i, long j2, int i2, byte[] bArr) {
            C1392a.m2711b(!this.f2945o);
            m3219b(j);
            this.f2936f[this.f2942l] = j;
            this.f2933c[this.f2942l] = j2;
            this.f2934d[this.f2942l] = i2;
            this.f2935e[this.f2942l] = i;
            this.f2937g[this.f2942l] = bArr;
            this.f2938h[this.f2942l] = this.f2946p;
            this.f2932b[this.f2942l] = this.f2947q;
            this.f2939i++;
            if (this.f2939i == this.f2931a) {
                int i3 = this.f2931a + 1000;
                Object obj = new int[i3];
                Object obj2 = new long[i3];
                Object obj3 = new long[i3];
                Object obj4 = new int[i3];
                Object obj5 = new int[i3];
                Object obj6 = new byte[i3][];
                Object obj7 = new Format[i3];
                int i4 = this.f2931a - this.f2941k;
                System.arraycopy(this.f2933c, this.f2941k, obj2, 0, i4);
                System.arraycopy(this.f2936f, this.f2941k, obj3, 0, i4);
                System.arraycopy(this.f2935e, this.f2941k, obj4, 0, i4);
                System.arraycopy(this.f2934d, this.f2941k, obj5, 0, i4);
                System.arraycopy(this.f2937g, this.f2941k, obj6, 0, i4);
                System.arraycopy(this.f2938h, this.f2941k, obj7, 0, i4);
                System.arraycopy(this.f2932b, this.f2941k, obj, 0, i4);
                int i5 = this.f2941k;
                System.arraycopy(this.f2933c, 0, obj2, i4, i5);
                System.arraycopy(this.f2936f, 0, obj3, i4, i5);
                System.arraycopy(this.f2935e, 0, obj4, i4, i5);
                System.arraycopy(this.f2934d, 0, obj5, i4, i5);
                System.arraycopy(this.f2937g, 0, obj6, i4, i5);
                System.arraycopy(this.f2938h, 0, obj7, i4, i5);
                System.arraycopy(this.f2932b, 0, obj, i4, i5);
                this.f2933c = obj2;
                this.f2936f = obj3;
                this.f2935e = obj4;
                this.f2934d = obj5;
                this.f2937g = obj6;
                this.f2938h = obj7;
                this.f2932b = obj;
                this.f2941k = 0;
                this.f2942l = this.f2931a;
                this.f2939i = this.f2931a;
                this.f2931a = i3;
            } else {
                this.f2942l++;
                if (this.f2942l == this.f2931a) {
                    this.f2942l = 0;
                }
            }
        }

        public synchronized void m3219b(long j) {
            this.f2944n = Math.max(this.f2944n, j);
        }

        public synchronized boolean m3221c(long j) {
            boolean z;
            if (this.f2943m >= j) {
                z = false;
            } else {
                int i = this.f2939i;
                while (i > 0 && this.f2936f[((this.f2941k + i) - 1) % this.f2931a] >= j) {
                    i--;
                }
                m3213a(i + this.f2940j);
                z = true;
            }
            return z;
        }
    }

    public interface C1496c {
        void mo2275a(Format format);
    }

    public C1522d(C1684b c1684b) {
        this.f3044a = c1684b;
        this.f3045b = c1684b.mo2321c();
    }

    public void m3337a(boolean z) {
        int andSet = this.f3050g.getAndSet(z ? 0 : 2);
        m3329h();
        this.f3046c.m3218b();
        if (andSet == 2) {
            this.f3052i = null;
        }
    }

    public int m3330a() {
        return this.f3046c.m3220c();
    }

    public void m3339b() {
        if (this.f3050g.getAndSet(2) == 0) {
            m3329h();
        }
    }

    public boolean m3340c() {
        return this.f3046c.m3222d();
    }

    public Format m3341d() {
        return this.f3046c.m3223e();
    }

    public long m3342e() {
        return this.f3046c.m3224f();
    }

    public boolean m3338a(long j) {
        long a = this.f3046c.m3214a(j);
        if (a == -1) {
            return false;
        }
        m3326b(a);
        return true;
    }

    public int m3332a(C1581h c1581h, C1347e c1347e, boolean z, long j) {
        switch (this.f3046c.m3212a(c1581h, c1347e, this.f3052i, this.f3048e)) {
            case -5:
                this.f3052i = c1581h.f3419a;
                return -5;
            case -4:
                if (c1347e.f2221c < j) {
                    c1347e.m2422b(Integer.MIN_VALUE);
                }
                if (c1347e.m2438d()) {
                    m3325a(c1347e, this.f3048e);
                }
                c1347e.m2440e(this.f3048e.f2927a);
                m3323a(this.f3048e.f2928b, c1347e.f2220b, this.f3048e.f2927a);
                m3326b(this.f3048e.f2929c);
                return -4;
            case -3:
                if (!z) {
                    return -3;
                }
                c1347e.a_(4);
                return -4;
            default:
                throw new IllegalStateException();
        }
    }

    private void m3325a(C1347e c1347e, C1494a c1494a) {
        long j;
        int i = 0;
        long j2 = c1494a.f2928b;
        this.f3049f.m2753a(1);
        m3324a(j2, this.f3049f.f2479a, 1);
        long j3 = 1 + j2;
        byte b = this.f3049f.f2479a[0];
        int i2 = (b & 128) != 0 ? 1 : 0;
        int i3 = b & 127;
        if (c1347e.f2219a.f2205a == null) {
            c1347e.f2219a.f2205a = new byte[16];
        }
        m3324a(j3, c1347e.f2219a.f2205a, i3);
        j3 += (long) i3;
        if (i2 != 0) {
            this.f3049f.m2753a(2);
            m3324a(j3, this.f3049f.f2479a, 2);
            j3 += 2;
            i3 = this.f3049f.m2767h();
            j = j3;
        } else {
            i3 = 1;
            j = j3;
        }
        int[] iArr = c1347e.f2219a.f2208d;
        if (iArr == null || iArr.length < i3) {
            iArr = new int[i3];
        }
        int[] iArr2 = c1347e.f2219a.f2209e;
        if (iArr2 == null || iArr2.length < i3) {
            iArr2 = new int[i3];
        }
        if (i2 != 0) {
            i2 = i3 * 6;
            this.f3049f.m2753a(i2);
            m3324a(j, this.f3049f.f2479a, i2);
            j += (long) i2;
            this.f3049f.m2760c(0);
            while (i < i3) {
                iArr[i] = this.f3049f.m2767h();
                iArr2[i] = this.f3049f.m2779t();
                i++;
            }
        } else {
            iArr[0] = 0;
            iArr2[0] = c1494a.f2927a - ((int) (j - c1494a.f2928b));
        }
        c1347e.f2219a.m2429a(i3, iArr, iArr2, c1494a.f2930d, c1347e.f2219a.f2205a, 1);
        i2 = (int) (j - c1494a.f2928b);
        c1494a.f2928b += (long) i2;
        c1494a.f2927a -= i2;
    }

    private void m3323a(long j, ByteBuffer byteBuffer, int i) {
        while (i > 0) {
            m3326b(j);
            int i2 = (int) (j - this.f3051h);
            int min = Math.min(i, this.f3045b - i2);
            C1683a c1683a = (C1683a) this.f3047d.peek();
            byteBuffer.put(c1683a.f3848a, c1683a.m4219a(i2), min);
            j += (long) min;
            i -= min;
        }
    }

    private void m3324a(long j, byte[] bArr, int i) {
        int i2 = 0;
        while (i2 < i) {
            m3326b(j);
            int i3 = (int) (j - this.f3051h);
            int min = Math.min(i - i2, this.f3045b - i3);
            C1683a c1683a = (C1683a) this.f3047d.peek();
            System.arraycopy(c1683a.f3848a, c1683a.m4219a(i3), bArr, i2, min);
            j += (long) min;
            i2 += min;
        }
    }

    private void m3326b(long j) {
        int i = ((int) (j - this.f3051h)) / this.f3045b;
        for (int i2 = 0; i2 < i; i2++) {
            this.f3044a.mo2318a((C1683a) this.f3047d.remove());
            this.f3051h += (long) this.f3045b;
        }
    }

    public void m3336a(C1496c c1496c) {
        this.f3059p = c1496c;
    }

    public void mo2202a(Format format) {
        Format a = C1522d.m3322a(format, this.f3053j);
        boolean a2 = this.f3046c.m3217a(a);
        if (this.f3059p != null && a2) {
            this.f3059p.mo2275a(a);
        }
    }

    public int mo2200a(C1464g c1464g, int i, boolean z) {
        int a;
        if (m3327f()) {
            try {
                a = c1464g.mo2178a(this.f3055l.f3848a, this.f3055l.m4219a(this.f3056m), m3321a(i));
                if (a != -1) {
                    this.f3056m += a;
                    this.f3054k += (long) a;
                    m3328g();
                    return a;
                } else if (z) {
                    return -1;
                } else {
                    throw new EOFException();
                }
            } finally {
                m3328g();
            }
        } else {
            a = c1464g.mo2177a(i);
            if (a != -1) {
                return a;
            }
            if (z) {
                return -1;
            }
            throw new EOFException();
        }
    }

    public void mo2203a(C1403k c1403k, int i) {
        if (m3327f()) {
            while (i > 0) {
                int a = m3321a(i);
                c1403k.m2756a(this.f3055l.f3848a, this.f3055l.m4219a(this.f3056m), a);
                this.f3056m += a;
                this.f3054k += (long) a;
                i -= a;
            }
            m3328g();
            return;
        }
        c1403k.m2762d(i);
    }

    public void mo2201a(long j, int i, int i2, int i3, byte[] bArr) {
        if (m3327f()) {
            try {
                if (this.f3058o) {
                    if ((i & 1) == 0 || !this.f3046c.m3221c(j)) {
                        m3328g();
                        return;
                    }
                    this.f3058o = false;
                }
                if (this.f3057n) {
                    if ((i & 1) == 0) {
                        m3328g();
                        return;
                    }
                    this.f3057n = false;
                }
                this.f3046c.m3216a(j + this.f3053j, i, (this.f3054k - ((long) i2)) - ((long) i3), i2, bArr);
                m3328g();
            } catch (Throwable th) {
                m3328g();
            }
        } else {
            this.f3046c.m3219b(j);
        }
    }

    private boolean m3327f() {
        return this.f3050g.compareAndSet(0, 1);
    }

    private void m3328g() {
        if (!this.f3050g.compareAndSet(1, 0)) {
            m3329h();
        }
    }

    private void m3329h() {
        this.f3046c.m3215a();
        this.f3044a.mo2319a((C1683a[]) this.f3047d.toArray(new C1683a[this.f3047d.size()]));
        this.f3047d.clear();
        this.f3044a.mo2320b();
        this.f3051h = 0;
        this.f3054k = 0;
        this.f3055l = null;
        this.f3056m = this.f3045b;
        this.f3057n = true;
    }

    private int m3321a(int i) {
        if (this.f3056m == this.f3045b) {
            this.f3056m = 0;
            this.f3055l = this.f3044a.mo2317a();
            this.f3047d.add(this.f3055l);
        }
        return Math.min(i, this.f3045b - this.f3056m);
    }

    private static Format m3322a(Format format, long j) {
        if (format == null) {
            return null;
        }
        if (j == 0 || format.f2199u == Long.MAX_VALUE) {
            return format;
        }
        return format.m2418a(format.f2199u + j);
    }
}
