package com.google.android.exoplayer2.extractor.p036c;

final class C1476c {
    public final int f2823a;
    public final int f2824b;
    public final int f2825c;
    public final int f2826d;

    public C1476c(int i, int i2, int i3, int i4) {
        this.f2823a = i;
        this.f2824b = i2;
        this.f2825c = i3;
        this.f2826d = i4;
    }
}
