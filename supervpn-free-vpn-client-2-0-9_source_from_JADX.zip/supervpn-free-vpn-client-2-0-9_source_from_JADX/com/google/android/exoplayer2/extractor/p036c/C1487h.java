package com.google.android.exoplayer2.extractor.p036c;

import android.support.v4.media.session.PlaybackStateCompat;
import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1414r;

final class C1487h {
    private static final int[] f2886a = new int[]{C1414r.m2830e("isom"), C1414r.m2830e("iso2"), C1414r.m2830e("iso3"), C1414r.m2830e("iso4"), C1414r.m2830e("iso5"), C1414r.m2830e("iso6"), C1414r.m2830e("avc1"), C1414r.m2830e("hvc1"), C1414r.m2830e("hev1"), C1414r.m2830e("mp41"), C1414r.m2830e("mp42"), C1414r.m2830e("3g2a"), C1414r.m2830e("3g2b"), C1414r.m2830e("3gr6"), C1414r.m2830e("3gs6"), C1414r.m2830e("3ge6"), C1414r.m2830e("3gg6"), C1414r.m2830e("M4V "), C1414r.m2830e("M4A "), C1414r.m2830e("f4v "), C1414r.m2830e("kddi"), C1414r.m2830e("M4VP"), C1414r.m2830e("qt  "), C1414r.m2830e("MSNV")};

    public static boolean m3200a(C1464g c1464g) {
        return C1487h.m3201a(c1464g, true);
    }

    public static boolean m3202b(C1464g c1464g) {
        return C1487h.m3201a(c1464g, false);
    }

    private static boolean m3201a(C1464g c1464g, boolean z) {
        long d = c1464g.mo2188d();
        if (d == -1 || d > PlaybackStateCompat.ACTION_SKIP_TO_QUEUE_ITEM) {
            d = PlaybackStateCompat.ACTION_SKIP_TO_QUEUE_ITEM;
        }
        int i = (int) d;
        C1403k c1403k = new C1403k(64);
        Object obj = null;
        boolean z2 = false;
        int i2 = 0;
        while (i2 < i) {
            int i3 = 8;
            c1403k.m2753a(8);
            c1464g.mo2187c(c1403k.f2479a, 0, 8);
            long l = c1403k.m2771l();
            int n = c1403k.m2773n();
            if (l == 1) {
                i3 = 16;
                c1464g.mo2187c(c1403k.f2479a, 8, 8);
                c1403k.m2758b(16);
                l = c1403k.m2781v();
            }
            if (l >= ((long) i3)) {
                i2 += i3;
                if (n != C1466a.f2740A) {
                    if (n != C1466a.f2749J && n != C1466a.f2751L) {
                        if ((((long) i2) + l) - ((long) i3) >= ((long) i)) {
                            break;
                        }
                        int i4 = (int) (l - ((long) i3));
                        int i5 = i2 + i4;
                        if (n == C1466a.f2766a) {
                            if (i4 < 8) {
                                return false;
                            }
                            c1403k.m2753a(i4);
                            c1464g.mo2187c(c1403k.f2479a, 0, i4);
                            i3 = i4 / 4;
                            for (i4 = 0; i4 < i3; i4++) {
                                if (i4 == 1) {
                                    c1403k.m2762d(4);
                                } else if (C1487h.m3199a(c1403k.m2773n())) {
                                    obj = 1;
                                    break;
                                }
                            }
                            if (obj == null) {
                                return false;
                            }
                        } else if (i4 != 0) {
                            c1464g.mo2186c(i4);
                        }
                        i2 = i5;
                    } else {
                        z2 = true;
                        break;
                    }
                }
            } else {
                return false;
            }
        }
        if (obj == null || z != r1) {
            return false;
        }
        return true;
    }

    private static boolean m3199a(int i) {
        if ((i >>> 8) == C1414r.m2830e("3gp")) {
            return true;
        }
        for (int i2 : f2886a) {
            if (i2 == i) {
                return true;
            }
        }
        return false;
    }
}
