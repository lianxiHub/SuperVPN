package com.google.android.exoplayer2.extractor.p036c;

import android.support.v4.media.session.PlaybackStateCompat;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.extractor.C1447i;
import com.google.android.exoplayer2.extractor.C1451f;
import com.google.android.exoplayer2.extractor.C1455m;
import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.extractor.C1568j;
import com.google.android.exoplayer2.extractor.C1570l;
import com.google.android.exoplayer2.extractor.p036c.C1466a.C1467a;
import com.google.android.exoplayer2.extractor.p036c.C1466a.C1468b;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1401i;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1414r;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public final class C1485f implements C1451f, C1455m {
    public static final C1447i f2869a = new C14831();
    private static final int f2870b = C1414r.m2830e("qt  ");
    private final C1403k f2871c = new C1403k(C1401i.f2471a);
    private final C1403k f2872d = new C1403k(4);
    private final C1403k f2873e = new C1403k(16);
    private final Stack f2874f = new Stack();
    private int f2875g;
    private int f2876h;
    private long f2877i;
    private int f2878j;
    private C1403k f2879k;
    private int f2880l;
    private int f2881m;
    private C1567h f2882n;
    private C1484a[] f2883o;
    private long f2884p;
    private boolean f2885q;

    static class C14831 implements C1447i {
        C14831() {
        }

        public C1451f[] mo2159a() {
            return new C1451f[]{new C1485f()};
        }
    }

    private static final class C1484a {
        public final C1488i f2865a;
        public final C1491l f2866b;
        public final C1521o f2867c;
        public int f2868d;

        public C1484a(C1488i c1488i, C1491l c1491l, C1521o c1521o) {
            this.f2865a = c1488i;
            this.f2866b = c1491l;
            this.f2867c = c1521o;
        }
    }

    public C1485f() {
        m3187d();
    }

    public boolean mo2171a(C1464g c1464g) {
        return C1487h.m3202b(c1464g);
    }

    public void mo2170a(C1567h c1567h) {
        this.f2882n = c1567h;
    }

    public void mo2169a(long j) {
        this.f2874f.clear();
        this.f2878j = 0;
        this.f2880l = 0;
        this.f2881m = 0;
        this.f2875g = 0;
    }

    public void mo2172c() {
    }

    public int mo2168a(C1464g c1464g, C1570l c1570l) {
        while (true) {
            switch (this.f2875g) {
                case 0:
                    if (c1464g.mo2185c() != 0) {
                        this.f2875g = 3;
                        break;
                    }
                    m3187d();
                    break;
                case 1:
                    if (m3183b(c1464g)) {
                        break;
                    }
                    return -1;
                case 2:
                    if (!m3184b(c1464g, c1570l)) {
                        break;
                    }
                    return 1;
                default:
                    return m3185c(c1464g, c1570l);
            }
        }
    }

    public boolean mo2173a() {
        return true;
    }

    public long mo2174b() {
        return this.f2884p;
    }

    public long mo2175b(long j) {
        long j2 = Long.MAX_VALUE;
        C1484a[] c1484aArr = this.f2883o;
        int length = c1484aArr.length;
        int i = 0;
        while (i < length) {
            C1484a c1484a = c1484aArr[i];
            C1491l c1491l = c1484a.f2866b;
            int a = c1491l.m3209a(j);
            if (a == -1) {
                a = c1491l.m3210b(j);
            }
            c1484a.f2868d = a;
            long j3 = c1491l.f2921b[a];
            if (j3 >= j2) {
                j3 = j2;
            }
            i++;
            j2 = j3;
        }
        return j2;
    }

    private void m3187d() {
        this.f2875g = 1;
        this.f2878j = 0;
    }

    private boolean m3183b(C1464g c1464g) {
        if (this.f2878j == 0) {
            if (!c1464g.mo2180a(this.f2873e.f2479a, 0, 8, true)) {
                return false;
            }
            this.f2878j = 8;
            this.f2873e.m2760c(0);
            this.f2877i = this.f2873e.m2771l();
            this.f2876h = this.f2873e.m2773n();
        }
        if (this.f2877i == 1) {
            c1464g.mo2183b(this.f2873e.f2479a, 8, 8);
            this.f2878j += 8;
            this.f2877i = this.f2873e.m2781v();
        }
        if (C1485f.m3182b(this.f2876h)) {
            long c = (c1464g.mo2185c() + this.f2877i) - ((long) this.f2878j);
            this.f2874f.add(new C1467a(this.f2876h, c));
            if (this.f2877i == ((long) this.f2878j)) {
                m3186c(c);
            } else {
                m3187d();
            }
        } else if (C1485f.m3180a(this.f2876h)) {
            boolean z;
            if (this.f2878j == 8) {
                z = true;
            } else {
                z = false;
            }
            C1392a.m2711b(z);
            if (this.f2877i <= 2147483647L) {
                z = true;
            } else {
                z = false;
            }
            C1392a.m2711b(z);
            this.f2879k = new C1403k((int) this.f2877i);
            System.arraycopy(this.f2873e.f2479a, 0, this.f2879k.f2479a, 0, 8);
            this.f2875g = 2;
        } else {
            this.f2879k = null;
            this.f2875g = 2;
        }
        return true;
    }

    private boolean m3184b(C1464g c1464g, C1570l c1570l) {
        boolean z;
        long j = this.f2877i - ((long) this.f2878j);
        long c = c1464g.mo2185c() + j;
        if (this.f2879k != null) {
            c1464g.mo2183b(this.f2879k.f2479a, this.f2878j, (int) j);
            if (this.f2876h == C1466a.f2766a) {
                this.f2885q = C1485f.m3181a(this.f2879k);
                z = false;
            } else if (this.f2874f.isEmpty()) {
                z = false;
            } else {
                ((C1467a) this.f2874f.peek()).m3101a(new C1468b(this.f2876h, this.f2879k));
                z = false;
            }
        } else if (j < PlaybackStateCompat.ACTION_SET_REPEAT_MODE) {
            c1464g.mo2182b((int) j);
            z = false;
        } else {
            c1570l.f3345a = j + c1464g.mo2185c();
            z = true;
        }
        m3186c(c);
        if (!z || this.f2875g == 3) {
            return false;
        }
        return true;
    }

    private void m3186c(long j) {
        while (!this.f2874f.isEmpty() && ((C1467a) this.f2874f.peek()).aN == j) {
            C1467a c1467a = (C1467a) this.f2874f.pop();
            if (c1467a.aM == C1466a.f2740A) {
                m3179a(c1467a);
                this.f2874f.clear();
                this.f2875g = 3;
            } else if (!this.f2874f.isEmpty()) {
                ((C1467a) this.f2874f.peek()).m3100a(c1467a);
            }
        }
        if (this.f2875g != 3) {
            m3187d();
        }
    }

    private static boolean m3181a(C1403k c1403k) {
        c1403k.m2760c(8);
        if (c1403k.m2773n() == f2870b) {
            return true;
        }
        c1403k.m2762d(4);
        while (c1403k.m2757b() > 0) {
            if (c1403k.m2773n() == f2870b) {
                return true;
            }
        }
        return false;
    }

    private void m3179a(C1467a c1467a) {
        List arrayList = new ArrayList();
        C1568j c1568j = new C1568j();
        C1468b d = c1467a.m3102d(C1466a.az);
        if (d != null) {
            C1475b.m3128a(d, this.f2885q, c1568j);
        }
        int i = 0;
        long j = Long.MAX_VALUE;
        long j2 = -9223372036854775807L;
        while (i < c1467a.aP.size()) {
            long j3;
            long j4;
            C1467a c1467a2 = (C1467a) c1467a.aP.get(i);
            if (c1467a2.aM != C1466a.f2742C) {
                j3 = j;
                j4 = j2;
            } else {
                C1488i a = C1475b.m3123a(c1467a2, c1467a.m3102d(C1466a.f2741B), -9223372036854775807L, null, this.f2885q);
                if (a == null) {
                    j3 = j;
                    j4 = j2;
                } else {
                    C1491l a2 = C1475b.m3124a(a, c1467a2.m3103e(C1466a.f2743D).m3103e(C1466a.f2744E).m3103e(C1466a.f2745F), c1568j);
                    if (a2.f2920a == 0) {
                        j3 = j;
                        j4 = j2;
                    } else {
                        C1484a c1484a = new C1484a(a, a2, this.f2882n.mo2273a(i));
                        Format a3 = a.f2892f.m2416a(a2.f2923d + 30);
                        if (a.f2888b == 1 && c1568j.m3563a()) {
                            a3 = a3.m2417a(c1568j.f3329a, c1568j.f3330b);
                        }
                        c1484a.f2867c.mo2202a(a3);
                        j2 = Math.max(j2, a.f2891e);
                        arrayList.add(c1484a);
                        j3 = a2.f2921b[0];
                        if (j3 < j) {
                            j4 = j2;
                        } else {
                            j3 = j;
                            j4 = j2;
                        }
                    }
                }
            }
            i++;
            j = j3;
            j2 = j4;
        }
        this.f2884p = j2;
        this.f2883o = (C1484a[]) arrayList.toArray(new C1484a[arrayList.size()]);
        this.f2882n.mo2274a();
        this.f2882n.mo2276a((C1455m) this);
    }

    private int m3185c(C1464g c1464g, C1570l c1570l) {
        int e = m3188e();
        if (e == -1) {
            return -1;
        }
        C1484a c1484a = this.f2883o[e];
        C1521o c1521o = c1484a.f2867c;
        int i = c1484a.f2868d;
        long j = c1484a.f2866b.f2921b[i];
        e = c1484a.f2866b.f2922c[i];
        if (c1484a.f2865a.f2893g == 1) {
            j += 8;
            e -= 8;
        }
        long c = (j - c1464g.mo2185c()) + ((long) this.f2880l);
        if (c < 0 || c >= PlaybackStateCompat.ACTION_SET_REPEAT_MODE) {
            c1570l.f3345a = j;
            return 1;
        }
        int a;
        c1464g.mo2182b((int) c);
        int i2;
        if (c1484a.f2865a.f2897k != 0) {
            byte[] bArr = this.f2872d.f2479a;
            bArr[0] = (byte) 0;
            bArr[1] = (byte) 0;
            bArr[2] = (byte) 0;
            i2 = c1484a.f2865a.f2897k;
            int i3 = 4 - c1484a.f2865a.f2897k;
            while (this.f2880l < e) {
                if (this.f2881m == 0) {
                    c1464g.mo2183b(this.f2872d.f2479a, i3, i2);
                    this.f2872d.m2760c(0);
                    this.f2881m = this.f2872d.m2779t();
                    this.f2871c.m2760c(0);
                    c1521o.mo2203a(this.f2871c, 4);
                    this.f2880l += 4;
                    e += i3;
                } else {
                    a = c1521o.mo2200a(c1464g, this.f2881m, false);
                    this.f2880l += a;
                    this.f2881m -= a;
                }
            }
            a = e;
        } else {
            while (this.f2880l < e) {
                i2 = c1521o.mo2200a(c1464g, e - this.f2880l, false);
                this.f2880l += i2;
                this.f2881m -= i2;
            }
            a = e;
        }
        c1521o.mo2201a(c1484a.f2866b.f2924e[i], c1484a.f2866b.f2925f[i], a, 0, null);
        c1484a.f2868d++;
        this.f2880l = 0;
        this.f2881m = 0;
        return 0;
    }

    private int m3188e() {
        int i = -1;
        long j = Long.MAX_VALUE;
        for (int i2 = 0; i2 < this.f2883o.length; i2++) {
            C1484a c1484a = this.f2883o[i2];
            int i3 = c1484a.f2868d;
            if (i3 != c1484a.f2866b.f2920a) {
                long j2 = c1484a.f2866b.f2921b[i3];
                if (j2 < j) {
                    j = j2;
                    i = i2;
                }
            }
        }
        return i;
    }

    private static boolean m3180a(int i) {
        return i == C1466a.f2756Q || i == C1466a.f2741B || i == C1466a.f2757R || i == C1466a.f2758S || i == C1466a.al || i == C1466a.am || i == C1466a.an || i == C1466a.f2755P || i == C1466a.ao || i == C1466a.ap || i == C1466a.aq || i == C1466a.ar || i == C1466a.as || i == C1466a.f2753N || i == C1466a.f2766a || i == C1466a.az;
    }

    private static boolean m3182b(int i) {
        return i == C1466a.f2740A || i == C1466a.f2742C || i == C1466a.f2743D || i == C1466a.f2744E || i == C1466a.f2745F || i == C1466a.f2754O;
    }
}
