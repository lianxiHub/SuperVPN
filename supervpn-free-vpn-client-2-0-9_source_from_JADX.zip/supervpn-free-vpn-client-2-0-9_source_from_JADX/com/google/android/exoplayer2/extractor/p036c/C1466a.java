package com.google.android.exoplayer2.extractor.p036c;

import android.support.v4.view.ViewCompat;
import com.facebook.share.internal.ShareConstants;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1414r;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

abstract class C1466a {
    public static final int f2740A = C1414r.m2830e("moov");
    public static final int f2741B = C1414r.m2830e("mvhd");
    public static final int f2742C = C1414r.m2830e("trak");
    public static final int f2743D = C1414r.m2830e("mdia");
    public static final int f2744E = C1414r.m2830e("minf");
    public static final int f2745F = C1414r.m2830e("stbl");
    public static final int f2746G = C1414r.m2830e("avcC");
    public static final int f2747H = C1414r.m2830e("hvcC");
    public static final int f2748I = C1414r.m2830e("esds");
    public static final int f2749J = C1414r.m2830e("moof");
    public static final int f2750K = C1414r.m2830e("traf");
    public static final int f2751L = C1414r.m2830e("mvex");
    public static final int f2752M = C1414r.m2830e("mehd");
    public static final int f2753N = C1414r.m2830e("tkhd");
    public static final int f2754O = C1414r.m2830e("edts");
    public static final int f2755P = C1414r.m2830e("elst");
    public static final int f2756Q = C1414r.m2830e("mdhd");
    public static final int f2757R = C1414r.m2830e("hdlr");
    public static final int f2758S = C1414r.m2830e("stsd");
    public static final int f2759T = C1414r.m2830e("pssh");
    public static final int f2760U = C1414r.m2830e("sinf");
    public static final int f2761V = C1414r.m2830e("schm");
    public static final int f2762W = C1414r.m2830e("schi");
    public static final int f2763X = C1414r.m2830e("tenc");
    public static final int f2764Y = C1414r.m2830e("encv");
    public static final int f2765Z = C1414r.m2830e("enca");
    public static final int f2766a = C1414r.m2830e("ftyp");
    public static final int aA = C1414r.m2830e("meta");
    public static final int aB = C1414r.m2830e("ilst");
    public static final int aC = C1414r.m2830e("mean");
    public static final int aD = C1414r.m2830e("name");
    public static final int aE = C1414r.m2830e(ShareConstants.WEB_DIALOG_PARAM_DATA);
    public static final int aF = C1414r.m2830e("st3d");
    public static final int aG = C1414r.m2830e("sv3d");
    public static final int aH = C1414r.m2830e("proj");
    public static final int aI = C1414r.m2830e("vp08");
    public static final int aJ = C1414r.m2830e("vp09");
    public static final int aK = C1414r.m2830e("vpcC");
    public static final int aL = C1414r.m2830e("----");
    public static final int aa = C1414r.m2830e("frma");
    public static final int ab = C1414r.m2830e("saiz");
    public static final int ac = C1414r.m2830e("saio");
    public static final int ad = C1414r.m2830e("sbgp");
    public static final int ae = C1414r.m2830e("sgpd");
    public static final int af = C1414r.m2830e("uuid");
    public static final int ag = C1414r.m2830e("senc");
    public static final int ah = C1414r.m2830e("pasp");
    public static final int ai = C1414r.m2830e("TTML");
    public static final int aj = C1414r.m2830e("vmhd");
    public static final int ak = C1414r.m2830e("mp4v");
    public static final int al = C1414r.m2830e("stts");
    public static final int am = C1414r.m2830e("stss");
    public static final int an = C1414r.m2830e("ctts");
    public static final int ao = C1414r.m2830e("stsc");
    public static final int ap = C1414r.m2830e("stsz");
    public static final int aq = C1414r.m2830e("stz2");
    public static final int ar = C1414r.m2830e("stco");
    public static final int as = C1414r.m2830e("co64");
    public static final int at = C1414r.m2830e("tx3g");
    public static final int au = C1414r.m2830e("wvtt");
    public static final int av = C1414r.m2830e("stpp");
    public static final int aw = C1414r.m2830e("c608");
    public static final int ax = C1414r.m2830e("samr");
    public static final int ay = C1414r.m2830e("sawb");
    public static final int az = C1414r.m2830e("udta");
    public static final int f2767b = C1414r.m2830e("avc1");
    public static final int f2768c = C1414r.m2830e("avc3");
    public static final int f2769d = C1414r.m2830e("hvc1");
    public static final int f2770e = C1414r.m2830e("hev1");
    public static final int f2771f = C1414r.m2830e("s263");
    public static final int f2772g = C1414r.m2830e("d263");
    public static final int f2773h = C1414r.m2830e("mdat");
    public static final int f2774i = C1414r.m2830e("mp4a");
    public static final int f2775j = C1414r.m2830e("wave");
    public static final int f2776k = C1414r.m2830e("lpcm");
    public static final int f2777l = C1414r.m2830e("sowt");
    public static final int f2778m = C1414r.m2830e("ac-3");
    public static final int f2779n = C1414r.m2830e("dac3");
    public static final int f2780o = C1414r.m2830e("ec-3");
    public static final int f2781p = C1414r.m2830e("dec3");
    public static final int f2782q = C1414r.m2830e("dtsc");
    public static final int f2783r = C1414r.m2830e("dtsh");
    public static final int f2784s = C1414r.m2830e("dtsl");
    public static final int f2785t = C1414r.m2830e("dtse");
    public static final int f2786u = C1414r.m2830e("ddts");
    public static final int f2787v = C1414r.m2830e("tfdt");
    public static final int f2788w = C1414r.m2830e("tfhd");
    public static final int f2789x = C1414r.m2830e("trex");
    public static final int f2790y = C1414r.m2830e("trun");
    public static final int f2791z = C1414r.m2830e("sidx");
    public final int aM;

    static final class C1467a extends C1466a {
        public final long aN;
        public final List aO = new ArrayList();
        public final List aP = new ArrayList();

        public C1467a(int i, long j) {
            super(i);
            this.aN = j;
        }

        public void m3101a(C1468b c1468b) {
            this.aO.add(c1468b);
        }

        public void m3100a(C1467a c1467a) {
            this.aP.add(c1467a);
        }

        public C1468b m3102d(int i) {
            int size = this.aO.size();
            for (int i2 = 0; i2 < size; i2++) {
                C1468b c1468b = (C1468b) this.aO.get(i2);
                if (c1468b.aM == i) {
                    return c1468b;
                }
            }
            return null;
        }

        public C1467a m3103e(int i) {
            int size = this.aP.size();
            for (int i2 = 0; i2 < size; i2++) {
                C1467a c1467a = (C1467a) this.aP.get(i2);
                if (c1467a.aM == i) {
                    return c1467a;
                }
            }
            return null;
        }

        public String toString() {
            return C1466a.m3099c(this.aM) + " leaves: " + Arrays.toString(this.aO.toArray()) + " containers: " + Arrays.toString(this.aP.toArray());
        }
    }

    static final class C1468b extends C1466a {
        public final C1403k aN;

        public C1468b(int i, C1403k c1403k) {
            super(i);
            this.aN = c1403k;
        }
    }

    public C1466a(int i) {
        this.aM = i;
    }

    public String toString() {
        return C1466a.m3099c(this.aM);
    }

    public static int m3097a(int i) {
        return (i >> 24) & 255;
    }

    public static int m3098b(int i) {
        return ViewCompat.MEASURED_SIZE_MASK & i;
    }

    public static String m3099c(int i) {
        return "" + ((char) (i >> 24)) + ((char) ((i >> 16) & 255)) + ((char) ((i >> 8) & 255)) + ((char) (i & 255));
    }
}
