package com.google.android.exoplayer2.extractor.p036c;

import android.util.Log;
import android.util.Pair;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.ParserException;
import com.google.android.exoplayer2.audio.C1360a;
import com.google.android.exoplayer2.drm.DrmInitData;
import com.google.android.exoplayer2.extractor.C1568j;
import com.google.android.exoplayer2.extractor.p036c.C1466a.C1467a;
import com.google.android.exoplayer2.extractor.p036c.C1466a.C1468b;
import com.google.android.exoplayer2.extractor.p036c.C1479d.C1478a;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1393b;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1414r;
import com.google.android.exoplayer2.p033d.C1419a;
import com.google.android.exoplayer2.p033d.C1420b;
import com.mopub.volley.DefaultRetryPolicy;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

final class C1475b {
    private static final int f2816a = C1414r.m2830e("vide");
    private static final int f2817b = C1414r.m2830e("soun");
    private static final int f2818c = C1414r.m2830e("text");
    private static final int f2819d = C1414r.m2830e("sbtl");
    private static final int f2820e = C1414r.m2830e("subt");
    private static final int f2821f = C1414r.m2830e("clcp");
    private static final int f2822g = C1414r.m2830e("cenc");

    private static final class C1469a {
        public final int f2792a;
        public int f2793b;
        public int f2794c;
        public long f2795d;
        private final boolean f2796e;
        private final C1403k f2797f;
        private final C1403k f2798g;
        private int f2799h;
        private int f2800i;

        public C1469a(C1403k c1403k, C1403k c1403k2, boolean z) {
            boolean z2 = true;
            this.f2798g = c1403k;
            this.f2797f = c1403k2;
            this.f2796e = z;
            c1403k2.m2760c(12);
            this.f2792a = c1403k2.m2779t();
            c1403k.m2760c(12);
            this.f2800i = c1403k.m2779t();
            if (c1403k.m2773n() != 1) {
                z2 = false;
            }
            C1392a.m2712b(z2, "first_chunk must be 1");
            this.f2793b = -1;
        }

        public boolean m3104a() {
            int i = this.f2793b + 1;
            this.f2793b = i;
            if (i == this.f2792a) {
                return false;
            }
            long v;
            if (this.f2796e) {
                v = this.f2797f.m2781v();
            } else {
                v = this.f2797f.m2771l();
            }
            this.f2795d = v;
            if (this.f2793b == this.f2799h) {
                this.f2794c = this.f2798g.m2779t();
                this.f2798g.m2762d(4);
                i = this.f2800i - 1;
                this.f2800i = i;
                this.f2799h = i > 0 ? this.f2798g.m2779t() - 1 : -1;
            }
            return true;
        }
    }

    private interface C1470b {
        int mo2190a();

        int mo2191b();

        boolean mo2192c();
    }

    private static final class C1471c {
        public final C1489j[] f2801a;
        public Format f2802b;
        public int f2803c;
        public int f2804d = 0;

        public C1471c(int i) {
            this.f2801a = new C1489j[i];
        }
    }

    static final class C1472d implements C1470b {
        private final int f2805a = this.f2807c.m2779t();
        private final int f2806b = this.f2807c.m2779t();
        private final C1403k f2807c;

        public C1472d(C1468b c1468b) {
            this.f2807c = c1468b.aN;
            this.f2807c.m2760c(12);
        }

        public int mo2190a() {
            return this.f2806b;
        }

        public int mo2191b() {
            return this.f2805a == 0 ? this.f2807c.m2779t() : this.f2805a;
        }

        public boolean mo2192c() {
            return this.f2805a != 0;
        }
    }

    static final class C1473e implements C1470b {
        private final C1403k f2808a;
        private final int f2809b = this.f2808a.m2779t();
        private final int f2810c = (this.f2808a.m2779t() & 255);
        private int f2811d;
        private int f2812e;

        public C1473e(C1468b c1468b) {
            this.f2808a = c1468b.aN;
            this.f2808a.m2760c(12);
        }

        public int mo2190a() {
            return this.f2809b;
        }

        public int mo2191b() {
            if (this.f2810c == 8) {
                return this.f2808a.m2766g();
            }
            if (this.f2810c == 16) {
                return this.f2808a.m2767h();
            }
            int i = this.f2811d;
            this.f2811d = i + 1;
            if (i % 2 != 0) {
                return this.f2812e & 15;
            }
            this.f2812e = this.f2808a.m2766g();
            return (this.f2812e & 240) >> 4;
        }

        public boolean mo2192c() {
            return false;
        }
    }

    private static final class C1474f {
        private final int f2813a;
        private final long f2814b;
        private final int f2815c;

        public C1474f(int i, long j, int i2) {
            this.f2813a = i;
            this.f2814b = j;
            this.f2815c = i2;
        }
    }

    public static C1488i m3123a(C1467a c1467a, C1468b c1468b, long j, DrmInitData drmInitData, boolean z) {
        C1467a e = c1467a.m3103e(C1466a.f2743D);
        int c = C1475b.m3133c(e.m3102d(C1466a.f2757R).aN);
        if (c == -1) {
            return null;
        }
        long a;
        long j2;
        C1474f b = C1475b.m3131b(c1467a.m3102d(C1466a.f2753N).aN);
        if (j == -9223372036854775807L) {
            a = b.f2814b;
        } else {
            a = j;
        }
        long a2 = C1475b.m3120a(c1468b.aN);
        if (a == -9223372036854775807L) {
            j2 = -9223372036854775807L;
        } else {
            j2 = C1414r.m2816a(a, 1000000, a2);
        }
        C1467a e2 = e.m3103e(C1466a.f2744E).m3103e(C1466a.f2745F);
        Pair d = C1475b.m3135d(e.m3102d(C1466a.f2756Q).aN);
        C1471c a3 = C1475b.m3122a(e2.m3102d(C1466a.f2758S).aN, b.f2813a, b.f2815c, (String) d.second, drmInitData, z);
        Pair a4 = C1475b.m3121a(c1467a.m3103e(C1466a.f2754O));
        if (a3.f2802b == null) {
            return null;
        }
        return new C1488i(b.f2813a, c, ((Long) d.first).longValue(), a2, j2, a3.f2802b, a3.f2804d, a3.f2801a, a3.f2803c, (long[]) a4.first, (long[]) a4.second);
    }

    public static C1491l m3124a(C1488i c1488i, C1467a c1467a, C1568j c1568j) {
        C1470b c1472d;
        C1468b d = c1467a.m3102d(C1466a.ap);
        if (d != null) {
            c1472d = new C1472d(d);
        } else {
            d = c1467a.m3102d(C1466a.aq);
            if (d == null) {
                throw new ParserException("Track has no sample table size information");
            }
            c1472d = new C1473e(d);
        }
        int a = c1472d.mo2190a();
        if (a == 0) {
            return new C1491l(new long[0], new int[0], 0, new long[0], new int[0]);
        }
        int t;
        int i;
        int i2;
        Object obj;
        int i3;
        long j;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        long[] jArr;
        int i9;
        Object obj2;
        Object obj3;
        long j2;
        boolean z = false;
        d = c1467a.m3102d(C1466a.ar);
        if (d == null) {
            z = true;
            d = c1467a.m3102d(C1466a.as);
        }
        C1403k c1403k = d.aN;
        C1403k c1403k2 = c1467a.m3102d(C1466a.ao).aN;
        C1403k c1403k3 = c1467a.m3102d(C1466a.al).aN;
        d = c1467a.m3102d(C1466a.am);
        C1403k c1403k4 = d != null ? d.aN : null;
        C1468b d2 = c1467a.m3102d(C1466a.an);
        C1403k c1403k5 = d2 != null ? d2.aN : null;
        C1469a c1469a = new C1469a(c1403k2, c1403k, z);
        c1403k3.m2760c(12);
        int t2 = c1403k3.m2779t() - 1;
        int t3 = c1403k3.m2779t();
        int t4 = c1403k3.m2779t();
        int i10 = 0;
        if (c1403k5 != null) {
            c1403k5.m2760c(12);
            i10 = c1403k5.m2779t();
        }
        if (c1403k4 != null) {
            c1403k4.m2760c(12);
            t = c1403k4.m2779t();
            if (t > 0) {
                i = t;
                t = c1403k4.m2779t() - 1;
                c1403k = c1403k4;
                i2 = i;
            } else {
                i = t;
                t = -1;
                c1403k = null;
                i2 = i;
            }
        } else {
            t = -1;
            c1403k = c1403k4;
            i2 = 0;
        }
        Object obj4 = (c1472d.mo2192c() && "audio/raw".equals(c1488i.f2892f.f2183e) && t2 == 0 && i10 == 0 && i2 == 0) ? 1 : null;
        if (obj4 == null) {
            obj = new long[a];
            Object obj5 = new int[a];
            long[] jArr2 = new long[a];
            Object obj6 = new int[a];
            long j3 = 0;
            int i11 = 0;
            i3 = t3;
            int i12 = 0;
            int i13 = i2;
            i2 = 0;
            i = t;
            t = i10;
            j = 0;
            i4 = 0;
            i5 = 0;
            i6 = t4;
            i7 = t2;
            t4 = i;
            while (i11 < a) {
                long j4 = j3;
                i8 = i5;
                while (i8 == 0) {
                    C1392a.m2711b(c1469a.m3104a());
                    j4 = c1469a.f2795d;
                    i8 = c1469a.f2794c;
                }
                if (c1403k5 != null) {
                    while (i12 == 0 && t > 0) {
                        i12 = c1403k5.m2779t();
                        i2 = c1403k5.m2773n();
                        t--;
                    }
                    i12--;
                }
                obj[i11] = j4;
                obj5[i11] = c1472d.mo2191b();
                if (obj5[i11] > i4) {
                    i4 = obj5[i11];
                }
                jArr2[i11] = ((long) i2) + j;
                obj6[i11] = c1403k == null ? 1 : 0;
                if (i11 == t4) {
                    obj6[i11] = 1;
                    i5 = i13 - 1;
                    if (i5 > 0) {
                        t4 = c1403k.m2779t() - 1;
                        i13 = i5;
                    } else {
                        i13 = i5;
                    }
                }
                long j5 = ((long) i6) + j;
                i5 = i3 - 1;
                if (i5 != 0 || i7 <= 0) {
                    i = i6;
                    i6 = i5;
                    i5 = i;
                } else {
                    i6 = c1403k3.m2779t();
                    i5 = c1403k3.m2779t();
                    i7--;
                }
                j4 += (long) obj5[i11];
                i10 = i8 - 1;
                i11++;
                j3 = j4;
                i3 = i6;
                i6 = i5;
                i5 = i10;
                j = j5;
            }
            C1392a.m2709a(i12 == 0);
            while (t > 0) {
                C1392a.m2709a(c1403k5.m2779t() == 0);
                c1403k5.m2773n();
                t--;
            }
            if (!(i13 == 0 && i3 == 0 && i5 == 0 && i7 == 0)) {
                Log.w("AtomParsers", "Inconsistent stbl box for track " + c1488i.f2887a + ": remainingSynchronizationSamples " + i13 + ", remainingSamplesAtTimestampDelta " + i3 + ", remainingSamplesInChunk " + i5 + ", remainingTimestampDeltaChanges " + i7);
            }
            obj4 = obj6;
            jArr = jArr2;
            i9 = i4;
            obj2 = obj5;
            obj3 = obj;
            j2 = j;
        } else {
            long[] jArr3 = new long[c1469a.f2792a];
            int[] iArr = new int[c1469a.f2792a];
            while (c1469a.m3104a()) {
                jArr3[c1469a.f2793b] = c1469a.f2795d;
                iArr[c1469a.f2793b] = c1469a.f2794c;
            }
            C1478a a2 = C1479d.m3138a(c1472d.mo2191b(), jArr3, iArr, (long) t4);
            obj3 = a2.f2827a;
            obj2 = a2.f2828b;
            i9 = a2.f2829c;
            jArr = a2.f2830d;
            obj4 = a2.f2831e;
            j2 = 0;
        }
        if (c1488i.f2895i == null || c1568j.m3563a()) {
            C1414r.m2821a(jArr, 1000000, c1488i.f2889c);
            return new C1491l(obj3, obj2, i9, jArr, obj4);
        }
        long a3;
        if (c1488i.f2895i.length == 1 && c1488i.f2888b == 1 && jArr.length >= 2) {
            long j6 = c1488i.f2896j[0];
            a3 = C1414r.m2816a(c1488i.f2895i[0], c1488i.f2889c, c1488i.f2890d) + j6;
            if (jArr[0] <= j6 && j6 < jArr[1] && jArr[jArr.length - 1] < a3 && a3 <= j2) {
                j2 -= a3;
                j6 = C1414r.m2816a(j6 - jArr[0], (long) c1488i.f2892f.f2195q, c1488i.f2889c);
                a3 = C1414r.m2816a(j2, (long) c1488i.f2892f.f2195q, c1488i.f2889c);
                if (!(j6 == 0 && a3 == 0) && j6 <= 2147483647L && a3 <= 2147483647L) {
                    c1568j.f3329a = (int) j6;
                    c1568j.f3330b = (int) a3;
                    C1414r.m2821a(jArr, 1000000, c1488i.f2889c);
                    return new C1491l(obj3, obj2, i9, jArr, obj4);
                }
            }
        }
        int i14;
        if (c1488i.f2895i.length == 1 && c1488i.f2895i[0] == 0) {
            for (i14 = 0; i14 < jArr.length; i14++) {
                jArr[i14] = C1414r.m2816a(jArr[i14] - c1488i.f2896j[0], 1000000, c1488i.f2889c);
            }
            return new C1491l(obj3, obj2, i9, jArr, obj4);
        }
        long j7;
        Object obj7;
        Object obj8;
        i14 = 0;
        int i15 = 0;
        int i16 = 0;
        int i17 = 0;
        while (i14 < c1488i.f2895i.length) {
            j7 = c1488i.f2896j[i14];
            if (j7 != -1) {
                a3 = C1414r.m2816a(c1488i.f2895i[i14], c1488i.f2889c, c1488i.f2890d);
                i7 = C1414r.m2826b(jArr, j7, true, true);
                i5 = C1414r.m2826b(jArr, a3 + j7, true, false);
                i6 = i17 + (i5 - i7);
                if (i16 != i7) {
                    i4 = 1;
                } else {
                    i4 = 0;
                }
                i4 |= i15;
            } else {
                i4 = i15;
                i5 = i16;
                i6 = i17;
            }
            i14++;
            i15 = i4;
            i16 = i5;
            i17 = i6;
        }
        t2 = i15 | (i17 != a ? 1 : 0);
        if (t2 != 0) {
            obj7 = new long[i17];
        } else {
            obj7 = obj3;
        }
        if (t2 != 0) {
            obj8 = new int[i17];
        } else {
            obj8 = obj2;
        }
        if (t2 != 0) {
            i6 = 0;
        } else {
            i6 = i9;
        }
        if (t2 != 0) {
            obj = new int[i17];
        } else {
            obj = obj4;
        }
        long[] jArr4 = new long[i17];
        i14 = 0;
        i15 = 0;
        j7 = 0;
        i9 = i6;
        while (i14 < c1488i.f2895i.length) {
            j5 = c1488i.f2896j[i14];
            a3 = c1488i.f2895i[i14];
            if (j5 != -1) {
                j = j5 + C1414r.m2816a(a3, c1488i.f2889c, c1488i.f2890d);
                i6 = C1414r.m2826b(jArr, j5, true, true);
                i3 = C1414r.m2826b(jArr, j, true, false);
                if (t2 != 0) {
                    i7 = i3 - i6;
                    System.arraycopy(obj3, i6, obj7, i15, i7);
                    System.arraycopy(obj2, i6, obj8, i15, i7);
                    System.arraycopy(obj4, i6, obj, i15, i7);
                }
                i17 = i15;
                for (i8 = i6; i8 < i3; i8++) {
                    jArr4[i17] = C1414r.m2816a(jArr[i8] - j5, 1000000, c1488i.f2889c) + C1414r.m2816a(j7, 1000000, c1488i.f2890d);
                    if (t2 != 0 && obj8[i17] > i9) {
                        i9 = obj2[i8];
                    }
                    i17++;
                }
                i6 = i9;
                i9 = i17;
            } else {
                i6 = i9;
                i9 = i15;
            }
            i14++;
            i15 = i9;
            j7 = a3 + j7;
            i9 = i6;
        }
        i2 = 0;
        for (i14 = 0; i14 < obj.length && i2 == 0; i14++) {
            i2 |= (obj[i14] & 1) != 0 ? 1 : 0;
        }
        if (i2 != 0) {
            return new C1491l(obj7, obj8, i9, jArr4, obj);
        }
        throw new ParserException("The edited sample sequence does not contain a sync sample.");
    }

    public static void m3128a(C1468b c1468b, boolean z, C1568j c1568j) {
        if (!z) {
            C1403k c1403k = c1468b.aN;
            c1403k.m2760c(8);
            while (c1403k.m2757b() >= 8) {
                int n = c1403k.m2773n();
                if (c1403k.m2773n() == C1466a.aA) {
                    c1403k.m2760c(c1403k.m2761d() - 8);
                    c1403k.m2758b(n + c1403k.m2761d());
                    C1475b.m3127a(c1403k, c1568j);
                    return;
                }
                c1403k.m2762d(n - 8);
            }
        }
    }

    private static void m3127a(C1403k c1403k, C1568j c1568j) {
        c1403k.m2762d(12);
        C1403k c1403k2 = new C1403k();
        while (c1403k.m2757b() >= 8) {
            int n = c1403k.m2773n() - 8;
            if (c1403k.m2773n() == C1466a.aB) {
                c1403k2.m2755a(c1403k.f2479a, c1403k.m2761d() + n);
                c1403k2.m2760c(c1403k.m2761d());
                C1475b.m3132b(c1403k2, c1568j);
                if (c1568j.m3563a()) {
                    return;
                }
            }
            c1403k.m2762d(n);
        }
    }

    private static void m3132b(C1403k c1403k, C1568j c1568j) {
        while (c1403k.m2757b() > 0) {
            int d = c1403k.m2761d() + c1403k.m2773n();
            if (c1403k.m2773n() == C1466a.aL) {
                String str = null;
                String str2 = null;
                Object obj = null;
                while (c1403k.m2761d() < d) {
                    int n = c1403k.m2773n() - 12;
                    int n2 = c1403k.m2773n();
                    c1403k.m2762d(4);
                    if (n2 == C1466a.aC) {
                        obj = c1403k.m2764e(n);
                    } else if (n2 == C1466a.aD) {
                        str2 = c1403k.m2764e(n);
                    } else if (n2 == C1466a.aE) {
                        c1403k.m2762d(4);
                        str = c1403k.m2764e(n - 4);
                    } else {
                        c1403k.m2762d(n);
                    }
                }
                if (!(str2 == null || str == null || !"com.apple.iTunes".equals(r2))) {
                    c1568j.m3565a(str2, str);
                    return;
                }
            }
            c1403k.m2760c(d);
        }
    }

    private static long m3120a(C1403k c1403k) {
        int i = 8;
        c1403k.m2760c(8);
        if (C1466a.m3097a(c1403k.m2773n()) != 0) {
            i = 16;
        }
        c1403k.m2762d(i);
        return c1403k.m2771l();
    }

    private static C1474f m3131b(C1403k c1403k) {
        long j;
        int i = 8;
        c1403k.m2760c(8);
        int a = C1466a.m3097a(c1403k.m2773n());
        c1403k.m2762d(a == 0 ? 8 : 16);
        int n = c1403k.m2773n();
        c1403k.m2762d(4);
        Object obj = 1;
        int d = c1403k.m2761d();
        if (a == 0) {
            i = 4;
        }
        for (int i2 = 0; i2 < i; i2++) {
            if (c1403k.f2479a[d + i2] != (byte) -1) {
                obj = null;
                break;
            }
        }
        if (obj != null) {
            c1403k.m2762d(i);
            j = -9223372036854775807L;
        } else {
            j = a == 0 ? c1403k.m2771l() : c1403k.m2781v();
            if (j == 0) {
                j = -9223372036854775807L;
            }
        }
        c1403k.m2762d(16);
        int n2 = c1403k.m2773n();
        int n3 = c1403k.m2773n();
        c1403k.m2762d(4);
        int n4 = c1403k.m2773n();
        int n5 = c1403k.m2773n();
        n2 = (n2 == 0 && n3 == 65536 && n4 == (-65536) && n5 == 0) ? 90 : (n2 == 0 && n3 == (-65536) && n4 == 65536 && n5 == 0) ? 270 : (n2 == (-65536) && n3 == 0 && n4 == 0 && n5 == (-65536)) ? 180 : 0;
        return new C1474f(n, j, n2);
    }

    private static int m3133c(C1403k c1403k) {
        c1403k.m2760c(16);
        int n = c1403k.m2773n();
        if (n == f2817b) {
            return 1;
        }
        if (n == f2816a) {
            return 2;
        }
        if (n == f2818c || n == f2819d || n == f2820e || n == f2821f) {
            return 3;
        }
        return -1;
    }

    private static Pair m3135d(C1403k c1403k) {
        int i = 8;
        c1403k.m2760c(8);
        int a = C1466a.m3097a(c1403k.m2773n());
        c1403k.m2762d(a == 0 ? 8 : 16);
        long l = c1403k.m2771l();
        if (a == 0) {
            i = 4;
        }
        c1403k.m2762d(i);
        int h = c1403k.m2767h();
        return Pair.create(Long.valueOf(l), "" + ((char) (((h >> 10) & 31) + 96)) + ((char) (((h >> 5) & 31) + 96)) + ((char) ((h & 31) + 96)));
    }

    private static C1471c m3122a(C1403k c1403k, int i, int i2, String str, DrmInitData drmInitData, boolean z) {
        c1403k.m2760c(12);
        int n = c1403k.m2773n();
        C1471c c1471c = new C1471c(n);
        for (int i3 = 0; i3 < n; i3++) {
            int d = c1403k.m2761d();
            int n2 = c1403k.m2773n();
            C1392a.m2710a(n2 > 0, "childAtomSize should be positive");
            int n3 = c1403k.m2773n();
            if (n3 == C1466a.f2767b || n3 == C1466a.f2768c || n3 == C1466a.f2764Y || n3 == C1466a.ak || n3 == C1466a.f2769d || n3 == C1466a.f2770e || n3 == C1466a.f2771f || n3 == C1466a.aI || n3 == C1466a.aJ) {
                C1475b.m3125a(c1403k, n3, d, n2, i, i2, drmInitData, c1471c, i3);
            } else if (n3 == C1466a.f2774i || n3 == C1466a.f2765Z || n3 == C1466a.f2778m || n3 == C1466a.f2780o || n3 == C1466a.f2782q || n3 == C1466a.f2785t || n3 == C1466a.f2783r || n3 == C1466a.f2784s || n3 == C1466a.ax || n3 == C1466a.ay || n3 == C1466a.f2776k || n3 == C1466a.f2777l) {
                C1475b.m3126a(c1403k, n3, d, n2, i, str, z, drmInitData, c1471c, i3);
            } else if (n3 == C1466a.ai) {
                c1471c.f2802b = Format.m2408a(Integer.toString(i), "application/ttml+xml", null, -1, 0, str, drmInitData);
            } else if (n3 == C1466a.at) {
                c1471c.f2802b = Format.m2408a(Integer.toString(i), "application/x-quicktime-tx3g", null, -1, 0, str, drmInitData);
            } else if (n3 == C1466a.au) {
                c1471c.f2802b = Format.m2408a(Integer.toString(i), "application/x-mp4vtt", null, -1, 0, str, drmInitData);
            } else if (n3 == C1466a.av) {
                c1471c.f2802b = Format.m2409a(Integer.toString(i), "application/ttml+xml", null, -1, 0, str, drmInitData, 0);
            } else if (n3 == C1466a.aw) {
                c1471c.f2802b = Format.m2408a(Integer.toString(i), "application/cea-608", null, -1, 0, str, drmInitData);
                c1471c.f2804d = 1;
            }
            c1403k.m2760c(d + n2);
        }
        return c1471c;
    }

    private static void m3125a(C1403k c1403k, int i, int i2, int i3, int i4, int i5, DrmInitData drmInitData, C1471c c1471c, int i6) {
        c1403k.m2760c(i2 + 8);
        c1403k.m2762d(24);
        int h = c1403k.m2767h();
        int h2 = c1403k.m2767h();
        Object obj = null;
        float f = DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;
        c1403k.m2762d(50);
        int d = c1403k.m2761d();
        if (i == C1466a.f2764Y) {
            i = C1475b.m3119a(c1403k, i2, i3, c1471c, i6);
            c1403k.m2760c(d);
        }
        List list = null;
        String str = null;
        byte[] bArr = null;
        int i7 = -1;
        int i8 = d;
        while (i8 - i2 < i3) {
            c1403k.m2760c(i8);
            int d2 = c1403k.m2761d();
            int n = c1403k.m2773n();
            if (n != 0 || c1403k.m2761d() - i2 != i3) {
                Object obj2;
                C1392a.m2710a(n > 0, "childAtomSize should be positive");
                d = c1403k.m2773n();
                if (d == C1466a.f2746G) {
                    C1392a.m2711b(str == null);
                    str = "video/avc";
                    c1403k.m2760c(d2 + 8);
                    C1419a a = C1419a.m2854a(c1403k);
                    list = a.f2522a;
                    c1471c.f2803c = a.f2523b;
                    if (obj == null) {
                        f = a.f2526e;
                    }
                    obj2 = obj;
                } else if (d == C1466a.f2747H) {
                    C1392a.m2711b(str == null);
                    str = "video/hevc";
                    c1403k.m2760c(d2 + 8);
                    C1420b a2 = C1420b.m2856a(c1403k);
                    list = a2.f2527a;
                    c1471c.f2803c = a2.f2528b;
                    obj2 = obj;
                } else if (d == C1466a.aK) {
                    C1392a.m2711b(str == null);
                    str = i == C1466a.aI ? "video/x-vnd.on2.vp8" : "video/x-vnd.on2.vp9";
                    obj2 = obj;
                } else if (d == C1466a.f2772g) {
                    C1392a.m2711b(str == null);
                    str = "video/3gpp";
                    obj2 = obj;
                } else if (d == C1466a.f2748I) {
                    C1392a.m2711b(str == null);
                    Pair b = C1475b.m3129b(c1403k, d2);
                    String str2 = (String) b.first;
                    list = Collections.singletonList(b.second);
                    str = str2;
                    obj2 = obj;
                } else if (d == C1466a.ah) {
                    f = C1475b.m3117a(c1403k, d2);
                    obj2 = 1;
                } else if (d == C1466a.aG) {
                    bArr = C1475b.m3136d(c1403k, d2, n);
                    obj2 = obj;
                } else {
                    if (d == C1466a.aF) {
                        d = c1403k.m2766g();
                        c1403k.m2762d(3);
                        if (d == 0) {
                            switch (c1403k.m2766g()) {
                                case 0:
                                    i7 = 0;
                                    obj2 = obj;
                                    continue;
                                case 1:
                                    i7 = 1;
                                    obj2 = obj;
                                    continue;
                                case 2:
                                    i7 = 2;
                                    obj2 = obj;
                                    continue;
                            }
                        }
                    }
                    obj2 = obj;
                }
                i8 += n;
                obj = obj2;
            } else if (str == null) {
                c1471c.f2802b = Format.m2404a(Integer.toString(i4), str, null, -1, -1, h, h2, -1.0f, list, i5, f, bArr, i7, drmInitData);
            }
        }
        if (str == null) {
            c1471c.f2802b = Format.m2404a(Integer.toString(i4), str, null, -1, -1, h, h2, -1.0f, list, i5, f, bArr, i7, drmInitData);
        }
    }

    private static Pair m3121a(C1467a c1467a) {
        if (c1467a != null) {
            C1468b d = c1467a.m3102d(C1466a.f2755P);
            if (d != null) {
                C1403k c1403k = d.aN;
                c1403k.m2760c(8);
                int a = C1466a.m3097a(c1403k.m2773n());
                int t = c1403k.m2779t();
                Object obj = new long[t];
                Object obj2 = new long[t];
                for (int i = 0; i < t; i++) {
                    obj[i] = a == 1 ? c1403k.m2781v() : c1403k.m2771l();
                    obj2[i] = a == 1 ? c1403k.m2775p() : (long) c1403k.m2773n();
                    if (c1403k.m2769j() != (short) 1) {
                        throw new IllegalArgumentException("Unsupported media rate.");
                    }
                    c1403k.m2762d(2);
                }
                return Pair.create(obj, obj2);
            }
        }
        return Pair.create(null, null);
    }

    private static float m3117a(C1403k c1403k, int i) {
        c1403k.m2760c(i + 8);
        return ((float) c1403k.m2779t()) / ((float) c1403k.m2779t());
    }

    private static void m3126a(C1403k c1403k, int i, int i2, int i3, int i4, String str, boolean z, DrmInitData drmInitData, C1471c c1471c, int i5) {
        int h;
        int i6;
        int h2;
        c1403k.m2760c(i2 + 8);
        if (z) {
            c1403k.m2762d(8);
            h = c1403k.m2767h();
            c1403k.m2762d(6);
            i6 = h;
        } else {
            c1403k.m2762d(16);
            i6 = 0;
        }
        if (i6 == 0 || i6 == 1) {
            h2 = c1403k.m2767h();
            c1403k.m2762d(6);
            h = c1403k.m2777r();
            if (i6 == 1) {
                c1403k.m2762d(16);
            }
        } else if (i6 == 2) {
            c1403k.m2762d(16);
            h = (int) Math.round(c1403k.m2782w());
            h2 = c1403k.m2779t();
            c1403k.m2762d(20);
        } else {
            return;
        }
        int d = c1403k.m2761d();
        if (i == C1466a.f2765Z) {
            i = C1475b.m3119a(c1403k, i2, i3, c1471c, i5);
            c1403k.m2760c(d);
        }
        String str2 = null;
        if (i == C1466a.f2778m) {
            str2 = "audio/ac3";
        } else if (i == C1466a.f2780o) {
            str2 = "audio/eac3";
        } else if (i == C1466a.f2782q) {
            str2 = "audio/vnd.dts";
        } else if (i == C1466a.f2783r || i == C1466a.f2784s) {
            str2 = "audio/vnd.dts.hd";
        } else if (i == C1466a.f2785t) {
            str2 = "audio/vnd.dts.hd;profile=lbr";
        } else if (i == C1466a.ax) {
            str2 = "audio/3gpp";
        } else if (i == C1466a.ay) {
            str2 = "audio/amr-wb";
        } else if (i == C1466a.f2776k || i == C1466a.f2777l) {
            str2 = "audio/raw";
        }
        Object obj = null;
        int i7 = h;
        int i8 = h2;
        String str3 = str2;
        while (d - i2 < i3) {
            c1403k.m2760c(d);
            int n = c1403k.m2773n();
            C1392a.m2710a(n > 0, "childAtomSize should be positive");
            h = c1403k.m2773n();
            if (h == C1466a.f2748I || (z && h == C1466a.f2775j)) {
                Object obj2;
                if (h == C1466a.f2748I) {
                    h = d;
                } else {
                    h = C1475b.m3118a(c1403k, d, n);
                }
                if (h != -1) {
                    Pair b = C1475b.m3129b(c1403k, h);
                    str3 = (String) b.first;
                    obj2 = (byte[]) b.second;
                    if ("audio/mp4a-latm".equals(str3)) {
                        Pair a = C1393b.m2713a(obj2);
                        i7 = ((Integer) a.first).intValue();
                        i8 = ((Integer) a.second).intValue();
                    }
                } else {
                    obj2 = obj;
                }
                obj = obj2;
            } else if (h == C1466a.f2779n) {
                c1403k.m2760c(d + 8);
                c1471c.f2802b = C1360a.m2570a(c1403k, Integer.toString(i4), str, drmInitData);
            } else if (h == C1466a.f2781p) {
                c1403k.m2760c(d + 8);
                c1471c.f2802b = C1360a.m2573b(c1403k, Integer.toString(i4), str, drmInitData);
            } else if (h == C1466a.f2786u) {
                c1471c.f2802b = Format.m2407a(Integer.toString(i4), str3, null, -1, -1, i8, i7, null, drmInitData, 0, str);
            }
            d += n;
        }
        if (c1471c.f2802b == null && str3 != null) {
            List list;
            int i9 = "audio/raw".equals(str3) ? 2 : -1;
            String num = Integer.toString(i4);
            if (obj == null) {
                list = null;
            } else {
                list = Collections.singletonList(obj);
            }
            c1471c.f2802b = Format.m2406a(num, str3, null, -1, -1, i8, i7, i9, list, drmInitData, 0, str);
        }
    }

    private static int m3118a(C1403k c1403k, int i, int i2) {
        int d = c1403k.m2761d();
        while (d - i < i2) {
            c1403k.m2760c(d);
            int n = c1403k.m2773n();
            C1392a.m2710a(n > 0, "childAtomSize should be positive");
            if (c1403k.m2773n() == C1466a.f2748I) {
                return d;
            }
            d += n;
        }
        return -1;
    }

    private static Pair m3129b(C1403k c1403k, int i) {
        Object obj = null;
        c1403k.m2760c((i + 8) + 4);
        c1403k.m2762d(1);
        C1475b.m3137e(c1403k);
        c1403k.m2762d(2);
        int g = c1403k.m2766g();
        if ((g & 128) != 0) {
            c1403k.m2762d(2);
        }
        if ((g & 64) != 0) {
            c1403k.m2762d(c1403k.m2767h());
        }
        if ((g & 32) != 0) {
            c1403k.m2762d(2);
        }
        c1403k.m2762d(1);
        C1475b.m3137e(c1403k);
        switch (c1403k.m2766g()) {
            case 32:
                obj = "video/mp4v-es";
                break;
            case 33:
                obj = "video/avc";
                break;
            case 35:
                obj = "video/hevc";
                break;
            case 64:
            case 102:
            case 103:
            case 104:
                obj = "audio/mp4a-latm";
                break;
            case 107:
                return Pair.create("audio/mpeg", null);
            case 165:
                obj = "audio/ac3";
                break;
            case 166:
                obj = "audio/eac3";
                break;
            case 169:
            case 172:
                return Pair.create("audio/vnd.dts", null);
            case 170:
            case 171:
                return Pair.create("audio/vnd.dts.hd", null);
        }
        c1403k.m2762d(12);
        c1403k.m2762d(1);
        g = C1475b.m3137e(c1403k);
        Object obj2 = new byte[g];
        c1403k.m2756a(obj2, 0, g);
        return Pair.create(obj, obj2);
    }

    private static int m3119a(C1403k c1403k, int i, int i2, C1471c c1471c, int i3) {
        int d = c1403k.m2761d();
        while (d - i < i2) {
            c1403k.m2760c(d);
            int n = c1403k.m2773n();
            C1392a.m2710a(n > 0, "childAtomSize should be positive");
            if (c1403k.m2773n() == C1466a.f2760U) {
                Pair b = C1475b.m3130b(c1403k, d, n);
                if (b != null) {
                    c1471c.f2801a[i3] = (C1489j) b.second;
                    return ((Integer) b.first).intValue();
                }
            }
            d += n;
        }
        return 0;
    }

    private static Pair m3130b(C1403k c1403k, int i, int i2) {
        boolean z = true;
        Object obj = null;
        boolean z2 = false;
        int i3 = i + 8;
        Object obj2 = null;
        while (i3 - i < i2) {
            c1403k.m2760c(i3);
            int n = c1403k.m2773n();
            int n2 = c1403k.m2773n();
            if (n2 == C1466a.aa) {
                obj2 = Integer.valueOf(c1403k.m2773n());
            } else if (n2 == C1466a.f2761V) {
                c1403k.m2762d(4);
                z2 = c1403k.m2773n() == f2822g;
            } else if (n2 == C1466a.f2762W) {
                obj = C1475b.m3134c(c1403k, i3, n);
            }
            i3 += n;
        }
        if (!z2) {
            return null;
        }
        if (obj2 != null) {
            z2 = true;
        } else {
            z2 = false;
        }
        C1392a.m2710a(z2, "frma atom is mandatory");
        if (obj == null) {
            z = false;
        }
        C1392a.m2710a(z, "schi->tenc atom is mandatory");
        return Pair.create(obj2, obj);
    }

    private static C1489j m3134c(C1403k c1403k, int i, int i2) {
        boolean z = true;
        int i3 = i + 8;
        while (i3 - i < i2) {
            c1403k.m2760c(i3);
            int n = c1403k.m2773n();
            if (c1403k.m2773n() == C1466a.f2763X) {
                c1403k.m2762d(6);
                if (c1403k.m2766g() != 1) {
                    z = false;
                }
                i3 = c1403k.m2766g();
                byte[] bArr = new byte[16];
                c1403k.m2756a(bArr, 0, bArr.length);
                return new C1489j(z, i3, bArr);
            }
            i3 += n;
        }
        return null;
    }

    private static byte[] m3136d(C1403k c1403k, int i, int i2) {
        int i3 = i + 8;
        while (i3 - i < i2) {
            c1403k.m2760c(i3);
            int n = c1403k.m2773n();
            if (c1403k.m2773n() == C1466a.aH) {
                return Arrays.copyOfRange(c1403k.f2479a, i3, n + i3);
            }
            i3 += n;
        }
        return null;
    }

    private static int m3137e(C1403k c1403k) {
        int g = c1403k.m2766g();
        int i = g & 127;
        while ((g & 128) == 128) {
            g = c1403k.m2766g();
            i = (i << 7) | (g & 127);
        }
        return i;
    }
}
