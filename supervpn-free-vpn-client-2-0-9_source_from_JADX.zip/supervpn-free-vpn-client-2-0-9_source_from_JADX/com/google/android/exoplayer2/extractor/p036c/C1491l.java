package com.google.android.exoplayer2.extractor.p036c;

import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1414r;

final class C1491l {
    public final int f2920a;
    public final long[] f2921b;
    public final int[] f2922c;
    public final int f2923d;
    public final long[] f2924e;
    public final int[] f2925f;

    public C1491l(long[] jArr, int[] iArr, int i, long[] jArr2, int[] iArr2) {
        boolean z;
        boolean z2 = true;
        C1392a.m2709a(iArr.length == jArr2.length);
        if (jArr.length == jArr2.length) {
            z = true;
        } else {
            z = false;
        }
        C1392a.m2709a(z);
        if (iArr2.length != jArr2.length) {
            z2 = false;
        }
        C1392a.m2709a(z2);
        this.f2921b = jArr;
        this.f2922c = iArr;
        this.f2923d = i;
        this.f2924e = jArr2;
        this.f2925f = iArr2;
        this.f2920a = jArr.length;
    }

    public int m3209a(long j) {
        for (int a = C1414r.m2815a(this.f2924e, j, true, false); a >= 0; a--) {
            if ((this.f2925f[a] & 1) != 0) {
                return a;
            }
        }
        return -1;
    }

    public int m3210b(long j) {
        for (int b = C1414r.m2826b(this.f2924e, j, true, false); b < this.f2924e.length; b++) {
            if ((this.f2925f[b] & 1) != 0) {
                return b;
            }
        }
        return -1;
    }
}
