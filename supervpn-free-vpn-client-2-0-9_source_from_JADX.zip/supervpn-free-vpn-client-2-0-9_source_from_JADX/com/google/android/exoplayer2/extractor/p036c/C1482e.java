package com.google.android.exoplayer2.extractor.p036c;

import android.util.Log;
import android.util.Pair;
import android.util.SparseArray;
import com.google.android.exoplayer2.ParserException;
import com.google.android.exoplayer2.drm.DrmInitData;
import com.google.android.exoplayer2.drm.DrmInitData.SchemeData;
import com.google.android.exoplayer2.extractor.C1447i;
import com.google.android.exoplayer2.extractor.C1451f;
import com.google.android.exoplayer2.extractor.C1455m.C1571a;
import com.google.android.exoplayer2.extractor.C1456a;
import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.extractor.C1570l;
import com.google.android.exoplayer2.extractor.C1572n;
import com.google.android.exoplayer2.extractor.p036c.C1466a.C1467a;
import com.google.android.exoplayer2.extractor.p036c.C1466a.C1468b;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1401i;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1414r;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Stack;
import java.util.UUID;

public final class C1482e implements C1451f {
    public static final C1447i f2839a = new C14801();
    private static final int f2840b = C1414r.m2830e("seig");
    private static final byte[] f2841c = new byte[]{(byte) -94, (byte) 57, (byte) 79, (byte) 82, (byte) 90, (byte) -101, (byte) 79, (byte) 20, (byte) -94, (byte) 68, (byte) 108, (byte) 66, (byte) 124, (byte) 100, (byte) -115, (byte) -12};
    private final int f2842d;
    private final C1488i f2843e;
    private final SparseArray f2844f;
    private final C1403k f2845g;
    private final C1403k f2846h;
    private final C1403k f2847i;
    private final C1572n f2848j;
    private final C1403k f2849k;
    private final byte[] f2850l;
    private final Stack f2851m;
    private int f2852n;
    private int f2853o;
    private long f2854p;
    private int f2855q;
    private C1403k f2856r;
    private long f2857s;
    private long f2858t;
    private C1481a f2859u;
    private int f2860v;
    private int f2861w;
    private int f2862x;
    private C1567h f2863y;
    private boolean f2864z;

    static class C14801 implements C1447i {
        C14801() {
        }

        public C1451f[] mo2159a() {
            return new C1451f[]{new C1482e()};
        }
    }

    private static final class C1481a {
        public final C1490k f2832a = new C1490k();
        public final C1521o f2833b;
        public C1488i f2834c;
        public C1476c f2835d;
        public int f2836e;
        public int f2837f;
        public int f2838g;

        public C1481a(C1521o c1521o) {
            this.f2833b = c1521o;
        }

        public void m3142a(C1488i c1488i, C1476c c1476c) {
            this.f2834c = (C1488i) C1392a.m2707a((Object) c1488i);
            this.f2835d = (C1476c) C1392a.m2707a((Object) c1476c);
            this.f2833b.mo2202a(c1488i.f2892f);
            m3140a();
        }

        public void m3140a() {
            this.f2832a.m3203a();
            this.f2836e = 0;
            this.f2838g = 0;
            this.f2837f = 0;
        }

        public void m3141a(DrmInitData drmInitData) {
            this.f2833b.mo2202a(this.f2834c.f2892f.m2419a(drmInitData));
        }
    }

    public C1482e() {
        this(0, null);
    }

    public C1482e(int i, C1572n c1572n) {
        this(i, null, c1572n);
    }

    public C1482e(int i, C1488i c1488i, C1572n c1572n) {
        this.f2843e = c1488i;
        this.f2842d = (c1488i != null ? 4 : 0) | i;
        this.f2848j = c1572n;
        this.f2849k = new C1403k(16);
        this.f2845g = new C1403k(C1401i.f2471a);
        this.f2846h = new C1403k(4);
        this.f2847i = new C1403k(1);
        this.f2850l = new byte[16];
        this.f2851m = new Stack();
        this.f2844f = new SparseArray();
        this.f2858t = -9223372036854775807L;
        m3150a();
    }

    public boolean mo2171a(C1464g c1464g) {
        return C1487h.m3200a(c1464g);
    }

    public void mo2170a(C1567h c1567h) {
        this.f2863y = c1567h;
        if (this.f2843e != null) {
            C1481a c1481a = new C1481a(c1567h.mo2273a(0));
            c1481a.m3142a(this.f2843e, new C1476c(0, 0, 0, 0));
            this.f2844f.put(0, c1481a);
            this.f2863y.mo2274a();
        }
    }

    public void mo2169a(long j) {
        int size = this.f2844f.size();
        for (int i = 0; i < size; i++) {
            ((C1481a) this.f2844f.valueAt(i)).m3140a();
        }
        this.f2851m.clear();
        m3150a();
    }

    public void mo2172c() {
    }

    public int mo2168a(C1464g c1464g, C1570l c1570l) {
        while (true) {
            switch (this.f2852n) {
                case 0:
                    if (m3167b(c1464g)) {
                        break;
                    }
                    return -1;
                case 1:
                    m3170c(c1464g);
                    break;
                case 2:
                    m3171d(c1464g);
                    break;
                default:
                    if (!m3172e(c1464g)) {
                        break;
                    }
                    return 0;
            }
        }
    }

    private void m3150a() {
        this.f2852n = 0;
        this.f2855q = 0;
    }

    private boolean m3167b(C1464g c1464g) {
        if (this.f2855q == 0) {
            if (!c1464g.mo2180a(this.f2849k.f2479a, 0, 8, true)) {
                return false;
            }
            this.f2855q = 8;
            this.f2849k.m2760c(0);
            this.f2854p = this.f2849k.m2771l();
            this.f2853o = this.f2849k.m2773n();
        }
        if (this.f2854p == 1) {
            c1464g.mo2183b(this.f2849k.f2479a, 8, 8);
            this.f2855q += 8;
            this.f2854p = this.f2849k.m2781v();
        }
        long c = c1464g.mo2185c() - ((long) this.f2855q);
        if (this.f2853o == C1466a.f2749J) {
            int size = this.f2844f.size();
            for (int i = 0; i < size; i++) {
                C1490k c1490k = ((C1481a) this.f2844f.valueAt(i)).f2832a;
                c1490k.f2902b = c;
                c1490k.f2904d = c;
                c1490k.f2903c = c;
            }
        }
        if (this.f2853o == C1466a.f2773h) {
            this.f2859u = null;
            this.f2857s = this.f2854p + c;
            if (!this.f2864z) {
                this.f2863y.mo2276a(new C1571a(this.f2858t));
                this.f2864z = true;
            }
            this.f2852n = 2;
            return true;
        }
        if (C1482e.m3166b(this.f2853o)) {
            long c2 = (c1464g.mo2185c() + this.f2854p) - 8;
            this.f2851m.add(new C1467a(this.f2853o, c2));
            if (this.f2854p == ((long) this.f2855q)) {
                m3162b(c2);
            } else {
                m3150a();
            }
        } else if (C1482e.m3160a(this.f2853o)) {
            if (this.f2855q != 8) {
                throw new ParserException("Leaf atom defines extended atom size (unsupported).");
            } else if (this.f2854p > 2147483647L) {
                throw new ParserException("Leaf atom with length > 2147483647 (unsupported).");
            } else {
                this.f2856r = new C1403k((int) this.f2854p);
                System.arraycopy(this.f2849k.f2479a, 0, this.f2856r.f2479a, 0, 8);
                this.f2852n = 1;
            }
        } else if (this.f2854p > 2147483647L) {
            throw new ParserException("Skipping atom with length > 2147483647 (unsupported).");
        } else {
            this.f2856r = null;
            this.f2852n = 1;
        }
        return true;
    }

    private void m3170c(C1464g c1464g) {
        int i = ((int) this.f2854p) - this.f2855q;
        if (this.f2856r != null) {
            c1464g.mo2183b(this.f2856r.f2479a, 8, i);
            m3158a(new C1468b(this.f2853o, this.f2856r), c1464g.mo2185c());
        } else {
            c1464g.mo2182b(i);
        }
        m3162b(c1464g.mo2185c());
    }

    private void m3162b(long j) {
        while (!this.f2851m.isEmpty() && ((C1467a) this.f2851m.peek()).aN == j) {
            m3155a((C1467a) this.f2851m.pop());
        }
        m3150a();
    }

    private void m3158a(C1468b c1468b, long j) {
        if (!this.f2851m.isEmpty()) {
            ((C1467a) this.f2851m.peek()).m3101a(c1468b);
        } else if (c1468b.aM == C1466a.f2791z) {
            this.f2863y.mo2276a(C1482e.m3147a(c1468b.aN, j));
            this.f2864z = true;
        }
    }

    private void m3155a(C1467a c1467a) {
        if (c1467a.aM == C1466a.f2740A) {
            m3164b(c1467a);
        } else if (c1467a.aM == C1466a.f2749J) {
            m3169c(c1467a);
        } else if (!this.f2851m.isEmpty()) {
            ((C1467a) this.f2851m.peek()).m3100a(c1467a);
        }
    }

    private void m3164b(C1467a c1467a) {
        int i;
        boolean z = true;
        int i2 = 0;
        C1392a.m2712b(this.f2843e == null, "Unexpected moov box.");
        DrmInitData a = C1482e.m3146a(c1467a.aO);
        C1467a e = c1467a.m3103e(C1466a.f2751L);
        SparseArray sparseArray = new SparseArray();
        long j = -9223372036854775807L;
        int size = e.aO.size();
        for (i = 0; i < size; i++) {
            C1468b c1468b = (C1468b) e.aO.get(i);
            if (c1468b.aM == C1466a.f2789x) {
                Pair a2 = C1482e.m3145a(c1468b.aN);
                sparseArray.put(((Integer) a2.first).intValue(), a2.second);
            } else if (c1468b.aM == C1466a.f2752M) {
                j = C1482e.m3161b(c1468b.aN);
            }
        }
        SparseArray sparseArray2 = new SparseArray();
        int size2 = c1467a.aP.size();
        for (int i3 = 0; i3 < size2; i3++) {
            C1488i a3;
            C1467a c1467a2 = (C1467a) c1467a.aP.get(i3);
            if (c1467a2.aM == C1466a.f2742C) {
                a3 = C1475b.m3123a(c1467a2, c1467a.m3102d(C1466a.f2741B), j, a, false);
                if (a3 != null) {
                    sparseArray2.put(a3.f2887a, a3);
                }
            }
        }
        int size3 = sparseArray2.size();
        if (this.f2844f.size() == 0) {
            for (i = 0; i < size3; i++) {
                a3 = (C1488i) sparseArray2.valueAt(i);
                this.f2844f.put(a3.f2887a, new C1481a(this.f2863y.mo2273a(i)));
                this.f2858t = Math.max(this.f2858t, a3.f2891e);
            }
            this.f2863y.mo2274a();
        } else {
            if (this.f2844f.size() != size3) {
                z = false;
            }
            C1392a.m2711b(z);
        }
        while (i2 < size3) {
            a3 = (C1488i) sparseArray2.valueAt(i2);
            ((C1481a) this.f2844f.get(a3.f2887a)).m3142a(a3, (C1476c) sparseArray.get(a3.f2887a));
            i2++;
        }
    }

    private void m3169c(C1467a c1467a) {
        C1482e.m3156a(c1467a, this.f2844f, this.f2842d, this.f2850l);
        DrmInitData a = C1482e.m3146a(c1467a.aO);
        if (a != null) {
            int size = this.f2844f.size();
            for (int i = 0; i < size; i++) {
                ((C1481a) this.f2844f.valueAt(i)).m3141a(a);
            }
        }
    }

    private static Pair m3145a(C1403k c1403k) {
        c1403k.m2760c(12);
        return Pair.create(Integer.valueOf(c1403k.m2773n()), new C1476c(c1403k.m2779t() - 1, c1403k.m2779t(), c1403k.m2779t(), c1403k.m2773n()));
    }

    private static long m3161b(C1403k c1403k) {
        c1403k.m2760c(8);
        return C1466a.m3097a(c1403k.m2773n()) == 0 ? c1403k.m2771l() : c1403k.m2781v();
    }

    private static void m3156a(C1467a c1467a, SparseArray sparseArray, int i, byte[] bArr) {
        int size = c1467a.aP.size();
        for (int i2 = 0; i2 < size; i2++) {
            C1467a c1467a2 = (C1467a) c1467a.aP.get(i2);
            if (c1467a2.aM == C1466a.f2750K) {
                C1482e.m3165b(c1467a2, sparseArray, i, bArr);
            }
        }
    }

    private static void m3165b(C1467a c1467a, SparseArray sparseArray, int i, byte[] bArr) {
        C1481a a = C1482e.m3149a(c1467a.m3102d(C1466a.f2788w).aN, sparseArray, i);
        if (a != null) {
            C1490k c1490k = a.f2832a;
            long j = c1490k.f2919s;
            a.m3140a();
            if (c1467a.m3102d(C1466a.f2787v) != null && (i & 2) == 0) {
                j = C1482e.m3168c(c1467a.m3102d(C1466a.f2787v).aN);
            }
            C1482e.m3157a(c1467a, a, j, i);
            C1468b d = c1467a.m3102d(C1466a.ab);
            if (d != null) {
                C1482e.m3159a(a.f2834c.f2894h[c1490k.f2901a.f2823a], d.aN, c1490k);
            }
            d = c1467a.m3102d(C1466a.ac);
            if (d != null) {
                C1482e.m3153a(d.aN, c1490k);
            }
            d = c1467a.m3102d(C1466a.ag);
            if (d != null) {
                C1482e.m3163b(d.aN, c1490k);
            }
            d = c1467a.m3102d(C1466a.ad);
            C1468b d2 = c1467a.m3102d(C1466a.ae);
            if (!(d == null || d2 == null)) {
                C1482e.m3152a(d.aN, d2.aN, c1490k);
            }
            int size = c1467a.aO.size();
            for (int i2 = 0; i2 < size; i2++) {
                d = (C1468b) c1467a.aO.get(i2);
                if (d.aM == C1466a.af) {
                    C1482e.m3154a(d.aN, c1490k, bArr);
                }
            }
        }
    }

    private static void m3157a(C1467a c1467a, C1481a c1481a, long j, int i) {
        List list = c1467a.aO;
        int size = list.size();
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        while (i2 < size) {
            int t;
            C1468b c1468b = (C1468b) list.get(i2);
            if (c1468b.aM == C1466a.f2790y) {
                C1403k c1403k = c1468b.aN;
                c1403k.m2760c(12);
                t = c1403k.m2779t();
                if (t > 0) {
                    t += i3;
                    i3 = i4 + 1;
                    i2++;
                    i4 = i3;
                    i3 = t;
                }
            }
            t = i3;
            i3 = i4;
            i2++;
            i4 = i3;
            i3 = t;
        }
        c1481a.f2838g = 0;
        c1481a.f2837f = 0;
        c1481a.f2836e = 0;
        c1481a.f2832a.m3205a(i4, i3);
        int i5 = 0;
        i3 = 0;
        for (int i6 = 0; i6 < size; i6++) {
            c1468b = (C1468b) list.get(i6);
            if (c1468b.aM == C1466a.f2790y) {
                int i7 = i3 + 1;
                i5 = C1482e.m3144a(c1481a, i3, j, i, c1468b.aN, i5);
                i3 = i7;
            }
        }
    }

    private static void m3159a(C1489j c1489j, C1403k c1403k, C1490k c1490k) {
        boolean z = true;
        int i = c1489j.f2899b;
        c1403k.m2760c(8);
        if ((C1466a.m3098b(c1403k.m2773n()) & 1) == 1) {
            c1403k.m2762d(8);
        }
        int g = c1403k.m2766g();
        int t = c1403k.m2779t();
        if (t != c1490k.f2906f) {
            throw new ParserException("Length mismatch: " + t + ", " + c1490k.f2906f);
        }
        if (g == 0) {
            boolean[] zArr = c1490k.f2914n;
            int i2 = 0;
            g = 0;
            while (i2 < t) {
                boolean z2;
                int g2 = c1403k.m2766g();
                int i3 = g + g2;
                if (g2 > i) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                zArr[i2] = z2;
                i2++;
                g = i3;
            }
        } else {
            if (g <= i) {
                z = false;
            }
            g = (g * t) + 0;
            Arrays.fill(c1490k.f2914n, 0, t, z);
        }
        c1490k.m3204a(g);
    }

    private static void m3153a(C1403k c1403k, C1490k c1490k) {
        c1403k.m2760c(8);
        int n = c1403k.m2773n();
        if ((C1466a.m3098b(n) & 1) == 1) {
            c1403k.m2762d(8);
        }
        int t = c1403k.m2779t();
        if (t != 1) {
            throw new ParserException("Unexpected saio entry count: " + t);
        }
        n = C1466a.m3097a(n);
        c1490k.f2904d = (n == 0 ? c1403k.m2771l() : c1403k.m2781v()) + c1490k.f2904d;
    }

    private static C1481a m3149a(C1403k c1403k, SparseArray sparseArray, int i) {
        c1403k.m2760c(8);
        int b = C1466a.m3098b(c1403k.m2773n());
        int n = c1403k.m2773n();
        if ((i & 4) != 0) {
            n = 0;
        }
        C1481a c1481a = (C1481a) sparseArray.get(n);
        if (c1481a == null) {
            return null;
        }
        if ((b & 1) != 0) {
            long v = c1403k.m2781v();
            c1481a.f2832a.f2903c = v;
            c1481a.f2832a.f2904d = v;
        }
        C1476c c1476c = c1481a.f2835d;
        c1481a.f2832a.f2901a = new C1476c((b & 2) != 0 ? c1403k.m2779t() - 1 : c1476c.f2823a, (b & 8) != 0 ? c1403k.m2779t() : c1476c.f2824b, (b & 16) != 0 ? c1403k.m2779t() : c1476c.f2825c, (b & 32) != 0 ? c1403k.m2779t() : c1476c.f2826d);
        return c1481a;
    }

    private static long m3168c(C1403k c1403k) {
        c1403k.m2760c(8);
        return C1466a.m3097a(c1403k.m2773n()) == 1 ? c1403k.m2781v() : c1403k.m2771l();
    }

    private static int m3144a(C1481a c1481a, int i, long j, int i2, C1403k c1403k, int i3) {
        Object obj;
        long a;
        c1403k.m2760c(8);
        int b = C1466a.m3098b(c1403k.m2773n());
        C1488i c1488i = c1481a.f2834c;
        C1490k c1490k = c1481a.f2832a;
        C1476c c1476c = c1490k.f2901a;
        c1490k.f2908h[i] = c1403k.m2779t();
        c1490k.f2907g[i] = c1490k.f2903c;
        if ((b & 1) != 0) {
            long[] jArr = c1490k.f2907g;
            jArr[i] = jArr[i] + ((long) c1403k.m2773n());
        }
        Object obj2 = (b & 4) != 0 ? 1 : null;
        int i4 = c1476c.f2826d;
        if (obj2 != null) {
            i4 = c1403k.m2779t();
        }
        Object obj3 = (b & 256) != 0 ? 1 : null;
        Object obj4 = (b & 512) != 0 ? 1 : null;
        Object obj5 = (b & 1024) != 0 ? 1 : null;
        if ((b & 2048) != 0) {
            obj = 1;
        } else {
            obj = null;
        }
        if (c1488i.f2895i != null && c1488i.f2895i.length == 1 && c1488i.f2895i[0] == 0) {
            a = C1414r.m2816a(c1488i.f2896j[0], 1000, c1488i.f2889c);
        } else {
            a = 0;
        }
        int[] iArr = c1490k.f2909i;
        int[] iArr2 = c1490k.f2910j;
        long[] jArr2 = c1490k.f2911k;
        boolean[] zArr = c1490k.f2912l;
        Object obj6 = (c1488i.f2888b != 2 || (i2 & 1) == 0) ? null : 1;
        int i5 = i3 + c1490k.f2908h[i];
        long j2 = c1488i.f2889c;
        if (i > 0) {
            j = c1490k.f2919s;
        }
        long j3 = j;
        while (i3 < i5) {
            int t = obj3 != null ? c1403k.m2779t() : c1476c.f2824b;
            int t2 = obj4 != null ? c1403k.m2779t() : c1476c.f2825c;
            int n = (i3 != 0 || obj2 == null) ? obj5 != null ? c1403k.m2773n() : c1476c.f2826d : i4;
            if (obj != null) {
                iArr2[i3] = (int) (((long) (c1403k.m2773n() * 1000)) / j2);
            } else {
                iArr2[i3] = 0;
            }
            jArr2[i3] = C1414r.m2816a(j3, 1000, j2) - a;
            iArr[i3] = t2;
            boolean z = ((n >> 16) & 1) == 0 && (obj6 == null || i3 == 0);
            zArr[i3] = z;
            j3 += (long) t;
            i3++;
        }
        c1490k.f2919s = j3;
        return i5;
    }

    private static void m3154a(C1403k c1403k, C1490k c1490k, byte[] bArr) {
        c1403k.m2760c(8);
        c1403k.m2756a(bArr, 0, 16);
        if (Arrays.equals(bArr, f2841c)) {
            C1482e.m3151a(c1403k, 16, c1490k);
        }
    }

    private static void m3163b(C1403k c1403k, C1490k c1490k) {
        C1482e.m3151a(c1403k, 0, c1490k);
    }

    private static void m3151a(C1403k c1403k, int i, C1490k c1490k) {
        c1403k.m2760c(i + 8);
        int b = C1466a.m3098b(c1403k.m2773n());
        if ((b & 1) != 0) {
            throw new ParserException("Overriding TrackEncryptionBox parameters is unsupported.");
        }
        boolean z;
        if ((b & 2) != 0) {
            z = true;
        } else {
            z = false;
        }
        int t = c1403k.m2779t();
        if (t != c1490k.f2906f) {
            throw new ParserException("Length mismatch: " + t + ", " + c1490k.f2906f);
        }
        Arrays.fill(c1490k.f2914n, 0, t, z);
        c1490k.m3204a(c1403k.m2757b());
        c1490k.m3206a(c1403k);
    }

    private static void m3152a(C1403k c1403k, C1403k c1403k2, C1490k c1490k) {
        c1403k.m2760c(8);
        int n = c1403k.m2773n();
        if (c1403k.m2773n() == f2840b) {
            if (C1466a.m3097a(n) == 1) {
                c1403k.m2762d(4);
            }
            if (c1403k.m2773n() != 1) {
                throw new ParserException("Entry count in sbgp != 1 (unsupported).");
            }
            c1403k2.m2760c(8);
            n = c1403k2.m2773n();
            if (c1403k2.m2773n() == f2840b) {
                n = C1466a.m3097a(n);
                if (n == 1) {
                    if (c1403k2.m2771l() == 0) {
                        throw new ParserException("Variable length decription in sgpd found (unsupported)");
                    }
                } else if (n >= 2) {
                    c1403k2.m2762d(4);
                }
                if (c1403k2.m2771l() != 1) {
                    throw new ParserException("Entry count in sgpd != 1 (unsupported).");
                }
                c1403k2.m2762d(2);
                boolean z = c1403k2.m2766g() == 1;
                if (z) {
                    int g = c1403k2.m2766g();
                    byte[] bArr = new byte[16];
                    c1403k2.m2756a(bArr, 0, bArr.length);
                    c1490k.f2913m = true;
                    c1490k.f2915o = new C1489j(z, g, bArr);
                }
            }
        }
    }

    private static C1456a m3147a(C1403k c1403k, long j) {
        long l;
        long l2;
        c1403k.m2760c(8);
        int a = C1466a.m3097a(c1403k.m2773n());
        c1403k.m2762d(4);
        long l3 = c1403k.m2771l();
        if (a == 0) {
            l = c1403k.m2771l() + j;
            l2 = c1403k.m2771l();
        } else {
            l = c1403k.m2781v() + j;
            l2 = c1403k.m2781v();
        }
        c1403k.m2762d(2);
        int h = c1403k.m2767h();
        int[] iArr = new int[h];
        long[] jArr = new long[h];
        long[] jArr2 = new long[h];
        long[] jArr3 = new long[h];
        long j2 = l;
        int i = 0;
        long j3 = l2;
        l2 = C1414r.m2816a(l2, 1000000, l3);
        while (i < h) {
            int n = c1403k.m2773n();
            if ((Integer.MIN_VALUE & n) != 0) {
                throw new ParserException("Unhandled indirect reference");
            }
            long l4 = c1403k.m2771l();
            iArr[i] = n & Integer.MAX_VALUE;
            jArr[i] = j2;
            jArr3[i] = l2;
            l2 = j3 + l4;
            l4 = C1414r.m2816a(l2, 1000000, l3);
            jArr2[i] = l4 - jArr3[i];
            c1403k.m2762d(4);
            j2 += (long) iArr[i];
            i++;
            j3 = l2;
            l2 = l4;
        }
        return new C1456a(iArr, jArr, jArr2, jArr3);
    }

    private void m3171d(C1464g c1464g) {
        C1481a c1481a = null;
        long j = Long.MAX_VALUE;
        int size = this.f2844f.size();
        int i = 0;
        while (i < size) {
            C1481a c1481a2;
            long j2;
            C1490k c1490k = ((C1481a) this.f2844f.valueAt(i)).f2832a;
            long j3;
            if (!c1490k.f2918r || c1490k.f2904d >= j) {
                j3 = j;
                c1481a2 = c1481a;
                j2 = j3;
            } else {
                j3 = c1490k.f2904d;
                c1481a2 = (C1481a) this.f2844f.valueAt(i);
                j2 = j3;
            }
            i++;
            c1481a = c1481a2;
            j = j2;
        }
        if (c1481a == null) {
            this.f2852n = 3;
            return;
        }
        int c = (int) (j - c1464g.mo2185c());
        if (c < 0) {
            throw new ParserException("Offset to encryption data was negative.");
        }
        c1464g.mo2182b(c);
        c1481a.f2832a.m3207a(c1464g);
    }

    private boolean m3172e(C1464g c1464g) {
        int c;
        long j;
        int i;
        byte[] bArr;
        if (this.f2852n == 3) {
            if (this.f2859u == null) {
                C1481a a = C1482e.m3148a(this.f2844f);
                if (a == null) {
                    c = (int) (this.f2857s - c1464g.mo2185c());
                    if (c < 0) {
                        throw new ParserException("Offset to end of mdat was negative.");
                    }
                    c1464g.mo2182b(c);
                    m3150a();
                    return false;
                }
                j = a.f2832a.f2907g[a.f2838g];
                c = (int) (j - c1464g.mo2185c());
                if (c < 0) {
                    if (j == a.f2832a.f2902b) {
                        Log.w("FragmentedMp4Extractor", "Offset to sample data was missing.");
                        c = 0;
                    } else {
                        throw new ParserException("Offset to sample data was negative.");
                    }
                }
                c1464g.mo2182b(c);
                this.f2859u = a;
            }
            this.f2860v = this.f2859u.f2832a.f2909i[this.f2859u.f2836e];
            if (this.f2859u.f2832a.f2913m) {
                this.f2861w = m3143a(this.f2859u);
                this.f2860v += this.f2861w;
            } else {
                this.f2861w = 0;
            }
            if (this.f2859u.f2834c.f2893g == 1) {
                this.f2860v -= 8;
                c1464g.mo2182b(8);
            }
            this.f2852n = 4;
            this.f2862x = 0;
        }
        C1490k c1490k = this.f2859u.f2832a;
        C1488i c1488i = this.f2859u.f2834c;
        C1521o c1521o = this.f2859u.f2833b;
        int i2 = this.f2859u.f2836e;
        if (c1488i.f2897k != 0) {
            byte[] bArr2 = this.f2846h.f2479a;
            bArr2[0] = (byte) 0;
            bArr2[1] = (byte) 0;
            bArr2[2] = (byte) 0;
            c = c1488i.f2897k;
            i = 4 - c1488i.f2897k;
            while (this.f2861w < this.f2860v) {
                if (this.f2862x == 0) {
                    c1464g.mo2183b(this.f2846h.f2479a, i, c);
                    this.f2846h.m2760c(0);
                    this.f2862x = this.f2846h.m2779t();
                    this.f2845g.m2760c(0);
                    c1521o.mo2203a(this.f2845g, 4);
                    this.f2861w += 4;
                    this.f2860v += i;
                } else {
                    int a2 = c1521o.mo2200a(c1464g, this.f2862x, false);
                    this.f2861w += a2;
                    this.f2862x -= a2;
                }
            }
        } else {
            while (this.f2861w < this.f2860v) {
                this.f2861w = c1521o.mo2200a(c1464g, this.f2860v - this.f2861w, false) + this.f2861w;
            }
        }
        long b = 1000 * c1490k.m3208b(i2);
        i = (c1490k.f2913m ? 1073741824 : 0) | (c1490k.f2912l[i2] ? 1 : 0);
        c = c1490k.f2901a.f2823a;
        if (c1490k.f2913m) {
            bArr = c1490k.f2915o != null ? c1490k.f2915o.f2900c : c1488i.f2894h[c].f2900c;
        } else {
            bArr = null;
        }
        if (this.f2848j != null) {
            j = this.f2848j.m3576b(b);
        } else {
            j = b;
        }
        c1521o.mo2201a(j, i, this.f2860v, 0, bArr);
        C1481a c1481a = this.f2859u;
        c1481a.f2836e++;
        c1481a = this.f2859u;
        c1481a.f2837f++;
        if (this.f2859u.f2837f == c1490k.f2908h[this.f2859u.f2838g]) {
            c1481a = this.f2859u;
            c1481a.f2838g++;
            this.f2859u.f2837f = 0;
            this.f2859u = null;
        }
        this.f2852n = 3;
        return true;
    }

    private static C1481a m3148a(SparseArray sparseArray) {
        C1481a c1481a = null;
        long j = Long.MAX_VALUE;
        int size = sparseArray.size();
        int i = 0;
        while (i < size) {
            C1481a c1481a2;
            long j2;
            C1481a c1481a3 = (C1481a) sparseArray.valueAt(i);
            long j3;
            if (c1481a3.f2838g == c1481a3.f2832a.f2905e) {
                j3 = j;
                c1481a2 = c1481a;
                j2 = j3;
            } else {
                long j4 = c1481a3.f2832a.f2907g[c1481a3.f2838g];
                if (j4 < j) {
                    c1481a2 = c1481a3;
                    j2 = j4;
                } else {
                    j3 = j;
                    c1481a2 = c1481a;
                    j2 = j3;
                }
            }
            i++;
            c1481a = c1481a2;
            j = j2;
        }
        return c1481a;
    }

    private int m3143a(C1481a c1481a) {
        int i;
        C1490k c1490k = c1481a.f2832a;
        C1403k c1403k = c1490k.f2917q;
        int i2 = (c1490k.f2915o != null ? c1490k.f2915o : c1481a.f2834c.f2894h[c1490k.f2901a.f2823a]).f2899b;
        boolean z = c1490k.f2914n[c1481a.f2836e];
        byte[] bArr = this.f2847i.f2479a;
        if (z) {
            i = 128;
        } else {
            i = 0;
        }
        bArr[0] = (byte) (i | i2);
        this.f2847i.m2760c(0);
        C1521o c1521o = c1481a.f2833b;
        c1521o.mo2203a(this.f2847i, 1);
        c1521o.mo2203a(c1403k, i2);
        if (!z) {
            return i2 + 1;
        }
        int h = c1403k.m2767h();
        c1403k.m2762d(-2);
        h = (h * 6) + 2;
        c1521o.mo2203a(c1403k, h);
        return (i2 + 1) + h;
    }

    private static DrmInitData m3146a(List list) {
        int size = list.size();
        List list2 = null;
        for (int i = 0; i < size; i++) {
            C1468b c1468b = (C1468b) list.get(i);
            if (c1468b.aM == C1466a.f2759T) {
                if (list2 == null) {
                    list2 = new ArrayList();
                }
                byte[] bArr = c1468b.aN.f2479a;
                UUID a = C1486g.m3197a(bArr);
                if (a == null) {
                    Log.w("FragmentedMp4Extractor", "Skipped pssh atom (failed to extract uuid)");
                } else {
                    list2.add(new SchemeData(a, "video/mp4", bArr));
                }
            }
        }
        return list2 == null ? null : new DrmInitData(list2);
    }

    private static boolean m3160a(int i) {
        return i == C1466a.f2757R || i == C1466a.f2756Q || i == C1466a.f2741B || i == C1466a.f2791z || i == C1466a.f2758S || i == C1466a.f2787v || i == C1466a.f2788w || i == C1466a.f2753N || i == C1466a.f2789x || i == C1466a.f2790y || i == C1466a.f2759T || i == C1466a.ab || i == C1466a.ac || i == C1466a.ag || i == C1466a.af || i == C1466a.ad || i == C1466a.ae || i == C1466a.f2755P || i == C1466a.f2752M;
    }

    private static boolean m3166b(int i) {
        return i == C1466a.f2740A || i == C1466a.f2742C || i == C1466a.f2743D || i == C1466a.f2744E || i == C1466a.f2745F || i == C1466a.f2749J || i == C1466a.f2750K || i == C1466a.f2751L || i == C1466a.f2754O;
    }
}
