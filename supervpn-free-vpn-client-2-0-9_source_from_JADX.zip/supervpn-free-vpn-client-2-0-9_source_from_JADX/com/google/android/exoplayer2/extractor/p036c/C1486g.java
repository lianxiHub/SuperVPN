package com.google.android.exoplayer2.extractor.p036c;

import android.util.Log;
import android.util.Pair;
import com.google.android.exoplayer2.p031c.C1403k;
import java.util.UUID;

public final class C1486g {
    public static UUID m3197a(byte[] bArr) {
        Pair b = C1486g.m3198b(bArr);
        if (b == null) {
            return null;
        }
        return (UUID) b.first;
    }

    private static Pair m3198b(byte[] bArr) {
        C1403k c1403k = new C1403k(bArr);
        if (c1403k.m2759c() < 32) {
            return null;
        }
        c1403k.m2760c(0);
        if (c1403k.m2773n() != c1403k.m2757b() + 4 || c1403k.m2773n() != C1466a.f2759T) {
            return null;
        }
        int a = C1466a.m3097a(c1403k.m2773n());
        if (a > 1) {
            Log.w("PsshAtomUtil", "Unsupported pssh version: " + a);
            return null;
        }
        UUID uuid = new UUID(c1403k.m2775p(), c1403k.m2775p());
        if (a == 1) {
            c1403k.m2762d(c1403k.m2779t() * 16);
        }
        a = c1403k.m2779t();
        if (a != c1403k.m2757b()) {
            return null;
        }
        Object obj = new byte[a];
        c1403k.m2756a(obj, 0, a);
        return Pair.create(uuid, obj);
    }
}
