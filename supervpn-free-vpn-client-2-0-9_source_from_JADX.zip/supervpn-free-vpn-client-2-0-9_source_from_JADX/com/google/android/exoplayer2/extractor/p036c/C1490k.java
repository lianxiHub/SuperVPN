package com.google.android.exoplayer2.extractor.p036c;

import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.p031c.C1403k;

final class C1490k {
    public C1476c f2901a;
    public long f2902b;
    public long f2903c;
    public long f2904d;
    public int f2905e;
    public int f2906f;
    public long[] f2907g;
    public int[] f2908h;
    public int[] f2909i;
    public int[] f2910j;
    public long[] f2911k;
    public boolean[] f2912l;
    public boolean f2913m;
    public boolean[] f2914n;
    public C1489j f2915o;
    public int f2916p;
    public C1403k f2917q;
    public boolean f2918r;
    public long f2919s;

    C1490k() {
    }

    public void m3203a() {
        this.f2905e = 0;
        this.f2919s = 0;
        this.f2913m = false;
        this.f2918r = false;
        this.f2915o = null;
    }

    public void m3205a(int i, int i2) {
        this.f2905e = i;
        this.f2906f = i2;
        if (this.f2908h == null || this.f2908h.length < i) {
            this.f2907g = new long[i];
            this.f2908h = new int[i];
        }
        if (this.f2909i == null || this.f2909i.length < i2) {
            int i3 = (i2 * 125) / 100;
            this.f2909i = new int[i3];
            this.f2910j = new int[i3];
            this.f2911k = new long[i3];
            this.f2912l = new boolean[i3];
            this.f2914n = new boolean[i3];
        }
    }

    public void m3204a(int i) {
        if (this.f2917q == null || this.f2917q.m2759c() < i) {
            this.f2917q = new C1403k(i);
        }
        this.f2916p = i;
        this.f2913m = true;
        this.f2918r = true;
    }

    public void m3207a(C1464g c1464g) {
        c1464g.mo2183b(this.f2917q.f2479a, 0, this.f2916p);
        this.f2917q.m2760c(0);
        this.f2918r = false;
    }

    public void m3206a(C1403k c1403k) {
        c1403k.m2756a(this.f2917q.f2479a, 0, this.f2916p);
        this.f2917q.m2760c(0);
        this.f2918r = false;
    }

    public long m3208b(int i) {
        return this.f2911k[i] + ((long) this.f2910j[i]);
    }
}
