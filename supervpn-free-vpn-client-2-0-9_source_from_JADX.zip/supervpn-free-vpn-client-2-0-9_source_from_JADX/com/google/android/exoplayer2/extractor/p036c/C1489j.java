package com.google.android.exoplayer2.extractor.p036c;

public final class C1489j {
    public final boolean f2898a;
    public final int f2899b;
    public final byte[] f2900c;

    public C1489j(boolean z, int i, byte[] bArr) {
        this.f2898a = z;
        this.f2899b = i;
        this.f2900c = bArr;
    }
}
