package com.google.android.exoplayer2.extractor.p036c;

import com.google.android.exoplayer2.Format;

public final class C1488i {
    public final int f2887a;
    public final int f2888b;
    public final long f2889c;
    public final long f2890d;
    public final long f2891e;
    public final Format f2892f;
    public final int f2893g;
    public final C1489j[] f2894h;
    public final long[] f2895i;
    public final long[] f2896j;
    public final int f2897k;

    public C1488i(int i, int i2, long j, long j2, long j3, Format format, int i3, C1489j[] c1489jArr, int i4, long[] jArr, long[] jArr2) {
        this.f2887a = i;
        this.f2888b = i2;
        this.f2889c = j;
        this.f2890d = j2;
        this.f2891e = j3;
        this.f2892f = format;
        this.f2893g = i3;
        this.f2894h = c1489jArr;
        this.f2897k = i4;
        this.f2895i = jArr;
        this.f2896j = jArr2;
    }
}
