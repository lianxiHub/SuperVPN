package com.google.android.exoplayer2.extractor;

public interface C1567h {
    C1521o mo2273a(int i);

    void mo2274a();

    void mo2276a(C1455m c1455m);
}
