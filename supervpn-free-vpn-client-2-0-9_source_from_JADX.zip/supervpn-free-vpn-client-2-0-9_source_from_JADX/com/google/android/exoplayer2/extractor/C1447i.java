package com.google.android.exoplayer2.extractor;

public interface C1447i {
    C1451f[] mo2159a();
}
