package com.google.android.exoplayer2.extractor.p038e;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.text.p041a.C1634a;

final class C1549o {
    private final C1521o f3246a;

    public C1549o(C1521o c1521o) {
        this.f3246a = c1521o;
        c1521o.mo2202a(Format.m2408a(null, "application/cea-608", null, -1, 0, null, null));
    }

    public void m3468a(long j, C1403k c1403k) {
        while (c1403k.m2757b() > 1) {
            int g;
            int i = 0;
            do {
                g = c1403k.m2766g();
                i += g;
            } while (g == 255);
            g = 0;
            while (true) {
                int g2 = c1403k.m2766g();
                int i2 = g + g2;
                if (g2 != 255) {
                    break;
                }
                g = i2;
            }
            if (C1634a.m3902a(i, i2, c1403k)) {
                c1403k.m2762d(8);
                int g3 = c1403k.m2766g() & 31;
                c1403k.m2762d(1);
                int i3 = 0;
                for (i = 0; i < g3; i++) {
                    if ((c1403k.m2765f() & 7) != 4) {
                        c1403k.m2762d(3);
                    } else {
                        i3 += 3;
                        this.f3246a.mo2203a(c1403k, 3);
                    }
                }
                this.f3246a.mo2201a(j, 1, i3, 0, null);
                c1403k.m2762d(i2 - ((g3 * 3) + 10));
            } else {
                c1403k.m2762d(i2);
            }
        }
    }
}
