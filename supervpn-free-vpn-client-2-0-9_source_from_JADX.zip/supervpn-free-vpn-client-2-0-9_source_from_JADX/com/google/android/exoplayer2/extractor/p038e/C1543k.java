package com.google.android.exoplayer2.extractor.p038e;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.extractor.p038e.C1525g.C1534c;
import com.google.android.exoplayer2.p031c.C1403k;

final class C1543k extends C1525g {
    private final C1403k f3208a = new C1403k(10);
    private C1521o f3209b;
    private boolean f3210c;
    private long f3211d;
    private int f3212e;
    private int f3213f;

    public void mo2204a() {
        this.f3210c = false;
    }

    public void mo2207a(C1567h c1567h, C1534c c1534c) {
        this.f3209b = c1567h.mo2273a(c1534c.m3392a());
        this.f3209b.mo2202a(Format.m2410a(null, "application/id3", null, -1, null));
    }

    public void mo2205a(long j, boolean z) {
        if (z) {
            this.f3210c = true;
            this.f3211d = j;
            this.f3212e = 0;
            this.f3213f = 0;
        }
    }

    public void mo2206a(C1403k c1403k) {
        if (this.f3210c) {
            int b = c1403k.m2757b();
            if (this.f3213f < 10) {
                int min = Math.min(b, 10 - this.f3213f);
                System.arraycopy(c1403k.f2479a, c1403k.m2761d(), this.f3208a.f2479a, this.f3213f, min);
                if (min + this.f3213f == 10) {
                    this.f3208a.m2760c(6);
                    this.f3212e = this.f3208a.m2778s() + 10;
                }
            }
            b = Math.min(b, this.f3212e - this.f3213f);
            this.f3209b.mo2203a(c1403k, b);
            this.f3213f = b + this.f3213f;
        }
    }

    public void mo2208b() {
        if (this.f3210c && this.f3212e != 0 && this.f3213f == this.f3212e) {
            this.f3209b.mo2201a(this.f3211d, 1, this.f3212e, 0, null);
            this.f3210c = false;
        }
    }
}
