package com.google.android.exoplayer2.extractor.p038e;

import android.util.Log;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.extractor.p038e.C1525g.C1534c;
import com.google.android.exoplayer2.p031c.C1401i;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1404l;
import com.mopub.volley.DefaultRetryPolicy;
import java.util.Collections;

final class C1542j extends C1525g {
    private C1521o f3195a;
    private C1549o f3196b;
    private boolean f3197c;
    private final boolean[] f3198d = new boolean[3];
    private final C1545m f3199e = new C1545m(32, 128);
    private final C1545m f3200f = new C1545m(33, 128);
    private final C1545m f3201g = new C1545m(34, 128);
    private final C1545m f3202h = new C1545m(39, 128);
    private final C1545m f3203i = new C1545m(40, 128);
    private final C1541a f3204j = new C1541a(this.f3195a);
    private long f3205k;
    private long f3206l;
    private final C1403k f3207m = new C1403k();

    private static final class C1541a {
        private final C1521o f3182a;
        private long f3183b;
        private boolean f3184c;
        private int f3185d;
        private long f3186e;
        private boolean f3187f;
        private boolean f3188g;
        private boolean f3189h;
        private boolean f3190i;
        private boolean f3191j;
        private long f3192k;
        private long f3193l;
        private boolean f3194m;

        public C1541a(C1521o c1521o) {
            this.f3182a = c1521o;
        }

        public void m3425a() {
            this.f3187f = false;
            this.f3188g = false;
            this.f3189h = false;
            this.f3190i = false;
            this.f3191j = false;
        }

        public void m3427a(long j, int i, int i2, long j2) {
            boolean z;
            boolean z2 = false;
            this.f3188g = false;
            this.f3189h = false;
            this.f3186e = j2;
            this.f3185d = 0;
            this.f3183b = j;
            if (i2 >= 32) {
                if (!this.f3191j && this.f3190i) {
                    m3424a(i);
                    this.f3190i = false;
                }
                if (i2 <= 34) {
                    this.f3189h = !this.f3191j;
                    this.f3191j = true;
                }
            }
            if (i2 < 16 || i2 > 21) {
                z = false;
            } else {
                z = true;
            }
            this.f3184c = z;
            if (this.f3184c || i2 <= 9) {
                z2 = true;
            }
            this.f3187f = z2;
        }

        public void m3428a(byte[] bArr, int i, int i2) {
            if (this.f3187f) {
                int i3 = (i + 2) - this.f3185d;
                if (i3 < i2) {
                    this.f3188g = (bArr[i3] & 128) != 0;
                    this.f3187f = false;
                    return;
                }
                this.f3185d += i2 - i;
            }
        }

        public void m3426a(long j, int i) {
            if (this.f3191j && this.f3188g) {
                this.f3194m = this.f3184c;
                this.f3191j = false;
            } else if (this.f3189h || this.f3188g) {
                if (this.f3190i) {
                    m3424a(((int) (j - this.f3183b)) + i);
                }
                this.f3192k = this.f3183b;
                this.f3193l = this.f3186e;
                this.f3190i = true;
                this.f3194m = this.f3184c;
            }
        }

        private void m3424a(int i) {
            this.f3182a.mo2201a(this.f3193l, this.f3194m ? 1 : 0, (int) (this.f3183b - this.f3192k), i, null);
        }
    }

    public void mo2204a() {
        C1401i.m2740a(this.f3198d);
        this.f3199e.m3453a();
        this.f3200f.m3453a();
        this.f3201g.m3453a();
        this.f3202h.m3453a();
        this.f3203i.m3453a();
        this.f3204j.m3425a();
        this.f3205k = 0;
    }

    public void mo2207a(C1567h c1567h, C1534c c1534c) {
        this.f3195a = c1567h.mo2273a(c1534c.m3392a());
        this.f3196b = new C1549o(c1567h.mo2273a(c1534c.m3392a()));
    }

    public void mo2205a(long j, boolean z) {
        this.f3206l = j;
    }

    public void mo2206a(C1403k c1403k) {
        while (c1403k.m2757b() > 0) {
            int d = c1403k.m2761d();
            int c = c1403k.m2759c();
            byte[] bArr = c1403k.f2479a;
            this.f3205k += (long) c1403k.m2757b();
            this.f3195a.mo2203a(c1403k, c1403k.m2757b());
            while (d < c) {
                int a = C1401i.m2736a(bArr, d, c, this.f3198d);
                if (a == c) {
                    m3432a(bArr, d, c);
                    return;
                }
                int c2 = C1401i.m2743c(bArr, a);
                int i = a - d;
                if (i > 0) {
                    m3432a(bArr, d, a);
                }
                int i2 = c - a;
                long j = this.f3205k - ((long) i2);
                m3433b(j, i2, i < 0 ? -i : 0, this.f3206l);
                m3430a(j, i2, c2, this.f3206l);
                d = a + 3;
            }
        }
    }

    public void mo2208b() {
    }

    private void m3430a(long j, int i, int i2, long j2) {
        if (this.f3197c) {
            this.f3204j.m3427a(j, i, i2, j2);
        } else {
            this.f3199e.m3454a(i2);
            this.f3200f.m3454a(i2);
            this.f3201g.m3454a(i2);
        }
        this.f3202h.m3454a(i2);
        this.f3203i.m3454a(i2);
    }

    private void m3432a(byte[] bArr, int i, int i2) {
        if (this.f3197c) {
            this.f3204j.m3428a(bArr, i, i2);
        } else {
            this.f3199e.m3455a(bArr, i, i2);
            this.f3200f.m3455a(bArr, i, i2);
            this.f3201g.m3455a(bArr, i, i2);
        }
        this.f3202h.m3455a(bArr, i, i2);
        this.f3203i.m3455a(bArr, i, i2);
    }

    private void m3433b(long j, int i, int i2, long j2) {
        if (this.f3197c) {
            this.f3204j.m3426a(j, i);
        } else {
            this.f3199e.m3457b(i2);
            this.f3200f.m3457b(i2);
            this.f3201g.m3457b(i2);
            if (this.f3199e.m3456b() && this.f3200f.m3456b() && this.f3201g.m3456b()) {
                this.f3195a.mo2202a(C1542j.m3429a(this.f3199e, this.f3200f, this.f3201g));
                this.f3197c = true;
            }
        }
        if (this.f3202h.m3457b(i2)) {
            this.f3207m.m2755a(this.f3202h.f3225a, C1401i.m2735a(this.f3202h.f3225a, this.f3202h.f3226b));
            this.f3207m.m2762d(5);
            this.f3196b.m3468a(j2, this.f3207m);
        }
        if (this.f3203i.m3457b(i2)) {
            this.f3207m.m2755a(this.f3203i.f3225a, C1401i.m2735a(this.f3203i.f3225a, this.f3203i.f3226b));
            this.f3207m.m2762d(5);
            this.f3196b.m3468a(j2, this.f3207m);
        }
    }

    private static Format m3429a(C1545m c1545m, C1545m c1545m2, C1545m c1545m3) {
        int i;
        float f;
        Object obj = new byte[((c1545m.f3226b + c1545m2.f3226b) + c1545m3.f3226b)];
        System.arraycopy(c1545m.f3225a, 0, obj, 0, c1545m.f3226b);
        System.arraycopy(c1545m2.f3225a, 0, obj, c1545m.f3226b, c1545m2.f3226b);
        System.arraycopy(c1545m3.f3225a, 0, obj, c1545m.f3226b + c1545m2.f3226b, c1545m3.f3226b);
        C1404l c1404l = new C1404l(c1545m2.f3225a, 0, c1545m2.f3226b);
        c1404l.m2788a(44);
        int c = c1404l.m2794c(3);
        c1404l.m2788a(1);
        c1404l.m2788a(88);
        c1404l.m2788a(8);
        int i2 = 0;
        for (i = 0; i < c; i++) {
            if (c1404l.m2790a()) {
                i2 += 89;
            }
            if (c1404l.m2790a()) {
                i2 += 8;
            }
        }
        c1404l.m2788a(i2);
        if (c > 0) {
            c1404l.m2788a((8 - c) * 2);
        }
        c1404l.m2793c();
        int c2 = c1404l.m2793c();
        if (c2 == 3) {
            c1404l.m2788a(1);
        }
        int c3 = c1404l.m2793c();
        int c4 = c1404l.m2793c();
        if (c1404l.m2790a()) {
            int c5 = c1404l.m2793c();
            int c6 = c1404l.m2793c();
            int c7 = c1404l.m2793c();
            int c8 = c1404l.m2793c();
            i = (c2 == 1 || c2 == 2) ? 2 : 1;
            c3 -= i * (c5 + c6);
            c4 -= (c2 == 1 ? 2 : 1) * (c7 + c8);
        }
        c1404l.m2793c();
        c1404l.m2793c();
        i = c1404l.m2793c();
        i2 = c1404l.m2790a() ? 0 : c;
        while (i2 <= c) {
            c1404l.m2793c();
            c1404l.m2793c();
            c1404l.m2793c();
            i2++;
        }
        c1404l.m2793c();
        c1404l.m2793c();
        c1404l.m2793c();
        c1404l.m2793c();
        c1404l.m2793c();
        c1404l.m2793c();
        if (c1404l.m2790a() && c1404l.m2790a()) {
            C1542j.m3431a(c1404l);
        }
        c1404l.m2788a(2);
        if (c1404l.m2790a()) {
            c1404l.m2788a(8);
            c1404l.m2793c();
            c1404l.m2793c();
            c1404l.m2788a(1);
        }
        C1542j.m3434b(c1404l);
        if (c1404l.m2790a()) {
            for (i2 = 0; i2 < c1404l.m2793c(); i2++) {
                c1404l.m2788a((i + 4) + 1);
            }
        }
        c1404l.m2788a(2);
        float f2 = DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;
        if (c1404l.m2790a() && c1404l.m2790a()) {
            c = c1404l.m2794c(8);
            if (c == 255) {
                c = c1404l.m2794c(16);
                i = c1404l.m2794c(16);
                if (!(c == 0 || i == 0)) {
                    f2 = ((float) c) / ((float) i);
                }
                f = f2;
            } else if (c < C1401i.f2472b.length) {
                f = C1401i.f2472b[c];
            } else {
                Log.w("H265Reader", "Unexpected aspect_ratio_idc value: " + c);
            }
            return Format.m2403a(null, "video/hevc", null, -1, -1, c3, c4, -1.0f, Collections.singletonList(obj), -1, f, null);
        }
        f = DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;
        return Format.m2403a(null, "video/hevc", null, -1, -1, c3, c4, -1.0f, Collections.singletonList(obj), -1, f, null);
    }

    private static void m3431a(C1404l c1404l) {
        int i = 0;
        while (i < 4) {
            for (int i2 = 0; i2 < 6; i2 = (i == 3 ? 3 : 1) + i2) {
                if (c1404l.m2790a()) {
                    int min = Math.min(64, 1 << ((i << 1) + 4));
                    if (i > 1) {
                        c1404l.m2795d();
                    }
                    for (int i3 = 0; i3 < min; i3++) {
                        c1404l.m2795d();
                    }
                } else {
                    c1404l.m2793c();
                }
            }
            i++;
        }
    }

    private static void m3434b(C1404l c1404l) {
        int c = c1404l.m2793c();
        int i = 0;
        int i2 = 0;
        boolean z = false;
        while (i < c) {
            boolean a;
            if (i != 0) {
                a = c1404l.m2790a();
            } else {
                a = z;
            }
            int i3;
            if (a) {
                c1404l.m2788a(1);
                c1404l.m2793c();
                for (i3 = 0; i3 <= i2; i3++) {
                    if (c1404l.m2790a()) {
                        c1404l.m2788a(1);
                    }
                }
            } else {
                int c2 = c1404l.m2793c();
                int c3 = c1404l.m2793c();
                i2 = c2 + c3;
                for (i3 = 0; i3 < c2; i3++) {
                    c1404l.m2793c();
                    c1404l.m2788a(1);
                }
                for (i3 = 0; i3 < c3; i3++) {
                    c1404l.m2793c();
                    c1404l.m2788a(1);
                }
            }
            i++;
            z = a;
        }
    }
}
