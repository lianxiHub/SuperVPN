package com.google.android.exoplayer2.extractor.p038e;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.audio.C1370d;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.extractor.p038e.C1525g.C1534c;
import com.google.android.exoplayer2.p031c.C1403k;

final class C1532f extends C1525g {
    private final C1403k f3102a = new C1403k(new byte[15]);
    private final String f3103b;
    private C1521o f3104c;
    private int f3105d;
    private int f3106e;
    private int f3107f;
    private long f3108g;
    private Format f3109h;
    private int f3110i;
    private long f3111j;

    public C1532f(String str) {
        this.f3102a.f2479a[0] = Byte.MAX_VALUE;
        this.f3102a.f2479a[1] = (byte) -2;
        this.f3102a.f2479a[2] = Byte.MIN_VALUE;
        this.f3102a.f2479a[3] = (byte) 1;
        this.f3105d = 0;
        this.f3103b = str;
    }

    public void mo2204a() {
        this.f3105d = 0;
        this.f3106e = 0;
        this.f3107f = 0;
    }

    public void mo2207a(C1567h c1567h, C1534c c1534c) {
        this.f3104c = c1567h.mo2273a(c1534c.m3392a());
    }

    public void mo2205a(long j, boolean z) {
        this.f3111j = j;
    }

    public void mo2206a(C1403k c1403k) {
        while (c1403k.m2757b() > 0) {
            switch (this.f3105d) {
                case 0:
                    if (!m3385b(c1403k)) {
                        break;
                    }
                    this.f3106e = 4;
                    this.f3105d = 1;
                    break;
                case 1:
                    if (!m3384a(c1403k, this.f3102a.f2479a, 15)) {
                        break;
                    }
                    m3386c();
                    this.f3102a.m2760c(0);
                    this.f3104c.mo2203a(this.f3102a, 15);
                    this.f3105d = 2;
                    break;
                case 2:
                    int min = Math.min(c1403k.m2757b(), this.f3110i - this.f3106e);
                    this.f3104c.mo2203a(c1403k, min);
                    this.f3106e = min + this.f3106e;
                    if (this.f3106e != this.f3110i) {
                        break;
                    }
                    this.f3104c.mo2201a(this.f3111j, 1, this.f3110i, 0, null);
                    this.f3111j += this.f3108g;
                    this.f3105d = 0;
                    break;
                default:
                    break;
            }
        }
    }

    public void mo2208b() {
    }

    private boolean m3384a(C1403k c1403k, byte[] bArr, int i) {
        int min = Math.min(c1403k.m2757b(), i - this.f3106e);
        c1403k.m2756a(bArr, this.f3106e, min);
        this.f3106e = min + this.f3106e;
        return this.f3106e == i;
    }

    private boolean m3385b(C1403k c1403k) {
        while (c1403k.m2757b() > 0) {
            this.f3107f <<= 8;
            this.f3107f |= c1403k.m2766g();
            if (this.f3107f == 2147385345) {
                this.f3107f = 0;
                return true;
            }
        }
        return false;
    }

    private void m3386c() {
        byte[] bArr = this.f3102a.f2479a;
        if (this.f3109h == null) {
            this.f3109h = C1370d.m2593a(bArr, null, this.f3103b, null);
            this.f3104c.mo2202a(this.f3109h);
        }
        this.f3110i = C1370d.m2594b(bArr);
        this.f3108g = (long) ((int) ((((long) C1370d.m2592a(bArr)) * 1000000) / ((long) this.f3109h.f2195q)));
    }
}
