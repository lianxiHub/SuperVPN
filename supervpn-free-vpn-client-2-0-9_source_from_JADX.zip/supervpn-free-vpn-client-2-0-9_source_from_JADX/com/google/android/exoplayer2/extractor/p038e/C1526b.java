package com.google.android.exoplayer2.extractor.p038e;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.audio.C1360a;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.extractor.p038e.C1525g.C1534c;
import com.google.android.exoplayer2.p031c.C1402j;
import com.google.android.exoplayer2.p031c.C1403k;

final class C1526b extends C1525g {
    private final C1402j f3066a;
    private final C1403k f3067b;
    private final String f3068c;
    private C1521o f3069d;
    private int f3070e;
    private int f3071f;
    private boolean f3072g;
    private long f3073h;
    private Format f3074i;
    private int f3075j;
    private boolean f3076k;
    private long f3077l;

    public C1526b() {
        this(null);
    }

    public C1526b(String str) {
        this.f3066a = new C1402j(new byte[8]);
        this.f3067b = new C1403k(this.f3066a.f2475a);
        this.f3070e = 0;
        this.f3068c = str;
    }

    public void mo2204a() {
        this.f3070e = 0;
        this.f3071f = 0;
        this.f3072g = false;
    }

    public void mo2207a(C1567h c1567h, C1534c c1534c) {
        this.f3069d = c1567h.mo2273a(c1534c.m3392a());
    }

    public void mo2205a(long j, boolean z) {
        this.f3077l = j;
    }

    public void mo2206a(C1403k c1403k) {
        while (c1403k.m2757b() > 0) {
            switch (this.f3070e) {
                case 0:
                    if (!m3355b(c1403k)) {
                        break;
                    }
                    this.f3070e = 1;
                    this.f3067b.f2479a[0] = (byte) 11;
                    this.f3067b.f2479a[1] = (byte) 119;
                    this.f3071f = 2;
                    break;
                case 1:
                    if (!m3354a(c1403k, this.f3067b.f2479a, 8)) {
                        break;
                    }
                    m3356c();
                    this.f3067b.m2760c(0);
                    this.f3069d.mo2203a(this.f3067b, 8);
                    this.f3070e = 2;
                    break;
                case 2:
                    int min = Math.min(c1403k.m2757b(), this.f3075j - this.f3071f);
                    this.f3069d.mo2203a(c1403k, min);
                    this.f3071f = min + this.f3071f;
                    if (this.f3071f != this.f3075j) {
                        break;
                    }
                    this.f3069d.mo2201a(this.f3077l, 1, this.f3075j, 0, null);
                    this.f3077l += this.f3073h;
                    this.f3070e = 0;
                    break;
                default:
                    break;
            }
        }
    }

    public void mo2208b() {
    }

    private boolean m3354a(C1403k c1403k, byte[] bArr, int i) {
        int min = Math.min(c1403k.m2757b(), i - this.f3071f);
        c1403k.m2756a(bArr, this.f3071f, min);
        this.f3071f = min + this.f3071f;
        return this.f3071f == i;
    }

    private boolean m3355b(C1403k c1403k) {
        while (c1403k.m2757b() > 0) {
            if (this.f3072g) {
                int g = c1403k.m2766g();
                if (g == 119) {
                    this.f3072g = false;
                    return true;
                }
                this.f3072g = g == 11;
            } else {
                this.f3072g = c1403k.m2766g() == 11;
            }
        }
        return false;
    }

    private void m3356c() {
        int b;
        if (this.f3074i == null) {
            Format b2;
            this.f3066a.m2748b(40);
            this.f3076k = this.f3066a.m2750c(5) == 16;
            this.f3066a.m2747a(this.f3066a.m2746a() - 45);
            if (this.f3076k) {
                b2 = C1360a.m2572b(this.f3066a, null, this.f3068c, null);
            } else {
                b2 = C1360a.m2569a(this.f3066a, null, this.f3068c, null);
            }
            this.f3074i = b2;
            this.f3069d.mo2202a(this.f3074i);
        }
        if (this.f3076k) {
            b = C1360a.m2571b(this.f3066a.f2475a);
        } else {
            b = C1360a.m2568a(this.f3066a.f2475a);
        }
        this.f3075j = b;
        if (this.f3076k) {
            b = C1360a.m2574c(this.f3066a.f2475a);
        } else {
            b = C1360a.m2565a();
        }
        this.f3073h = (long) ((int) ((((long) b) * 1000000) / ((long) this.f3074i.f2195q)));
    }
}
