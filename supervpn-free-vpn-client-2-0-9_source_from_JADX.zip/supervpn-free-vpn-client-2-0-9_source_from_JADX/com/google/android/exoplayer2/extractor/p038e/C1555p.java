package com.google.android.exoplayer2.extractor.p038e;

import android.util.Log;
import android.util.SparseArray;
import android.util.SparseBooleanArray;
import android.util.SparseIntArray;
import com.google.android.exoplayer2.extractor.C1447i;
import com.google.android.exoplayer2.extractor.C1451f;
import com.google.android.exoplayer2.extractor.C1455m.C1571a;
import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.extractor.C1570l;
import com.google.android.exoplayer2.extractor.C1572n;
import com.google.android.exoplayer2.extractor.p038e.C1525g.C1530b;
import com.google.android.exoplayer2.extractor.p038e.C1525g.C1533a;
import com.google.android.exoplayer2.extractor.p038e.C1525g.C1534c;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1402j;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1414r;
import java.util.Arrays;

public final class C1555p implements C1451f {
    public static final C1447i f3272a = new C15501();
    private static final long f3273b = ((long) C1414r.m2830e("AC-3"));
    private static final long f3274c = ((long) C1414r.m2830e("EAC3"));
    private static final long f3275d = ((long) C1414r.m2830e("HEVC"));
    private final boolean f3276e;
    private final C1572n f3277f;
    private final C1403k f3278g;
    private final C1402j f3279h;
    private final SparseIntArray f3280i;
    private final C1530b f3281j;
    private final SparseArray f3282k;
    private final SparseBooleanArray f3283l;
    private C1567h f3284m;
    private boolean f3285n;
    private C1525g f3286o;

    static class C15501 implements C1447i {
        C15501() {
        }

        public C1451f[] mo2159a() {
            return new C1451f[]{new C1555p()};
        }
    }

    private static abstract class C1551d {
        public abstract void mo2210a();

        public abstract void mo2211a(C1403k c1403k, boolean z, C1567h c1567h);

        private C1551d() {
        }
    }

    private class C1552a extends C1551d {
        final /* synthetic */ C1555p f3247a;
        private final C1403k f3248b = new C1403k();
        private final C1402j f3249c = new C1402j(new byte[4]);
        private int f3250d;
        private int f3251e;
        private int f3252f;

        public C1552a(C1555p c1555p) {
            this.f3247a = c1555p;
            super();
        }

        public void mo2210a() {
        }

        public void mo2211a(C1403k c1403k, boolean z, C1567h c1567h) {
            int i = 0;
            if (z) {
                c1403k.m2762d(c1403k.m2766g());
                c1403k.m2754a(this.f3249c, 3);
                this.f3249c.m2748b(12);
                this.f3250d = this.f3249c.m2750c(12);
                this.f3251e = 0;
                this.f3252f = C1414r.m2814a(this.f3249c.f2475a, 0, 3, -1);
                this.f3248b.m2753a(this.f3250d);
            }
            int min = Math.min(c1403k.m2757b(), this.f3250d - this.f3251e);
            c1403k.m2756a(this.f3248b.f2479a, this.f3251e, min);
            this.f3251e = min + this.f3251e;
            if (this.f3251e >= this.f3250d && C1414r.m2814a(this.f3248b.f2479a, 0, this.f3250d, this.f3252f) == 0) {
                this.f3248b.m2762d(5);
                min = (this.f3250d - 9) / 4;
                while (i < min) {
                    this.f3248b.m2754a(this.f3249c, 4);
                    int c = this.f3249c.m2750c(16);
                    this.f3249c.m2748b(3);
                    if (c == 0) {
                        this.f3249c.m2748b(13);
                    } else {
                        c = this.f3249c.m2750c(13);
                        this.f3247a.f3282k.put(c, new C1554c(this.f3247a, c));
                    }
                    i++;
                }
            }
        }
    }

    private static final class C1553b extends C1551d {
        private final C1525g f3253a;
        private final C1572n f3254b;
        private final C1402j f3255c = new C1402j(new byte[10]);
        private int f3256d = 0;
        private int f3257e;
        private boolean f3258f;
        private boolean f3259g;
        private boolean f3260h;
        private int f3261i;
        private int f3262j;
        private boolean f3263k;
        private long f3264l;

        public C1553b(C1525g c1525g, C1572n c1572n) {
            super();
            this.f3253a = c1525g;
            this.f3254b = c1572n;
        }

        public void mo2210a() {
            this.f3256d = 0;
            this.f3257e = 0;
            this.f3260h = false;
            this.f3253a.mo2204a();
        }

        public void mo2211a(C1403k c1403k, boolean z, C1567h c1567h) {
            if (z) {
                switch (this.f3256d) {
                    case 2:
                        Log.w("TsExtractor", "Unexpected start indicator reading extended header");
                        break;
                    case 3:
                        if (this.f3262j != -1) {
                            Log.w("TsExtractor", "Unexpected start indicator: expected " + this.f3262j + " more bytes");
                        }
                        this.f3253a.mo2208b();
                        break;
                }
                m3474a(1);
            }
            while (c1403k.m2757b() > 0) {
                switch (this.f3256d) {
                    case 0:
                        c1403k.m2762d(c1403k.m2757b());
                        break;
                    case 1:
                        if (!m3475a(c1403k, this.f3255c.f2475a, 9)) {
                            break;
                        }
                        m3474a(m3476b() ? 2 : 0);
                        break;
                    case 2:
                        if (m3475a(c1403k, this.f3255c.f2475a, Math.min(10, this.f3261i)) && m3475a(c1403k, null, this.f3261i)) {
                            m3477c();
                            this.f3253a.mo2205a(this.f3264l, this.f3263k);
                            m3474a(3);
                            break;
                        }
                    case 3:
                        int i;
                        int b = c1403k.m2757b();
                        if (this.f3262j == -1) {
                            i = 0;
                        } else {
                            i = b - this.f3262j;
                        }
                        if (i > 0) {
                            b -= i;
                            c1403k.m2758b(c1403k.m2761d() + b);
                        }
                        this.f3253a.mo2206a(c1403k);
                        if (this.f3262j == -1) {
                            break;
                        }
                        this.f3262j -= b;
                        if (this.f3262j != 0) {
                            break;
                        }
                        this.f3253a.mo2208b();
                        m3474a(1);
                        break;
                    default:
                        break;
                }
            }
        }

        private void m3474a(int i) {
            this.f3256d = i;
            this.f3257e = 0;
        }

        private boolean m3475a(C1403k c1403k, byte[] bArr, int i) {
            int min = Math.min(c1403k.m2757b(), i - this.f3257e);
            if (min <= 0) {
                return true;
            }
            if (bArr == null) {
                c1403k.m2762d(min);
            } else {
                c1403k.m2756a(bArr, this.f3257e, min);
            }
            this.f3257e = min + this.f3257e;
            if (this.f3257e != i) {
                return false;
            }
            return true;
        }

        private boolean m3476b() {
            this.f3255c.m2747a(0);
            int c = this.f3255c.m2750c(24);
            if (c != 1) {
                Log.w("TsExtractor", "Unexpected start code prefix: " + c);
                this.f3262j = -1;
                return false;
            }
            this.f3255c.m2748b(8);
            int c2 = this.f3255c.m2750c(16);
            this.f3255c.m2748b(5);
            this.f3263k = this.f3255c.m2749b();
            this.f3255c.m2748b(2);
            this.f3258f = this.f3255c.m2749b();
            this.f3259g = this.f3255c.m2749b();
            this.f3255c.m2748b(6);
            this.f3261i = this.f3255c.m2750c(8);
            if (c2 == 0) {
                this.f3262j = -1;
            } else {
                this.f3262j = ((c2 + 6) - 9) - this.f3261i;
            }
            return true;
        }

        private void m3477c() {
            this.f3255c.m2747a(0);
            this.f3264l = -9223372036854775807L;
            if (this.f3258f) {
                this.f3255c.m2748b(4);
                long c = ((long) this.f3255c.m2750c(3)) << 30;
                this.f3255c.m2748b(1);
                c |= (long) (this.f3255c.m2750c(15) << 15);
                this.f3255c.m2748b(1);
                c |= (long) this.f3255c.m2750c(15);
                this.f3255c.m2748b(1);
                if (!this.f3260h && this.f3259g) {
                    this.f3255c.m2748b(4);
                    long c2 = ((long) this.f3255c.m2750c(3)) << 30;
                    this.f3255c.m2748b(1);
                    c2 |= (long) (this.f3255c.m2750c(15) << 15);
                    this.f3255c.m2748b(1);
                    c2 |= (long) this.f3255c.m2750c(15);
                    this.f3255c.m2748b(1);
                    this.f3254b.m3574a(c2);
                    this.f3260h = true;
                }
                this.f3264l = this.f3254b.m3574a(c);
            }
        }
    }

    private class C1554c extends C1551d {
        final /* synthetic */ C1555p f3265a;
        private final C1402j f3266b = new C1402j(new byte[5]);
        private final C1403k f3267c = new C1403k();
        private final int f3268d;
        private int f3269e;
        private int f3270f;
        private int f3271g;

        public C1554c(C1555p c1555p, int i) {
            this.f3265a = c1555p;
            super();
            this.f3268d = i;
        }

        public void mo2210a() {
        }

        public void mo2211a(C1403k c1403k, boolean z, C1567h c1567h) {
            if (z) {
                c1403k.m2762d(c1403k.m2766g());
                c1403k.m2754a(this.f3266b, 3);
                this.f3266b.m2748b(12);
                this.f3269e = this.f3266b.m2750c(12);
                this.f3270f = 0;
                this.f3271g = C1414r.m2814a(this.f3266b.f2475a, 0, 3, -1);
                this.f3267c.m2753a(this.f3269e);
            }
            int min = Math.min(c1403k.m2757b(), this.f3269e - this.f3270f);
            c1403k.m2756a(this.f3267c.f2479a, this.f3270f, min);
            this.f3270f = min + this.f3270f;
            if (this.f3270f >= this.f3269e && C1414r.m2814a(this.f3267c.f2479a, 0, this.f3269e, this.f3271g) == 0) {
                this.f3267c.m2762d(7);
                this.f3267c.m2754a(this.f3266b, 2);
                this.f3266b.m2748b(4);
                min = this.f3266b.m2750c(12);
                this.f3267c.m2762d(min);
                if (this.f3265a.f3276e && this.f3265a.f3286o == null) {
                    this.f3265a.f3286o = this.f3265a.f3281j.mo2209a(21, new C1533a(21, null, new byte[0]));
                    this.f3265a.f3286o.mo2207a(c1567h, new C1534c(21, 8192));
                }
                int i = ((this.f3269e - 9) - min) - 4;
                while (i > 0) {
                    this.f3267c.m2754a(this.f3266b, 5);
                    min = this.f3266b.m2750c(8);
                    this.f3266b.m2748b(3);
                    int c = this.f3266b.m2750c(13);
                    this.f3266b.m2748b(4);
                    int c2 = this.f3266b.m2750c(12);
                    C1533a a = m3480a(this.f3267c, c2);
                    if (min == 6) {
                        min = a.f3112a;
                    }
                    c2 = i - (c2 + 5);
                    if (this.f3265a.f3276e) {
                        i = min;
                    } else {
                        i = c;
                    }
                    if (this.f3265a.f3283l.get(i)) {
                        i = c2;
                    } else {
                        C1525g c3;
                        this.f3265a.f3283l.put(i, true);
                        if (this.f3265a.f3276e && min == 21) {
                            c3 = this.f3265a.f3286o;
                        } else {
                            c3 = this.f3265a.f3281j.mo2209a(min, a);
                            c3.mo2207a(c1567h, new C1534c(i, 8192));
                        }
                        if (c3 != null) {
                            this.f3265a.f3282k.put(c, new C1553b(c3, this.f3265a.f3277f));
                        }
                        i = c2;
                    }
                }
                if (!this.f3265a.f3276e) {
                    this.f3265a.f3282k.remove(0);
                    this.f3265a.f3282k.remove(this.f3268d);
                    c1567h.mo2274a();
                } else if (!this.f3265a.f3285n) {
                    c1567h.mo2274a();
                }
                this.f3265a.f3285n = true;
            }
        }

        private C1533a m3480a(C1403k c1403k, int i) {
            int d = c1403k.m2761d();
            int i2 = d + i;
            int i3 = -1;
            String str = null;
            while (c1403k.m2761d() < i2) {
                int g = c1403k.m2766g();
                int g2 = c1403k.m2766g() + c1403k.m2761d();
                if (g == 5) {
                    long l = c1403k.m2771l();
                    if (l == C1555p.f3273b) {
                        i3 = 129;
                    } else if (l == C1555p.f3274c) {
                        i3 = 135;
                    } else if (l == C1555p.f3275d) {
                        i3 = 36;
                    }
                } else if (g == 106) {
                    i3 = 129;
                } else if (g == 122) {
                    i3 = 135;
                } else if (g == 123) {
                    i3 = 138;
                } else if (g == 10) {
                    str = new String(c1403k.f2479a, c1403k.m2761d(), 3).trim();
                }
                c1403k.m2762d(g2 - c1403k.m2761d());
            }
            c1403k.m2760c(i2);
            return new C1533a(i3, str, Arrays.copyOfRange(this.f3267c.f2479a, d, i2));
        }
    }

    public C1555p() {
        this(new C1572n(0));
    }

    public C1555p(C1572n c1572n) {
        this(c1572n, new C1531e(), false);
    }

    public C1555p(C1572n c1572n, C1530b c1530b, boolean z) {
        this.f3277f = c1572n;
        this.f3281j = (C1530b) C1392a.m2707a((Object) c1530b);
        this.f3276e = z;
        this.f3278g = new C1403k(940);
        this.f3279h = new C1402j(new byte[3]);
        this.f3283l = new SparseBooleanArray();
        this.f3282k = new SparseArray();
        this.f3280i = new SparseIntArray();
        m3493e();
    }

    public boolean mo2171a(C1464g c1464g) {
        byte[] bArr = this.f3278g.f2479a;
        c1464g.mo2187c(bArr, 0, 940);
        int i = 0;
        while (i < 188) {
            int i2 = 0;
            while (i2 != 5) {
                if (bArr[(i2 * 188) + i] != (byte) 71) {
                    i++;
                } else {
                    i2++;
                }
            }
            c1464g.mo2182b(i);
            return true;
        }
        return false;
    }

    public void mo2170a(C1567h c1567h) {
        this.f3284m = c1567h;
        c1567h.mo2276a(new C1571a(-9223372036854775807L));
    }

    public void mo2169a(long j) {
        this.f3277f.m3575a();
        this.f3278g.m2752a();
        this.f3280i.clear();
        m3493e();
    }

    public void mo2172c() {
    }

    public int mo2168a(C1464g c1464g, C1570l c1570l) {
        int b;
        int a;
        byte[] bArr = this.f3278g.f2479a;
        if (940 - this.f3278g.m2761d() < 188) {
            b = this.f3278g.m2757b();
            if (b > 0) {
                System.arraycopy(bArr, this.f3278g.m2761d(), bArr, 0, b);
            }
            this.f3278g.m2755a(bArr, b);
        }
        while (this.f3278g.m2757b() < 188) {
            b = this.f3278g.m2759c();
            a = c1464g.mo2178a(bArr, b, 940 - b);
            if (a == -1) {
                return -1;
            }
            this.f3278g.m2758b(b + a);
        }
        b = this.f3278g.m2759c();
        int d = this.f3278g.m2761d();
        while (d < b && bArr[d] != (byte) 71) {
            d++;
        }
        this.f3278g.m2760c(d);
        a = d + 188;
        if (a > b) {
            return 0;
        }
        this.f3278g.m2762d(1);
        this.f3278g.m2754a(this.f3279h, 3);
        if (this.f3279h.m2749b()) {
            this.f3278g.m2760c(a);
            return 0;
        }
        boolean b2 = this.f3279h.m2749b();
        this.f3279h.m2748b(1);
        d = this.f3279h.m2750c(13);
        this.f3279h.m2748b(2);
        boolean b3 = this.f3279h.m2749b();
        boolean b4 = this.f3279h.m2749b();
        int c = this.f3279h.m2750c(4);
        int i = this.f3280i.get(d, c - 1);
        this.f3280i.put(d, c);
        if (i == c) {
            this.f3278g.m2760c(a);
            return 0;
        }
        if (c != (i + 1) % 16) {
            c = 1;
        } else {
            c = 0;
        }
        if (b3) {
            this.f3278g.m2762d(this.f3278g.m2766g());
        }
        if (b4) {
            C1551d c1551d = (C1551d) this.f3282k.get(d);
            if (c1551d != null) {
                if (c != 0) {
                    c1551d.mo2210a();
                }
                this.f3278g.m2758b(a);
                c1551d.mo2211a(this.f3278g, b2, this.f3284m);
                C1392a.m2711b(this.f3278g.m2761d() <= a);
                this.f3278g.m2758b(b);
            }
        }
        this.f3278g.m2760c(a);
        return 0;
    }

    private void m3493e() {
        this.f3283l.clear();
        this.f3282k.clear();
        this.f3282k.put(0, new C1552a(this));
        this.f3286o = null;
    }
}
