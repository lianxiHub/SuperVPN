package com.google.android.exoplayer2.extractor.p038e;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.extractor.C1569k;
import com.google.android.exoplayer2.extractor.p038e.C1525g.C1534c;
import com.google.android.exoplayer2.p031c.C1403k;

final class C1544l extends C1525g {
    private final C1403k f3214a;
    private final C1569k f3215b;
    private final String f3216c;
    private C1521o f3217d;
    private int f3218e;
    private int f3219f;
    private boolean f3220g;
    private boolean f3221h;
    private long f3222i;
    private int f3223j;
    private long f3224k;

    public C1544l() {
        this(null);
    }

    public C1544l(String str) {
        this.f3218e = 0;
        this.f3214a = new C1403k(4);
        this.f3214a.f2479a[0] = (byte) -1;
        this.f3215b = new C1569k();
        this.f3216c = str;
    }

    public void mo2204a() {
        this.f3218e = 0;
        this.f3219f = 0;
        this.f3221h = false;
    }

    public void mo2207a(C1567h c1567h, C1534c c1534c) {
        this.f3217d = c1567h.mo2273a(c1534c.m3392a());
    }

    public void mo2205a(long j, boolean z) {
        this.f3224k = j;
    }

    public void mo2206a(C1403k c1403k) {
        while (c1403k.m2757b() > 0) {
            switch (this.f3218e) {
                case 0:
                    m3445b(c1403k);
                    break;
                case 1:
                    m3446c(c1403k);
                    break;
                case 2:
                    m3447d(c1403k);
                    break;
                default:
                    break;
            }
        }
    }

    public void mo2208b() {
    }

    private void m3445b(C1403k c1403k) {
        byte[] bArr = c1403k.f2479a;
        int d = c1403k.m2761d();
        int c = c1403k.m2759c();
        int i = d;
        while (i < c) {
            boolean z = (bArr[i] & 255) == 255;
            if (this.f3221h && (bArr[i] & 224) == 224) {
                int i2 = 1;
            } else {
                boolean z2 = false;
            }
            this.f3221h = z;
            if (i2 != 0) {
                c1403k.m2760c(i + 1);
                this.f3221h = false;
                this.f3214a.f2479a[1] = bArr[i];
                this.f3219f = 2;
                this.f3218e = 1;
                return;
            }
            i++;
        }
        c1403k.m2760c(c);
    }

    private void m3446c(C1403k c1403k) {
        int min = Math.min(c1403k.m2757b(), 4 - this.f3219f);
        c1403k.m2756a(this.f3214a.f2479a, this.f3219f, min);
        this.f3219f = min + this.f3219f;
        if (this.f3219f >= 4) {
            this.f3214a.m2760c(0);
            if (C1569k.m3568a(this.f3214a.m2773n(), this.f3215b)) {
                this.f3223j = this.f3215b.f3340c;
                if (!this.f3220g) {
                    this.f3222i = (1000000 * ((long) this.f3215b.f3344g)) / ((long) this.f3215b.f3341d);
                    this.f3217d.mo2202a(Format.m2407a(null, this.f3215b.f3339b, null, -1, 4096, this.f3215b.f3342e, this.f3215b.f3341d, null, null, 0, this.f3216c));
                    this.f3220g = true;
                }
                this.f3214a.m2760c(0);
                this.f3217d.mo2203a(this.f3214a, 4);
                this.f3218e = 2;
                return;
            }
            this.f3219f = 0;
            this.f3218e = 1;
        }
    }

    private void m3447d(C1403k c1403k) {
        int min = Math.min(c1403k.m2757b(), this.f3223j - this.f3219f);
        this.f3217d.mo2203a(c1403k, min);
        this.f3219f = min + this.f3219f;
        if (this.f3219f >= this.f3223j) {
            this.f3217d.mo2201a(this.f3224k, 1, this.f3223j, 0, null);
            this.f3224k += this.f3222i;
            this.f3219f = 0;
            this.f3218e = 0;
        }
    }
}
