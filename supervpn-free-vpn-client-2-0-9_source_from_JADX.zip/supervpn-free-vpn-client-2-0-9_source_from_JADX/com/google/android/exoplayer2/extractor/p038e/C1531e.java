package com.google.android.exoplayer2.extractor.p038e;

import com.google.android.exoplayer2.extractor.p038e.C1525g.C1530b;
import com.google.android.exoplayer2.extractor.p038e.C1525g.C1533a;

public final class C1531e implements C1530b {
    private final int f3101a;

    public C1531e() {
        this(0);
    }

    public C1531e(int i) {
        this.f3101a = i;
    }

    public C1525g mo2209a(int i, C1533a c1533a) {
        boolean z = true;
        switch (i) {
            case 2:
                return new C1536h();
            case 3:
            case 4:
                return new C1544l(c1533a.f3113b);
            case 15:
                if ((this.f3101a & 2) == 0) {
                    return new C1529d(false, c1533a.f3113b);
                }
                return null;
            case 21:
                return new C1543k();
            case 27:
                if ((this.f3101a & 4) != 0) {
                    return null;
                }
                boolean z2 = (this.f3101a & 1) != 0;
                if ((this.f3101a & 8) == 0) {
                    z = false;
                }
                return new C1540i(z2, z);
            case 36:
                return new C1542j();
            case 129:
            case 135:
                return new C1526b(c1533a.f3113b);
            case 130:
            case 138:
                return new C1532f(c1533a.f3113b);
            default:
                return null;
        }
    }
}
