package com.google.android.exoplayer2.extractor.p038e;

import android.util.Pair;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.extractor.p038e.C1525g.C1534c;
import com.google.android.exoplayer2.p031c.C1401i;
import com.google.android.exoplayer2.p031c.C1403k;
import com.mopub.volley.DefaultRetryPolicy;
import java.util.Arrays;
import java.util.Collections;

final class C1536h extends C1525g {
    private static final double[] f3122b = new double[]{23.976023976023978d, 24.0d, 25.0d, 29.97002997002997d, 30.0d, 50.0d, 59.94005994005994d, 60.0d};
    private C1521o f3123a;
    private boolean f3124c;
    private long f3125d;
    private final boolean[] f3126e = new boolean[4];
    private final C1535a f3127f = new C1535a(128);
    private boolean f3128g;
    private long f3129h;
    private long f3130i;
    private boolean f3131j;
    private boolean f3132k;
    private long f3133l;
    private long f3134m;

    private static final class C1535a {
        public int f3118a;
        public int f3119b;
        public byte[] f3120c;
        private boolean f3121d;

        public C1535a(int i) {
            this.f3120c = new byte[i];
        }

        public void m3393a() {
            this.f3121d = false;
            this.f3118a = 0;
            this.f3119b = 0;
        }

        public boolean m3395a(int i, int i2) {
            if (this.f3121d) {
                if (this.f3119b == 0 && i == 181) {
                    this.f3119b = this.f3118a;
                } else {
                    this.f3118a -= i2;
                    this.f3121d = false;
                    return true;
                }
            } else if (i == 179) {
                this.f3121d = true;
            }
            return false;
        }

        public void m3394a(byte[] bArr, int i, int i2) {
            if (this.f3121d) {
                int i3 = i2 - i;
                if (this.f3120c.length < this.f3118a + i3) {
                    this.f3120c = Arrays.copyOf(this.f3120c, (this.f3118a + i3) * 2);
                }
                System.arraycopy(bArr, i, this.f3120c, this.f3118a, i3);
                this.f3118a = i3 + this.f3118a;
            }
        }
    }

    public void mo2204a() {
        C1401i.m2740a(this.f3126e);
        this.f3127f.m3393a();
        this.f3131j = false;
        this.f3128g = false;
        this.f3129h = 0;
    }

    public void mo2207a(C1567h c1567h, C1534c c1534c) {
        this.f3123a = c1567h.mo2273a(c1534c.m3392a());
    }

    public void mo2205a(long j, boolean z) {
        this.f3131j = j != -9223372036854775807L;
        if (this.f3131j) {
            this.f3130i = j;
        }
    }

    public void mo2206a(C1403k c1403k) {
        int d = c1403k.m2761d();
        int c = c1403k.m2759c();
        byte[] bArr = c1403k.f2479a;
        this.f3129h += (long) c1403k.m2757b();
        this.f3123a.mo2203a(c1403k, c1403k.m2757b());
        int i = d;
        while (true) {
            int a = C1401i.m2736a(bArr, d, c, this.f3126e);
            if (a == c) {
                break;
            }
            int i2 = c1403k.f2479a[a + 3] & 255;
            if (!this.f3124c) {
                d = a - i;
                if (d > 0) {
                    this.f3127f.m3394a(bArr, i, a);
                }
                if (this.f3127f.m3395a(i2, d < 0 ? -d : 0)) {
                    Pair a2 = C1536h.m3396a(this.f3127f);
                    this.f3123a.mo2202a((Format) a2.first);
                    this.f3125d = ((Long) a2.second).longValue();
                    this.f3124c = true;
                }
            }
            if (this.f3124c && (i2 == 184 || i2 == 0)) {
                int i3 = c - a;
                if (this.f3128g) {
                    this.f3123a.mo2201a(this.f3134m, this.f3132k ? 1 : 0, ((int) (this.f3129h - this.f3133l)) - i3, i3, null);
                    this.f3132k = false;
                }
                if (i2 == 184) {
                    this.f3128g = false;
                    this.f3132k = true;
                } else {
                    this.f3134m = this.f3131j ? this.f3130i : this.f3134m + this.f3125d;
                    this.f3133l = this.f3129h - ((long) i3);
                    this.f3131j = false;
                    this.f3128g = true;
                }
            }
            d = a + 3;
            i = a;
        }
        if (!this.f3124c) {
            this.f3127f.m3394a(bArr, i, c);
        }
    }

    public void mo2208b() {
    }

    private static Pair m3396a(C1535a c1535a) {
        Object copyOf = Arrays.copyOf(c1535a.f3120c, c1535a.f3118a);
        int i = copyOf[5] & 255;
        int i2 = i >> 4;
        i2 |= (copyOf[4] & 255) << 4;
        int i3 = ((i & 15) << 8) | (copyOf[6] & 255);
        float f = DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;
        switch ((copyOf[7] & 240) >> 4) {
            case 2:
                f = ((float) (i3 * 4)) / ((float) (i2 * 3));
                break;
            case 3:
                f = ((float) (i3 * 16)) / ((float) (i2 * 9));
                break;
            case 4:
                f = ((float) (i3 * 121)) / ((float) (i2 * 100));
                break;
        }
        Format a = Format.m2403a(null, "video/mpeg2", null, -1, -1, i2, i3, -1.0f, Collections.singletonList(copyOf), -1, f, null);
        long j = 0;
        int i4 = (copyOf[7] & 15) - 1;
        if (i4 >= 0 && i4 < f3122b.length) {
            double d = f3122b[i4];
            i4 = c1535a.f3119b;
            int i5 = (copyOf[i4 + 9] & 96) >> 5;
            i4 = copyOf[i4 + 9] & 31;
            if (i5 != i4) {
                d *= (((double) i5) + 1.0d) / ((double) (i4 + 1));
            }
            j = (long) (1000000.0d / d);
        }
        return Pair.create(a, Long.valueOf(j));
    }
}
