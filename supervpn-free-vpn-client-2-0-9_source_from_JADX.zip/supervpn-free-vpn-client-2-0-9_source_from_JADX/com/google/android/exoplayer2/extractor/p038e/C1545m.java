package com.google.android.exoplayer2.extractor.p038e;

import com.google.android.exoplayer2.p031c.C1392a;
import java.util.Arrays;

final class C1545m {
    public byte[] f3225a;
    public int f3226b;
    private final int f3227c;
    private boolean f3228d;
    private boolean f3229e;

    public C1545m(int i, int i2) {
        this.f3227c = i;
        this.f3225a = new byte[(i2 + 3)];
        this.f3225a[2] = (byte) 1;
    }

    public void m3453a() {
        this.f3228d = false;
        this.f3229e = false;
    }

    public boolean m3456b() {
        return this.f3229e;
    }

    public void m3454a(int i) {
        boolean z = true;
        C1392a.m2711b(!this.f3228d);
        if (i != this.f3227c) {
            z = false;
        }
        this.f3228d = z;
        if (this.f3228d) {
            this.f3226b = 3;
            this.f3229e = false;
        }
    }

    public void m3455a(byte[] bArr, int i, int i2) {
        if (this.f3228d) {
            int i3 = i2 - i;
            if (this.f3225a.length < this.f3226b + i3) {
                this.f3225a = Arrays.copyOf(this.f3225a, (this.f3226b + i3) * 2);
            }
            System.arraycopy(bArr, i, this.f3225a, this.f3226b, i3);
            this.f3226b = i3 + this.f3226b;
        }
    }

    public boolean m3457b(int i) {
        if (!this.f3228d) {
            return false;
        }
        this.f3226b -= i;
        this.f3228d = false;
        this.f3229e = true;
        return true;
    }
}
