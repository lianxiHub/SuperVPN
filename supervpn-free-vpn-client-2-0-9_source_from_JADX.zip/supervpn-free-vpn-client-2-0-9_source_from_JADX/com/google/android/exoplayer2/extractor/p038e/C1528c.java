package com.google.android.exoplayer2.extractor.p038e;

import android.support.v7.widget.helper.ItemTouchHelper.Callback;
import com.google.android.exoplayer2.extractor.C1447i;
import com.google.android.exoplayer2.extractor.C1451f;
import com.google.android.exoplayer2.extractor.C1455m.C1571a;
import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.extractor.C1570l;
import com.google.android.exoplayer2.extractor.p038e.C1525g.C1534c;
import com.google.android.exoplayer2.p031c.C1402j;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1414r;

public final class C1528c implements C1451f {
    public static final C1447i f3078a = new C15271();
    private static final int f3079b = C1414r.m2830e("ID3");
    private final long f3080c;
    private final C1403k f3081d;
    private C1529d f3082e;
    private boolean f3083f;

    static class C15271 implements C1447i {
        C15271() {
        }

        public C1451f[] mo2159a() {
            return new C1451f[]{new C1528c()};
        }
    }

    public C1528c() {
        this(0);
    }

    public C1528c(long j) {
        this.f3080c = j;
        this.f3081d = new C1403k((int) Callback.DEFAULT_DRAG_ANIMATION_DURATION);
    }

    public boolean mo2171a(C1464g c1464g) {
        int s;
        C1403k c1403k = new C1403k(10);
        C1402j c1402j = new C1402j(c1403k.f2479a);
        int i = 0;
        while (true) {
            c1464g.mo2187c(c1403k.f2479a, 0, 10);
            c1403k.m2760c(0);
            if (c1403k.m2770k() != f3079b) {
                break;
            }
            c1403k.m2762d(3);
            s = c1403k.m2778s();
            i += s + 10;
            c1464g.mo2186c(s);
        }
        c1464g.mo2179a();
        c1464g.mo2186c(i);
        s = 0;
        int i2 = 0;
        int i3 = i;
        while (true) {
            c1464g.mo2187c(c1403k.f2479a, 0, 2);
            c1403k.m2760c(0);
            if ((c1403k.m2767h() & 65526) != 65520) {
                c1464g.mo2179a();
                i3++;
                if (i3 - i >= 8192) {
                    return false;
                }
                c1464g.mo2186c(i3);
                s = 0;
                i2 = 0;
            } else {
                s++;
                if (s >= 4 && i2 > 188) {
                    return true;
                }
                c1464g.mo2187c(c1403k.f2479a, 0, 4);
                c1402j.m2747a(14);
                int c = c1402j.m2750c(13);
                if (c <= 6) {
                    return false;
                }
                c1464g.mo2186c(c - 6);
                i2 += c;
            }
        }
    }

    public void mo2170a(C1567h c1567h) {
        this.f3082e = new C1529d(true);
        this.f3082e.mo2207a(c1567h, new C1534c(0, 1));
        c1567h.mo2274a();
        c1567h.mo2276a(new C1571a(-9223372036854775807L));
    }

    public void mo2169a(long j) {
        this.f3083f = false;
        this.f3082e.mo2204a();
    }

    public void mo2172c() {
    }

    public int mo2168a(C1464g c1464g, C1570l c1570l) {
        int a = c1464g.mo2178a(this.f3081d.f2479a, 0, Callback.DEFAULT_DRAG_ANIMATION_DURATION);
        if (a == -1) {
            return -1;
        }
        this.f3081d.m2760c(0);
        this.f3081d.m2758b(a);
        if (!this.f3083f) {
            this.f3082e.mo2205a(this.f3080c, true);
            this.f3083f = true;
        }
        this.f3082e.mo2206a(this.f3081d);
        return 0;
    }
}
