package com.google.android.exoplayer2.extractor.p038e;

import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.p031c.C1403k;

public abstract class C1525g {

    public interface C1530b {
        C1525g mo2209a(int i, C1533a c1533a);
    }

    public static final class C1533a {
        public final int f3112a;
        public String f3113b;
        public byte[] f3114c;

        public C1533a(int i, String str, byte[] bArr) {
            this.f3112a = i;
            this.f3113b = str;
            this.f3114c = bArr;
        }
    }

    public static final class C1534c {
        private final int f3115a;
        private final int f3116b;
        private int f3117c;

        public C1534c(int i, int i2) {
            this.f3115a = i;
            this.f3116b = i2;
        }

        public int m3392a() {
            int i = this.f3115a;
            int i2 = this.f3116b;
            int i3 = this.f3117c;
            this.f3117c = i3 + 1;
            return i + (i2 * i3);
        }
    }

    public abstract void mo2204a();

    public abstract void mo2205a(long j, boolean z);

    public abstract void mo2206a(C1403k c1403k);

    public abstract void mo2207a(C1567h c1567h, C1534c c1534c);

    public abstract void mo2208b();
}
