package com.google.android.exoplayer2.extractor.p038e;

import android.support.v4.app.FrameMetricsAggregator;
import android.util.Log;
import android.util.Pair;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.extractor.C1556e;
import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.extractor.p038e.C1525g.C1534c;
import com.google.android.exoplayer2.p031c.C1393b;
import com.google.android.exoplayer2.p031c.C1402j;
import com.google.android.exoplayer2.p031c.C1403k;
import java.util.Arrays;
import java.util.Collections;

final class C1529d extends C1525g {
    private static final byte[] f3084a = new byte[]{(byte) 73, (byte) 68, (byte) 51};
    private final boolean f3085b;
    private final C1402j f3086c;
    private final C1403k f3087d;
    private final String f3088e;
    private C1521o f3089f;
    private C1521o f3090g;
    private int f3091h;
    private int f3092i;
    private int f3093j;
    private boolean f3094k;
    private boolean f3095l;
    private long f3096m;
    private int f3097n;
    private long f3098o;
    private C1521o f3099p;
    private long f3100q;

    public C1529d(boolean z) {
        this(z, null);
    }

    public C1529d(boolean z, String str) {
        this.f3086c = new C1402j(new byte[7]);
        this.f3087d = new C1403k(Arrays.copyOf(f3084a, 10));
        m3371c();
        this.f3085b = z;
        this.f3088e = str;
    }

    public void mo2204a() {
        m3371c();
    }

    public void mo2207a(C1567h c1567h, C1534c c1534c) {
        this.f3089f = c1567h.mo2273a(c1534c.m3392a());
        if (this.f3085b) {
            this.f3090g = c1567h.mo2273a(c1534c.m3392a());
            this.f3090g.mo2202a(Format.m2410a(null, "application/id3", null, -1, null));
            return;
        }
        this.f3090g = new C1556e();
    }

    public void mo2205a(long j, boolean z) {
        this.f3098o = j;
    }

    public void mo2206a(C1403k c1403k) {
        while (c1403k.m2757b() > 0) {
            switch (this.f3091h) {
                case 0:
                    m3370b(c1403k);
                    break;
                case 1:
                    if (!m3369a(c1403k, this.f3087d.f2479a, 10)) {
                        break;
                    }
                    m3375f();
                    break;
                case 2:
                    if (!m3369a(c1403k, this.f3086c.f2475a, this.f3094k ? 7 : 5)) {
                        break;
                    }
                    m3376g();
                    break;
                case 3:
                    m3372c(c1403k);
                    break;
                default:
                    break;
            }
        }
    }

    public void mo2208b() {
    }

    private boolean m3369a(C1403k c1403k, byte[] bArr, int i) {
        int min = Math.min(c1403k.m2757b(), i - this.f3092i);
        c1403k.m2756a(bArr, this.f3092i, min);
        this.f3092i = min + this.f3092i;
        return this.f3092i == i;
    }

    private void m3371c() {
        this.f3091h = 0;
        this.f3092i = 0;
        this.f3093j = 256;
    }

    private void m3373d() {
        this.f3091h = 1;
        this.f3092i = f3084a.length;
        this.f3097n = 0;
        this.f3087d.m2760c(0);
    }

    private void m3368a(C1521o c1521o, long j, int i, int i2) {
        this.f3091h = 3;
        this.f3092i = i;
        this.f3099p = c1521o;
        this.f3100q = j;
        this.f3097n = i2;
    }

    private void m3374e() {
        this.f3091h = 2;
        this.f3092i = 0;
    }

    private void m3370b(C1403k c1403k) {
        byte[] bArr = c1403k.f2479a;
        int d = c1403k.m2761d();
        int c = c1403k.m2759c();
        while (d < c) {
            int i = d + 1;
            d = bArr[d] & 255;
            if (this.f3093j != 512 || d < 240 || d == 255) {
                switch (d | this.f3093j) {
                    case 329:
                        this.f3093j = 768;
                        d = i;
                        break;
                    case FrameMetricsAggregator.EVERY_DURATION /*511*/:
                        this.f3093j = 512;
                        d = i;
                        break;
                    case 836:
                        this.f3093j = 1024;
                        d = i;
                        break;
                    case 1075:
                        m3373d();
                        c1403k.m2760c(i);
                        return;
                    default:
                        if (this.f3093j == 256) {
                            d = i;
                            break;
                        }
                        this.f3093j = 256;
                        d = i - 1;
                        break;
                }
            }
            this.f3094k = (d & 1) == 0;
            m3374e();
            c1403k.m2760c(i);
            return;
        }
        c1403k.m2760c(d);
    }

    private void m3375f() {
        this.f3090g.mo2203a(this.f3087d, 10);
        this.f3087d.m2760c(6);
        m3368a(this.f3090g, 0, 10, this.f3087d.m2778s() + 10);
    }

    private void m3376g() {
        int i = 2;
        this.f3086c.m2747a(0);
        if (this.f3095l) {
            this.f3086c.m2748b(10);
        } else {
            int c = this.f3086c.m2750c(2) + 1;
            if (c != 2) {
                Log.w("AdtsReader", "Detected audio object type: " + c + ", but assuming AAC LC.");
            } else {
                i = c;
            }
            c = this.f3086c.m2750c(4);
            this.f3086c.m2748b(1);
            Object a = C1393b.m2714a(i, c, this.f3086c.m2750c(3));
            Pair a2 = C1393b.m2713a(a);
            Format a3 = Format.m2407a(null, "audio/mp4a-latm", null, -1, -1, ((Integer) a2.second).intValue(), ((Integer) a2.first).intValue(), Collections.singletonList(a), null, 0, this.f3088e);
            this.f3096m = 1024000000 / ((long) a3.f2195q);
            this.f3089f.mo2202a(a3);
            this.f3095l = true;
        }
        this.f3086c.m2748b(4);
        int c2 = (this.f3086c.m2750c(13) - 2) - 5;
        if (this.f3094k) {
            c2 -= 2;
        }
        m3368a(this.f3089f, this.f3096m, 0, c2);
    }

    private void m3372c(C1403k c1403k) {
        int min = Math.min(c1403k.m2757b(), this.f3097n - this.f3092i);
        this.f3099p.mo2203a(c1403k, min);
        this.f3092i = min + this.f3092i;
        if (this.f3092i == this.f3097n) {
            this.f3099p.mo2201a(this.f3098o, 1, this.f3097n, 0, null);
            this.f3098o += this.f3100q;
            m3371c();
        }
    }
}
