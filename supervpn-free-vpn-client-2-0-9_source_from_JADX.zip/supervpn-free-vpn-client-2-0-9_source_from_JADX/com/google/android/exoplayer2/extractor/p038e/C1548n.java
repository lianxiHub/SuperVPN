package com.google.android.exoplayer2.extractor.p038e;

import android.support.v4.media.session.PlaybackStateCompat;
import android.support.v4.view.InputDeviceCompat;
import android.util.SparseArray;
import com.google.android.exoplayer2.extractor.C1447i;
import com.google.android.exoplayer2.extractor.C1451f;
import com.google.android.exoplayer2.extractor.C1455m.C1571a;
import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.extractor.C1570l;
import com.google.android.exoplayer2.extractor.C1572n;
import com.google.android.exoplayer2.extractor.p038e.C1525g.C1534c;
import com.google.android.exoplayer2.p031c.C1402j;
import com.google.android.exoplayer2.p031c.C1403k;

public final class C1548n implements C1451f {
    public static final C1447i f3238a = new C15461();
    private final C1572n f3239b;
    private final SparseArray f3240c;
    private final C1403k f3241d;
    private boolean f3242e;
    private boolean f3243f;
    private boolean f3244g;
    private C1567h f3245h;

    static class C15461 implements C1447i {
        C15461() {
        }

        public C1451f[] mo2159a() {
            return new C1451f[]{new C1548n()};
        }
    }

    private static final class C1547a {
        private final C1525g f3230a;
        private final C1572n f3231b;
        private final C1402j f3232c = new C1402j(new byte[64]);
        private boolean f3233d;
        private boolean f3234e;
        private boolean f3235f;
        private int f3236g;
        private long f3237h;

        public C1547a(C1525g c1525g, C1572n c1572n) {
            this.f3230a = c1525g;
            this.f3231b = c1572n;
        }

        public void m3461a() {
            this.f3235f = false;
            this.f3230a.mo2204a();
        }

        public void m3462a(C1403k c1403k) {
            c1403k.m2756a(this.f3232c.f2475a, 0, 3);
            this.f3232c.m2747a(0);
            m3459b();
            c1403k.m2756a(this.f3232c.f2475a, 0, this.f3236g);
            this.f3232c.m2747a(0);
            m3460c();
            this.f3230a.mo2205a(this.f3237h, true);
            this.f3230a.mo2206a(c1403k);
            this.f3230a.mo2208b();
        }

        private void m3459b() {
            this.f3232c.m2748b(8);
            this.f3233d = this.f3232c.m2749b();
            this.f3234e = this.f3232c.m2749b();
            this.f3232c.m2748b(6);
            this.f3236g = this.f3232c.m2750c(8);
        }

        private void m3460c() {
            this.f3237h = 0;
            if (this.f3233d) {
                this.f3232c.m2748b(4);
                long c = ((long) this.f3232c.m2750c(3)) << 30;
                this.f3232c.m2748b(1);
                c |= (long) (this.f3232c.m2750c(15) << 15);
                this.f3232c.m2748b(1);
                c |= (long) this.f3232c.m2750c(15);
                this.f3232c.m2748b(1);
                if (!this.f3235f && this.f3234e) {
                    this.f3232c.m2748b(4);
                    long c2 = ((long) this.f3232c.m2750c(3)) << 30;
                    this.f3232c.m2748b(1);
                    c2 |= (long) (this.f3232c.m2750c(15) << 15);
                    this.f3232c.m2748b(1);
                    c2 |= (long) this.f3232c.m2750c(15);
                    this.f3232c.m2748b(1);
                    this.f3231b.m3574a(c2);
                    this.f3235f = true;
                }
                this.f3237h = this.f3231b.m3574a(c);
            }
        }
    }

    public C1548n() {
        this(new C1572n(0));
    }

    public C1548n(C1572n c1572n) {
        this.f3239b = c1572n;
        this.f3241d = new C1403k(4096);
        this.f3240c = new SparseArray();
    }

    public boolean mo2171a(C1464g c1464g) {
        boolean z = true;
        byte[] bArr = new byte[14];
        c1464g.mo2187c(bArr, 0, 14);
        if (442 != (((((bArr[0] & 255) << 24) | ((bArr[1] & 255) << 16)) | ((bArr[2] & 255) << 8)) | (bArr[3] & 255)) || (bArr[4] & 196) != 68 || (bArr[6] & 4) != 4 || (bArr[8] & 4) != 4 || (bArr[9] & 1) != 1 || (bArr[12] & 3) != 3) {
            return false;
        }
        c1464g.mo2186c(bArr[13] & 7);
        c1464g.mo2187c(bArr, 0, 3);
        if (1 != ((bArr[2] & 255) | (((bArr[0] & 255) << 16) | ((bArr[1] & 255) << 8)))) {
            z = false;
        }
        return z;
    }

    public void mo2170a(C1567h c1567h) {
        this.f3245h = c1567h;
        c1567h.mo2276a(new C1571a(-9223372036854775807L));
    }

    public void mo2169a(long j) {
        this.f3239b.m3575a();
        for (int i = 0; i < this.f3240c.size(); i++) {
            ((C1547a) this.f3240c.valueAt(i)).m3461a();
        }
    }

    public void mo2172c() {
    }

    public int mo2168a(C1464g c1464g, C1570l c1570l) {
        if (!c1464g.mo2184b(this.f3241d.f2479a, 0, 4, true)) {
            return -1;
        }
        this.f3241d.m2760c(0);
        int n = this.f3241d.m2773n();
        if (n == 441) {
            return -1;
        }
        if (n == 442) {
            c1464g.mo2187c(this.f3241d.f2479a, 0, 10);
            this.f3241d.m2760c(9);
            c1464g.mo2182b((this.f3241d.m2766g() & 7) + 14);
            return 0;
        } else if (n == 443) {
            c1464g.mo2187c(this.f3241d.f2479a, 0, 2);
            this.f3241d.m2760c(0);
            c1464g.mo2182b(this.f3241d.m2767h() + 6);
            return 0;
        } else if (((n & InputDeviceCompat.SOURCE_ANY) >> 8) != 1) {
            c1464g.mo2182b(1);
            return 0;
        } else {
            int i = n & 255;
            C1547a c1547a = (C1547a) this.f3240c.get(i);
            if (!this.f3242e) {
                if (c1547a == null) {
                    C1525g c1525g = null;
                    if (!this.f3243f && i == 189) {
                        c1525g = new C1526b();
                        this.f3243f = true;
                    } else if (!this.f3243f && (i & 224) == 192) {
                        c1525g = new C1544l();
                        this.f3243f = true;
                    } else if (!this.f3244g && (i & 240) == 224) {
                        c1525g = new C1536h();
                        this.f3244g = true;
                    }
                    if (c1525g != null) {
                        c1525g.mo2207a(this.f3245h, new C1534c(i, 256));
                        c1547a = new C1547a(c1525g, this.f3239b);
                        this.f3240c.put(i, c1547a);
                    }
                }
                if ((this.f3243f && this.f3244g) || c1464g.mo2185c() > PlaybackStateCompat.ACTION_SET_CAPTIONING_ENABLED) {
                    this.f3242e = true;
                    this.f3245h.mo2274a();
                }
            }
            c1464g.mo2187c(this.f3241d.f2479a, 0, 2);
            this.f3241d.m2760c(0);
            n = this.f3241d.m2767h() + 6;
            if (c1547a == null) {
                c1464g.mo2182b(n);
            } else {
                this.f3241d.m2753a(n);
                c1464g.mo2183b(this.f3241d.f2479a, 0, n);
                this.f3241d.m2760c(6);
                c1547a.m3462a(this.f3241d);
                this.f3241d.m2758b(this.f3241d.m2763e());
            }
            return 0;
        }
    }
}
