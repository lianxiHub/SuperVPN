package com.google.android.exoplayer2.extractor.p038e;

import android.util.SparseArray;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.extractor.p038e.C1525g.C1534c;
import com.google.android.exoplayer2.p031c.C1401i;
import com.google.android.exoplayer2.p031c.C1401i.C1399a;
import com.google.android.exoplayer2.p031c.C1401i.C1400b;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1404l;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

final class C1540i extends C1525g {
    private final boolean f3169a;
    private final boolean f3170b;
    private final C1545m f3171c;
    private final C1545m f3172d;
    private final C1545m f3173e;
    private long f3174f;
    private final boolean[] f3175g = new boolean[3];
    private C1521o f3176h;
    private C1549o f3177i;
    private C1539a f3178j;
    private boolean f3179k;
    private long f3180l;
    private final C1403k f3181m;

    private static final class C1539a {
        private final C1521o f3151a;
        private final boolean f3152b;
        private final boolean f3153c;
        private final SparseArray f3154d = new SparseArray();
        private final SparseArray f3155e = new SparseArray();
        private final C1404l f3156f = new C1404l(this.f3157g, 0, 0);
        private byte[] f3157g = new byte[128];
        private int f3158h;
        private int f3159i;
        private long f3160j;
        private boolean f3161k;
        private long f3162l;
        private C1538a f3163m = new C1538a();
        private C1538a f3164n = new C1538a();
        private boolean f3165o;
        private long f3166p;
        private long f3167q;
        private boolean f3168r;

        private static final class C1538a {
            private boolean f3135a;
            private boolean f3136b;
            private C1400b f3137c;
            private int f3138d;
            private int f3139e;
            private int f3140f;
            private int f3141g;
            private boolean f3142h;
            private boolean f3143i;
            private boolean f3144j;
            private boolean f3145k;
            private int f3146l;
            private int f3147m;
            private int f3148n;
            private int f3149o;
            private int f3150p;

            private C1538a() {
            }

            public void m3404a() {
                this.f3136b = false;
                this.f3135a = false;
            }

            public void m3405a(int i) {
                this.f3139e = i;
                this.f3136b = true;
            }

            public void m3406a(C1400b c1400b, int i, int i2, int i3, int i4, boolean z, boolean z2, boolean z3, boolean z4, int i5, int i6, int i7, int i8, int i9) {
                this.f3137c = c1400b;
                this.f3138d = i;
                this.f3139e = i2;
                this.f3140f = i3;
                this.f3141g = i4;
                this.f3142h = z;
                this.f3143i = z2;
                this.f3144j = z3;
                this.f3145k = z4;
                this.f3146l = i5;
                this.f3147m = i6;
                this.f3148n = i7;
                this.f3149o = i8;
                this.f3150p = i9;
                this.f3135a = true;
                this.f3136b = true;
            }

            public boolean m3407b() {
                return this.f3136b && (this.f3139e == 7 || this.f3139e == 2);
            }

            private boolean m3402a(C1538a c1538a) {
                if (this.f3135a) {
                    if (!c1538a.f3135a || this.f3140f != c1538a.f3140f || this.f3141g != c1538a.f3141g || this.f3142h != c1538a.f3142h) {
                        return true;
                    }
                    if (this.f3143i && c1538a.f3143i && this.f3144j != c1538a.f3144j) {
                        return true;
                    }
                    if (this.f3138d != c1538a.f3138d && (this.f3138d == 0 || c1538a.f3138d == 0)) {
                        return true;
                    }
                    if (this.f3137c.f2468h == 0 && c1538a.f3137c.f2468h == 0 && (this.f3147m != c1538a.f3147m || this.f3148n != c1538a.f3148n)) {
                        return true;
                    }
                    if ((this.f3137c.f2468h == 1 && c1538a.f3137c.f2468h == 1 && (this.f3149o != c1538a.f3149o || this.f3150p != c1538a.f3150p)) || this.f3145k != c1538a.f3145k) {
                        return true;
                    }
                    if (this.f3145k && c1538a.f3145k && this.f3146l != c1538a.f3146l) {
                        return true;
                    }
                }
                return false;
            }
        }

        public C1539a(C1521o c1521o, boolean z, boolean z2) {
            this.f3151a = c1521o;
            this.f3152b = z;
            this.f3153c = z2;
            m3415b();
        }

        public boolean m3414a() {
            return this.f3153c;
        }

        public void m3412a(C1400b c1400b) {
            this.f3154d.append(c1400b.f2461a, c1400b);
        }

        public void m3411a(C1399a c1399a) {
            this.f3155e.append(c1399a.f2458a, c1399a);
        }

        public void m3415b() {
            this.f3161k = false;
            this.f3165o = false;
            this.f3164n.m3404a();
        }

        public void m3410a(long j, int i, long j2) {
            this.f3159i = i;
            this.f3162l = j2;
            this.f3160j = j;
            if (!(this.f3152b && this.f3159i == 1)) {
                if (!this.f3153c) {
                    return;
                }
                if (!(this.f3159i == 5 || this.f3159i == 1 || this.f3159i == 2)) {
                    return;
                }
            }
            C1538a c1538a = this.f3163m;
            this.f3163m = this.f3164n;
            this.f3164n = c1538a;
            this.f3164n.m3404a();
            this.f3158h = 0;
            this.f3161k = true;
        }

        public void m3413a(byte[] bArr, int i, int i2) {
            if (this.f3161k) {
                int i3 = i2 - i;
                if (this.f3157g.length < this.f3158h + i3) {
                    this.f3157g = Arrays.copyOf(this.f3157g, (this.f3158h + i3) * 2);
                }
                System.arraycopy(bArr, i, this.f3157g, this.f3158h, i3);
                this.f3158h = i3 + this.f3158h;
                this.f3156f.m2789a(this.f3157g, 0, this.f3158h);
                if (this.f3156f.m2792b(8)) {
                    this.f3156f.m2788a(1);
                    int c = this.f3156f.m2794c(2);
                    this.f3156f.m2788a(5);
                    if (this.f3156f.m2791b()) {
                        this.f3156f.m2793c();
                        if (this.f3156f.m2791b()) {
                            int c2 = this.f3156f.m2793c();
                            if (!this.f3153c) {
                                this.f3161k = false;
                                this.f3164n.m3405a(c2);
                            } else if (this.f3156f.m2791b()) {
                                int c3 = this.f3156f.m2793c();
                                if (this.f3155e.indexOfKey(c3) < 0) {
                                    this.f3161k = false;
                                    return;
                                }
                                C1399a c1399a = (C1399a) this.f3155e.get(c3);
                                C1400b c1400b = (C1400b) this.f3154d.get(c1399a.f2459b);
                                if (c1400b.f2465e) {
                                    if (this.f3156f.m2792b(2)) {
                                        this.f3156f.m2788a(2);
                                    } else {
                                        return;
                                    }
                                }
                                if (this.f3156f.m2792b(c1400b.f2467g)) {
                                    boolean z = false;
                                    boolean z2 = false;
                                    boolean z3 = false;
                                    int c4 = this.f3156f.m2794c(c1400b.f2467g);
                                    if (!c1400b.f2466f) {
                                        if (this.f3156f.m2792b(1)) {
                                            z = this.f3156f.m2790a();
                                            if (z) {
                                                if (this.f3156f.m2792b(1)) {
                                                    z3 = this.f3156f.m2790a();
                                                    z2 = true;
                                                } else {
                                                    return;
                                                }
                                            }
                                        }
                                        return;
                                    }
                                    boolean z4 = this.f3159i == 5;
                                    int i4 = 0;
                                    if (z4) {
                                        if (this.f3156f.m2791b()) {
                                            i4 = this.f3156f.m2793c();
                                        } else {
                                            return;
                                        }
                                    }
                                    int i5 = 0;
                                    int i6 = 0;
                                    int i7 = 0;
                                    int i8 = 0;
                                    if (c1400b.f2468h == 0) {
                                        if (this.f3156f.m2792b(c1400b.f2469i)) {
                                            i5 = this.f3156f.m2794c(c1400b.f2469i);
                                            if (c1399a.f2460c && !z) {
                                                if (this.f3156f.m2791b()) {
                                                    i6 = this.f3156f.m2795d();
                                                } else {
                                                    return;
                                                }
                                            }
                                        }
                                        return;
                                    } else if (c1400b.f2468h == 1 && !c1400b.f2470j) {
                                        if (this.f3156f.m2791b()) {
                                            i7 = this.f3156f.m2795d();
                                            if (c1399a.f2460c && !z) {
                                                if (this.f3156f.m2791b()) {
                                                    i8 = this.f3156f.m2795d();
                                                } else {
                                                    return;
                                                }
                                            }
                                        }
                                        return;
                                    }
                                    this.f3164n.m3406a(c1400b, c, c2, c4, c3, z, z2, z3, z4, i4, i5, i6, i7, i8);
                                    this.f3161k = false;
                                }
                            }
                        }
                    }
                }
            }
        }

        public void m3409a(long j, int i) {
            int i2 = 0;
            if (this.f3159i == 9 || (this.f3153c && this.f3164n.m3402a(this.f3163m))) {
                if (this.f3165o) {
                    m3408a(((int) (j - this.f3160j)) + i);
                }
                this.f3166p = this.f3160j;
                this.f3167q = this.f3162l;
                this.f3168r = false;
                this.f3165o = true;
            }
            boolean z = this.f3168r;
            if (this.f3159i == 5 || (this.f3152b && this.f3159i == 1 && this.f3164n.m3407b())) {
                i2 = 1;
            }
            this.f3168r = i2 | z;
        }

        private void m3408a(int i) {
            this.f3151a.mo2201a(this.f3167q, this.f3168r ? 1 : 0, (int) (this.f3160j - this.f3166p), i, null);
        }
    }

    public C1540i(boolean z, boolean z2) {
        this.f3169a = z;
        this.f3170b = z2;
        this.f3171c = new C1545m(7, 128);
        this.f3172d = new C1545m(8, 128);
        this.f3173e = new C1545m(6, 128);
        this.f3181m = new C1403k();
    }

    public void mo2204a() {
        C1401i.m2740a(this.f3175g);
        this.f3171c.m3453a();
        this.f3172d.m3453a();
        this.f3173e.m3453a();
        this.f3178j.m3415b();
        this.f3174f = 0;
    }

    public void mo2207a(C1567h c1567h, C1534c c1534c) {
        this.f3176h = c1567h.mo2273a(c1534c.m3392a());
        this.f3178j = new C1539a(this.f3176h, this.f3169a, this.f3170b);
        this.f3177i = new C1549o(c1567h.mo2273a(c1534c.m3392a()));
    }

    public void mo2205a(long j, boolean z) {
        this.f3180l = j;
    }

    public void mo2206a(C1403k c1403k) {
        int d = c1403k.m2761d();
        int c = c1403k.m2759c();
        byte[] bArr = c1403k.f2479a;
        this.f3174f += (long) c1403k.m2757b();
        this.f3176h.mo2203a(c1403k, c1403k.m2757b());
        while (true) {
            int a = C1401i.m2736a(bArr, d, c, this.f3175g);
            if (a == c) {
                m3418a(bArr, d, c);
                return;
            }
            int b = C1401i.m2741b(bArr, a);
            int i = a - d;
            if (i > 0) {
                m3418a(bArr, d, a);
            }
            int i2 = c - a;
            long j = this.f3174f - ((long) i2);
            m3416a(j, i2, i < 0 ? -i : 0, this.f3180l);
            m3417a(j, b, this.f3180l);
            d = a + 3;
        }
    }

    public void mo2208b() {
    }

    private void m3417a(long j, int i, long j2) {
        if (!this.f3179k || this.f3178j.m3414a()) {
            this.f3171c.m3454a(i);
            this.f3172d.m3454a(i);
        }
        this.f3173e.m3454a(i);
        this.f3178j.m3410a(j, i, j2);
    }

    private void m3418a(byte[] bArr, int i, int i2) {
        if (!this.f3179k || this.f3178j.m3414a()) {
            this.f3171c.m3455a(bArr, i, i2);
            this.f3172d.m3455a(bArr, i, i2);
        }
        this.f3173e.m3455a(bArr, i, i2);
        this.f3178j.m3413a(bArr, i, i2);
    }

    private void m3416a(long j, int i, int i2, long j2) {
        if (!this.f3179k || this.f3178j.m3414a()) {
            this.f3171c.m3457b(i2);
            this.f3172d.m3457b(i2);
            if (this.f3179k) {
                if (this.f3171c.m3456b()) {
                    this.f3178j.m3412a(C1401i.m2737a(this.f3171c.f3225a, 3, this.f3171c.f3226b));
                    this.f3171c.m3453a();
                } else if (this.f3172d.m3456b()) {
                    this.f3178j.m3411a(C1401i.m2742b(this.f3172d.f3225a, 3, this.f3172d.f3226b));
                    this.f3172d.m3453a();
                }
            } else if (this.f3171c.m3456b() && this.f3172d.m3456b()) {
                List arrayList = new ArrayList();
                arrayList.add(Arrays.copyOf(this.f3171c.f3225a, this.f3171c.f3226b));
                arrayList.add(Arrays.copyOf(this.f3172d.f3225a, this.f3172d.f3226b));
                C1400b a = C1401i.m2737a(this.f3171c.f3225a, 3, this.f3171c.f3226b);
                C1399a b = C1401i.m2742b(this.f3172d.f3225a, 3, this.f3172d.f3226b);
                this.f3176h.mo2202a(Format.m2403a(null, "video/avc", null, -1, -1, a.f2462b, a.f2463c, -1.0f, arrayList, -1, a.f2464d, null));
                this.f3179k = true;
                this.f3178j.m3412a(a);
                this.f3178j.m3411a(b);
                this.f3171c.m3453a();
                this.f3172d.m3453a();
            }
        }
        if (this.f3173e.m3457b(i2)) {
            this.f3181m.m2755a(this.f3173e.f3225a, C1401i.m2735a(this.f3173e.f3225a, this.f3173e.f3226b));
            this.f3181m.m2760c(4);
            this.f3177i.m3468a(j2, this.f3181m);
        }
        this.f3178j.m3409a(j, i);
    }
}
