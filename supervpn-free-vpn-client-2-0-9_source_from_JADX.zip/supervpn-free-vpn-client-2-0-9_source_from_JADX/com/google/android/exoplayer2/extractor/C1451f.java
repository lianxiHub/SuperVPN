package com.google.android.exoplayer2.extractor;

public interface C1451f {
    int mo2168a(C1464g c1464g, C1570l c1570l);

    void mo2169a(long j);

    void mo2170a(C1567h c1567h);

    boolean mo2171a(C1464g c1464g);

    void mo2172c();
}
