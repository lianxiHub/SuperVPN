package com.google.android.exoplayer2.extractor;

import com.google.android.exoplayer2.upstream.C1678d;
import java.io.EOFException;
import java.util.Arrays;

public final class C1465b implements C1464g {
    private static final byte[] f2733a = new byte[4096];
    private final C1678d f2734b;
    private final long f2735c;
    private long f2736d;
    private byte[] f2737e = new byte[8192];
    private int f2738f;
    private int f2739g;

    public C1465b(C1678d c1678d, long j, long j2) {
        this.f2734b = c1678d;
        this.f2736d = j;
        this.f2735c = j2;
    }

    public int mo2178a(byte[] bArr, int i, int i2) {
        int d = m3078d(bArr, i, i2);
        if (d == 0) {
            d = m3077a(bArr, i, i2, 0, true);
        }
        m3082g(d);
        return d;
    }

    public boolean mo2180a(byte[] bArr, int i, int i2, boolean z) {
        int d = m3078d(bArr, i, i2);
        while (d < i2 && d != -1) {
            d = m3077a(bArr, i, i2, d, z);
        }
        m3082g(d);
        return d != -1;
    }

    public void mo2183b(byte[] bArr, int i, int i2) {
        mo2180a(bArr, i, i2, false);
    }

    public int mo2177a(int i) {
        int e = m3080e(i);
        if (e == 0) {
            e = m3077a(f2733a, 0, Math.min(i, f2733a.length), 0, true);
        }
        m3082g(e);
        return e;
    }

    public boolean m3086a(int i, boolean z) {
        int e = m3080e(i);
        while (e < i && e != -1) {
            e = m3077a(f2733a, -e, Math.min(i, f2733a.length + e), e, z);
        }
        m3082g(e);
        return e != -1;
    }

    public void mo2182b(int i) {
        m3086a(i, false);
    }

    public boolean mo2184b(byte[] bArr, int i, int i2, boolean z) {
        if (!m3091b(i2, z)) {
            return false;
        }
        System.arraycopy(this.f2737e, this.f2738f - i2, bArr, i, i2);
        return true;
    }

    public void mo2187c(byte[] bArr, int i, int i2) {
        mo2184b(bArr, i, i2, false);
    }

    public boolean m3091b(int i, boolean z) {
        m3079d(i);
        int min = Math.min(this.f2739g - this.f2738f, i);
        while (min < i) {
            min = m3077a(this.f2737e, this.f2738f, i, min, z);
            if (min == -1) {
                return false;
            }
        }
        this.f2738f += i;
        this.f2739g = Math.max(this.f2739g, this.f2738f);
        return true;
    }

    public void mo2186c(int i) {
        m3091b(i, false);
    }

    public void mo2179a() {
        this.f2738f = 0;
    }

    public long mo2181b() {
        return this.f2736d + ((long) this.f2738f);
    }

    public long mo2185c() {
        return this.f2736d;
    }

    public long mo2188d() {
        return this.f2735c;
    }

    private void m3079d(int i) {
        int i2 = this.f2738f + i;
        if (i2 > this.f2737e.length) {
            this.f2737e = Arrays.copyOf(this.f2737e, Math.max(this.f2737e.length * 2, i2));
        }
    }

    private int m3080e(int i) {
        int min = Math.min(this.f2739g, i);
        m3081f(min);
        return min;
    }

    private int m3078d(byte[] bArr, int i, int i2) {
        if (this.f2739g == 0) {
            return 0;
        }
        int min = Math.min(this.f2739g, i2);
        System.arraycopy(this.f2737e, 0, bArr, i, min);
        m3081f(min);
        return min;
    }

    private void m3081f(int i) {
        this.f2739g -= i;
        this.f2738f = 0;
        System.arraycopy(this.f2737e, i, this.f2737e, 0, this.f2739g);
    }

    private int m3077a(byte[] bArr, int i, int i2, int i3, boolean z) {
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        int a = this.f2734b.mo2313a(bArr, i + i3, i2 - i3);
        if (a != -1) {
            return i3 + a;
        }
        if (i3 == 0 && z) {
            return -1;
        }
        throw new EOFException();
    }

    private void m3082g(int i) {
        if (i != -1) {
            this.f2736d += (long) i;
        }
    }
}
