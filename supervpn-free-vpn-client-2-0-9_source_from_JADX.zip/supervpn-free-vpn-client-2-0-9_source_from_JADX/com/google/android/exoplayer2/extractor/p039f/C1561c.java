package com.google.android.exoplayer2.extractor.p039f;

import android.util.Log;
import com.facebook.share.internal.ShareConstants;
import com.google.android.exoplayer2.ParserException;
import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1414r;

final class C1561c {

    private static final class C1560a {
        public final int f3301a;
        public final long f3302b;

        private C1560a(int i, long j) {
            this.f3301a = i;
            this.f3302b = j;
        }

        public static C1560a m3524a(C1464g c1464g, C1403k c1403k) {
            c1464g.mo2187c(c1403k.f2479a, 0, 8);
            c1403k.m2760c(0);
            return new C1560a(c1403k.m2773n(), c1403k.m2772m());
        }
    }

    public static C1559b m3525a(C1464g c1464g) {
        C1392a.m2707a((Object) c1464g);
        C1403k c1403k = new C1403k(16);
        if (C1560a.m3524a(c1464g, c1403k).f3301a != C1414r.m2830e("RIFF")) {
            return null;
        }
        c1464g.mo2187c(c1403k.f2479a, 0, 4);
        c1403k.m2760c(0);
        int n = c1403k.m2773n();
        if (n != C1414r.m2830e("WAVE")) {
            Log.e("WavHeaderReader", "Unsupported RIFF format: " + n);
            return null;
        }
        C1560a a = C1560a.m3524a(c1464g, c1403k);
        while (a.f3301a != C1414r.m2830e("fmt ")) {
            c1464g.mo2186c((int) a.f3302b);
            a = C1560a.m3524a(c1464g, c1403k);
        }
        C1392a.m2711b(a.f3302b >= 16);
        c1464g.mo2187c(c1403k.f2479a, 0, 16);
        c1403k.m2760c(0);
        int i = c1403k.m2768i();
        int i2 = c1403k.m2768i();
        int u = c1403k.m2780u();
        int u2 = c1403k.m2780u();
        int i3 = c1403k.m2768i();
        int i4 = c1403k.m2768i();
        int i5 = (i2 * i4) / 8;
        if (i3 != i5) {
            throw new ParserException("Expected block alignment: " + i5 + "; got: " + i3);
        }
        i5 = C1414r.m2812a(i4);
        if (i5 == 0) {
            Log.e("WavHeaderReader", "Unsupported WAV bit depth: " + i4);
            return null;
        } else if (i == 1 || i == 65534) {
            c1464g.mo2186c(((int) a.f3302b) - 16);
            return new C1559b(i2, u, u2, i3, i4, i5);
        } else {
            Log.e("WavHeaderReader", "Unsupported WAV format type: " + i);
            return null;
        }
    }

    public static void m3526a(C1464g c1464g, C1559b c1559b) {
        C1392a.m2707a((Object) c1464g);
        C1392a.m2707a((Object) c1559b);
        c1464g.mo2179a();
        C1403k c1403k = new C1403k(8);
        C1560a a = C1560a.m3524a(c1464g, c1403k);
        while (a.f3301a != C1414r.m2830e(ShareConstants.WEB_DIALOG_PARAM_DATA)) {
            Log.w("WavHeaderReader", "Ignoring unknown WAV chunk: " + a.f3301a);
            long j = 8 + a.f3302b;
            if (a.f3301a == C1414r.m2830e("RIFF")) {
                j = 12;
            }
            if (j > 2147483647L) {
                throw new ParserException("Chunk is too large (~2GB+) to skip; id: " + a.f3301a);
            }
            c1464g.mo2182b((int) j);
            a = C1560a.m3524a(c1464g, c1403k);
        }
        c1464g.mo2182b(8);
        c1559b.m3516a(c1464g.mo2185c(), a.f3302b);
    }
}
