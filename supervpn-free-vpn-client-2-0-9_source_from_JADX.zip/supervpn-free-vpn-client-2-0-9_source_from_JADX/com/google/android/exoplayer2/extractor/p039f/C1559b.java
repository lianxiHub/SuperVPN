package com.google.android.exoplayer2.extractor.p039f;

final class C1559b {
    private final int f3293a;
    private final int f3294b;
    private final int f3295c;
    private final int f3296d;
    private final int f3297e;
    private final int f3298f;
    private long f3299g;
    private long f3300h;

    public C1559b(int i, int i2, int i3, int i4, int i5, int i6) {
        this.f3293a = i;
        this.f3294b = i2;
        this.f3295c = i3;
        this.f3296d = i4;
        this.f3297e = i5;
        this.f3298f = i6;
    }

    public long m3514a() {
        return ((this.f3300h / ((long) this.f3296d)) * 1000000) / ((long) this.f3294b);
    }

    public int m3517b() {
        return this.f3296d;
    }

    public int m3519c() {
        return (this.f3294b * this.f3297e) * this.f3293a;
    }

    public int m3520d() {
        return this.f3294b;
    }

    public int m3521e() {
        return this.f3293a;
    }

    public long m3515a(long j) {
        return Math.min((((((long) this.f3295c) * j) / 1000000) / ((long) this.f3296d)) * ((long) this.f3296d), this.f3300h - ((long) this.f3296d)) + this.f3299g;
    }

    public long m3518b(long j) {
        return (1000000 * j) / ((long) this.f3295c);
    }

    public boolean m3522f() {
        return (this.f3299g == 0 || this.f3300h == 0) ? false : true;
    }

    public void m3516a(long j, long j2) {
        this.f3299g = j;
        this.f3300h = j2;
    }

    public int m3523g() {
        return this.f3298f;
    }
}
