package com.google.android.exoplayer2.extractor.p039f;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.ParserException;
import com.google.android.exoplayer2.extractor.C1447i;
import com.google.android.exoplayer2.extractor.C1451f;
import com.google.android.exoplayer2.extractor.C1455m;
import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.extractor.C1570l;

public final class C1558a implements C1451f, C1455m {
    public static final C1447i f3287a = new C15571();
    private C1567h f3288b;
    private C1521o f3289c;
    private C1559b f3290d;
    private int f3291e;
    private int f3292f;

    static class C15571 implements C1447i {
        C15571() {
        }

        public C1451f[] mo2159a() {
            return new C1451f[]{new C1558a()};
        }
    }

    public boolean mo2171a(C1464g c1464g) {
        return C1561c.m3525a(c1464g) != null;
    }

    public void mo2170a(C1567h c1567h) {
        this.f3288b = c1567h;
        this.f3289c = c1567h.mo2273a(0);
        this.f3290d = null;
        c1567h.mo2274a();
    }

    public void mo2169a(long j) {
        this.f3292f = 0;
    }

    public void mo2172c() {
    }

    public int mo2168a(C1464g c1464g, C1570l c1570l) {
        if (this.f3290d == null) {
            this.f3290d = C1561c.m3525a(c1464g);
            if (this.f3290d == null) {
                throw new ParserException("Unsupported or unrecognized wav header.");
            }
            this.f3289c.mo2202a(Format.m2406a(null, "audio/raw", null, this.f3290d.m3519c(), 32768, this.f3290d.m3521e(), this.f3290d.m3520d(), this.f3290d.m3523g(), null, null, 0, null));
            this.f3291e = this.f3290d.m3517b();
        }
        if (!this.f3290d.m3522f()) {
            C1561c.m3526a(c1464g, this.f3290d);
            this.f3288b.mo2276a((C1455m) this);
        }
        int a = this.f3289c.mo2200a(c1464g, 32768 - this.f3292f, true);
        if (a != -1) {
            this.f3292f += a;
        }
        int i = this.f3292f / this.f3291e;
        if (i > 0) {
            long b = this.f3290d.m3518b(c1464g.mo2185c() - ((long) this.f3292f));
            int i2 = i * this.f3291e;
            this.f3292f -= i2;
            this.f3289c.mo2201a(b, 1, i2, this.f3292f, null);
        }
        return a == -1 ? -1 : 0;
    }

    public long mo2174b() {
        return this.f3290d.m3514a();
    }

    public boolean mo2173a() {
        return true;
    }

    public long mo2175b(long j) {
        return this.f3290d.m3515a(j);
    }
}
