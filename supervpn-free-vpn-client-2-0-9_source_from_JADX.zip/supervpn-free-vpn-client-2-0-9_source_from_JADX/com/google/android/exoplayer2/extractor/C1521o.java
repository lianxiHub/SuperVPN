package com.google.android.exoplayer2.extractor;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.p031c.C1403k;

public interface C1521o {
    int mo2200a(C1464g c1464g, int i, boolean z);

    void mo2201a(long j, int i, int i2, int i3, byte[] bArr);

    void mo2202a(Format format);

    void mo2203a(C1403k c1403k, int i);
}
