package com.google.android.exoplayer2.extractor.p037d;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.ParserException;
import com.google.android.exoplayer2.extractor.p037d.C1503h.C1511a;
import com.google.android.exoplayer2.extractor.p037d.C1520k.C1517b;
import com.google.android.exoplayer2.extractor.p037d.C1520k.C1518c;
import com.google.android.exoplayer2.extractor.p037d.C1520k.C1519d;
import com.google.android.exoplayer2.p031c.C1403k;
import java.util.ArrayList;
import java.util.List;

final class C1515j extends C1503h {
    private C1514a f3017a;
    private int f3018b;
    private boolean f3019c;
    private C1519d f3020d;
    private C1517b f3021e;

    static final class C1514a {
        public final C1519d f3012a;
        public final C1517b f3013b;
        public final byte[] f3014c;
        public final C1518c[] f3015d;
        public final int f3016e;

        public C1514a(C1519d c1519d, C1517b c1517b, byte[] bArr, C1518c[] c1518cArr, int i) {
            this.f3012a = c1519d;
            this.f3013b = c1517b;
            this.f3014c = bArr;
            this.f3015d = c1518cArr;
            this.f3016e = i;
        }
    }

    C1515j() {
    }

    public static boolean m3300a(C1403k c1403k) {
        try {
            return C1520k.m3310a(1, c1403k, true);
        } catch (ParserException e) {
            return false;
        }
    }

    protected void mo2196a(boolean z) {
        super.mo2196a(z);
        if (z) {
            this.f3017a = null;
            this.f3020d = null;
            this.f3021e = null;
        }
        this.f3018b = 0;
        this.f3019c = false;
    }

    protected void mo2199d(long j) {
        boolean z;
        int i = 0;
        super.mo2199d(j);
        if (j != 0) {
            z = true;
        } else {
            z = false;
        }
        this.f3019c = z;
        if (this.f3020d != null) {
            i = this.f3020d.f3040g;
        }
        this.f3018b = i;
    }

    protected long mo2198b(C1403k c1403k) {
        int i = 0;
        if ((c1403k.f2479a[0] & 1) == 1) {
            return -1;
        }
        int a = C1515j.m3298a(c1403k.f2479a[0], this.f3017a);
        if (this.f3019c) {
            i = (this.f3018b + a) / 4;
        }
        C1515j.m3299a(c1403k, (long) i);
        this.f3019c = true;
        this.f3018b = a;
        return (long) i;
    }

    protected boolean mo2197a(C1403k c1403k, long j, C1511a c1511a) {
        if (this.f3017a != null) {
            return false;
        }
        this.f3017a = m3304c(c1403k);
        if (this.f3017a == null) {
            return true;
        }
        List arrayList = new ArrayList();
        arrayList.add(this.f3017a.f3012a.f3043j);
        arrayList.add(this.f3017a.f3014c);
        c1511a.f3006a = Format.m2407a(null, "audio/vorbis", null, this.f3017a.f3012a.f3038e, 65025, this.f3017a.f3012a.f3035b, (int) this.f3017a.f3012a.f3036c, arrayList, null, 0, null);
        return true;
    }

    C1514a m3304c(C1403k c1403k) {
        if (this.f3020d == null) {
            this.f3020d = C1520k.m3308a(c1403k);
            return null;
        } else if (this.f3021e == null) {
            this.f3021e = C1520k.m3313b(c1403k);
            return null;
        } else {
            Object obj = new byte[c1403k.m2759c()];
            System.arraycopy(c1403k.f2479a, 0, obj, 0, c1403k.m2759c());
            C1518c[] a = C1520k.m3311a(c1403k, this.f3020d.f3035b);
            return new C1514a(this.f3020d, this.f3021e, obj, a, C1520k.m3306a(a.length - 1));
        }
    }

    static int m3297a(byte b, int i, int i2) {
        return (b >> i2) & (255 >>> (8 - i));
    }

    static void m3299a(C1403k c1403k, long j) {
        c1403k.m2758b(c1403k.m2759c() + 4);
        c1403k.f2479a[c1403k.m2759c() - 4] = (byte) ((int) (j & 255));
        c1403k.f2479a[c1403k.m2759c() - 3] = (byte) ((int) ((j >>> 8) & 255));
        c1403k.f2479a[c1403k.m2759c() - 2] = (byte) ((int) ((j >>> 16) & 255));
        c1403k.f2479a[c1403k.m2759c() - 1] = (byte) ((int) ((j >>> 24) & 255));
    }

    private static int m3298a(byte b, C1514a c1514a) {
        if (c1514a.f3015d[C1515j.m3297a(b, c1514a.f3016e, 1)].f3030a) {
            return c1514a.f3012a.f3041h;
        }
        return c1514a.f3012a.f3040g;
    }
}
