package com.google.android.exoplayer2.extractor.p037d;

import com.google.android.exoplayer2.ParserException;
import com.google.android.exoplayer2.extractor.C1447i;
import com.google.android.exoplayer2.extractor.C1451f;
import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.extractor.C1570l;
import com.google.android.exoplayer2.p031c.C1403k;

public class C1506c implements C1451f {
    public static final C1447i f2984a = new C15051();
    private C1503h f2985b;

    static class C15051 implements C1447i {
        C15051() {
        }

        public C1451f[] mo2159a() {
            return new C1451f[]{new C1506c()};
        }
    }

    public boolean mo2171a(C1464g c1464g) {
        try {
            C1508e c1508e = new C1508e();
            if (!c1508e.m3284a(c1464g, true) || (c1508e.f2993b & 2) != 2) {
                return false;
            }
            int min = Math.min(c1508e.f3000i, 8);
            C1403k c1403k = new C1403k(min);
            c1464g.mo2187c(c1403k.f2479a, 0, min);
            if (C1504b.m3266a(C1506c.m3273a(c1403k))) {
                this.f2985b = new C1504b();
            } else if (C1515j.m3300a(C1506c.m3273a(c1403k))) {
                this.f2985b = new C1515j();
            } else if (!C1509g.m3287a(C1506c.m3273a(c1403k))) {
                return false;
            } else {
                this.f2985b = new C1509g();
            }
            return true;
        } catch (ParserException e) {
            return false;
        }
    }

    public void mo2170a(C1567h c1567h) {
        C1521o a = c1567h.mo2273a(0);
        c1567h.mo2274a();
        this.f2985b.m3258a(c1567h, a);
    }

    public void mo2169a(long j) {
        this.f2985b.m3257a(j);
    }

    public void mo2172c() {
    }

    public int mo2168a(C1464g c1464g, C1570l c1570l) {
        return this.f2985b.m3256a(c1464g, c1570l);
    }

    private static C1403k m3273a(C1403k c1403k) {
        c1403k.m2760c(0);
        return c1403k;
    }
}
