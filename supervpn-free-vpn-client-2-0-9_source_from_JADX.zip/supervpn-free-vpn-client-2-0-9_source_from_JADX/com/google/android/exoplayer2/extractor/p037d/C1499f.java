package com.google.android.exoplayer2.extractor.p037d;

import com.google.android.exoplayer2.extractor.C1455m;
import com.google.android.exoplayer2.extractor.C1464g;

interface C1499f {
    long mo2193a(C1464g c1464g);

    long a_();

    C1455m mo2195d();
}
