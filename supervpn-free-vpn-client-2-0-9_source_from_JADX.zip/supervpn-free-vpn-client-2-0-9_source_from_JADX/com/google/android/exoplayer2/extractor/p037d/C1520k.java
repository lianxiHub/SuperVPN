package com.google.android.exoplayer2.extractor.p037d;

import android.util.Log;
import com.google.android.exoplayer2.ParserException;
import com.google.android.exoplayer2.p031c.C1403k;
import java.util.Arrays;

final class C1520k {

    public static final class C1516a {
        public final int f3022a;
        public final int f3023b;
        public final long[] f3024c;
        public final int f3025d;
        public final boolean f3026e;

        public C1516a(int i, int i2, long[] jArr, int i3, boolean z) {
            this.f3022a = i;
            this.f3023b = i2;
            this.f3024c = jArr;
            this.f3025d = i3;
            this.f3026e = z;
        }
    }

    public static final class C1517b {
        public final String f3027a;
        public final String[] f3028b;
        public final int f3029c;

        public C1517b(String str, String[] strArr, int i) {
            this.f3027a = str;
            this.f3028b = strArr;
            this.f3029c = i;
        }
    }

    public static final class C1518c {
        public final boolean f3030a;
        public final int f3031b;
        public final int f3032c;
        public final int f3033d;

        public C1518c(boolean z, int i, int i2, int i3) {
            this.f3030a = z;
            this.f3031b = i;
            this.f3032c = i2;
            this.f3033d = i3;
        }
    }

    public static final class C1519d {
        public final long f3034a;
        public final int f3035b;
        public final long f3036c;
        public final int f3037d;
        public final int f3038e;
        public final int f3039f;
        public final int f3040g;
        public final int f3041h;
        public final boolean f3042i;
        public final byte[] f3043j;

        public C1519d(long j, int i, long j2, int i2, int i3, int i4, int i5, int i6, boolean z, byte[] bArr) {
            this.f3034a = j;
            this.f3035b = i;
            this.f3036c = j2;
            this.f3037d = i2;
            this.f3038e = i3;
            this.f3039f = i4;
            this.f3040g = i5;
            this.f3041h = i6;
            this.f3042i = z;
            this.f3043j = bArr;
        }
    }

    public static int m3306a(int i) {
        int i2 = 0;
        while (i > 0) {
            i2++;
            i >>>= 1;
        }
        return i2;
    }

    public static C1519d m3308a(C1403k c1403k) {
        C1520k.m3310a(1, c1403k, false);
        long m = c1403k.m2772m();
        int g = c1403k.m2766g();
        long m2 = c1403k.m2772m();
        int o = c1403k.m2774o();
        int o2 = c1403k.m2774o();
        int o3 = c1403k.m2774o();
        int g2 = c1403k.m2766g();
        return new C1519d(m, g, m2, o, o2, o3, (int) Math.pow(2.0d, (double) (g2 & 15)), (int) Math.pow(2.0d, (double) ((g2 & 240) >> 4)), (c1403k.m2766g() & 1) > 0, Arrays.copyOf(c1403k.f2479a, c1403k.m2759c()));
    }

    public static C1517b m3313b(C1403k c1403k) {
        int i = 0;
        C1520k.m3310a(3, c1403k, false);
        String e = c1403k.m2764e((int) c1403k.m2772m());
        int length = e.length() + 11;
        long m = c1403k.m2772m();
        String[] strArr = new String[((int) m)];
        length += 4;
        while (((long) i) < m) {
            length += 4;
            strArr[i] = c1403k.m2764e((int) c1403k.m2772m());
            length += strArr[i].length();
            i++;
        }
        if ((c1403k.m2766g() & 1) != 0) {
            return new C1517b(e, strArr, length + 1);
        }
        throw new ParserException("framing bit expected to be set");
    }

    public static boolean m3310a(int i, C1403k c1403k, boolean z) {
        if (c1403k.m2757b() < 7) {
            if (z) {
                return false;
            }
            throw new ParserException("too short header: " + c1403k.m2757b());
        } else if (c1403k.m2766g() != i) {
            if (z) {
                return false;
            }
            throw new ParserException("expected header type " + Integer.toHexString(i));
        } else if (c1403k.m2766g() == 118 && c1403k.m2766g() == 111 && c1403k.m2766g() == 114 && c1403k.m2766g() == 98 && c1403k.m2766g() == 105 && c1403k.m2766g() == 115) {
            return true;
        } else {
            if (z) {
                return false;
            }
            throw new ParserException("expected characters 'vorbis'");
        }
    }

    public static C1518c[] m3311a(C1403k c1403k, int i) {
        int i2;
        int i3 = 0;
        C1520k.m3310a(5, c1403k, false);
        int g = c1403k.m2766g() + 1;
        C1513i c1513i = new C1513i(c1403k.f2479a);
        c1513i.m3296b(c1403k.m2761d() * 8);
        for (i2 = 0; i2 < g; i2++) {
            C1520k.m3316d(c1513i);
        }
        i2 = c1513i.m3293a(6) + 1;
        while (i3 < i2) {
            if (c1513i.m3293a(16) != 0) {
                throw new ParserException("placeholder of time domain transforms not zeroed out");
            }
            i3++;
        }
        C1520k.m3315c(c1513i);
        C1520k.m3314b(c1513i);
        C1520k.m3309a(i, c1513i);
        C1518c[] a = C1520k.m3312a(c1513i);
        if (c1513i.m3294a()) {
            return a;
        }
        throw new ParserException("framing bit after modes not set as expected");
    }

    private static C1518c[] m3312a(C1513i c1513i) {
        int a = c1513i.m3293a(6) + 1;
        C1518c[] c1518cArr = new C1518c[a];
        for (int i = 0; i < a; i++) {
            c1518cArr[i] = new C1518c(c1513i.m3294a(), c1513i.m3293a(16), c1513i.m3293a(16), c1513i.m3293a(8));
        }
        return c1518cArr;
    }

    private static void m3309a(int i, C1513i c1513i) {
        int a = c1513i.m3293a(6) + 1;
        for (int i2 = 0; i2 < a; i2++) {
            int a2 = c1513i.m3293a(16);
            switch (a2) {
                case 0:
                    int i3;
                    if (c1513i.m3294a()) {
                        a2 = c1513i.m3293a(4) + 1;
                    } else {
                        a2 = 1;
                    }
                    if (c1513i.m3294a()) {
                        int a3 = c1513i.m3293a(8) + 1;
                        for (i3 = 0; i3 < a3; i3++) {
                            c1513i.m3296b(C1520k.m3306a(i - 1));
                            c1513i.m3296b(C1520k.m3306a(i - 1));
                        }
                    }
                    if (c1513i.m3293a(2) == 0) {
                        if (a2 > 1) {
                            for (i3 = 0; i3 < i; i3++) {
                                c1513i.m3296b(4);
                            }
                        }
                        for (i3 = 0; i3 < a2; i3++) {
                            c1513i.m3296b(8);
                            c1513i.m3296b(8);
                            c1513i.m3296b(8);
                        }
                        break;
                    }
                    throw new ParserException("to reserved bits must be zero after mapping coupling steps");
                default:
                    Log.e("VorbisUtil", "mapping type other than 0 not supported: " + a2);
                    break;
            }
        }
    }

    private static void m3314b(C1513i c1513i) {
        int a = c1513i.m3293a(6) + 1;
        for (int i = 0; i < a; i++) {
            if (c1513i.m3293a(16) > 2) {
                throw new ParserException("residueType greater than 2 is not decodable");
            }
            int i2;
            c1513i.m3296b(24);
            c1513i.m3296b(24);
            c1513i.m3296b(24);
            int a2 = c1513i.m3293a(6) + 1;
            c1513i.m3296b(8);
            int[] iArr = new int[a2];
            for (i2 = 0; i2 < a2; i2++) {
                int a3;
                int a4 = c1513i.m3293a(3);
                if (c1513i.m3294a()) {
                    a3 = c1513i.m3293a(5);
                } else {
                    a3 = 0;
                }
                iArr[i2] = (a3 * 8) + a4;
            }
            for (i2 = 0; i2 < a2; i2++) {
                for (a3 = 0; a3 < 8; a3++) {
                    if ((iArr[i2] & (1 << a3)) != 0) {
                        c1513i.m3296b(8);
                    }
                }
            }
        }
    }

    private static void m3315c(C1513i c1513i) {
        int a = c1513i.m3293a(6) + 1;
        for (int i = 0; i < a; i++) {
            int a2 = c1513i.m3293a(16);
            int a3;
            switch (a2) {
                case 0:
                    c1513i.m3296b(8);
                    c1513i.m3296b(16);
                    c1513i.m3296b(16);
                    c1513i.m3296b(6);
                    c1513i.m3296b(8);
                    a3 = c1513i.m3293a(4) + 1;
                    for (a2 = 0; a2 < a3; a2++) {
                        c1513i.m3296b(8);
                    }
                    break;
                case 1:
                    int a4;
                    int a5 = c1513i.m3293a(5);
                    a2 = -1;
                    int[] iArr = new int[a5];
                    for (a3 = 0; a3 < a5; a3++) {
                        iArr[a3] = c1513i.m3293a(4);
                        if (iArr[a3] > a2) {
                            a2 = iArr[a3];
                        }
                    }
                    int[] iArr2 = new int[(a2 + 1)];
                    for (a2 = 0; a2 < iArr2.length; a2++) {
                        iArr2[a2] = c1513i.m3293a(3) + 1;
                        a4 = c1513i.m3293a(2);
                        if (a4 > 0) {
                            c1513i.m3296b(8);
                        }
                        for (a3 = 0; a3 < (1 << a4); a3++) {
                            c1513i.m3296b(8);
                        }
                    }
                    c1513i.m3296b(2);
                    int a6 = c1513i.m3293a(4);
                    a2 = 0;
                    a4 = 0;
                    for (a3 = 0; a3 < a5; a3++) {
                        a4 += iArr2[iArr[a3]];
                        while (a2 < a4) {
                            c1513i.m3296b(a6);
                            a2++;
                        }
                    }
                    break;
                default:
                    throw new ParserException("floor type greater than 1 not decodable: " + a2);
            }
        }
    }

    private static C1516a m3316d(C1513i c1513i) {
        int i = 0;
        if (c1513i.m3293a(24) != 5653314) {
            throw new ParserException("expected code book to start with [0x56, 0x43, 0x42] at " + c1513i.m3295b());
        }
        int i2;
        int a = c1513i.m3293a(16);
        int a2 = c1513i.m3293a(24);
        long[] jArr = new long[a2];
        boolean a3 = c1513i.m3294a();
        if (a3) {
            int a4 = c1513i.m3293a(5) + 1;
            i2 = 0;
            while (i2 < jArr.length) {
                int a5 = c1513i.m3293a(C1520k.m3306a(a2 - i2));
                int i3 = 0;
                while (i3 < a5 && i2 < jArr.length) {
                    jArr[i2] = (long) a4;
                    i3++;
                    i2++;
                }
                a4++;
            }
        } else {
            boolean a6 = c1513i.m3294a();
            while (i < jArr.length) {
                if (!a6) {
                    jArr[i] = (long) (c1513i.m3293a(5) + 1);
                } else if (c1513i.m3294a()) {
                    jArr[i] = (long) (c1513i.m3293a(5) + 1);
                } else {
                    jArr[i] = 0;
                }
                i++;
            }
        }
        i2 = c1513i.m3293a(4);
        if (i2 > 2) {
            throw new ParserException("lookup type greater than 2 not decodable: " + i2);
        }
        if (i2 == 1 || i2 == 2) {
            long j;
            c1513i.m3296b(32);
            c1513i.m3296b(32);
            i = c1513i.m3293a(4) + 1;
            c1513i.m3296b(1);
            if (i2 != 1) {
                j = (long) (a2 * a);
            } else if (a != 0) {
                j = C1520k.m3307a((long) a2, (long) a);
            } else {
                j = 0;
            }
            c1513i.m3296b((int) (j * ((long) i)));
        }
        return new C1516a(a, a2, jArr, i2, a3);
    }

    private static long m3307a(long j, long j2) {
        return (long) Math.floor(Math.pow((double) j, 1.0d / ((double) j2)));
    }
}
