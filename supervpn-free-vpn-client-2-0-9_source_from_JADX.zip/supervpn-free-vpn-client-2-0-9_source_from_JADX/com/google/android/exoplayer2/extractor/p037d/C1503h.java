package com.google.android.exoplayer2.extractor.p037d;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.extractor.C1455m;
import com.google.android.exoplayer2.extractor.C1455m.C1571a;
import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.extractor.C1570l;
import com.google.android.exoplayer2.p031c.C1403k;

abstract class C1503h {
    private C1507d f2969a;
    private C1521o f2970b;
    private C1567h f2971c;
    private C1499f f2972d;
    private long f2973e;
    private long f2974f;
    private long f2975g;
    private int f2976h;
    private int f2977i;
    private C1511a f2978j;
    private long f2979k;
    private boolean f2980l;
    private boolean f2981m;

    static class C1511a {
        Format f3006a;
        C1499f f3007b;

        C1511a() {
        }
    }

    private static final class C1512b implements C1499f {
        private C1512b() {
        }

        public long mo2193a(C1464g c1464g) {
            return -1;
        }

        public long a_() {
            return 0;
        }

        public C1455m mo2195d() {
            return new C1571a(-9223372036854775807L);
        }
    }

    protected abstract boolean mo2197a(C1403k c1403k, long j, C1511a c1511a);

    protected abstract long mo2198b(C1403k c1403k);

    C1503h() {
    }

    void m3258a(C1567h c1567h, C1521o c1521o) {
        this.f2971c = c1567h;
        this.f2970b = c1521o;
        this.f2969a = new C1507d();
        mo2196a(true);
    }

    protected void mo2196a(boolean z) {
        if (z) {
            this.f2978j = new C1511a();
            this.f2974f = 0;
            this.f2976h = 0;
        } else {
            this.f2976h = 1;
        }
        this.f2973e = -1;
        this.f2975g = 0;
    }

    final void m3257a(long j) {
        this.f2969a.m3280a();
        if (j == 0) {
            mo2196a(!this.f2980l);
        } else if (this.f2976h != 0) {
            this.f2973e = this.f2972d.a_();
            this.f2976h = 2;
        }
    }

    final int m3256a(C1464g c1464g, C1570l c1570l) {
        switch (this.f2976h) {
            case 0:
                return m3254a(c1464g);
            case 1:
                c1464g.mo2182b((int) this.f2974f);
                this.f2976h = 2;
                return 0;
            case 2:
                return m3255b(c1464g, c1570l);
            default:
                throw new IllegalStateException();
        }
    }

    private int m3254a(C1464g c1464g) {
        boolean z = true;
        while (z) {
            if (this.f2969a.m3281a(c1464g)) {
                this.f2979k = c1464g.mo2185c() - this.f2974f;
                z = mo2197a(this.f2969a.m3282b(), this.f2974f, this.f2978j);
                if (z) {
                    this.f2974f = c1464g.mo2185c();
                }
            } else {
                this.f2976h = 3;
                return -1;
            }
        }
        this.f2977i = this.f2978j.f3006a.f2195q;
        if (!this.f2981m) {
            this.f2970b.mo2202a(this.f2978j.f3006a);
            this.f2981m = true;
        }
        if (this.f2978j.f3007b != null) {
            this.f2972d = this.f2978j.f3007b;
        } else if (c1464g.mo2188d() == -1) {
            this.f2972d = new C1512b();
        } else {
            this.f2972d = new C1500a(this.f2974f, c1464g.mo2188d(), this);
        }
        this.f2978j = null;
        this.f2976h = 2;
        return 0;
    }

    private int m3255b(C1464g c1464g, C1570l c1570l) {
        long a = this.f2972d.mo2193a(c1464g);
        if (a >= 0) {
            c1570l.f3345a = a;
            return 1;
        }
        if (a < -1) {
            mo2199d((-a) - 2);
        }
        if (!this.f2980l) {
            this.f2971c.mo2276a(this.f2972d.mo2195d());
            this.f2980l = true;
        }
        if (this.f2979k > 0 || this.f2969a.m3281a(c1464g)) {
            this.f2979k = 0;
            C1403k b = this.f2969a.m3282b();
            long b2 = mo2198b(b);
            if (b2 >= 0 && this.f2975g + b2 >= this.f2973e) {
                long b3 = m3261b(this.f2975g);
                this.f2970b.mo2203a(b, b.m2759c());
                this.f2970b.mo2201a(b3, 1, b.m2759c(), 0, null);
                this.f2973e = -1;
            }
            this.f2975g += b2;
            return 0;
        }
        this.f2976h = 3;
        return -1;
    }

    protected long m3261b(long j) {
        return (1000000 * j) / ((long) this.f2977i);
    }

    protected long m3263c(long j) {
        return (((long) this.f2977i) * j) / 1000000;
    }

    protected void mo2199d(long j) {
        this.f2975g = j;
    }
}
