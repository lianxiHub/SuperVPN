package com.google.android.exoplayer2.extractor.p037d;

import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1403k;

final class C1507d {
    private final C1508e f2986a = new C1508e();
    private final C1403k f2987b = new C1403k(new byte[65025], 0);
    private int f2988c = -1;
    private int f2989d;
    private boolean f2990e;

    C1507d() {
    }

    public void m3280a() {
        this.f2986a.m3283a();
        this.f2987b.m2752a();
        this.f2988c = -1;
        this.f2990e = false;
    }

    public boolean m3281a(C1464g c1464g) {
        C1392a.m2711b(c1464g != null);
        if (this.f2990e) {
            this.f2990e = false;
            this.f2987b.m2752a();
        }
        while (!this.f2990e) {
            int i;
            int i2;
            if (this.f2988c < 0) {
                if (!this.f2986a.m3284a(c1464g, true)) {
                    return false;
                }
                i = this.f2986a.f2999h;
                if ((this.f2986a.f2993b & 1) == 1 && this.f2987b.m2759c() == 0) {
                    i += m3279a(0);
                    i2 = this.f2989d + 0;
                } else {
                    i2 = 0;
                }
                c1464g.mo2182b(i);
                this.f2988c = i2;
            }
            i = m3279a(this.f2988c);
            i2 = this.f2988c + this.f2989d;
            if (i > 0) {
                boolean z;
                c1464g.mo2183b(this.f2987b.f2479a, this.f2987b.m2759c(), i);
                this.f2987b.m2758b(i + this.f2987b.m2759c());
                if (this.f2986a.f3001j[i2 - 1] != 255) {
                    z = true;
                } else {
                    z = false;
                }
                this.f2990e = z;
            }
            if (i2 == this.f2986a.f2998g) {
                i = -1;
            } else {
                i = i2;
            }
            this.f2988c = i;
        }
        return true;
    }

    public C1403k m3282b() {
        return this.f2987b;
    }

    private int m3279a(int i) {
        int i2 = 0;
        this.f2989d = 0;
        while (this.f2989d + i < this.f2986a.f2998g) {
            int[] iArr = this.f2986a.f3001j;
            int i3 = this.f2989d;
            this.f2989d = i3 + 1;
            int i4 = iArr[i3 + i];
            i2 += i4;
            if (i4 != 255) {
                break;
            }
        }
        return i2;
    }
}
