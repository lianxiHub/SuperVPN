package com.google.android.exoplayer2.extractor.p037d;

import com.google.android.exoplayer2.extractor.C1455m;
import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.p031c.C1392a;
import java.io.EOFException;
import java.io.IOException;

final class C1500a implements C1499f {
    private final C1508e f2949a = new C1508e();
    private final long f2950b;
    private final long f2951c;
    private final C1503h f2952d;
    private int f2953e;
    private long f2954f;
    private volatile long f2955g;
    private long f2956h;
    private long f2957i;
    private long f2958j;
    private long f2959k;
    private long f2960l;
    private long f2961m;

    private class C1498a implements C1455m {
        final /* synthetic */ C1500a f2948a;

        private C1498a(C1500a c1500a) {
            this.f2948a = c1500a;
        }

        public boolean mo2173a() {
            return true;
        }

        public long mo2175b(long j) {
            if (j == 0) {
                this.f2948a.f2955g = 0;
                return this.f2948a.f2950b;
            }
            this.f2948a.f2955g = this.f2948a.f2952d.m3263c(j);
            return this.f2948a.m3231a(this.f2948a.f2950b, this.f2948a.f2955g, 30000);
        }

        public long mo2174b() {
            return this.f2948a.f2952d.m3261b(this.f2948a.f2954f);
        }
    }

    public /* synthetic */ C1455m mo2195d() {
        return m3242b();
    }

    public C1500a(long j, long j2, C1503h c1503h) {
        boolean z = j >= 0 && j2 > j;
        C1392a.m2709a(z);
        this.f2952d = c1503h;
        this.f2950b = j;
        this.f2951c = j2;
        this.f2953e = 0;
    }

    public long mo2193a(C1464g c1464g) {
        long j = 0;
        switch (this.f2953e) {
            case 0:
                this.f2956h = c1464g.mo2185c();
                this.f2953e = 1;
                j = this.f2951c - 65307;
                if (j > this.f2956h) {
                    return j;
                }
                break;
            case 1:
                break;
            case 2:
                if (this.f2957i != 0) {
                    long a = m3238a(this.f2957i, c1464g);
                    if (a >= 0) {
                        return a;
                    }
                    C1464g c1464g2 = c1464g;
                    j = m3240a(c1464g2, this.f2957i, -(a + 2));
                }
                this.f2953e = 3;
                return -(j + 2);
            case 3:
                return -1;
            default:
                throw new IllegalStateException();
        }
        this.f2954f = m3244c(c1464g);
        this.f2953e = 3;
        return this.f2956h;
    }

    public long a_() {
        boolean z = this.f2953e == 3 || this.f2953e == 2;
        C1392a.m2709a(z);
        this.f2957i = this.f2955g;
        this.f2953e = 2;
        m3245c();
        return this.f2957i;
    }

    public C1498a m3242b() {
        return this.f2954f != 0 ? new C1498a() : null;
    }

    public void m3245c() {
        this.f2958j = this.f2950b;
        this.f2959k = this.f2951c;
        this.f2960l = 0;
        this.f2961m = this.f2954f;
    }

    public long m3238a(long j, C1464g c1464g) {
        if (this.f2958j == this.f2959k) {
            return -(this.f2960l + 2);
        }
        long c = c1464g.mo2185c();
        if (m3241a(c1464g, this.f2959k)) {
            this.f2949a.m3284a(c1464g, false);
            c1464g.mo2179a();
            long j2 = j - this.f2949a.f2994c;
            int i = this.f2949a.f2999h + this.f2949a.f3000i;
            if (j2 < 0 || j2 > 72000) {
                if (j2 < 0) {
                    this.f2959k = c;
                    this.f2961m = this.f2949a.f2994c;
                } else {
                    this.f2958j = c1464g.mo2185c() + ((long) i);
                    this.f2960l = this.f2949a.f2994c;
                    if ((this.f2959k - this.f2958j) + ((long) i) < 100000) {
                        c1464g.mo2182b(i);
                        return -(this.f2960l + 2);
                    }
                }
                if (this.f2959k - this.f2958j < 100000) {
                    this.f2959k = this.f2958j;
                    return this.f2958j;
                }
                return Math.min(Math.max((c1464g.mo2185c() - ((long) ((j2 <= 0 ? 2 : 1) * i))) + ((j2 * (this.f2959k - this.f2958j)) / (this.f2961m - this.f2960l)), this.f2958j), this.f2959k - 1);
            }
            c1464g.mo2182b(i);
            return -(this.f2949a.f2994c + 2);
        } else if (this.f2958j != c) {
            return this.f2958j;
        } else {
            throw new IOException("No ogg page can be found.");
        }
    }

    private long m3231a(long j, long j2, long j3) {
        long j4 = ((((this.f2951c - this.f2950b) * j2) / this.f2954f) - j3) + j;
        if (j4 < this.f2950b) {
            j4 = this.f2950b;
        }
        if (j4 >= this.f2951c) {
            return this.f2951c - 1;
        }
        return j4;
    }

    void m3243b(C1464g c1464g) {
        if (!m3241a(c1464g, this.f2951c)) {
            throw new EOFException();
        }
    }

    boolean m3241a(C1464g c1464g, long j) {
        long min = Math.min(3 + j, this.f2951c);
        byte[] bArr = new byte[2048];
        int length = bArr.length;
        while (true) {
            if (c1464g.mo2185c() + ((long) length) > min) {
                length = (int) (min - c1464g.mo2185c());
                if (length < 4) {
                    return false;
                }
            }
            c1464g.mo2184b(bArr, 0, length, false);
            int i = 0;
            while (i < length - 3) {
                if (bArr[i] == (byte) 79 && bArr[i + 1] == (byte) 103 && bArr[i + 2] == (byte) 103 && bArr[i + 3] == (byte) 83) {
                    c1464g.mo2182b(i);
                    return true;
                }
                i++;
            }
            c1464g.mo2182b(length - 3);
        }
    }

    long m3244c(C1464g c1464g) {
        m3243b(c1464g);
        this.f2949a.m3283a();
        while ((this.f2949a.f2993b & 4) != 4 && c1464g.mo2185c() < this.f2951c) {
            this.f2949a.m3284a(c1464g, false);
            c1464g.mo2182b(this.f2949a.f2999h + this.f2949a.f3000i);
        }
        return this.f2949a.f2994c;
    }

    long m3240a(C1464g c1464g, long j, long j2) {
        this.f2949a.m3284a(c1464g, false);
        while (this.f2949a.f2994c < j) {
            c1464g.mo2182b(this.f2949a.f2999h + this.f2949a.f3000i);
            j2 = this.f2949a.f2994c;
            this.f2949a.m3284a(c1464g, false);
        }
        c1464g.mo2179a();
        return j2;
    }
}
