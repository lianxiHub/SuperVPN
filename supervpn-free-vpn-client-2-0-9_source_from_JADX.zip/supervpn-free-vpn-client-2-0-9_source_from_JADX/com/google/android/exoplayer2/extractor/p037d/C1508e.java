package com.google.android.exoplayer2.extractor.p037d;

import com.google.android.exoplayer2.ParserException;
import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1414r;
import java.io.EOFException;

final class C1508e {
    private static final int f2991k = C1414r.m2830e("OggS");
    public int f2992a;
    public int f2993b;
    public long f2994c;
    public long f2995d;
    public long f2996e;
    public long f2997f;
    public int f2998g;
    public int f2999h;
    public int f3000i;
    public final int[] f3001j = new int[255];
    private final C1403k f3002l = new C1403k(255);

    C1508e() {
    }

    public void m3283a() {
        this.f2992a = 0;
        this.f2993b = 0;
        this.f2994c = 0;
        this.f2995d = 0;
        this.f2996e = 0;
        this.f2997f = 0;
        this.f2998g = 0;
        this.f2999h = 0;
        this.f3000i = 0;
    }

    public boolean m3284a(C1464g c1464g, boolean z) {
        int i = 0;
        this.f3002l.m2752a();
        m3283a();
        int i2 = (c1464g.mo2188d() == -1 || c1464g.mo2188d() - c1464g.mo2181b() >= 27) ? true : 0;
        if (i2 == 0 || !c1464g.mo2184b(this.f3002l.f2479a, 0, 27, true)) {
            if (z) {
                return false;
            }
            throw new EOFException();
        } else if (this.f3002l.m2771l() == ((long) f2991k)) {
            this.f2992a = this.f3002l.m2766g();
            if (this.f2992a == 0) {
                this.f2993b = this.f3002l.m2766g();
                this.f2994c = this.f3002l.m2776q();
                this.f2995d = this.f3002l.m2772m();
                this.f2996e = this.f3002l.m2772m();
                this.f2997f = this.f3002l.m2772m();
                this.f2998g = this.f3002l.m2766g();
                this.f2999h = this.f2998g + 27;
                this.f3002l.m2752a();
                c1464g.mo2187c(this.f3002l.f2479a, 0, this.f2998g);
                while (i < this.f2998g) {
                    this.f3001j[i] = this.f3002l.m2766g();
                    this.f3000i += this.f3001j[i];
                    i++;
                }
                return true;
            } else if (z) {
                return false;
            } else {
                throw new ParserException("unsupported bit stream revision");
            }
        } else if (z) {
            return false;
        } else {
            throw new ParserException("expected OggS capture pattern at begin of page");
        }
    }
}
