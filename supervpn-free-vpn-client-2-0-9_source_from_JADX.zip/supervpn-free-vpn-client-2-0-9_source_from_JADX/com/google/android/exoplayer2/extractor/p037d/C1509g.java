package com.google.android.exoplayer2.extractor.p037d;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.extractor.p037d.C1503h.C1511a;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1414r;
import com.mopub.volley.DefaultRetryPolicy;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

final class C1509g extends C1503h {
    private static final int f3003a = C1414r.m2830e("Opus");
    private static final byte[] f3004b = new byte[]{(byte) 79, (byte) 112, (byte) 117, (byte) 115, (byte) 72, (byte) 101, (byte) 97, (byte) 100};
    private boolean f3005c;

    C1509g() {
    }

    public static boolean m3287a(C1403k c1403k) {
        if (c1403k.m2757b() < f3004b.length) {
            return false;
        }
        byte[] bArr = new byte[f3004b.length];
        c1403k.m2756a(bArr, 0, f3004b.length);
        return Arrays.equals(bArr, f3004b);
    }

    protected void mo2196a(boolean z) {
        super.mo2196a(z);
        if (z) {
            this.f3005c = false;
        }
    }

    protected long mo2198b(C1403k c1403k) {
        return m3263c(m3285a(c1403k.f2479a));
    }

    protected boolean mo2197a(C1403k c1403k, long j, C1511a c1511a) {
        if (this.f3005c) {
            boolean z = c1403k.m2773n() == f3003a;
            c1403k.m2760c(0);
            return z;
        }
        Object copyOf = Arrays.copyOf(c1403k.f2479a, c1403k.m2759c());
        int i = copyOf[9] & 255;
        int i2 = ((copyOf[11] & 255) << 8) | (copyOf[10] & 255);
        List arrayList = new ArrayList(3);
        arrayList.add(copyOf);
        m3286a(arrayList, i2);
        m3286a(arrayList, 3840);
        c1511a.f3006a = Format.m2407a(null, "audio/opus", null, -1, -1, i, 48000, arrayList, null, 0, "und");
        this.f3005c = true;
        return true;
    }

    private void m3286a(List list, int i) {
        list.add(ByteBuffer.allocate(8).order(ByteOrder.nativeOrder()).putLong((((long) i) * 1000000000) / 48000).array());
    }

    private long m3285a(byte[] bArr) {
        int i;
        int i2 = bArr[0] & 255;
        switch (i2 & 3) {
            case 0:
                i = 1;
                break;
            case 1:
            case 2:
                i = 2;
                break;
            default:
                i = bArr[1] & 63;
                break;
        }
        int i3 = i2 >> 3;
        i2 = i3 & 3;
        if (i3 >= 16) {
            i3 = DefaultRetryPolicy.DEFAULT_TIMEOUT_MS << i2;
        } else if (i3 >= 12) {
            i3 = 10000 << (i2 & 1);
        } else if (i2 == 3) {
            i3 = 60000;
        } else {
            i3 = 10000 << i2;
        }
        return (long) (i3 * i);
    }
}
