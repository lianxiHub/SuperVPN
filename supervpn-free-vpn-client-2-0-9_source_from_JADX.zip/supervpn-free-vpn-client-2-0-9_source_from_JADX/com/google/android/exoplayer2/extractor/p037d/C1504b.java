package com.google.android.exoplayer2.extractor.p037d;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.extractor.C1455m;
import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.extractor.p037d.C1503h.C1511a;
import com.google.android.exoplayer2.p031c.C1396e;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1414r;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

final class C1504b extends C1503h {
    private C1396e f2982a;
    private C1502a f2983b;

    private class C1502a implements C1499f, C1455m {
        final /* synthetic */ C1504b f2962a;
        private long[] f2963b;
        private long[] f2964c;
        private long f2965d;
        private volatile long f2966e;
        private volatile long f2967f;
        private long f2968g;

        private C1502a(C1504b c1504b) {
            this.f2962a = c1504b;
            this.f2965d = -1;
            this.f2968g = -1;
        }

        public void m3248a(long j) {
            this.f2965d = j;
        }

        public void m3249a(C1403k c1403k) {
            c1403k.m2762d(1);
            int k = c1403k.m2770k() / 18;
            this.f2963b = new long[k];
            this.f2964c = new long[k];
            for (int i = 0; i < k; i++) {
                this.f2963b[i] = c1403k.m2775p();
                this.f2964c[i] = c1403k.m2775p();
                c1403k.m2762d(2);
            }
        }

        public long mo2193a(C1464g c1464g) {
            if (this.f2968g < 0) {
                return -1;
            }
            this.f2968g = (-this.f2968g) - 2;
            return this.f2968g;
        }

        public synchronized long a_() {
            this.f2968g = this.f2967f;
            return this.f2966e;
        }

        public C1455m mo2195d() {
            return this;
        }

        public boolean mo2173a() {
            return true;
        }

        public synchronized long mo2175b(long j) {
            int a;
            this.f2966e = this.f2962a.m3263c(j);
            a = C1414r.m2815a(this.f2963b, this.f2966e, true, true);
            this.f2967f = this.f2963b[a];
            return this.f2964c[a] + this.f2965d;
        }

        public long mo2174b() {
            return this.f2962a.f2982a.m2725b();
        }
    }

    C1504b() {
    }

    public static boolean m3266a(C1403k c1403k) {
        return c1403k.m2757b() >= 5 && c1403k.m2766g() == 127 && c1403k.m2771l() == 1179402563;
    }

    protected void mo2196a(boolean z) {
        super.mo2196a(z);
        if (z) {
            this.f2982a = null;
            this.f2983b = null;
        }
    }

    private static boolean m3267a(byte[] bArr) {
        return bArr[0] == (byte) -1;
    }

    protected long mo2198b(C1403k c1403k) {
        if (C1504b.m3267a(c1403k.f2479a)) {
            return (long) m3268c(c1403k);
        }
        return -1;
    }

    protected boolean mo2197a(C1403k c1403k, long j, C1511a c1511a) {
        byte[] bArr = c1403k.f2479a;
        if (this.f2982a == null) {
            this.f2982a = new C1396e(bArr, 17);
            Object copyOfRange = Arrays.copyOfRange(bArr, 9, c1403k.m2759c());
            copyOfRange[4] = Byte.MIN_VALUE;
            List singletonList = Collections.singletonList(copyOfRange);
            c1511a.f3006a = Format.m2407a(null, "audio/x-flac", null, -1, this.f2982a.m2724a(), this.f2982a.f2453f, this.f2982a.f2452e, singletonList, null, 0, null);
        } else if ((bArr[0] & 127) == 3) {
            this.f2983b = new C1502a();
            this.f2983b.m3249a(c1403k);
        } else if (C1504b.m3267a(bArr)) {
            if (this.f2983b == null) {
                return false;
            }
            this.f2983b.m3248a(j);
            c1511a.f3007b = this.f2983b;
            return false;
        }
        return true;
    }

    private int m3268c(C1403k c1403k) {
        int i = (c1403k.f2479a[2] & 255) >> 4;
        switch (i) {
            case 1:
                return 192;
            case 2:
            case 3:
            case 4:
            case 5:
                return 576 << (i - 2);
            case 6:
            case 7:
                c1403k.m2762d(4);
                c1403k.m2784y();
                i = i == 6 ? c1403k.m2766g() : c1403k.m2767h();
                c1403k.m2760c(0);
                return i + 1;
            case 8:
            case 9:
            case 10:
            case 11:
            case 12:
            case 13:
            case 14:
            case 15:
                return 256 << (i - 8);
            default:
                return -1;
        }
    }
}
