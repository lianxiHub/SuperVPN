package com.google.android.exoplayer2.extractor.p037d;

import com.google.android.exoplayer2.p031c.C1392a;

final class C1513i {
    public final byte[] f3008a;
    private int f3009b;
    private int f3010c;
    private int f3011d;

    public C1513i(byte[] bArr) {
        this(bArr, bArr.length);
    }

    public C1513i(byte[] bArr, int i) {
        this.f3008a = bArr;
        this.f3009b = i * 8;
    }

    public boolean m3294a() {
        return m3293a(1) == 1;
    }

    public int m3293a(int i) {
        C1392a.m2711b(m3295b() + i <= this.f3009b);
        if (i == 0) {
            return 0;
        }
        long min;
        int i2;
        int i3;
        int i4;
        if (this.f3011d != 0) {
            min = Math.min(i, 8 - this.f3011d);
            i2 = (255 >>> (8 - min)) & (this.f3008a[this.f3010c] >>> this.f3011d);
            this.f3011d += min;
            if (this.f3011d == 8) {
                this.f3010c++;
                this.f3011d = 0;
            }
        } else {
            min = 0;
            i2 = 0;
        }
        if (i - min > 7) {
            int i5 = (i - min) / 8;
            i3 = i2;
            i2 = 0;
            while (i2 < i5) {
                long j = (long) i3;
                byte[] bArr = this.f3008a;
                int i6 = this.f3010c;
                this.f3010c = i6 + 1;
                min += 8;
                i2++;
                i3 = (int) (j | ((((long) bArr[i6]) & 255) << min));
            }
            int i7 = min;
            i4 = i3;
            i3 = i7;
        } else {
            i3 = min;
            i4 = i2;
        }
        if (i > i3) {
            i2 = i - i3;
            i4 |= ((255 >>> (8 - i2)) & this.f3008a[this.f3010c]) << i3;
            this.f3011d += i2;
        }
        return i4;
    }

    public void m3296b(int i) {
        C1392a.m2711b(m3295b() + i <= this.f3009b);
        this.f3010c += i / 8;
        this.f3011d += i % 8;
        if (this.f3011d > 7) {
            this.f3010c++;
            this.f3011d -= 8;
        }
    }

    public int m3295b() {
        return (this.f3010c * 8) + this.f3011d;
    }
}
