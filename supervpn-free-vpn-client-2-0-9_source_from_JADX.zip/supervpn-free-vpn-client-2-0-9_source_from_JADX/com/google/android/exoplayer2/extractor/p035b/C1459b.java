package com.google.android.exoplayer2.extractor.p035b;

import android.util.Pair;
import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.extractor.C1568j;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1414r;
import java.nio.charset.Charset;

final class C1459b {
    private static final int f2707a = C1414r.m2830e("ID3");
    private static final Charset[] f2708b = new Charset[]{Charset.forName("ISO-8859-1"), Charset.forName("UTF-16LE"), Charset.forName("UTF-16BE"), Charset.forName(WebRequest.CHARSET_UTF_8)};

    public static void m3039a(C1464g c1464g, C1568j c1568j) {
        C1403k c1403k = new C1403k(10);
        int i = 0;
        while (true) {
            c1464g.mo2187c(c1403k.f2479a, 0, 10);
            c1403k.m2760c(0);
            if (c1403k.m2770k() != f2707a) {
                c1464g.mo2179a();
                c1464g.mo2186c(i);
                return;
            }
            int g = c1403k.m2766g();
            int g2 = c1403k.m2766g();
            int g3 = c1403k.m2766g();
            int s = c1403k.m2778s();
            if (c1568j.m3563a() || !C1459b.m3041a(g, g2, g3, s)) {
                c1464g.mo2186c(s);
            } else {
                byte[] bArr = new byte[s];
                c1464g.mo2187c(bArr, 0, s);
                C1459b.m3038a(new C1403k(bArr), g, g3, c1568j);
            }
            i += s + 10;
        }
    }

    private static boolean m3041a(int i, int i2, int i3, int i4) {
        return i2 != 255 && i >= 2 && i <= 4 && i4 <= 3145728 && ((i != 2 || ((i3 & 63) == 0 && (i3 & 64) == 0)) && ((i != 3 || (i3 & 31) == 0) && (i != 4 || (i3 & 15) == 0)));
    }

    private static void m3038a(C1403k c1403k, int i, int i2, C1568j c1568j) {
        C1459b.m3042a(c1403k, i, i2);
        c1403k.m2760c(0);
        int s;
        if (i != 3 || (i2 & 64) == 0) {
            if (i == 4 && (i2 & 64) != 0) {
                if (c1403k.m2757b() >= 4) {
                    s = c1403k.m2778s();
                    if (s >= 6 && s <= c1403k.m2757b() + 4) {
                        c1403k.m2760c(s);
                    } else {
                        return;
                    }
                }
                return;
            }
        } else if (c1403k.m2757b() >= 4) {
            s = c1403k.m2779t();
            if (s <= c1403k.m2757b()) {
                if (s >= 6) {
                    c1403k.m2762d(2);
                    int t = c1403k.m2779t();
                    c1403k.m2760c(4);
                    c1403k.m2758b(c1403k.m2759c() - t);
                    if (c1403k.m2757b() < s) {
                        return;
                    }
                }
                c1403k.m2762d(s);
            } else {
                return;
            }
        } else {
            return;
        }
        while (true) {
            Pair a = C1459b.m3037a(i, c1403k);
            if (a == null) {
                return;
            }
            if (((String) a.first).length() > 3 && c1568j.m3565a(((String) a.first).substring(3), (String) a.second)) {
                return;
            }
        }
    }

    private static Pair m3037a(int i, C1403k c1403k) {
        int h;
        while (true) {
            int k;
            if (i == 2) {
                if (c1403k.m2757b() < 6) {
                    return null;
                }
                String a = c1403k.m2751a(3, Charset.forName("US-ASCII"));
                if (a.equals("\u0000\u0000\u0000")) {
                    return null;
                }
                k = c1403k.m2770k();
                if (k == 0 || k > c1403k.m2757b()) {
                    return null;
                }
                if (a.equals("COM")) {
                    break;
                }
                c1403k.m2762d(k);
            } else if (c1403k.m2757b() < 10) {
                return null;
            } else {
                String a2 = c1403k.m2751a(4, Charset.forName("US-ASCII"));
                if (a2.equals("\u0000\u0000\u0000\u0000")) {
                    return null;
                }
                k = i == 4 ? c1403k.m2778s() : c1403k.m2779t();
                if (k == 0 || k > c1403k.m2757b() - 2) {
                    return null;
                }
                h = c1403k.m2767h();
                if ((i != 4 || (h & 12) == 0) && (i != 3 || (h & 192) == 0)) {
                    h = 0;
                } else {
                    h = 1;
                }
                if (h == 0 && a2.equals("COMM")) {
                    break;
                }
                c1403k.m2762d(k);
            }
        }
        h = c1403k.m2766g();
        if (h < 0 || h >= f2708b.length) {
            return null;
        }
        Pair create;
        String[] split = c1403k.m2751a(k - 1, f2708b[h]).split("\u0000");
        if (split.length == 2) {
            create = Pair.create(split[0], split[1]);
        } else {
            create = null;
        }
        return create;
    }

    private static boolean m3042a(C1403k c1403k, int i, int i2) {
        if (i != 4) {
            if ((i2 & 128) != 0) {
                Object obj = c1403k.f2479a;
                int length = obj.length;
                int i3 = false;
                while (i3 + 1 < length) {
                    if ((obj[i3] & 255) == 255 && obj[i3 + 1] == (byte) 0) {
                        System.arraycopy(obj, i3 + 2, obj, i3 + 1, (length - i3) - 2);
                        length--;
                    }
                    i3++;
                }
                c1403k.m2758b(length);
            }
        } else if (C1459b.m3043a(c1403k, false)) {
            C1459b.m3044b(c1403k, false);
        } else if (!C1459b.m3043a(c1403k, true)) {
            return false;
        } else {
            C1459b.m3044b(c1403k, true);
        }
        return true;
    }

    private static boolean m3043a(C1403k c1403k, boolean z) {
        c1403k.m2760c(0);
        while (c1403k.m2757b() >= 10) {
            if (c1403k.m2773n() == 0) {
                return true;
            }
            long l = c1403k.m2771l();
            if (!z) {
                if ((8421504 & l) != 0) {
                    return false;
                }
                l = (((l >> 24) & 127) << 21) | (((l & 127) | (((l >> 8) & 127) << 7)) | (((l >> 16) & 127) << 14));
            }
            if (l > ((long) (c1403k.m2757b() - 2))) {
                return false;
            }
            if ((c1403k.m2767h() & 1) != 0 && c1403k.m2757b() < 4) {
                return false;
            }
            c1403k.m2762d((int) l);
        }
        return true;
    }

    private static void m3044b(C1403k c1403k, boolean z) {
        c1403k.m2760c(0);
        byte[] bArr = c1403k.f2479a;
        while (c1403k.m2757b() >= 10 && c1403k.m2773n() != 0) {
            int d;
            int i;
            int t = z ? c1403k.m2779t() : c1403k.m2778s();
            int h = c1403k.m2767h();
            if ((h & 1) != 0) {
                d = c1403k.m2761d();
                System.arraycopy(bArr, d + 4, bArr, d, c1403k.m2757b() - 4);
                d = t - 4;
                i = h & -2;
                c1403k.m2758b(c1403k.m2759c() - 4);
            } else {
                i = h;
                d = t;
            }
            if ((i & 2) != 0) {
                t = c1403k.m2761d() + 1;
                int i2 = 0;
                int i3 = t;
                while (i2 + 1 < d) {
                    if ((bArr[t - 1] & 255) == 255 && bArr[t] == (byte) 0) {
                        t++;
                        d--;
                    }
                    int i4 = i3 + 1;
                    int i5 = t + 1;
                    bArr[i3] = bArr[t];
                    i2++;
                    i3 = i4;
                    t = i5;
                }
                c1403k.m2758b(c1403k.m2759c() - (t - i3));
                System.arraycopy(bArr, t, bArr, i3, c1403k.m2757b() - t);
                t = i & -3;
            } else {
                t = i;
            }
            if (t != h || z) {
                i = c1403k.m2761d() - 6;
                C1459b.m3040a(bArr, i, d);
                bArr[i + 4] = (byte) (t >> 8);
                bArr[i + 5] = (byte) (t & 255);
            }
            c1403k.m2762d(d);
        }
    }

    private static void m3040a(byte[] bArr, int i, int i2) {
        bArr[i] = (byte) ((i2 >> 21) & 127);
        bArr[i + 1] = (byte) ((i2 >> 14) & 127);
        bArr[i + 2] = (byte) ((i2 >> 7) & 127);
        bArr[i + 3] = (byte) (i2 & 127);
    }
}
