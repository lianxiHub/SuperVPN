package com.google.android.exoplayer2.extractor.p035b;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.extractor.C1447i;
import com.google.android.exoplayer2.extractor.C1451f;
import com.google.android.exoplayer2.extractor.C1455m;
import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.extractor.C1568j;
import com.google.android.exoplayer2.extractor.C1569k;
import com.google.android.exoplayer2.extractor.C1570l;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1414r;
import java.io.EOFException;

public final class C1461c implements C1451f {
    public static final C1447i f2709a = new C14601();
    private static final int f2710b = C1414r.m2830e("Xing");
    private static final int f2711c = C1414r.m2830e("Info");
    private static final int f2712d = C1414r.m2830e("VBRI");
    private final long f2713e;
    private final C1403k f2714f;
    private final C1569k f2715g;
    private final C1568j f2716h;
    private C1567h f2717i;
    private C1521o f2718j;
    private int f2719k;
    private C1457a f2720l;
    private long f2721m;
    private long f2722n;
    private int f2723o;

    interface C1457a extends C1455m {
        long mo2176a(long j);
    }

    static class C14601 implements C1447i {
        C14601() {
        }

        public C1451f[] mo2159a() {
            return new C1451f[]{new C1461c()};
        }
    }

    public C1461c() {
        this(-9223372036854775807L);
    }

    public C1461c(long j) {
        this.f2713e = j;
        this.f2714f = new C1403k(4);
        this.f2715g = new C1569k();
        this.f2716h = new C1568j();
        this.f2721m = -9223372036854775807L;
    }

    public boolean mo2171a(C1464g c1464g) {
        return m3046a(c1464g, true);
    }

    public void mo2170a(C1567h c1567h) {
        this.f2717i = c1567h;
        this.f2718j = this.f2717i.mo2273a(0);
        this.f2717i.mo2274a();
    }

    public void mo2169a(long j) {
        this.f2719k = 0;
        this.f2721m = -9223372036854775807L;
        this.f2722n = 0;
        this.f2723o = 0;
    }

    public void mo2172c() {
    }

    public int mo2168a(C1464g c1464g, C1570l c1570l) {
        if (this.f2719k == 0) {
            try {
                m3046a(c1464g, false);
            } catch (EOFException e) {
                return -1;
            }
        }
        if (this.f2720l == null) {
            this.f2720l = m3048c(c1464g);
            this.f2717i.mo2276a(this.f2720l);
            this.f2718j.mo2202a(Format.m2405a(null, this.f2715g.f3339b, null, -1, 4096, this.f2715g.f3342e, this.f2715g.f3341d, -1, this.f2716h.f3329a, this.f2716h.f3330b, null, null, 0, null));
        }
        return m3047b(c1464g);
    }

    private int m3047b(C1464g c1464g) {
        int n;
        if (this.f2723o == 0) {
            c1464g.mo2179a();
            if (!c1464g.mo2184b(this.f2714f.f2479a, 0, 4, true)) {
                return -1;
            }
            this.f2714f.m2760c(0);
            n = this.f2714f.m2773n();
            if ((n & -128000) != (this.f2719k & -128000) || C1569k.m3566a(n) == -1) {
                c1464g.mo2182b(1);
                this.f2719k = 0;
                return 0;
            }
            C1569k.m3568a(n, this.f2715g);
            if (this.f2721m == -9223372036854775807L) {
                this.f2721m = this.f2720l.mo2176a(c1464g.mo2185c());
                if (this.f2713e != -9223372036854775807L) {
                    long a = this.f2720l.mo2176a(0);
                    this.f2721m = (this.f2713e - a) + this.f2721m;
                }
            }
            this.f2723o = this.f2715g.f3340c;
        }
        n = this.f2718j.mo2200a(c1464g, this.f2723o, true);
        if (n == -1) {
            return -1;
        }
        this.f2723o -= n;
        if (this.f2723o > 0) {
            return 0;
        }
        this.f2718j.mo2201a(((this.f2722n * 1000000) / ((long) this.f2715g.f3341d)) + this.f2721m, 1, this.f2715g.f3340c, 0, null);
        this.f2722n += (long) this.f2715g.f3344g;
        this.f2723o = 0;
        return 0;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean m3046a(com.google.android.exoplayer2.extractor.C1464g r13, boolean r14) {
        /*
        r12 = this;
        r11 = 4;
        r10 = -128000; // 0xfffffffffffe0c00 float:NaN double:NaN;
        r7 = 1;
        r2 = 0;
        if (r14 == 0) goto L_0x0042;
    L_0x0008:
        r0 = 4096; // 0x1000 float:5.74E-42 double:2.0237E-320;
    L_0x000a:
        r13.mo2179a();
        r4 = r13.mo2185c();
        r8 = 0;
        r1 = (r4 > r8 ? 1 : (r4 == r8 ? 0 : -1));
        if (r1 != 0) goto L_0x009c;
    L_0x0017:
        r1 = r12.f2716h;
        com.google.android.exoplayer2.extractor.p035b.C1459b.m3039a(r13, r1);
        r4 = r13.mo2181b();
        r1 = (int) r4;
        if (r14 != 0) goto L_0x0026;
    L_0x0023:
        r13.mo2182b(r1);
    L_0x0026:
        r3 = r1;
        r4 = r2;
        r5 = r2;
        r1 = r2;
    L_0x002a:
        r6 = r12.f2714f;
        r8 = r6.f2479a;
        if (r5 <= 0) goto L_0x0045;
    L_0x0030:
        r6 = r7;
    L_0x0031:
        r6 = r13.mo2184b(r8, r2, r11, r6);
        if (r6 != 0) goto L_0x0047;
    L_0x0037:
        if (r14 == 0) goto L_0x0098;
    L_0x0039:
        r0 = r3 + r1;
        r13.mo2182b(r0);
    L_0x003e:
        r12.f2719k = r4;
        r2 = r7;
    L_0x0041:
        return r2;
    L_0x0042:
        r0 = 131072; // 0x20000 float:1.83671E-40 double:6.47582E-319;
        goto L_0x000a;
    L_0x0045:
        r6 = r2;
        goto L_0x0031;
    L_0x0047:
        r6 = r12.f2714f;
        r6.m2760c(r2);
        r6 = r12.f2714f;
        r6 = r6.m2773n();
        if (r4 == 0) goto L_0x005a;
    L_0x0054:
        r8 = r6 & r10;
        r9 = r4 & r10;
        if (r8 != r9) goto L_0x0061;
    L_0x005a:
        r8 = com.google.android.exoplayer2.extractor.C1569k.m3566a(r6);
        r9 = -1;
        if (r8 != r9) goto L_0x0085;
    L_0x0061:
        r4 = r1 + 1;
        if (r1 != r0) goto L_0x0070;
    L_0x0065:
        if (r14 != 0) goto L_0x0041;
    L_0x0067:
        r0 = new com.google.android.exoplayer2.ParserException;
        r1 = "Searched too many bytes.";
        r0.<init>(r1);
        throw r0;
    L_0x0070:
        if (r14 == 0) goto L_0x007e;
    L_0x0072:
        r13.mo2179a();
        r1 = r3 + r4;
        r13.mo2186c(r1);
        r1 = r4;
        r5 = r2;
        r4 = r2;
        goto L_0x002a;
    L_0x007e:
        r13.mo2182b(r7);
        r1 = r4;
        r5 = r2;
        r4 = r2;
        goto L_0x002a;
    L_0x0085:
        r5 = r5 + 1;
        if (r5 != r7) goto L_0x0095;
    L_0x0089:
        r4 = r12.f2715g;
        com.google.android.exoplayer2.extractor.C1569k.m3568a(r6, r4);
        r4 = r6;
    L_0x008f:
        r6 = r8 + -4;
        r13.mo2186c(r6);
        goto L_0x002a;
    L_0x0095:
        if (r5 != r11) goto L_0x008f;
    L_0x0097:
        goto L_0x0037;
    L_0x0098:
        r13.mo2179a();
        goto L_0x003e;
    L_0x009c:
        r1 = r2;
        r3 = r2;
        r4 = r2;
        r5 = r2;
        goto L_0x002a;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.extractor.b.c.a(com.google.android.exoplayer2.extractor.g, boolean):boolean");
    }

    private C1457a m3048c(C1464g c1464g) {
        int n;
        C1457a a;
        int i = 21;
        C1403k c1403k = new C1403k(this.f2715g.f3340c);
        c1464g.mo2187c(c1403k.f2479a, 0, this.f2715g.f3340c);
        long c = c1464g.mo2185c();
        long d = c1464g.mo2188d();
        if ((this.f2715g.f3338a & 1) != 0) {
            if (this.f2715g.f3342e != 1) {
                i = 36;
            }
        } else if (this.f2715g.f3342e == 1) {
            i = 13;
        }
        if (c1403k.m2759c() >= i + 4) {
            c1403k.m2760c(i);
            n = c1403k.m2773n();
        } else {
            n = 0;
        }
        if (n == f2710b || n == f2711c) {
            a = C1463e.m3060a(this.f2715g, c1403k, c, d);
            if (!(a == null || this.f2716h.m3563a())) {
                c1464g.mo2179a();
                c1464g.mo2186c(i + 141);
                c1464g.mo2187c(this.f2714f.f2479a, 0, 3);
                this.f2714f.m2760c(0);
                this.f2716h.m3564a(this.f2714f.m2770k());
            }
            c1464g.mo2182b(this.f2715g.f3340c);
        } else {
            if (c1403k.m2759c() >= 40) {
                c1403k.m2760c(36);
                if (c1403k.m2773n() == f2712d) {
                    a = C1462d.m3054a(this.f2715g, c1403k, c, d);
                    c1464g.mo2182b(this.f2715g.f3340c);
                }
            }
            a = null;
        }
        if (a != null) {
            return a;
        }
        c1464g.mo2179a();
        c1464g.mo2187c(this.f2714f.f2479a, 0, 4);
        this.f2714f.m2760c(0);
        C1569k.m3568a(this.f2714f.m2773n(), this.f2715g);
        return new C1458a(c1464g.mo2185c(), this.f2715g.f3343f, d);
    }
}
