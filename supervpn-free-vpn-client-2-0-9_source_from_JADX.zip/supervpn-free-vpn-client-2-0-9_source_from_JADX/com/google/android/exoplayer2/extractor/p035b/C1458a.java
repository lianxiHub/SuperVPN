package com.google.android.exoplayer2.extractor.p035b;

import com.google.android.exoplayer2.extractor.p035b.C1461c.C1457a;

final class C1458a implements C1457a {
    private final long f2704a;
    private final int f2705b;
    private final long f2706c;

    public C1458a(long j, int i, long j2) {
        this.f2704a = j;
        this.f2705b = i;
        this.f2706c = j2 == -1 ? -9223372036854775807L : mo2176a(j2);
    }

    public boolean mo2173a() {
        return this.f2706c != -9223372036854775807L;
    }

    public long mo2175b(long j) {
        return this.f2706c == -9223372036854775807L ? 0 : this.f2704a + ((((long) this.f2705b) * j) / 8000000);
    }

    public long mo2176a(long j) {
        return ((Math.max(0, j - this.f2704a) * 1000000) * 8) / ((long) this.f2705b);
    }

    public long mo2174b() {
        return this.f2706c;
    }
}
