package com.google.android.exoplayer2.extractor.p035b;

import com.google.android.exoplayer2.extractor.C1569k;
import com.google.android.exoplayer2.extractor.p035b.C1461c.C1457a;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1414r;

final class C1462d implements C1457a {
    private final long[] f2724a;
    private final long[] f2725b;
    private final long f2726c;

    public static C1462d m3054a(C1569k c1569k, C1403k c1403k, long j, long j2) {
        c1403k.m2762d(10);
        int n = c1403k.m2773n();
        if (n <= 0) {
            return null;
        }
        int i = c1569k.f3341d;
        long a = C1414r.m2816a((long) n, ((long) (i >= 32000 ? 1152 : 576)) * 1000000, (long) i);
        int h = c1403k.m2767h();
        int h2 = c1403k.m2767h();
        int h3 = c1403k.m2767h();
        c1403k.m2762d(2);
        long j3 = j + ((long) c1569k.f3340c);
        long[] jArr = new long[(h + 1)];
        long[] jArr2 = new long[(h + 1)];
        jArr[0] = 0;
        jArr2[0] = j3;
        for (n = 1; n < jArr.length; n++) {
            int g;
            long j4;
            switch (h3) {
                case 1:
                    g = c1403k.m2766g();
                    break;
                case 2:
                    g = c1403k.m2767h();
                    break;
                case 3:
                    g = c1403k.m2770k();
                    break;
                case 4:
                    g = c1403k.m2779t();
                    break;
                default:
                    return null;
            }
            j3 += (long) (g * h2);
            jArr[n] = (((long) n) * a) / ((long) h);
            if (j2 == -1) {
                j4 = j3;
            } else {
                j4 = Math.min(j2, j3);
            }
            jArr2[n] = j4;
        }
        return new C1462d(jArr, jArr2, a);
    }

    private C1462d(long[] jArr, long[] jArr2, long j) {
        this.f2724a = jArr;
        this.f2725b = jArr2;
        this.f2726c = j;
    }

    public boolean mo2173a() {
        return true;
    }

    public long mo2175b(long j) {
        return this.f2725b[C1414r.m2815a(this.f2724a, j, true, true)];
    }

    public long mo2176a(long j) {
        return this.f2724a[C1414r.m2815a(this.f2725b, j, true, true)];
    }

    public long mo2174b() {
        return this.f2726c;
    }
}
