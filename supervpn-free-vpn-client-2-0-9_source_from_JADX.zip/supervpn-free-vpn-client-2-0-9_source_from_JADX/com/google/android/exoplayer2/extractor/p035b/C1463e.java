package com.google.android.exoplayer2.extractor.p035b;

import com.google.android.exoplayer2.extractor.C1569k;
import com.google.android.exoplayer2.extractor.p035b.C1461c.C1457a;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1414r;

final class C1463e implements C1457a {
    private final long f2727a;
    private final long f2728b;
    private final long f2729c;
    private final long[] f2730d;
    private final long f2731e;
    private final int f2732f;

    public static C1463e m3060a(C1569k c1569k, C1403k c1403k, long j, long j2) {
        int i = c1569k.f3344g;
        int i2 = c1569k.f3341d;
        long j3 = j + ((long) c1569k.f3340c);
        int n = c1403k.m2773n();
        if ((n & 1) == 1) {
            int t = c1403k.m2779t();
            if (t != 0) {
                long a = C1414r.m2816a((long) t, ((long) i) * 1000000, (long) i2);
                if ((n & 6) != 6) {
                    return new C1463e(j3, a, j2);
                }
                long t2 = (long) c1403k.m2779t();
                c1403k.m2762d(1);
                long[] jArr = new long[99];
                for (t = 0; t < 99; t++) {
                    jArr[t] = (long) c1403k.m2766g();
                }
                return new C1463e(j3, a, j2, jArr, t2, c1569k.f3340c);
            }
        }
        return null;
    }

    private C1463e(long j, long j2, long j3) {
        this(j, j2, j3, null, 0, 0);
    }

    private C1463e(long j, long j2, long j3, long[] jArr, long j4, int i) {
        this.f2727a = j;
        this.f2728b = j2;
        this.f2729c = j3;
        this.f2730d = jArr;
        this.f2731e = j4;
        this.f2732f = i;
    }

    public boolean mo2173a() {
        return this.f2730d != null;
    }

    public long mo2175b(long j) {
        float f = 256.0f;
        float f2 = 0.0f;
        if (!mo2173a()) {
            return this.f2727a;
        }
        float f3 = (((float) j) * 100.0f) / ((float) this.f2728b);
        if (f3 <= 0.0f) {
            f = 0.0f;
        } else if (f3 < 100.0f) {
            int i = (int) f3;
            if (i != 0) {
                f2 = (float) this.f2730d[i - 1];
            }
            if (i < 99) {
                f = (float) this.f2730d[i];
            }
            f = ((f - f2) * (f3 - ((float) i))) + f2;
        }
        return Math.min(this.f2727a + Math.round((((double) f) * 0.00390625d) * ((double) this.f2731e)), this.f2729c != -1 ? this.f2729c - 1 : ((this.f2727a - ((long) this.f2732f)) + this.f2731e) - 1);
    }

    public long mo2176a(long j) {
        if (!mo2173a() || j < this.f2727a) {
            return 0;
        }
        double d = (256.0d * ((double) (j - this.f2727a))) / ((double) this.f2731e);
        int a = C1414r.m2815a(this.f2730d, (long) d, true, false) + 1;
        long a2 = m3059a(a);
        long j2 = a == 0 ? 0 : this.f2730d[a - 1];
        long j3 = a == 99 ? 256 : this.f2730d[a];
        return a2 + (j3 == j2 ? 0 : (long) ((((double) (m3059a(a + 1) - a2)) * (d - ((double) j2))) / ((double) (j3 - j2))));
    }

    public long mo2174b() {
        return this.f2728b;
    }

    private long m3059a(int i) {
        return (this.f2728b * ((long) i)) / 100;
    }
}
