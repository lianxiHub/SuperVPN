package com.google.android.exoplayer2.extractor;

import com.google.android.exoplayer2.p031c.C1414r;

public final class C1456a implements C1455m {
    public final int f2698a;
    public final int[] f2699b;
    public final long[] f2700c;
    public final long[] f2701d;
    public final long[] f2702e;
    private final long f2703f;

    public C1456a(int[] iArr, long[] jArr, long[] jArr2, long[] jArr3) {
        this.f2699b = iArr;
        this.f2700c = jArr;
        this.f2701d = jArr2;
        this.f2702e = jArr3;
        this.f2698a = iArr.length;
        this.f2703f = jArr2[this.f2698a - 1] + jArr3[this.f2698a - 1];
    }

    public int m3028a(long j) {
        return C1414r.m2815a(this.f2702e, j, true, true);
    }

    public boolean mo2173a() {
        return true;
    }

    public long mo2174b() {
        return this.f2703f;
    }

    public long mo2175b(long j) {
        return this.f2700c[m3028a(j)];
    }
}
