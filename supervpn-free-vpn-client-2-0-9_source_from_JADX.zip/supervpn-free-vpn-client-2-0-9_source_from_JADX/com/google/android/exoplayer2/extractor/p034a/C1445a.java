package com.google.android.exoplayer2.extractor.p034a;

import com.google.android.exoplayer2.ParserException;
import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.p031c.C1392a;
import java.util.Stack;

final class C1445a implements C1444b {
    private final byte[] f2606a = new byte[8];
    private final Stack f2607b = new Stack();
    private final C1454f f2608c = new C1454f();
    private C1446c f2609d;
    private int f2610e;
    private int f2611f;
    private long f2612g;

    private static final class C1443a {
        private final int f2604a;
        private final long f2605b;

        private C1443a(int i, long j) {
            this.f2604a = i;
            this.f2605b = j;
        }
    }

    C1445a() {
    }

    public void mo2157a(C1446c c1446c) {
        this.f2609d = c1446c;
    }

    public void mo2156a() {
        this.f2610e = 0;
        this.f2607b.clear();
        this.f2608c.m3023a();
    }

    public boolean mo2158a(C1464g c1464g) {
        C1392a.m2711b(this.f2609d != null);
        while (true) {
            if (this.f2607b.isEmpty() || c1464g.mo2185c() < ((C1443a) this.f2607b.peek()).f2605b) {
                if (this.f2610e == 0) {
                    long a = this.f2608c.m3022a(c1464g, true, false, 4);
                    if (a == -2) {
                        a = m2958b(c1464g);
                    }
                    if (a == -1) {
                        return false;
                    }
                    this.f2611f = (int) a;
                    this.f2610e = 1;
                }
                if (this.f2610e == 1) {
                    this.f2612g = this.f2608c.m3022a(c1464g, false, true, 8);
                    this.f2610e = 2;
                }
                int a2 = this.f2609d.mo2160a(this.f2611f);
                switch (a2) {
                    case 0:
                        c1464g.mo2182b((int) this.f2612g);
                        this.f2610e = 0;
                    case 1:
                        long c = c1464g.mo2185c();
                        this.f2607b.add(new C1443a(this.f2611f, this.f2612g + c));
                        this.f2609d.mo2164a(this.f2611f, c, this.f2612g);
                        this.f2610e = 0;
                        return true;
                    case 2:
                        if (this.f2612g > 8) {
                            throw new ParserException("Invalid integer size: " + this.f2612g);
                        }
                        this.f2609d.mo2163a(this.f2611f, m2956a(c1464g, (int) this.f2612g));
                        this.f2610e = 0;
                        return true;
                    case 3:
                        if (this.f2612g > 2147483647L) {
                            throw new ParserException("String element size: " + this.f2612g);
                        }
                        this.f2609d.mo2165a(this.f2611f, m2959c(c1464g, (int) this.f2612g));
                        this.f2610e = 0;
                        return true;
                    case 4:
                        this.f2609d.mo2162a(this.f2611f, (int) this.f2612g, c1464g);
                        this.f2610e = 0;
                        return true;
                    case 5:
                        if (this.f2612g == 4 || this.f2612g == 8) {
                            this.f2609d.mo2161a(this.f2611f, m2957b(c1464g, (int) this.f2612g));
                            this.f2610e = 0;
                            return true;
                        }
                        throw new ParserException("Invalid float size: " + this.f2612g);
                    default:
                        throw new ParserException("Invalid element type " + a2);
                }
            }
            this.f2609d.mo2167c(((C1443a) this.f2607b.pop()).f2604a);
            return true;
        }
    }

    private long m2958b(C1464g c1464g) {
        c1464g.mo2179a();
        while (true) {
            c1464g.mo2187c(this.f2606a, 0, 4);
            int a = C1454f.m3020a(this.f2606a[0]);
            if (a != -1 && a <= 4) {
                int a2 = (int) C1454f.m3021a(this.f2606a, a, false);
                if (this.f2609d.mo2166b(a2)) {
                    c1464g.mo2182b(a);
                    return (long) a2;
                }
            }
            c1464g.mo2182b(1);
        }
    }

    private long m2956a(C1464g c1464g, int i) {
        int i2 = 0;
        c1464g.mo2183b(this.f2606a, 0, i);
        long j = 0;
        while (i2 < i) {
            j = (j << 8) | ((long) (this.f2606a[i2] & 255));
            i2++;
        }
        return j;
    }

    private double m2957b(C1464g c1464g, int i) {
        long a = m2956a(c1464g, i);
        if (i == 4) {
            return (double) Float.intBitsToFloat((int) a);
        }
        return Double.longBitsToDouble(a);
    }

    private String m2959c(C1464g c1464g, int i) {
        if (i == 0) {
            return "";
        }
        byte[] bArr = new byte[i];
        c1464g.mo2183b(bArr, 0, i);
        return new String(bArr);
    }
}
