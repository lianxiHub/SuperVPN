package com.google.android.exoplayer2.extractor.p034a;

import com.google.android.exoplayer2.extractor.C1464g;

interface C1446c {
    int mo2160a(int i);

    void mo2161a(int i, double d);

    void mo2162a(int i, int i2, C1464g c1464g);

    void mo2163a(int i, long j);

    void mo2164a(int i, long j, long j2);

    void mo2165a(int i, String str);

    boolean mo2166b(int i);

    void mo2167c(int i);
}
