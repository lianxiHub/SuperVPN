package com.google.android.exoplayer2.extractor.p034a;

import com.google.android.exoplayer2.extractor.C1464g;

final class C1454f {
    private static final long[] f2694a = new long[]{128, 64, 32, 16, 8, 4, 2, 1};
    private final byte[] f2695b = new byte[8];
    private int f2696c;
    private int f2697d;

    public void m3023a() {
        this.f2696c = 0;
        this.f2697d = 0;
    }

    public long m3022a(C1464g c1464g, boolean z, boolean z2, int i) {
        if (this.f2696c == 0) {
            if (!c1464g.mo2180a(this.f2695b, 0, 1, z)) {
                return -1;
            }
            this.f2697d = C1454f.m3020a(this.f2695b[0] & 255);
            if (this.f2697d == -1) {
                throw new IllegalStateException("No valid varint length mask found");
            }
            this.f2696c = 1;
        }
        if (this.f2697d > i) {
            this.f2696c = 0;
            return -2;
        }
        if (this.f2697d != 1) {
            c1464g.mo2183b(this.f2695b, 1, this.f2697d - 1);
        }
        this.f2696c = 0;
        return C1454f.m3021a(this.f2695b, this.f2697d, z2);
    }

    public int m3024b() {
        return this.f2697d;
    }

    public static int m3020a(int i) {
        for (int i2 = 0; i2 < f2694a.length; i2++) {
            if ((f2694a[i2] & ((long) i)) != 0) {
                return i2 + 1;
            }
        }
        return -1;
    }

    public static long m3021a(byte[] bArr, int i, boolean z) {
        long j = ((long) bArr[0]) & 255;
        if (z) {
            j &= f2694a[i - 1] ^ -1;
        }
        long j2 = j;
        for (int i2 = 1; i2 < i; i2++) {
            j2 = (j2 << 8) | (((long) bArr[i2]) & 255);
        }
        return j2;
    }
}
