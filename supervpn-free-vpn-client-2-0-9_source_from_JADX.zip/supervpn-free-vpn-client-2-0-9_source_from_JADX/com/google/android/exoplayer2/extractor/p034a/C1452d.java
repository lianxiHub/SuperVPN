package com.google.android.exoplayer2.extractor.p034a;

import android.util.SparseArray;
import com.google.android.exoplayer2.C1391b;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.ParserException;
import com.google.android.exoplayer2.drm.DrmInitData;
import com.google.android.exoplayer2.drm.DrmInitData.SchemeData;
import com.google.android.exoplayer2.extractor.C1447i;
import com.google.android.exoplayer2.extractor.C1451f;
import com.google.android.exoplayer2.extractor.C1455m;
import com.google.android.exoplayer2.extractor.C1455m.C1571a;
import com.google.android.exoplayer2.extractor.C1456a;
import com.google.android.exoplayer2.extractor.C1464g;
import com.google.android.exoplayer2.extractor.C1521o;
import com.google.android.exoplayer2.extractor.C1567h;
import com.google.android.exoplayer2.extractor.C1570l;
import com.google.android.exoplayer2.p031c.C1397f;
import com.google.android.exoplayer2.p031c.C1398h;
import com.google.android.exoplayer2.p031c.C1401i;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1414r;
import com.google.android.exoplayer2.p033d.C1419a;
import com.google.android.exoplayer2.p033d.C1420b;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class C1452d implements C1451f {
    public static final C1447i f2640a = new C14481();
    private static final byte[] f2641b = new byte[]{(byte) 49, (byte) 10, (byte) 48, (byte) 48, (byte) 58, (byte) 48, (byte) 48, (byte) 58, (byte) 48, (byte) 48, (byte) 44, (byte) 48, (byte) 48, (byte) 48, (byte) 32, (byte) 45, (byte) 45, (byte) 62, (byte) 32, (byte) 48, (byte) 48, (byte) 58, (byte) 48, (byte) 48, (byte) 58, (byte) 48, (byte) 48, (byte) 44, (byte) 48, (byte) 48, (byte) 48, (byte) 10};
    private static final byte[] f2642c = new byte[]{(byte) 32, (byte) 32, (byte) 32, (byte) 32, (byte) 32, (byte) 32, (byte) 32, (byte) 32, (byte) 32, (byte) 32, (byte) 32, (byte) 32};
    private static final UUID f2643d = new UUID(72057594037932032L, -9223371306706625679L);
    private boolean f2644A;
    private long f2645B;
    private long f2646C;
    private long f2647D;
    private C1397f f2648E;
    private C1397f f2649F;
    private boolean f2650G;
    private int f2651H;
    private long f2652I;
    private long f2653J;
    private int f2654K;
    private int f2655L;
    private int[] f2656M;
    private int f2657N;
    private int f2658O;
    private int f2659P;
    private int f2660Q;
    private boolean f2661R;
    private boolean f2662S;
    private boolean f2663T;
    private boolean f2664U;
    private byte f2665V;
    private int f2666W;
    private int f2667X;
    private int f2668Y;
    private boolean f2669Z;
    private boolean aa;
    private C1567h ab;
    private final C1444b f2670e;
    private final C1454f f2671f;
    private final SparseArray f2672g;
    private final C1403k f2673h;
    private final C1403k f2674i;
    private final C1403k f2675j;
    private final C1403k f2676k;
    private final C1403k f2677l;
    private final C1403k f2678m;
    private final C1403k f2679n;
    private final C1403k f2680o;
    private final C1403k f2681p;
    private ByteBuffer f2682q;
    private long f2683r;
    private long f2684s;
    private long f2685t;
    private long f2686u;
    private long f2687v;
    private C1450b f2688w;
    private boolean f2689x;
    private int f2690y;
    private long f2691z;

    static class C14481 implements C1447i {
        C14481() {
        }

        public C1451f[] mo2159a() {
            return new C1451f[]{new C1452d()};
        }
    }

    private final class C1449a implements C1446c {
        final /* synthetic */ C1452d f2613a;

        private C1449a(C1452d c1452d) {
            this.f2613a = c1452d;
        }

        public int mo2160a(int i) {
            return this.f2613a.m3005a(i);
        }

        public boolean mo2166b(int i) {
            return this.f2613a.m3015b(i);
        }

        public void mo2164a(int i, long j, long j2) {
            this.f2613a.m3010a(i, j, j2);
        }

        public void mo2167c(int i) {
            this.f2613a.m3017c(i);
        }

        public void mo2163a(int i, long j) {
            this.f2613a.m3009a(i, j);
        }

        public void mo2161a(int i, double d) {
            this.f2613a.m3007a(i, d);
        }

        public void mo2165a(int i, String str) {
            this.f2613a.m3011a(i, str);
        }

        public void mo2162a(int i, int i2, C1464g c1464g) {
            this.f2613a.m3008a(i, i2, c1464g);
        }
    }

    private static final class C1450b {
        public String f2614a;
        public int f2615b;
        public int f2616c;
        public int f2617d;
        public boolean f2618e;
        public byte[] f2619f;
        public byte[] f2620g;
        public byte[] f2621h;
        public DrmInitData f2622i;
        public int f2623j;
        public int f2624k;
        public int f2625l;
        public int f2626m;
        public int f2627n;
        public byte[] f2628o;
        public int f2629p;
        public int f2630q;
        public int f2631r;
        public int f2632s;
        public long f2633t;
        public long f2634u;
        public boolean f2635v;
        public boolean f2636w;
        public C1521o f2637x;
        public int f2638y;
        private String f2639z;

        private C1450b() {
            this.f2623j = -1;
            this.f2624k = -1;
            this.f2625l = -1;
            this.f2626m = -1;
            this.f2627n = 0;
            this.f2628o = null;
            this.f2629p = -1;
            this.f2630q = 1;
            this.f2631r = -1;
            this.f2632s = 8000;
            this.f2633t = 0;
            this.f2634u = 0;
            this.f2636w = true;
            this.f2639z = "eng";
        }

        public void m2985a(C1567h c1567h, int i) {
            Format a;
            int i2 = -1;
            int i3 = -1;
            List list = null;
            String str = this.f2614a;
            Object obj = -1;
            switch (str.hashCode()) {
                case -2095576542:
                    if (str.equals("V_MPEG4/ISO/AP")) {
                        obj = 5;
                        break;
                    }
                    break;
                case -2095575984:
                    if (str.equals("V_MPEG4/ISO/SP")) {
                        obj = 3;
                        break;
                    }
                    break;
                case -1985379776:
                    if (str.equals("A_MS/ACM")) {
                        obj = 21;
                        break;
                    }
                    break;
                case -1784763192:
                    if (str.equals("A_TRUEHD")) {
                        obj = 16;
                        break;
                    }
                    break;
                case -1730367663:
                    if (str.equals("A_VORBIS")) {
                        obj = 10;
                        break;
                    }
                    break;
                case -1482641357:
                    if (str.equals("A_MPEG/L3")) {
                        obj = 13;
                        break;
                    }
                    break;
                case -1373388978:
                    if (str.equals("V_MS/VFW/FOURCC")) {
                        obj = 8;
                        break;
                    }
                    break;
                case -538363189:
                    if (str.equals("V_MPEG4/ISO/ASP")) {
                        obj = 4;
                        break;
                    }
                    break;
                case -538363109:
                    if (str.equals("V_MPEG4/ISO/AVC")) {
                        obj = 6;
                        break;
                    }
                    break;
                case -425012669:
                    if (str.equals("S_VOBSUB")) {
                        obj = 24;
                        break;
                    }
                    break;
                case -356037306:
                    if (str.equals("A_DTS/LOSSLESS")) {
                        obj = 19;
                        break;
                    }
                    break;
                case 62923557:
                    if (str.equals("A_AAC")) {
                        obj = 12;
                        break;
                    }
                    break;
                case 62923603:
                    if (str.equals("A_AC3")) {
                        obj = 14;
                        break;
                    }
                    break;
                case 62927045:
                    if (str.equals("A_DTS")) {
                        obj = 17;
                        break;
                    }
                    break;
                case 82338133:
                    if (str.equals("V_VP8")) {
                        obj = null;
                        break;
                    }
                    break;
                case 82338134:
                    if (str.equals("V_VP9")) {
                        obj = 1;
                        break;
                    }
                    break;
                case 99146302:
                    if (str.equals("S_HDMV/PGS")) {
                        obj = 25;
                        break;
                    }
                    break;
                case 444813526:
                    if (str.equals("V_THEORA")) {
                        obj = 9;
                        break;
                    }
                    break;
                case 542569478:
                    if (str.equals("A_DTS/EXPRESS")) {
                        obj = 18;
                        break;
                    }
                    break;
                case 725957860:
                    if (str.equals("A_PCM/INT/LIT")) {
                        obj = 22;
                        break;
                    }
                    break;
                case 855502857:
                    if (str.equals("V_MPEGH/ISO/HEVC")) {
                        obj = 7;
                        break;
                    }
                    break;
                case 1422270023:
                    if (str.equals("S_TEXT/UTF8")) {
                        obj = 23;
                        break;
                    }
                    break;
                case 1809237540:
                    if (str.equals("V_MPEG2")) {
                        obj = 2;
                        break;
                    }
                    break;
                case 1950749482:
                    if (str.equals("A_EAC3")) {
                        obj = 15;
                        break;
                    }
                    break;
                case 1950789798:
                    if (str.equals("A_FLAC")) {
                        obj = 20;
                        break;
                    }
                    break;
                case 1951062397:
                    if (str.equals("A_OPUS")) {
                        obj = 11;
                        break;
                    }
                    break;
            }
            switch (obj) {
                case null:
                    str = "video/x-vnd.on2.vp8";
                    break;
                case 1:
                    str = "video/x-vnd.on2.vp9";
                    break;
                case 2:
                    str = "video/mpeg2";
                    break;
                case 3:
                case 4:
                case 5:
                    List list2;
                    str = "video/mp4v-es";
                    if (this.f2621h == null) {
                        list2 = null;
                    } else {
                        list2 = Collections.singletonList(this.f2621h);
                    }
                    list = list2;
                    break;
                case 6:
                    str = "video/avc";
                    C1419a a2 = C1419a.m2854a(new C1403k(this.f2621h));
                    list = a2.f2522a;
                    this.f2638y = a2.f2523b;
                    break;
                case 7:
                    str = "video/hevc";
                    C1420b a3 = C1420b.m2856a(new C1403k(this.f2621h));
                    list = a3.f2527a;
                    this.f2638y = a3.f2528b;
                    break;
                case 8:
                    list = C1450b.m2982a(new C1403k(this.f2621h));
                    str = list == null ? "video/x-unknown" : "video/wvc1";
                    break;
                case 9:
                    str = "video/x-unknown";
                    break;
                case 10:
                    str = "audio/vorbis";
                    i2 = 8192;
                    list = C1450b.m2983a(this.f2621h);
                    break;
                case 11:
                    str = "audio/opus";
                    i2 = 5760;
                    list = new ArrayList(3);
                    list.add(this.f2621h);
                    list.add(ByteBuffer.allocate(8).order(ByteOrder.nativeOrder()).putLong(this.f2633t).array());
                    list.add(ByteBuffer.allocate(8).order(ByteOrder.nativeOrder()).putLong(this.f2634u).array());
                    break;
                case 12:
                    str = "audio/mp4a-latm";
                    list = Collections.singletonList(this.f2621h);
                    break;
                case 13:
                    str = "audio/mpeg";
                    i2 = 4096;
                    break;
                case 14:
                    str = "audio/ac3";
                    break;
                case 15:
                    str = "audio/eac3";
                    break;
                case 16:
                    str = "audio/true-hd";
                    break;
                case 17:
                case 18:
                    str = "audio/vnd.dts";
                    break;
                case 19:
                    str = "audio/vnd.dts.hd";
                    break;
                case 20:
                    str = "audio/x-flac";
                    list = Collections.singletonList(this.f2621h);
                    break;
                case 21:
                    str = "audio/raw";
                    if (C1450b.m2984b(new C1403k(this.f2621h))) {
                        i3 = C1414r.m2812a(this.f2631r);
                        if (i3 == 0) {
                            throw new ParserException("Unsupported PCM bit depth: " + this.f2631r);
                        }
                    }
                    throw new ParserException("Non-PCM MS/ACM is unsupported");
                    break;
                case 22:
                    str = "audio/raw";
                    i3 = C1414r.m2812a(this.f2631r);
                    if (i3 == 0) {
                        throw new ParserException("Unsupported PCM bit depth: " + this.f2631r);
                    }
                    break;
                case 23:
                    str = "application/x-subrip";
                    break;
                case 24:
                    str = "application/vobsub";
                    list = Collections.singletonList(this.f2621h);
                    break;
                case 25:
                    str = "application/pgs";
                    break;
                default:
                    throw new ParserException("Unrecognized codec identifier.");
            }
            int i4 = (0 | (this.f2636w ? 1 : 0)) | (this.f2635v ? 2 : 0);
            if (C1398h.m2730a(str)) {
                a = Format.m2406a(Integer.toString(i), str, null, -1, i2, this.f2630q, this.f2632s, i3, list, this.f2622i, i4, this.f2639z);
            } else if (C1398h.m2731b(str)) {
                if (this.f2627n == 0) {
                    this.f2625l = this.f2625l == -1 ? this.f2623j : this.f2625l;
                    this.f2626m = this.f2626m == -1 ? this.f2624k : this.f2626m;
                }
                float f = -1.0f;
                if (!(this.f2625l == -1 || this.f2626m == -1)) {
                    f = ((float) (this.f2624k * this.f2625l)) / ((float) (this.f2623j * this.f2626m));
                }
                a = Format.m2404a(Integer.toString(i), str, null, -1, i2, this.f2623j, this.f2624k, -1.0f, list, -1, f, this.f2628o, this.f2629p, this.f2622i);
            } else if ("application/x-subrip".equals(str)) {
                a = Format.m2408a(Integer.toString(i), str, null, -1, i4, this.f2639z, this.f2622i);
            } else if ("application/vobsub".equals(str) || "application/pgs".equals(str)) {
                a = Format.m2411a(Integer.toString(i), str, null, -1, list, this.f2639z, this.f2622i);
            } else {
                throw new ParserException("Unexpected MIME type.");
            }
            this.f2637x = c1567h.mo2273a(this.f2615b);
            this.f2637x.mo2202a(a);
        }

        private static List m2982a(C1403k c1403k) {
            try {
                c1403k.m2762d(16);
                if (c1403k.m2772m() != 826496599) {
                    return null;
                }
                int d = c1403k.m2761d() + 20;
                byte[] bArr = c1403k.f2479a;
                while (d < bArr.length - 4) {
                    if (bArr[d] == (byte) 0 && bArr[d + 1] == (byte) 0 && bArr[d + 2] == (byte) 1 && bArr[d + 3] == (byte) 15) {
                        return Collections.singletonList(Arrays.copyOfRange(bArr, d, bArr.length));
                    }
                    d++;
                }
                throw new ParserException("Failed to find FourCC VC1 initialization data");
            } catch (ArrayIndexOutOfBoundsException e) {
                throw new ParserException("Error parsing FourCC VC1 codec private");
            }
        }

        private static List m2983a(byte[] bArr) {
            int i = 0;
            try {
                if (bArr[0] != (byte) 2) {
                    throw new ParserException("Error parsing vorbis codec private");
                }
                int i2 = 0;
                int i3 = 1;
                while (bArr[i3] == (byte) -1) {
                    i3++;
                    i2 += 255;
                }
                int i4 = i3 + 1;
                i2 += bArr[i3];
                while (bArr[i4] == (byte) -1) {
                    i += 255;
                    i4++;
                }
                i3 = i4 + 1;
                i += bArr[i4];
                if (bArr[i3] != (byte) 1) {
                    throw new ParserException("Error parsing vorbis codec private");
                }
                Object obj = new byte[i2];
                System.arraycopy(bArr, i3, obj, 0, i2);
                i2 += i3;
                if (bArr[i2] != (byte) 3) {
                    throw new ParserException("Error parsing vorbis codec private");
                }
                i += i2;
                if (bArr[i] != (byte) 5) {
                    throw new ParserException("Error parsing vorbis codec private");
                }
                Object obj2 = new byte[(bArr.length - i)];
                System.arraycopy(bArr, i, obj2, 0, bArr.length - i);
                List arrayList = new ArrayList(2);
                arrayList.add(obj);
                arrayList.add(obj2);
                return arrayList;
            } catch (ArrayIndexOutOfBoundsException e) {
                throw new ParserException("Error parsing vorbis codec private");
            }
        }

        private static boolean m2984b(C1403k c1403k) {
            try {
                int i = c1403k.m2768i();
                if (i == 1) {
                    return true;
                }
                if (i != 65534) {
                    return false;
                }
                c1403k.m2760c(24);
                if (c1403k.m2775p() == C1452d.f2643d.getMostSignificantBits() && c1403k.m2775p() == C1452d.f2643d.getLeastSignificantBits()) {
                    return true;
                }
                return false;
            } catch (ArrayIndexOutOfBoundsException e) {
                throw new ParserException("Error parsing MS/ACM codec private");
            }
        }
    }

    public C1452d() {
        this(new C1445a());
    }

    C1452d(C1444b c1444b) {
        this.f2684s = -1;
        this.f2685t = -9223372036854775807L;
        this.f2686u = -9223372036854775807L;
        this.f2687v = -9223372036854775807L;
        this.f2645B = -1;
        this.f2646C = -1;
        this.f2647D = -9223372036854775807L;
        this.f2670e = c1444b;
        this.f2670e.mo2157a(new C1449a());
        this.f2671f = new C1454f();
        this.f2672g = new SparseArray();
        this.f2675j = new C1403k(4);
        this.f2676k = new C1403k(ByteBuffer.allocate(4).putInt(-1).array());
        this.f2677l = new C1403k(4);
        this.f2673h = new C1403k(C1401i.f2471a);
        this.f2674i = new C1403k(4);
        this.f2678m = new C1403k();
        this.f2679n = new C1403k();
        this.f2680o = new C1403k(8);
        this.f2681p = new C1403k();
    }

    public boolean mo2171a(C1464g c1464g) {
        return new C1453e().m3019a(c1464g);
    }

    public void mo2170a(C1567h c1567h) {
        this.ab = c1567h;
    }

    public void mo2169a(long j) {
        this.f2647D = -9223372036854775807L;
        this.f2651H = 0;
        this.f2670e.mo2156a();
        this.f2671f.m3023a();
        m3003b();
    }

    public void mo2172c() {
    }

    public int mo2168a(C1464g c1464g, C1570l c1570l) {
        this.f2669Z = false;
        boolean z = true;
        while (z && !this.f2669Z) {
            z = this.f2670e.mo2158a(c1464g);
            if (z && m2999a(c1570l, c1464g.mo2185c())) {
                return 1;
            }
        }
        if (z) {
            return 0;
        }
        return -1;
    }

    int m3005a(int i) {
        switch (i) {
            case 131:
            case 136:
            case 155:
            case 159:
            case 176:
            case 179:
            case 186:
            case 215:
            case 231:
            case 241:
            case 251:
            case 16980:
            case 17029:
            case 17143:
            case 18401:
            case 18408:
            case 20529:
            case 20530:
            case 21420:
            case 21432:
            case 21680:
            case 21682:
            case 21690:
            case 21930:
            case 22186:
            case 22203:
            case 25188:
            case 2352003:
            case 2807729:
                return 2;
            case 134:
            case 17026:
            case 2274716:
                return 3;
            case 160:
            case 174:
            case 183:
            case 187:
            case 224:
            case 225:
            case 18407:
            case 19899:
            case 20532:
            case 20533:
            case 25152:
            case 28032:
            case 30320:
            case 290298740:
            case 357149030:
            case 374648427:
            case 408125543:
            case 440786851:
            case 475249515:
            case 524531317:
                return 1;
            case 161:
            case 163:
            case 16981:
            case 18402:
            case 21419:
            case 25506:
            case 30322:
                return 4;
            case 181:
            case 17545:
                return 5;
            default:
                return 0;
        }
    }

    boolean m3015b(int i) {
        return i == 357149030 || i == 524531317 || i == 475249515 || i == 374648427;
    }

    void m3010a(int i, long j, long j2) {
        switch (i) {
            case 160:
                this.aa = false;
                return;
            case 174:
                this.f2688w = new C1450b();
                return;
            case 187:
                this.f2650G = false;
                return;
            case 19899:
                this.f2690y = -1;
                this.f2691z = -1;
                return;
            case 20533:
                this.f2688w.f2618e = true;
                return;
            case 408125543:
                if (this.f2684s == -1 || this.f2684s == j) {
                    this.f2684s = j;
                    this.f2683r = j2;
                    return;
                }
                throw new ParserException("Multiple Segment elements not supported");
            case 475249515:
                this.f2648E = new C1397f();
                this.f2649F = new C1397f();
                return;
            case 524531317:
                if (!this.f2689x) {
                    if (this.f2645B != -1) {
                        this.f2644A = true;
                        return;
                    }
                    this.ab.mo2276a(new C1571a(this.f2687v));
                    this.f2689x = true;
                    return;
                }
                return;
            default:
                return;
        }
    }

    void m3017c(int i) {
        switch (i) {
            case 160:
                if (this.f2651H == 2) {
                    if (!this.aa) {
                        this.f2659P |= 1;
                    }
                    m2994a((C1450b) this.f2672g.get(this.f2657N), this.f2652I);
                    this.f2651H = 0;
                    return;
                }
                return;
            case 174:
                if (this.f2672g.get(this.f2688w.f2615b) == null && C1452d.m3000a(this.f2688w.f2614a)) {
                    this.f2688w.m2985a(this.ab, this.f2688w.f2615b);
                    this.f2672g.put(this.f2688w.f2615b, this.f2688w);
                }
                this.f2688w = null;
                return;
            case 19899:
                if (this.f2690y == -1 || this.f2691z == -1) {
                    throw new ParserException("Mandatory element SeekID or SeekPosition not found");
                } else if (this.f2690y == 475249515) {
                    this.f2645B = this.f2691z;
                    return;
                } else {
                    return;
                }
            case 25152:
                if (!this.f2688w.f2618e) {
                    return;
                }
                if (this.f2688w.f2620g == null) {
                    throw new ParserException("Encrypted Track found but ContentEncKeyID was not found");
                }
                this.f2688w.f2622i = new DrmInitData(new SchemeData(C1391b.f2437b, "video/webm", this.f2688w.f2620g));
                return;
            case 28032:
                if (this.f2688w.f2618e && this.f2688w.f2619f != null) {
                    throw new ParserException("Combining encryption and compression is not supported");
                }
                return;
            case 357149030:
                if (this.f2685t == -9223372036854775807L) {
                    this.f2685t = 1000000;
                }
                if (this.f2686u != -9223372036854775807L) {
                    this.f2687v = m3002b(this.f2686u);
                    return;
                }
                return;
            case 374648427:
                if (this.f2672g.size() == 0) {
                    throw new ParserException("No valid tracks were found");
                }
                this.ab.mo2274a();
                return;
            case 475249515:
                if (!this.f2689x) {
                    this.ab.mo2276a(m3004d());
                    this.f2689x = true;
                    return;
                }
                return;
            default:
                return;
        }
    }

    void m3009a(int i, long j) {
        boolean z = true;
        C1450b c1450b;
        switch (i) {
            case 131:
                this.f2688w.f2616c = (int) j;
                return;
            case 136:
                c1450b = this.f2688w;
                if (j != 1) {
                    z = false;
                }
                c1450b.f2635v = z;
                return;
            case 155:
                this.f2653J = m3002b(j);
                return;
            case 159:
                this.f2688w.f2630q = (int) j;
                return;
            case 176:
                this.f2688w.f2623j = (int) j;
                return;
            case 179:
                this.f2648E.m2728a(m3002b(j));
                return;
            case 186:
                this.f2688w.f2624k = (int) j;
                return;
            case 215:
                this.f2688w.f2615b = (int) j;
                return;
            case 231:
                this.f2647D = m3002b(j);
                return;
            case 241:
                if (!this.f2650G) {
                    this.f2649F.m2728a(j);
                    this.f2650G = true;
                    return;
                }
                return;
            case 251:
                this.aa = true;
                return;
            case 16980:
                if (j != 3) {
                    throw new ParserException("ContentCompAlgo " + j + " not supported");
                }
                return;
            case 17029:
                if (j < 1 || j > 2) {
                    throw new ParserException("DocTypeReadVersion " + j + " not supported");
                }
                return;
            case 17143:
                if (j != 1) {
                    throw new ParserException("EBMLReadVersion " + j + " not supported");
                }
                return;
            case 18401:
                if (j != 5) {
                    throw new ParserException("ContentEncAlgo " + j + " not supported");
                }
                return;
            case 18408:
                if (j != 1) {
                    throw new ParserException("AESSettingsCipherMode " + j + " not supported");
                }
                return;
            case 20529:
                if (j != 0) {
                    throw new ParserException("ContentEncodingOrder " + j + " not supported");
                }
                return;
            case 20530:
                if (j != 1) {
                    throw new ParserException("ContentEncodingScope " + j + " not supported");
                }
                return;
            case 21420:
                this.f2691z = this.f2684s + j;
                return;
            case 21432:
                switch ((int) j) {
                    case 0:
                        this.f2688w.f2629p = 0;
                        return;
                    case 1:
                        this.f2688w.f2629p = 2;
                        return;
                    case 3:
                        this.f2688w.f2629p = 1;
                        return;
                    default:
                        return;
                }
            case 21680:
                this.f2688w.f2625l = (int) j;
                return;
            case 21682:
                this.f2688w.f2627n = (int) j;
                return;
            case 21690:
                this.f2688w.f2626m = (int) j;
                return;
            case 21930:
                c1450b = this.f2688w;
                if (j != 1) {
                    z = false;
                }
                c1450b.f2636w = z;
                return;
            case 22186:
                this.f2688w.f2633t = j;
                return;
            case 22203:
                this.f2688w.f2634u = j;
                return;
            case 25188:
                this.f2688w.f2631r = (int) j;
                return;
            case 2352003:
                this.f2688w.f2617d = (int) j;
                return;
            case 2807729:
                this.f2685t = j;
                return;
            default:
                return;
        }
    }

    void m3007a(int i, double d) {
        switch (i) {
            case 181:
                this.f2688w.f2632s = (int) d;
                return;
            case 17545:
                this.f2686u = (long) d;
                return;
            default:
                return;
        }
    }

    void m3011a(int i, String str) {
        switch (i) {
            case 134:
                this.f2688w.f2614a = str;
                return;
            case 17026:
                if (!"webm".equals(str) && !"matroska".equals(str)) {
                    throw new ParserException("DocType " + str + " not supported");
                }
                return;
            case 2274716:
                this.f2688w.f2639z = str;
                return;
            default:
                return;
        }
    }

    void m3008a(int i, int i2, C1464g c1464g) {
        switch (i) {
            case 161:
            case 163:
                if (this.f2651H == 0) {
                    this.f2657N = (int) this.f2671f.m3022a(c1464g, false, true, 8);
                    this.f2658O = this.f2671f.m3024b();
                    this.f2653J = -9223372036854775807L;
                    this.f2651H = 1;
                    this.f2675j.m2752a();
                }
                C1450b c1450b = (C1450b) this.f2672g.get(this.f2657N);
                if (c1450b == null) {
                    c1464g.mo2182b(i2 - this.f2658O);
                    this.f2651H = 0;
                    return;
                }
                if (this.f2651H == 1) {
                    int i3;
                    m2995a(c1464g, 3);
                    int i4 = (this.f2675j.f2479a[2] & 6) >> 1;
                    if (i4 == 0) {
                        this.f2655L = 1;
                        this.f2656M = C1452d.m3001a(this.f2656M, 1);
                        this.f2656M[0] = (i2 - this.f2658O) - 3;
                    } else if (i != 163) {
                        throw new ParserException("Lacing only supported in SimpleBlocks.");
                    } else {
                        m2995a(c1464g, 4);
                        this.f2655L = (this.f2675j.f2479a[3] & 255) + 1;
                        this.f2656M = C1452d.m3001a(this.f2656M, this.f2655L);
                        if (i4 == 2) {
                            Arrays.fill(this.f2656M, 0, this.f2655L, ((i2 - this.f2658O) - 4) / this.f2655L);
                        } else if (i4 == 1) {
                            r5 = 0;
                            i3 = 4;
                            for (i4 = 0; i4 < this.f2655L - 1; i4++) {
                                this.f2656M[i4] = 0;
                                do {
                                    i3++;
                                    m2995a(c1464g, i3);
                                    r6 = this.f2675j.f2479a[i3 - 1] & 255;
                                    r7 = this.f2656M;
                                    r7[i4] = r7[i4] + r6;
                                } while (r6 == 255);
                                r5 += this.f2656M[i4];
                            }
                            this.f2656M[this.f2655L - 1] = ((i2 - this.f2658O) - i3) - r5;
                        } else if (i4 == 3) {
                            r5 = 0;
                            i3 = 4;
                            i4 = 0;
                            while (i4 < this.f2655L - 1) {
                                this.f2656M[i4] = 0;
                                i3++;
                                m2995a(c1464g, i3);
                                if (this.f2675j.f2479a[i3 - 1] == (byte) 0) {
                                    throw new ParserException("No valid varint length mask found");
                                }
                                long j = 0;
                                int i5 = 0;
                                while (i5 < 8) {
                                    int i6 = 1 << (7 - i5);
                                    if ((this.f2675j.f2479a[i3 - 1] & i6) != 0) {
                                        int i7 = i3 - 1;
                                        i3 += i5;
                                        m2995a(c1464g, i3);
                                        j = (long) ((this.f2675j.f2479a[i7] & 255) & (i6 ^ -1));
                                        for (i6 = i7 + 1; i6 < i3; i6++) {
                                            j = ((long) (this.f2675j.f2479a[i6] & 255)) | (j << 8);
                                        }
                                        if (i4 > 0) {
                                            j -= (1 << ((i5 * 7) + 6)) - 1;
                                        }
                                        if (j >= -2147483648L || j > 2147483647L) {
                                            throw new ParserException("EBML lacing sample size out of range.");
                                        }
                                        r6 = (int) j;
                                        r7 = this.f2656M;
                                        if (i4 != 0) {
                                            r6 += this.f2656M[i4 - 1];
                                        }
                                        r7[i4] = r6;
                                        r5 += this.f2656M[i4];
                                        i4++;
                                    } else {
                                        i5++;
                                    }
                                }
                                if (j >= -2147483648L) {
                                    break;
                                }
                                throw new ParserException("EBML lacing sample size out of range.");
                            }
                            this.f2656M[this.f2655L - 1] = ((i2 - this.f2658O) - i3) - r5;
                        } else {
                            throw new ParserException("Unexpected lacing value: " + i4);
                        }
                    }
                    this.f2652I = this.f2647D + m3002b((long) ((this.f2675j.f2479a[0] << 8) | (this.f2675j.f2479a[1] & 255)));
                    Object obj = (this.f2675j.f2479a[2] & 8) == 8 ? 1 : null;
                    Object obj2 = (c1450b.f2616c == 2 || (i == 163 && (this.f2675j.f2479a[2] & 128) == 128)) ? 1 : null;
                    i3 = obj2 != null ? 1 : 0;
                    if (obj != null) {
                        i4 = Integer.MIN_VALUE;
                    } else {
                        i4 = 0;
                    }
                    this.f2659P = i4 | i3;
                    this.f2651H = 2;
                    this.f2654K = 0;
                }
                if (i == 163) {
                    while (this.f2654K < this.f2655L) {
                        m2996a(c1464g, c1450b, this.f2656M[this.f2654K]);
                        m2994a(c1450b, this.f2652I + ((long) ((this.f2654K * c1450b.f2617d) / 1000)));
                        this.f2654K++;
                    }
                    this.f2651H = 0;
                    return;
                }
                m2996a(c1464g, c1450b, this.f2656M[0]);
                return;
            case 16981:
                this.f2688w.f2619f = new byte[i2];
                c1464g.mo2183b(this.f2688w.f2619f, 0, i2);
                return;
            case 18402:
                this.f2688w.f2620g = new byte[i2];
                c1464g.mo2183b(this.f2688w.f2620g, 0, i2);
                return;
            case 21419:
                Arrays.fill(this.f2677l.f2479a, (byte) 0);
                c1464g.mo2183b(this.f2677l.f2479a, 4 - i2, i2);
                this.f2677l.m2760c(0);
                this.f2690y = (int) this.f2677l.m2771l();
                return;
            case 25506:
                this.f2688w.f2621h = new byte[i2];
                c1464g.mo2183b(this.f2688w.f2621h, 0, i2);
                return;
            case 30322:
                this.f2688w.f2628o = new byte[i2];
                c1464g.mo2183b(this.f2688w.f2628o, 0, i2);
                return;
            default:
                throw new ParserException("Unexpected id: " + i);
        }
    }

    private void m2994a(C1450b c1450b, long j) {
        if ("S_TEXT/UTF8".equals(c1450b.f2614a)) {
            m2993a(c1450b);
        }
        c1450b.f2637x.mo2201a(j, this.f2659P, this.f2668Y, 0, c1450b.f2620g);
        this.f2669Z = true;
        m3003b();
    }

    private void m3003b() {
        this.f2660Q = 0;
        this.f2668Y = 0;
        this.f2667X = 0;
        this.f2661R = false;
        this.f2662S = false;
        this.f2664U = false;
        this.f2666W = 0;
        this.f2665V = (byte) 0;
        this.f2663T = false;
        this.f2678m.m2752a();
    }

    private void m2995a(C1464g c1464g, int i) {
        if (this.f2675j.m2759c() < i) {
            if (this.f2675j.m2763e() < i) {
                this.f2675j.m2755a(Arrays.copyOf(this.f2675j.f2479a, Math.max(this.f2675j.f2479a.length * 2, i)), this.f2675j.m2759c());
            }
            c1464g.mo2183b(this.f2675j.f2479a, this.f2675j.m2759c(), i - this.f2675j.m2759c());
            this.f2675j.m2758b(i);
        }
    }

    private void m2996a(C1464g c1464g, C1450b c1450b, int i) {
        int length;
        if ("S_TEXT/UTF8".equals(c1450b.f2614a)) {
            length = f2641b.length + i;
            if (this.f2679n.m2763e() < length) {
                this.f2679n.f2479a = Arrays.copyOf(f2641b, length + i);
            }
            c1464g.mo2183b(this.f2679n.f2479a, f2641b.length, i);
            this.f2679n.m2760c(0);
            this.f2679n.m2758b(length);
            return;
        }
        int t;
        C1521o c1521o = c1450b.f2637x;
        if (!this.f2661R) {
            if (c1450b.f2618e) {
                this.f2659P &= -1073741825;
                if (!this.f2662S) {
                    c1464g.mo2183b(this.f2675j.f2479a, 0, 1);
                    this.f2660Q++;
                    if ((this.f2675j.f2479a[0] & 128) == 128) {
                        throw new ParserException("Extension bit is set in signal byte");
                    }
                    this.f2665V = this.f2675j.f2479a[0];
                    this.f2662S = true;
                }
                if ((this.f2665V & 1) == 1) {
                    boolean z;
                    int i2;
                    if ((this.f2665V & 2) == 2) {
                        z = true;
                    } else {
                        z = false;
                    }
                    this.f2659P |= 1073741824;
                    if (!this.f2663T) {
                        c1464g.mo2183b(this.f2680o.f2479a, 0, 8);
                        this.f2660Q += 8;
                        this.f2663T = true;
                        byte[] bArr = this.f2675j.f2479a;
                        if (z) {
                            i2 = 128;
                        } else {
                            i2 = 0;
                        }
                        bArr[0] = (byte) (i2 | 8);
                        this.f2675j.m2760c(0);
                        c1521o.mo2203a(this.f2675j, 1);
                        this.f2668Y++;
                        this.f2680o.m2760c(0);
                        c1521o.mo2203a(this.f2680o, 8);
                        this.f2668Y += 8;
                    }
                    if (z) {
                        if (!this.f2664U) {
                            c1464g.mo2183b(this.f2675j.f2479a, 0, 1);
                            this.f2660Q++;
                            this.f2675j.m2760c(0);
                            this.f2666W = this.f2675j.m2766g();
                            this.f2664U = true;
                        }
                        length = this.f2666W * 4;
                        this.f2675j.m2753a(length);
                        c1464g.mo2183b(this.f2675j.f2479a, 0, length);
                        this.f2660Q = length + this.f2660Q;
                        short s = (short) ((this.f2666W / 2) + 1);
                        int i3 = (s * 6) + 2;
                        if (this.f2682q == null || this.f2682q.capacity() < i3) {
                            this.f2682q = ByteBuffer.allocate(i3);
                        }
                        this.f2682q.position(0);
                        this.f2682q.putShort(s);
                        length = 0;
                        i2 = 0;
                        while (length < this.f2666W) {
                            t = this.f2675j.m2779t();
                            if (length % 2 == 0) {
                                this.f2682q.putShort((short) (t - i2));
                            } else {
                                this.f2682q.putInt(t - i2);
                            }
                            length++;
                            i2 = t;
                        }
                        length = (i - this.f2660Q) - i2;
                        if (this.f2666W % 2 == 1) {
                            this.f2682q.putInt(length);
                        } else {
                            this.f2682q.putShort((short) length);
                            this.f2682q.putInt(0);
                        }
                        this.f2681p.m2755a(this.f2682q.array(), i3);
                        c1521o.mo2203a(this.f2681p, i3);
                        this.f2668Y += i3;
                    }
                }
            } else if (c1450b.f2619f != null) {
                this.f2678m.m2755a(c1450b.f2619f, c1450b.f2619f.length);
            }
            this.f2661R = true;
        }
        length = this.f2678m.m2759c() + i;
        if ("V_MPEG4/ISO/AVC".equals(c1450b.f2614a) || "V_MPEGH/ISO/HEVC".equals(c1450b.f2614a)) {
            byte[] bArr2 = this.f2674i.f2479a;
            bArr2[0] = (byte) 0;
            bArr2[1] = (byte) 0;
            bArr2[2] = (byte) 0;
            int i4 = c1450b.f2638y;
            t = 4 - c1450b.f2638y;
            while (this.f2660Q < length) {
                if (this.f2667X == 0) {
                    m2997a(c1464g, bArr2, t, i4);
                    this.f2674i.m2760c(0);
                    this.f2667X = this.f2674i.m2779t();
                    this.f2673h.m2760c(0);
                    c1521o.mo2203a(this.f2673h, 4);
                    this.f2668Y += 4;
                } else {
                    this.f2667X -= m2991a(c1464g, c1521o, this.f2667X);
                }
            }
        } else {
            while (this.f2660Q < length) {
                m2991a(c1464g, c1521o, length - this.f2660Q);
            }
        }
        if ("A_VORBIS".equals(c1450b.f2614a)) {
            this.f2676k.m2760c(0);
            c1521o.mo2203a(this.f2676k, 4);
            this.f2668Y += 4;
        }
    }

    private void m2993a(C1450b c1450b) {
        C1452d.m2998a(this.f2679n.f2479a, this.f2653J);
        c1450b.f2637x.mo2203a(this.f2679n, this.f2679n.m2759c());
        this.f2668Y += this.f2679n.m2759c();
    }

    private static void m2998a(byte[] bArr, long j) {
        Object obj;
        if (j == -9223372036854775807L) {
            obj = f2642c;
        } else {
            long j2 = j - (((long) ((int) (j / 3600000000L))) * 3600000000L);
            j2 -= (long) (60000000 * ((int) (j2 / 60000000)));
            int i = (int) ((j2 - ((long) (1000000 * ((int) (j2 / 1000000))))) / 1000);
            obj = C1414r.m2828c(String.format(Locale.US, "%02d:%02d:%02d,%03d", new Object[]{Integer.valueOf((int) (j / 3600000000L)), Integer.valueOf(r1), Integer.valueOf(r4), Integer.valueOf(i)}));
        }
        System.arraycopy(obj, 0, bArr, 19, 12);
    }

    private void m2997a(C1464g c1464g, byte[] bArr, int i, int i2) {
        int min = Math.min(i2, this.f2678m.m2757b());
        c1464g.mo2183b(bArr, i + min, i2 - min);
        if (min > 0) {
            this.f2678m.m2756a(bArr, i, min);
        }
        this.f2660Q += i2;
    }

    private int m2991a(C1464g c1464g, C1521o c1521o, int i) {
        int b = this.f2678m.m2757b();
        if (b > 0) {
            b = Math.min(i, b);
            c1521o.mo2203a(this.f2678m, b);
        } else {
            b = c1521o.mo2200a(c1464g, i, false);
        }
        this.f2660Q += b;
        this.f2668Y += b;
        return b;
    }

    private C1455m m3004d() {
        int i = 0;
        if (this.f2684s == -1 || this.f2687v == -9223372036854775807L || this.f2648E == null || this.f2648E.m2726a() == 0 || this.f2649F == null || this.f2649F.m2726a() != this.f2648E.m2726a()) {
            this.f2648E = null;
            this.f2649F = null;
            return new C1571a(this.f2687v);
        }
        int a = this.f2648E.m2726a();
        int[] iArr = new int[a];
        long[] jArr = new long[a];
        long[] jArr2 = new long[a];
        long[] jArr3 = new long[a];
        for (int i2 = 0; i2 < a; i2++) {
            jArr3[i2] = this.f2648E.m2727a(i2);
            jArr[i2] = this.f2684s + this.f2649F.m2727a(i2);
        }
        while (i < a - 1) {
            iArr[i] = (int) (jArr[i + 1] - jArr[i]);
            jArr2[i] = jArr3[i + 1] - jArr3[i];
            i++;
        }
        iArr[a - 1] = (int) ((this.f2684s + this.f2683r) - jArr[a - 1]);
        jArr2[a - 1] = this.f2687v - jArr3[a - 1];
        this.f2648E = null;
        this.f2649F = null;
        return new C1456a(iArr, jArr, jArr2, jArr3);
    }

    private boolean m2999a(C1570l c1570l, long j) {
        if (this.f2644A) {
            this.f2646C = j;
            c1570l.f3345a = this.f2645B;
            this.f2644A = false;
            return true;
        } else if (!this.f2689x || this.f2646C == -1) {
            return false;
        } else {
            c1570l.f3345a = this.f2646C;
            this.f2646C = -1;
            return true;
        }
    }

    private long m3002b(long j) {
        if (this.f2685t == -9223372036854775807L) {
            throw new ParserException("Can't scale timecode prior to timecodeScale being set.");
        }
        return C1414r.m2816a(j, this.f2685t, 1000);
    }

    private static boolean m3000a(String str) {
        if ("V_VP8".equals(str) || "V_VP9".equals(str) || "V_MPEG2".equals(str) || "V_MPEG4/ISO/SP".equals(str) || "V_MPEG4/ISO/ASP".equals(str) || "V_MPEG4/ISO/AP".equals(str) || "V_MPEG4/ISO/AVC".equals(str) || "V_MPEGH/ISO/HEVC".equals(str) || "V_MS/VFW/FOURCC".equals(str) || "V_THEORA".equals(str) || "A_OPUS".equals(str) || "A_VORBIS".equals(str) || "A_AAC".equals(str) || "A_MPEG/L3".equals(str) || "A_AC3".equals(str) || "A_EAC3".equals(str) || "A_TRUEHD".equals(str) || "A_DTS".equals(str) || "A_DTS/EXPRESS".equals(str) || "A_DTS/LOSSLESS".equals(str) || "A_FLAC".equals(str) || "A_MS/ACM".equals(str) || "A_PCM/INT/LIT".equals(str) || "S_TEXT/UTF8".equals(str) || "S_VOBSUB".equals(str) || "S_HDMV/PGS".equals(str)) {
            return true;
        }
        return false;
    }

    private static int[] m3001a(int[] iArr, int i) {
        if (iArr == null) {
            return new int[i];
        }
        return iArr.length < i ? new int[Math.max(iArr.length * 2, i)] : iArr;
    }
}
