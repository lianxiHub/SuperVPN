package com.google.android.exoplayer2.extractor.p034a;

import com.google.android.exoplayer2.extractor.C1464g;

interface C1444b {
    void mo2156a();

    void mo2157a(C1446c c1446c);

    boolean mo2158a(C1464g c1464g);
}
