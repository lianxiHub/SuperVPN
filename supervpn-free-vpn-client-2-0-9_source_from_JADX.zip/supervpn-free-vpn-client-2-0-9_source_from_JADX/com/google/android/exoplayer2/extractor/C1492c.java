package com.google.android.exoplayer2.extractor;

import java.util.ArrayList;
import java.util.List;

public final class C1492c implements C1447i {
    private static List f2926a;

    public C1492c() {
        synchronized (C1492c.class) {
            if (f2926a == null) {
                List arrayList = new ArrayList();
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.extractor.a.d").asSubclass(C1451f.class));
                } catch (ClassNotFoundException e) {
                }
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.extractor.c.e").asSubclass(C1451f.class));
                } catch (ClassNotFoundException e2) {
                }
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.extractor.c.f").asSubclass(C1451f.class));
                } catch (ClassNotFoundException e3) {
                }
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.extractor.b.c").asSubclass(C1451f.class));
                } catch (ClassNotFoundException e4) {
                }
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.extractor.e.c").asSubclass(C1451f.class));
                } catch (ClassNotFoundException e5) {
                }
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.extractor.e.a").asSubclass(C1451f.class));
                } catch (ClassNotFoundException e6) {
                }
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.extractor.e.p").asSubclass(C1451f.class));
                } catch (ClassNotFoundException e7) {
                }
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.extractor.flv.b").asSubclass(C1451f.class));
                } catch (ClassNotFoundException e8) {
                }
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.extractor.d.c").asSubclass(C1451f.class));
                } catch (ClassNotFoundException e9) {
                }
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.extractor.e.n").asSubclass(C1451f.class));
                } catch (ClassNotFoundException e10) {
                }
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.extractor.f.a").asSubclass(C1451f.class));
                } catch (ClassNotFoundException e11) {
                }
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.ext.flac.FlacExtractor").asSubclass(C1451f.class));
                } catch (ClassNotFoundException e12) {
                }
                f2926a = arrayList;
            }
        }
    }

    public C1451f[] mo2159a() {
        C1451f[] c1451fArr = new C1451f[f2926a.size()];
        int i = 0;
        while (i < c1451fArr.length) {
            try {
                c1451fArr[i] = (C1451f) ((Class) f2926a.get(i)).getConstructor(new Class[0]).newInstance(new Object[0]);
                i++;
            } catch (Throwable e) {
                throw new IllegalStateException("Unexpected error creating default extractor", e);
            }
        }
        return c1451fArr;
    }
}
