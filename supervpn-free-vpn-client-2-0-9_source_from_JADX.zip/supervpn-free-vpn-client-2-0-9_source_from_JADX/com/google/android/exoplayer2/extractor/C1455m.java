package com.google.android.exoplayer2.extractor;

public interface C1455m {

    public static final class C1571a implements C1455m {
        private final long f3346a;

        public C1571a(long j) {
            this.f3346a = j;
        }

        public boolean mo2173a() {
            return false;
        }

        public long mo2174b() {
            return this.f3346a;
        }

        public long mo2175b(long j) {
            return 0;
        }
    }

    boolean mo2173a();

    long mo2174b();

    long mo2175b(long j);
}
