package com.google.android.exoplayer2.extractor;

public interface C1464g {
    int mo2177a(int i);

    int mo2178a(byte[] bArr, int i, int i2);

    void mo2179a();

    boolean mo2180a(byte[] bArr, int i, int i2, boolean z);

    long mo2181b();

    void mo2182b(int i);

    void mo2183b(byte[] bArr, int i, int i2);

    boolean mo2184b(byte[] bArr, int i, int i2, boolean z);

    long mo2185c();

    void mo2186c(int i);

    void mo2187c(byte[] bArr, int i, int i2);

    long mo2188d();
}
