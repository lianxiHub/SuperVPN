package com.google.android.exoplayer2;

import android.content.Context;
import com.google.android.exoplayer2.drm.C1438b;
import com.google.android.exoplayer2.p032b.C1381h;

public final class C1441e {
    public static C1592m m2947a(Context context, C1381h c1381h, C1416i c1416i) {
        return C1441e.m2948a(context, c1381h, c1416i, null);
    }

    public static C1592m m2948a(Context context, C1381h c1381h, C1416i c1416i, C1438b c1438b) {
        return C1441e.m2949a(context, c1381h, c1416i, c1438b, false);
    }

    public static C1592m m2949a(Context context, C1381h c1381h, C1416i c1416i, C1438b c1438b, boolean z) {
        return C1441e.m2950a(context, c1381h, c1416i, c1438b, z, 5000);
    }

    public static C1592m m2950a(Context context, C1381h c1381h, C1416i c1416i, C1438b c1438b, boolean z, long j) {
        return new C1592m(context, c1381h, c1416i, c1438b, z, j);
    }
}
