package com.google.android.exoplayer2.text;

import android.text.Layout.Alignment;

public class C1643b {
    public final CharSequence f3609a;
    public final Alignment f3610b;
    public final float f3611c;
    public final int f3612d;
    public final int f3613e;
    public final float f3614f;
    public final int f3615g;
    public final float f3616h;

    public C1643b(CharSequence charSequence) {
        this(charSequence, null, Float.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE, Float.MIN_VALUE, Integer.MIN_VALUE, Float.MIN_VALUE);
    }

    public C1643b(CharSequence charSequence, Alignment alignment, float f, int i, int i2, float f2, int i3, float f3) {
        this.f3609a = charSequence;
        this.f3610b = alignment;
        this.f3611c = f;
        this.f3612d = i;
        this.f3613e = i2;
        this.f3614f = f2;
        this.f3615g = i3;
        this.f3616h = f3;
    }
}
