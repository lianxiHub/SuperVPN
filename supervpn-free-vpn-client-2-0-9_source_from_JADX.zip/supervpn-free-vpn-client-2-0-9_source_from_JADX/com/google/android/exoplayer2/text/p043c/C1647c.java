package com.google.android.exoplayer2.text.p043c;

final class C1647c {
    public final float f3637a;
    public final float f3638b;
    public final int f3639c;
    public final float f3640d;

    public C1647c() {
        this(Float.MIN_VALUE, Float.MIN_VALUE, Integer.MIN_VALUE, Float.MIN_VALUE);
    }

    public C1647c(float f, float f2, int i, float f3) {
        this.f3637a = f;
        this.f3638b = f2;
        this.f3639c = i;
        this.f3640d = f3;
    }
}
