package com.google.android.exoplayer2.text.p043c;

import android.util.Log;
import android.util.Pair;
import com.facebook.internal.AnalyticsEvents;
import com.google.android.exoplayer2.p031c.C1415s;
import com.google.android.exoplayer2.text.C1635e;
import com.google.android.exoplayer2.text.C1640c;
import com.google.android.exoplayer2.text.SubtitleDecoderException;
import com.mopub.volley.DefaultRetryPolicy;
import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

public final class C1645a extends C1640c {
    private static final Pattern f3620a = Pattern.compile("^([0-9][0-9]+):([0-9][0-9]):([0-9][0-9])(?:(\\.[0-9]+)|:([0-9][0-9])(?:\\.([0-9]+))?)?$");
    private static final Pattern f3621b = Pattern.compile("^([0-9]+(?:\\.[0-9]+)?)(h|m|s|ms|f|t)$");
    private static final Pattern f3622c = Pattern.compile("^(([0-9]*.)?[0-9]+)(px|em|%)$");
    private static final Pattern f3623d = Pattern.compile("^(\\d+\\.?\\d*?)% (\\d+\\.?\\d*?)%$");
    private static final C1644a f3624e = new C1644a(30.0f, 1, 1);
    private final XmlPullParserFactory f3625f;

    private static final class C1644a {
        final float f3617a;
        final int f3618b;
        final int f3619c;

        C1644a(float f, int i, int i2) {
            this.f3617a = f;
            this.f3618b = i;
            this.f3619c = i2;
        }
    }

    protected /* synthetic */ C1635e mo2310a(byte[] bArr, int i) {
        return m3969b(bArr, i);
    }

    public C1645a() {
        super("TtmlDecoder");
        try {
            this.f3625f = XmlPullParserFactory.newInstance();
            this.f3625f.setNamespaceAware(true);
        } catch (Throwable e) {
            throw new RuntimeException("Couldn't create XmlPullParserFactory instance", e);
        }
    }

    protected C1650f m3969b(byte[] bArr, int i) {
        C1650f c1650f = null;
        int i2 = 0;
        try {
            XmlPullParser newPullParser = this.f3625f.newPullParser();
            Map hashMap = new HashMap();
            Map hashMap2 = new HashMap();
            hashMap2.put("", new C1647c());
            newPullParser.setInput(new ByteArrayInputStream(bArr, 0, i), null);
            LinkedList linkedList = new LinkedList();
            int eventType = newPullParser.getEventType();
            C1644a c1644a = f3624e;
            for (int i3 = eventType; i3 != 1; i3 = newPullParser.getEventType()) {
                C1646b c1646b = (C1646b) linkedList.peekLast();
                if (i2 == 0) {
                    C1650f c1650f2;
                    C1644a c1644a2;
                    int i4;
                    String name = newPullParser.getName();
                    if (i3 == 2) {
                        if ("tt".equals(name)) {
                            c1644a = m3959a(newPullParser);
                        }
                        int i5;
                        if (!C1645a.m3967b(name)) {
                            Log.i("TtmlDecoder", "Ignoring unsupported tag: " + newPullParser.getName());
                            eventType = i2 + 1;
                            c1650f2 = c1650f;
                            i5 = eventType;
                            c1644a2 = c1644a;
                            i4 = i5;
                        } else if ("head".equals(name)) {
                            m3963a(newPullParser, hashMap, hashMap2);
                            c1644a2 = c1644a;
                            i4 = i2;
                            c1650f2 = c1650f;
                        } else {
                            try {
                                C1646b a = m3960a(newPullParser, c1646b, hashMap2, c1644a);
                                linkedList.addLast(a);
                                if (c1646b != null) {
                                    c1646b.m3981a(a);
                                }
                                c1644a2 = c1644a;
                                i4 = i2;
                                c1650f2 = c1650f;
                            } catch (Throwable e) {
                                Log.w("TtmlDecoder", "Suppressing parser error", e);
                                eventType = i2 + 1;
                                c1650f2 = c1650f;
                                i5 = eventType;
                                c1644a2 = c1644a;
                                i4 = i5;
                            }
                        }
                    } else if (i3 == 4) {
                        c1646b.m3981a(C1646b.m3972a(newPullParser.getText()));
                        c1644a2 = c1644a;
                        i4 = i2;
                        c1650f2 = c1650f;
                    } else if (i3 == 3) {
                        C1650f c1650f3;
                        if (newPullParser.getName().equals("tt")) {
                            c1650f3 = new C1650f((C1646b) linkedList.getLast(), hashMap, hashMap2);
                        } else {
                            c1650f3 = c1650f;
                        }
                        linkedList.removeLast();
                        C1644a c1644a3 = c1644a;
                        i4 = i2;
                        c1650f2 = c1650f3;
                        c1644a2 = c1644a3;
                    } else {
                        c1644a2 = c1644a;
                        i4 = i2;
                        c1650f2 = c1650f;
                    }
                    c1650f = c1650f2;
                    i2 = i4;
                    c1644a = c1644a2;
                } else if (i3 == 2) {
                    i2++;
                } else if (i3 == 3) {
                    i2--;
                }
                newPullParser.next();
            }
            return c1650f;
        } catch (Throwable e2) {
            throw new SubtitleDecoderException("Unable to decode source", e2);
        } catch (Throwable e22) {
            throw new IllegalStateException("Unexpected error when reading input.", e22);
        }
    }

    private C1644a m3959a(XmlPullParser xmlPullParser) {
        int i = 30;
        String attributeValue = xmlPullParser.getAttributeValue("http://www.w3.org/ns/ttml#parameter", "frameRate");
        if (attributeValue != null) {
            i = Integer.parseInt(attributeValue);
        }
        float f = DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;
        String attributeValue2 = xmlPullParser.getAttributeValue("http://www.w3.org/ns/ttml#parameter", "frameRateMultiplier");
        if (attributeValue2 != null) {
            String[] split = attributeValue2.split(" ");
            if (split.length != 2) {
                throw new SubtitleDecoderException("frameRateMultiplier doesn't have 2 parts");
            }
            f = ((float) Integer.parseInt(split[0])) / ((float) Integer.parseInt(split[1]));
        }
        int i2 = f3624e.f3618b;
        String attributeValue3 = xmlPullParser.getAttributeValue("http://www.w3.org/ns/ttml#parameter", "subFrameRate");
        if (attributeValue3 != null) {
            i2 = Integer.parseInt(attributeValue3);
        }
        int i3 = f3624e.f3619c;
        String attributeValue4 = xmlPullParser.getAttributeValue("http://www.w3.org/ns/ttml#parameter", "tickRate");
        if (attributeValue4 != null) {
            i3 = Integer.parseInt(attributeValue4);
        }
        return new C1644a(((float) i) * f, i2, i3);
    }

    private Map m3963a(XmlPullParser xmlPullParser, Map map, Map map2) {
        do {
            xmlPullParser.next();
            if (C1415s.m2836b(xmlPullParser, AnalyticsEvents.PARAMETER_LIKE_VIEW_STYLE)) {
                String c = C1415s.m2837c(xmlPullParser, AnalyticsEvents.PARAMETER_LIKE_VIEW_STYLE);
                C1649e a = m3962a(xmlPullParser, new C1649e());
                if (c != null) {
                    for (Object obj : m3965a(c)) {
                        a.m3993a((C1649e) map.get(obj));
                    }
                }
                if (a.m4009i() != null) {
                    map.put(a.m4009i(), a);
                }
            } else if (C1415s.m2836b(xmlPullParser, "region")) {
                Pair b = m3966b(xmlPullParser);
                if (b != null) {
                    map2.put(b.first, b.second);
                }
            }
        } while (!C1415s.m2834a(xmlPullParser, "head"));
        return map;
    }

    private Pair m3966b(XmlPullParser xmlPullParser) {
        String c = C1415s.m2837c(xmlPullParser, "id");
        Object c2 = C1415s.m2837c(xmlPullParser, "origin");
        Object c3 = C1415s.m2837c(xmlPullParser, "extent");
        if (c2 == null || c == null) {
            return null;
        }
        float parseFloat;
        float parseFloat2;
        float parseFloat3;
        Matcher matcher = f3623d.matcher(c2);
        if (matcher.matches()) {
            try {
                parseFloat = Float.parseFloat(matcher.group(1)) / 100.0f;
                parseFloat2 = Float.parseFloat(matcher.group(2)) / 100.0f;
            } catch (Throwable e) {
                Log.w("TtmlDecoder", "Ignoring region with malformed origin: '" + c2 + "'", e);
                parseFloat2 = Float.MIN_VALUE;
                parseFloat = Float.MIN_VALUE;
            }
        } else {
            parseFloat2 = Float.MIN_VALUE;
            parseFloat = Float.MIN_VALUE;
        }
        if (c3 != null) {
            matcher = f3623d.matcher(c3);
            if (matcher.matches()) {
                try {
                    parseFloat3 = Float.parseFloat(matcher.group(1)) / 100.0f;
                } catch (Throwable e2) {
                    Log.w("TtmlDecoder", "Ignoring malformed region extent: '" + c3 + "'", e2);
                }
                if (parseFloat == Float.MIN_VALUE) {
                    return new Pair(c, new C1647c(parseFloat, parseFloat2, 0, parseFloat3));
                }
                return null;
            }
        }
        parseFloat3 = Float.MIN_VALUE;
        if (parseFloat == Float.MIN_VALUE) {
            return null;
        }
        return new Pair(c, new C1647c(parseFloat, parseFloat2, 0, parseFloat3));
    }

    private String[] m3965a(String str) {
        return str.split("\\s+");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private com.google.android.exoplayer2.text.p043c.C1649e m3962a(org.xmlpull.v1.XmlPullParser r13, com.google.android.exoplayer2.text.p043c.C1649e r14) {
        /*
        r12 = this;
        r6 = 3;
        r5 = 2;
        r3 = -1;
        r4 = 1;
        r2 = 0;
        r8 = r13.getAttributeCount();
        r7 = r2;
        r0 = r14;
    L_0x000b:
        if (r7 >= r8) goto L_0x0242;
    L_0x000d:
        r9 = r13.getAttributeValue(r7);
        r1 = r13.getAttributeName(r7);
        r10 = r1.hashCode();
        switch(r10) {
            case -1550943582: goto L_0x0066;
            case -1224696685: goto L_0x0045;
            case -1065511464: goto L_0x0071;
            case -879295043: goto L_0x007c;
            case -734428249: goto L_0x005b;
            case 3355: goto L_0x0024;
            case 94842723: goto L_0x003a;
            case 365601008: goto L_0x0050;
            case 1287124693: goto L_0x002f;
            default: goto L_0x001c;
        };
    L_0x001c:
        r1 = r3;
    L_0x001d:
        switch(r1) {
            case 0: goto L_0x0088;
            case 1: goto L_0x009e;
            case 2: goto L_0x00cf;
            case 3: goto L_0x0100;
            case 4: goto L_0x010a;
            case 5: goto L_0x0137;
            case 6: goto L_0x0148;
            case 7: goto L_0x0159;
            case 8: goto L_0x01dd;
            default: goto L_0x0020;
        };
    L_0x0020:
        r1 = r7 + 1;
        r7 = r1;
        goto L_0x000b;
    L_0x0024:
        r10 = "id";
        r1 = r1.equals(r10);
        if (r1 == 0) goto L_0x001c;
    L_0x002d:
        r1 = r2;
        goto L_0x001d;
    L_0x002f:
        r10 = "backgroundColor";
        r1 = r1.equals(r10);
        if (r1 == 0) goto L_0x001c;
    L_0x0038:
        r1 = r4;
        goto L_0x001d;
    L_0x003a:
        r10 = "color";
        r1 = r1.equals(r10);
        if (r1 == 0) goto L_0x001c;
    L_0x0043:
        r1 = r5;
        goto L_0x001d;
    L_0x0045:
        r10 = "fontFamily";
        r1 = r1.equals(r10);
        if (r1 == 0) goto L_0x001c;
    L_0x004e:
        r1 = r6;
        goto L_0x001d;
    L_0x0050:
        r10 = "fontSize";
        r1 = r1.equals(r10);
        if (r1 == 0) goto L_0x001c;
    L_0x0059:
        r1 = 4;
        goto L_0x001d;
    L_0x005b:
        r10 = "fontWeight";
        r1 = r1.equals(r10);
        if (r1 == 0) goto L_0x001c;
    L_0x0064:
        r1 = 5;
        goto L_0x001d;
    L_0x0066:
        r10 = "fontStyle";
        r1 = r1.equals(r10);
        if (r1 == 0) goto L_0x001c;
    L_0x006f:
        r1 = 6;
        goto L_0x001d;
    L_0x0071:
        r10 = "textAlign";
        r1 = r1.equals(r10);
        if (r1 == 0) goto L_0x001c;
    L_0x007a:
        r1 = 7;
        goto L_0x001d;
    L_0x007c:
        r10 = "textDecoration";
        r1 = r1.equals(r10);
        if (r1 == 0) goto L_0x001c;
    L_0x0085:
        r1 = 8;
        goto L_0x001d;
    L_0x0088:
        r1 = "style";
        r10 = r13.getName();
        r1 = r1.equals(r10);
        if (r1 == 0) goto L_0x0020;
    L_0x0095:
        r0 = r12.m3961a(r0);
        r0 = r0.m3997b(r9);
        goto L_0x0020;
    L_0x009e:
        r0 = r12.m3961a(r0);
        r1 = com.google.android.exoplayer2.p031c.C1394c.m2718a(r9);	 Catch:{ IllegalArgumentException -> 0x00ab }
        r0.m3996b(r1);	 Catch:{ IllegalArgumentException -> 0x00ab }
        goto L_0x0020;
    L_0x00ab:
        r1 = move-exception;
        r1 = "TtmlDecoder";
        r10 = new java.lang.StringBuilder;
        r10.<init>();
        r11 = "failed parsing background value: '";
        r10 = r10.append(r11);
        r9 = r10.append(r9);
        r10 = "'";
        r9 = r9.append(r10);
        r9 = r9.toString();
        android.util.Log.w(r1, r9);
        goto L_0x0020;
    L_0x00cf:
        r0 = r12.m3961a(r0);
        r1 = com.google.android.exoplayer2.p031c.C1394c.m2718a(r9);	 Catch:{ IllegalArgumentException -> 0x00dc }
        r0.m3991a(r1);	 Catch:{ IllegalArgumentException -> 0x00dc }
        goto L_0x0020;
    L_0x00dc:
        r1 = move-exception;
        r1 = "TtmlDecoder";
        r10 = new java.lang.StringBuilder;
        r10.<init>();
        r11 = "failed parsing color value: '";
        r10 = r10.append(r11);
        r9 = r10.append(r9);
        r10 = "'";
        r9 = r9.append(r10);
        r9 = r9.toString();
        android.util.Log.w(r1, r9);
        goto L_0x0020;
    L_0x0100:
        r0 = r12.m3961a(r0);
        r0 = r0.m3994a(r9);
        goto L_0x0020;
    L_0x010a:
        r0 = r12.m3961a(r0);	 Catch:{ SubtitleDecoderException -> 0x0113 }
        com.google.android.exoplayer2.text.p043c.C1645a.m3964a(r9, r0);	 Catch:{ SubtitleDecoderException -> 0x0113 }
        goto L_0x0020;
    L_0x0113:
        r1 = move-exception;
        r1 = "TtmlDecoder";
        r10 = new java.lang.StringBuilder;
        r10.<init>();
        r11 = "failed parsing fontSize value: '";
        r10 = r10.append(r11);
        r9 = r10.append(r9);
        r10 = "'";
        r9 = r9.append(r10);
        r9 = r9.toString();
        android.util.Log.w(r1, r9);
        goto L_0x0020;
    L_0x0137:
        r0 = r12.m3961a(r0);
        r1 = "bold";
        r1 = r1.equalsIgnoreCase(r9);
        r0 = r0.m4001c(r1);
        goto L_0x0020;
    L_0x0148:
        r0 = r12.m3961a(r0);
        r1 = "italic";
        r1 = r1.equalsIgnoreCase(r9);
        r0 = r0.m4003d(r1);
        goto L_0x0020;
    L_0x0159:
        r1 = com.google.android.exoplayer2.p031c.C1414r.m2829d(r9);
        r9 = r1.hashCode();
        switch(r9) {
            case -1364013995: goto L_0x01a2;
            case 100571: goto L_0x0197;
            case 3317767: goto L_0x0176;
            case 108511772: goto L_0x018c;
            case 109757538: goto L_0x0181;
            default: goto L_0x0164;
        };
    L_0x0164:
        r1 = r3;
    L_0x0165:
        switch(r1) {
            case 0: goto L_0x016a;
            case 1: goto L_0x01ad;
            case 2: goto L_0x01b9;
            case 3: goto L_0x01c5;
            case 4: goto L_0x01d1;
            default: goto L_0x0168;
        };
    L_0x0168:
        goto L_0x0020;
    L_0x016a:
        r0 = r12.m3961a(r0);
        r1 = android.text.Layout.Alignment.ALIGN_NORMAL;
        r0 = r0.m3992a(r1);
        goto L_0x0020;
    L_0x0176:
        r9 = "left";
        r1 = r1.equals(r9);
        if (r1 == 0) goto L_0x0164;
    L_0x017f:
        r1 = r2;
        goto L_0x0165;
    L_0x0181:
        r9 = "start";
        r1 = r1.equals(r9);
        if (r1 == 0) goto L_0x0164;
    L_0x018a:
        r1 = r4;
        goto L_0x0165;
    L_0x018c:
        r9 = "right";
        r1 = r1.equals(r9);
        if (r1 == 0) goto L_0x0164;
    L_0x0195:
        r1 = r5;
        goto L_0x0165;
    L_0x0197:
        r9 = "end";
        r1 = r1.equals(r9);
        if (r1 == 0) goto L_0x0164;
    L_0x01a0:
        r1 = r6;
        goto L_0x0165;
    L_0x01a2:
        r9 = "center";
        r1 = r1.equals(r9);
        if (r1 == 0) goto L_0x0164;
    L_0x01ab:
        r1 = 4;
        goto L_0x0165;
    L_0x01ad:
        r0 = r12.m3961a(r0);
        r1 = android.text.Layout.Alignment.ALIGN_NORMAL;
        r0 = r0.m3992a(r1);
        goto L_0x0020;
    L_0x01b9:
        r0 = r12.m3961a(r0);
        r1 = android.text.Layout.Alignment.ALIGN_OPPOSITE;
        r0 = r0.m3992a(r1);
        goto L_0x0020;
    L_0x01c5:
        r0 = r12.m3961a(r0);
        r1 = android.text.Layout.Alignment.ALIGN_OPPOSITE;
        r0 = r0.m3992a(r1);
        goto L_0x0020;
    L_0x01d1:
        r0 = r12.m3961a(r0);
        r1 = android.text.Layout.Alignment.ALIGN_CENTER;
        r0 = r0.m3992a(r1);
        goto L_0x0020;
    L_0x01dd:
        r1 = com.google.android.exoplayer2.p031c.C1414r.m2829d(r9);
        r9 = r1.hashCode();
        switch(r9) {
            case -1461280213: goto L_0x0219;
            case -1026963764: goto L_0x020e;
            case 913457136: goto L_0x0203;
            case 1679736913: goto L_0x01f8;
            default: goto L_0x01e8;
        };
    L_0x01e8:
        r1 = r3;
    L_0x01e9:
        switch(r1) {
            case 0: goto L_0x01ee;
            case 1: goto L_0x0224;
            case 2: goto L_0x022e;
            case 3: goto L_0x0238;
            default: goto L_0x01ec;
        };
    L_0x01ec:
        goto L_0x0020;
    L_0x01ee:
        r0 = r12.m3961a(r0);
        r0 = r0.m3995a(r4);
        goto L_0x0020;
    L_0x01f8:
        r9 = "linethrough";
        r1 = r1.equals(r9);
        if (r1 == 0) goto L_0x01e8;
    L_0x0201:
        r1 = r2;
        goto L_0x01e9;
    L_0x0203:
        r9 = "nolinethrough";
        r1 = r1.equals(r9);
        if (r1 == 0) goto L_0x01e8;
    L_0x020c:
        r1 = r4;
        goto L_0x01e9;
    L_0x020e:
        r9 = "underline";
        r1 = r1.equals(r9);
        if (r1 == 0) goto L_0x01e8;
    L_0x0217:
        r1 = r5;
        goto L_0x01e9;
    L_0x0219:
        r9 = "nounderline";
        r1 = r1.equals(r9);
        if (r1 == 0) goto L_0x01e8;
    L_0x0222:
        r1 = r6;
        goto L_0x01e9;
    L_0x0224:
        r0 = r12.m3961a(r0);
        r0 = r0.m3995a(r2);
        goto L_0x0020;
    L_0x022e:
        r0 = r12.m3961a(r0);
        r0 = r0.m3998b(r4);
        goto L_0x0020;
    L_0x0238:
        r0 = r12.m3961a(r0);
        r0 = r0.m3998b(r2);
        goto L_0x0020;
    L_0x0242:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.text.c.a.a(org.xmlpull.v1.XmlPullParser, com.google.android.exoplayer2.text.c.e):com.google.android.exoplayer2.text.c.e");
    }

    private C1649e m3961a(C1649e c1649e) {
        return c1649e == null ? new C1649e() : c1649e;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private com.google.android.exoplayer2.text.p043c.C1646b m3960a(org.xmlpull.v1.XmlPullParser r20, com.google.android.exoplayer2.text.p043c.C1646b r21, java.util.Map r22, com.google.android.exoplayer2.text.p043c.C1645a.C1644a r23) {
        /*
        r19 = this;
        r12 = -9223372036854775807; // 0x8000000000000001 float:1.4E-45 double:-4.9E-324;
        r6 = -9223372036854775807; // 0x8000000000000001 float:1.4E-45 double:-4.9E-324;
        r4 = -9223372036854775807; // 0x8000000000000001 float:1.4E-45 double:-4.9E-324;
        r10 = "";
        r9 = 0;
        r14 = r20.getAttributeCount();
        r2 = 0;
        r0 = r19;
        r1 = r20;
        r8 = r0.m3962a(r1, r2);
        r2 = 0;
        r11 = r2;
    L_0x0022:
        if (r11 >= r14) goto L_0x00b9;
    L_0x0024:
        r0 = r20;
        r15 = r0.getAttributeName(r11);
        r0 = r20;
        r2 = r0.getAttributeValue(r11);
        r3 = -1;
        r16 = r15.hashCode();
        switch(r16) {
            case -934795532: goto L_0x0070;
            case 99841: goto L_0x005a;
            case 100571: goto L_0x004f;
            case 93616297: goto L_0x0044;
            case 109780401: goto L_0x0065;
            default: goto L_0x0038;
        };
    L_0x0038:
        switch(r3) {
            case 0: goto L_0x007b;
            case 1: goto L_0x0088;
            case 2: goto L_0x0091;
            case 3: goto L_0x009e;
            case 4: goto L_0x00ac;
            default: goto L_0x003b;
        };
    L_0x003b:
        r2 = r4;
        r4 = r6;
        r6 = r12;
    L_0x003e:
        r11 = r11 + 1;
        r12 = r6;
        r6 = r4;
        r4 = r2;
        goto L_0x0022;
    L_0x0044:
        r16 = "begin";
        r15 = r15.equals(r16);
        if (r15 == 0) goto L_0x0038;
    L_0x004d:
        r3 = 0;
        goto L_0x0038;
    L_0x004f:
        r16 = "end";
        r15 = r15.equals(r16);
        if (r15 == 0) goto L_0x0038;
    L_0x0058:
        r3 = 1;
        goto L_0x0038;
    L_0x005a:
        r16 = "dur";
        r15 = r15.equals(r16);
        if (r15 == 0) goto L_0x0038;
    L_0x0063:
        r3 = 2;
        goto L_0x0038;
    L_0x0065:
        r16 = "style";
        r15 = r15.equals(r16);
        if (r15 == 0) goto L_0x0038;
    L_0x006e:
        r3 = 3;
        goto L_0x0038;
    L_0x0070:
        r16 = "region";
        r15 = r15.equals(r16);
        if (r15 == 0) goto L_0x0038;
    L_0x0079:
        r3 = 4;
        goto L_0x0038;
    L_0x007b:
        r0 = r23;
        r2 = com.google.android.exoplayer2.text.p043c.C1645a.m3958a(r2, r0);
        r6 = r12;
        r17 = r2;
        r2 = r4;
        r4 = r17;
        goto L_0x003e;
    L_0x0088:
        r0 = r23;
        r2 = com.google.android.exoplayer2.text.p043c.C1645a.m3958a(r2, r0);
        r4 = r6;
        r6 = r12;
        goto L_0x003e;
    L_0x0091:
        r0 = r23;
        r2 = com.google.android.exoplayer2.text.p043c.C1645a.m3958a(r2, r0);
        r17 = r4;
        r4 = r6;
        r6 = r2;
        r2 = r17;
        goto L_0x003e;
    L_0x009e:
        r0 = r19;
        r2 = r0.m3965a(r2);
        r3 = r2.length;
        if (r3 <= 0) goto L_0x003b;
    L_0x00a7:
        r9 = r2;
        r2 = r4;
        r4 = r6;
        r6 = r12;
        goto L_0x003e;
    L_0x00ac:
        r0 = r22;
        r3 = r0.containsKey(r2);
        if (r3 == 0) goto L_0x003b;
    L_0x00b4:
        r10 = r2;
        r2 = r4;
        r4 = r6;
        r6 = r12;
        goto L_0x003e;
    L_0x00b9:
        if (r21 == 0) goto L_0x011a;
    L_0x00bb:
        r0 = r21;
        r2 = r0.f3629d;
        r14 = -9223372036854775807; // 0x8000000000000001 float:1.4E-45 double:-4.9E-324;
        r2 = (r2 > r14 ? 1 : (r2 == r14 ? 0 : -1));
        if (r2 == 0) goto L_0x011a;
    L_0x00c8:
        r2 = -9223372036854775807; // 0x8000000000000001 float:1.4E-45 double:-4.9E-324;
        r2 = (r6 > r2 ? 1 : (r6 == r2 ? 0 : -1));
        if (r2 == 0) goto L_0x00d6;
    L_0x00d1:
        r0 = r21;
        r2 = r0.f3629d;
        r6 = r6 + r2;
    L_0x00d6:
        r2 = -9223372036854775807; // 0x8000000000000001 float:1.4E-45 double:-4.9E-324;
        r2 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1));
        if (r2 == 0) goto L_0x011a;
    L_0x00df:
        r0 = r21;
        r2 = r0.f3629d;
        r4 = r4 + r2;
        r17 = r4;
        r4 = r6;
        r6 = r17;
    L_0x00e9:
        r2 = -9223372036854775807; // 0x8000000000000001 float:1.4E-45 double:-4.9E-324;
        r2 = (r6 > r2 ? 1 : (r6 == r2 ? 0 : -1));
        if (r2 != 0) goto L_0x00fd;
    L_0x00f2:
        r2 = -9223372036854775807; // 0x8000000000000001 float:1.4E-45 double:-4.9E-324;
        r2 = (r12 > r2 ? 1 : (r12 == r2 ? 0 : -1));
        if (r2 == 0) goto L_0x0106;
    L_0x00fb:
        r6 = r4 + r12;
    L_0x00fd:
        r3 = r20.getName();
        r2 = com.google.android.exoplayer2.text.p043c.C1646b.m3973a(r3, r4, r6, r8, r9, r10);
        return r2;
    L_0x0106:
        if (r21 == 0) goto L_0x00fd;
    L_0x0108:
        r0 = r21;
        r2 = r0.f3630e;
        r12 = -9223372036854775807; // 0x8000000000000001 float:1.4E-45 double:-4.9E-324;
        r2 = (r2 > r12 ? 1 : (r2 == r12 ? 0 : -1));
        if (r2 == 0) goto L_0x00fd;
    L_0x0115:
        r0 = r21;
        r6 = r0.f3630e;
        goto L_0x00fd;
    L_0x011a:
        r17 = r4;
        r4 = r6;
        r6 = r17;
        goto L_0x00e9;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.text.c.a.a(org.xmlpull.v1.XmlPullParser, com.google.android.exoplayer2.text.c.b, java.util.Map, com.google.android.exoplayer2.text.c.a$a):com.google.android.exoplayer2.text.c.b");
    }

    private static boolean m3967b(String str) {
        if (str.equals("tt") || str.equals("head") || str.equals("body") || str.equals("div") || str.equals("p") || str.equals("span") || str.equals("br") || str.equals(AnalyticsEvents.PARAMETER_LIKE_VIEW_STYLE) || str.equals("styling") || str.equals("layout") || str.equals("region") || str.equals("metadata") || str.equals("smpte:image") || str.equals("smpte:data") || str.equals("smpte:information")) {
            return true;
        }
        return false;
    }

    private static void m3964a(String str, C1649e c1649e) {
        Matcher matcher;
        String[] split = str.split("\\s+");
        if (split.length == 1) {
            matcher = f3622c.matcher(str);
        } else if (split.length == 2) {
            matcher = f3622c.matcher(split[1]);
            Log.w("TtmlDecoder", "Multiple values in fontSize attribute. Picking the second value for vertical font size and ignoring the first.");
        } else {
            throw new SubtitleDecoderException("Invalid number of entries for fontSize: " + split.length + ".");
        }
        if (matcher.matches()) {
            String group = matcher.group(3);
            int i = -1;
            switch (group.hashCode()) {
                case 37:
                    if (group.equals("%")) {
                        i = 2;
                        break;
                    }
                    break;
                case 3240:
                    if (group.equals("em")) {
                        i = 1;
                        break;
                    }
                    break;
                case 3592:
                    if (group.equals("px")) {
                        i = 0;
                        break;
                    }
                    break;
            }
            switch (i) {
                case 0:
                    c1649e.m4000c(1);
                    break;
                case 1:
                    c1649e.m4000c(2);
                    break;
                case 2:
                    c1649e.m4000c(3);
                    break;
                default:
                    throw new SubtitleDecoderException("Invalid unit for fontSize: '" + group + "'.");
            }
            c1649e.m3990a(Float.valueOf(matcher.group(1)).floatValue());
            return;
        }
        throw new SubtitleDecoderException("Invalid expression for fontSize: '" + str + "'.");
    }

    private static long m3958a(String str, C1644a c1644a) {
        double d = 0.0d;
        Matcher matcher = f3620a.matcher(str);
        double parseLong;
        if (matcher.matches()) {
            double parseLong2 = ((double) Long.parseLong(matcher.group(3))) + (((double) (Long.parseLong(matcher.group(1)) * 3600)) + ((double) (Long.parseLong(matcher.group(2)) * 60)));
            String group = matcher.group(4);
            parseLong2 += group != null ? Double.parseDouble(group) : 0.0d;
            group = matcher.group(5);
            if (group != null) {
                parseLong = (double) (((float) Long.parseLong(group)) / c1644a.f3617a);
            } else {
                parseLong = 0.0d;
            }
            parseLong += parseLong2;
            String group2 = matcher.group(6);
            if (group2 != null) {
                d = (((double) Long.parseLong(group2)) / ((double) c1644a.f3618b)) / ((double) c1644a.f3617a);
            }
            return (long) ((parseLong + d) * 1000000.0d);
        }
        Matcher matcher2 = f3621b.matcher(str);
        if (matcher2.matches()) {
            parseLong = Double.parseDouble(matcher2.group(1));
            String group3 = matcher2.group(2);
            int i = -1;
            switch (group3.hashCode()) {
                case 102:
                    if (group3.equals("f")) {
                        i = 4;
                        break;
                    }
                    break;
                case 104:
                    if (group3.equals("h")) {
                        i = 0;
                        break;
                    }
                    break;
                case 109:
                    if (group3.equals("m")) {
                        i = 1;
                        break;
                    }
                    break;
                case 115:
                    if (group3.equals("s")) {
                        i = 2;
                        break;
                    }
                    break;
                case 116:
                    if (group3.equals("t")) {
                        i = 5;
                        break;
                    }
                    break;
                case 3494:
                    if (group3.equals("ms")) {
                        i = 3;
                        break;
                    }
                    break;
            }
            switch (i) {
                case 0:
                    parseLong *= 3600.0d;
                    break;
                case 1:
                    parseLong *= 60.0d;
                    break;
                case 3:
                    parseLong /= 1000.0d;
                    break;
                case 4:
                    parseLong /= (double) c1644a.f3617a;
                    break;
                case 5:
                    parseLong /= (double) c1644a.f3619c;
                    break;
            }
            return (long) (parseLong * 1000000.0d);
        }
        throw new SubtitleDecoderException("Malformed time expression: " + str);
    }
}
