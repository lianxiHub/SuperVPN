package com.google.android.exoplayer2.text.p043c;

import android.text.SpannableStringBuilder;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.text.C1643b;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.TreeSet;

final class C1646b {
    public final String f3626a;
    public final String f3627b;
    public final boolean f3628c;
    public final long f3629d;
    public final long f3630e;
    public final C1649e f3631f;
    public final String f3632g;
    private final String[] f3633h;
    private final HashMap f3634i;
    private final HashMap f3635j;
    private List f3636k;

    public static C1646b m3972a(String str) {
        return new C1646b(null, C1648d.m3985a(str), -9223372036854775807L, -9223372036854775807L, null, null, "");
    }

    public static C1646b m3973a(String str, long j, long j2, C1649e c1649e, String[] strArr, String str2) {
        return new C1646b(str, null, j, j2, c1649e, strArr, str2);
    }

    private C1646b(String str, String str2, long j, long j2, C1649e c1649e, String[] strArr, String str3) {
        this.f3626a = str;
        this.f3627b = str2;
        this.f3631f = c1649e;
        this.f3633h = strArr;
        this.f3628c = str2 != null;
        this.f3629d = j;
        this.f3630e = j2;
        this.f3632g = (String) C1392a.m2707a((Object) str3);
        this.f3634i = new HashMap();
        this.f3635j = new HashMap();
    }

    public boolean m3982a(long j) {
        return (this.f3629d == -9223372036854775807L && this.f3630e == -9223372036854775807L) || ((this.f3629d <= j && this.f3630e == -9223372036854775807L) || ((this.f3629d == -9223372036854775807L && j < this.f3630e) || (this.f3629d <= j && j < this.f3630e)));
    }

    public void m3981a(C1646b c1646b) {
        if (this.f3636k == null) {
            this.f3636k = new ArrayList();
        }
        this.f3636k.add(c1646b);
    }

    public C1646b m3979a(int i) {
        if (this.f3636k != null) {
            return (C1646b) this.f3636k.get(i);
        }
        throw new IndexOutOfBoundsException();
    }

    public int m3978a() {
        return this.f3636k == null ? 0 : this.f3636k.size();
    }

    public long[] m3983b() {
        TreeSet treeSet = new TreeSet();
        m3977a(treeSet, false);
        long[] jArr = new long[treeSet.size()];
        Iterator it = treeSet.iterator();
        int i = 0;
        while (it.hasNext()) {
            int i2 = i + 1;
            jArr[i] = ((Long) it.next()).longValue();
            i = i2;
        }
        return jArr;
    }

    private void m3977a(TreeSet treeSet, boolean z) {
        boolean equals = "p".equals(this.f3626a);
        if (z || equals) {
            if (this.f3629d != -9223372036854775807L) {
                treeSet.add(Long.valueOf(this.f3629d));
            }
            if (this.f3630e != -9223372036854775807L) {
                treeSet.add(Long.valueOf(this.f3630e));
            }
        }
        if (this.f3636k != null) {
            for (int i = 0; i < this.f3636k.size(); i++) {
                boolean z2;
                C1646b c1646b = (C1646b) this.f3636k.get(i);
                if (z || equals) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                c1646b.m3977a(treeSet, z2);
            }
        }
    }

    public List m3980a(long j, Map map, Map map2) {
        Map treeMap = new TreeMap();
        m3974a(j, false, this.f3632g, treeMap);
        m3976a(map, treeMap);
        List arrayList = new ArrayList();
        for (Entry entry : treeMap.entrySet()) {
            C1647c c1647c = (C1647c) map2.get(entry.getKey());
            arrayList.add(new C1643b(m3970a((SpannableStringBuilder) entry.getValue()), null, c1647c.f3638b, c1647c.f3639c, Integer.MIN_VALUE, c1647c.f3637a, Integer.MIN_VALUE, c1647c.f3640d));
        }
        return arrayList;
    }

    private void m3974a(long j, boolean z, String str, Map map) {
        this.f3634i.clear();
        this.f3635j.clear();
        String str2 = this.f3632g;
        if ("".equals(str2)) {
            str2 = str;
        }
        if (this.f3628c && z) {
            C1646b.m3971a(str2, map).append(this.f3627b);
        } else if ("br".equals(this.f3626a) && z) {
            C1646b.m3971a(str2, map).append('\n');
        } else if (!"metadata".equals(this.f3626a) && m3982a(j)) {
            boolean equals = "p".equals(this.f3626a);
            for (Entry entry : map.entrySet()) {
                this.f3634i.put(entry.getKey(), Integer.valueOf(((SpannableStringBuilder) entry.getValue()).length()));
            }
            for (int i = 0; i < m3978a(); i++) {
                boolean z2;
                C1646b a = m3979a(i);
                if (z || equals) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                a.m3974a(j, z2, str2, map);
            }
            if (equals) {
                C1648d.m3986a(C1646b.m3971a(str2, map));
            }
            for (Entry entry2 : map.entrySet()) {
                this.f3635j.put(entry2.getKey(), Integer.valueOf(((SpannableStringBuilder) entry2.getValue()).length()));
            }
        }
    }

    private static SpannableStringBuilder m3971a(String str, Map map) {
        if (!map.containsKey(str)) {
            map.put(str, new SpannableStringBuilder());
        }
        return (SpannableStringBuilder) map.get(str);
    }

    private void m3976a(Map map, Map map2) {
        for (Entry entry : this.f3635j.entrySet()) {
            int intValue;
            String str = (String) entry.getKey();
            if (this.f3634i.containsKey(str)) {
                intValue = ((Integer) this.f3634i.get(str)).intValue();
            } else {
                intValue = 0;
            }
            m3975a(map, (SpannableStringBuilder) map2.get(str), intValue, ((Integer) entry.getValue()).intValue());
            for (int i = 0; i < m3978a(); i++) {
                m3979a(i).m3976a(map, map2);
            }
        }
    }

    private void m3975a(Map map, SpannableStringBuilder spannableStringBuilder, int i, int i2) {
        if (i != i2) {
            C1649e a = C1648d.m3984a(this.f3631f, this.f3633h, map);
            if (a != null) {
                C1648d.m3987a(spannableStringBuilder, i, i2, a);
            }
        }
    }

    private SpannableStringBuilder m3970a(SpannableStringBuilder spannableStringBuilder) {
        int i;
        int length = spannableStringBuilder.length();
        int i2 = 0;
        while (i2 < length) {
            if (spannableStringBuilder.charAt(i2) == ' ') {
                i = i2 + 1;
                while (i < spannableStringBuilder.length() && spannableStringBuilder.charAt(i) == ' ') {
                    i++;
                }
                i -= i2 + 1;
                if (i > 0) {
                    spannableStringBuilder.delete(i2, i2 + i);
                    i = length - i;
                    i2++;
                    length = i;
                }
            }
            i = length;
            i2++;
            length = i;
        }
        if (length > 0 && spannableStringBuilder.charAt(0) == ' ') {
            spannableStringBuilder.delete(0, 1);
            length--;
        }
        i = length;
        length = 0;
        while (length < i - 1) {
            if (spannableStringBuilder.charAt(length) == '\n' && spannableStringBuilder.charAt(length + 1) == ' ') {
                spannableStringBuilder.delete(length + 1, length + 2);
                i--;
            }
            length++;
        }
        if (i > 0 && spannableStringBuilder.charAt(i - 1) == ' ') {
            spannableStringBuilder.delete(i - 1, i);
            i--;
        }
        length = 0;
        while (length < i - 1) {
            if (spannableStringBuilder.charAt(length) == ' ' && spannableStringBuilder.charAt(length + 1) == '\n') {
                spannableStringBuilder.delete(length, length + 1);
                i--;
            }
            length++;
        }
        if (i > 0 && spannableStringBuilder.charAt(i - 1) == '\n') {
            spannableStringBuilder.delete(i - 1, i);
        }
        return spannableStringBuilder;
    }
}
