package com.google.android.exoplayer2.text.p043c;

import android.text.SpannableStringBuilder;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.AlignmentSpan.Standard;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;
import android.text.style.UnderlineSpan;
import java.util.Map;

final class C1648d {
    public static C1649e m3984a(C1649e c1649e, String[] strArr, Map map) {
        if (c1649e == null && strArr == null) {
            return null;
        }
        if (c1649e == null && strArr.length == 1) {
            return (C1649e) map.get(strArr[0]);
        }
        if (c1649e == null && strArr.length > 1) {
            c1649e = new C1649e();
            for (Object obj : strArr) {
                c1649e.m3993a((C1649e) map.get(obj));
            }
            return c1649e;
        } else if (c1649e != null && strArr != null && strArr.length == 1) {
            return c1649e.m3993a((C1649e) map.get(strArr[0]));
        } else {
            if (c1649e == null || strArr == null || strArr.length <= 1) {
                return c1649e;
            }
            for (Object obj2 : strArr) {
                c1649e.m3993a((C1649e) map.get(obj2));
            }
            return c1649e;
        }
    }

    public static void m3987a(SpannableStringBuilder spannableStringBuilder, int i, int i2, C1649e c1649e) {
        if (c1649e.m3989a() != -1) {
            spannableStringBuilder.setSpan(new StyleSpan(c1649e.m3989a()), i, i2, 33);
        }
        if (c1649e.m3999b()) {
            spannableStringBuilder.setSpan(new StrikethroughSpan(), i, i2, 33);
        }
        if (c1649e.m4002c()) {
            spannableStringBuilder.setSpan(new UnderlineSpan(), i, i2, 33);
        }
        if (c1649e.m4006f()) {
            spannableStringBuilder.setSpan(new ForegroundColorSpan(c1649e.m4005e()), i, i2, 33);
        }
        if (c1649e.m4008h()) {
            spannableStringBuilder.setSpan(new BackgroundColorSpan(c1649e.m4007g()), i, i2, 33);
        }
        if (c1649e.m4004d() != null) {
            spannableStringBuilder.setSpan(new TypefaceSpan(c1649e.m4004d()), i, i2, 33);
        }
        if (c1649e.m4010j() != null) {
            spannableStringBuilder.setSpan(new Standard(c1649e.m4010j()), i, i2, 33);
        }
        if (c1649e.m4011k() != -1) {
            switch (c1649e.m4011k()) {
                case 1:
                    spannableStringBuilder.setSpan(new AbsoluteSizeSpan((int) c1649e.m4012l(), true), i, i2, 33);
                    return;
                case 2:
                    spannableStringBuilder.setSpan(new RelativeSizeSpan(c1649e.m4012l()), i, i2, 33);
                    return;
                case 3:
                    spannableStringBuilder.setSpan(new RelativeSizeSpan(c1649e.m4012l() / 100.0f), i, i2, 33);
                    return;
                default:
                    return;
            }
        }
    }

    static void m3986a(SpannableStringBuilder spannableStringBuilder) {
        int length = spannableStringBuilder.length() - 1;
        while (length >= 0 && spannableStringBuilder.charAt(length) == ' ') {
            length--;
        }
        if (length >= 0 && spannableStringBuilder.charAt(length) != '\n') {
            spannableStringBuilder.append('\n');
        }
    }

    static String m3985a(String str) {
        return str.replaceAll("\r\n", "\n").replaceAll(" *\n *", "\n").replaceAll("\n", " ").replaceAll("[ \t\\x0B\f\r]+", " ");
    }
}
