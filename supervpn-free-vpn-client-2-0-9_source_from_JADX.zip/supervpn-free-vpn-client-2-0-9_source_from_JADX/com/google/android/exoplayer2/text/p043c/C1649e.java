package com.google.android.exoplayer2.text.p043c;

import android.text.Layout.Alignment;
import com.google.android.exoplayer2.p031c.C1392a;

final class C1649e {
    private String f3641a;
    private int f3642b;
    private boolean f3643c;
    private int f3644d;
    private boolean f3645e;
    private int f3646f = -1;
    private int f3647g = -1;
    private int f3648h = -1;
    private int f3649i = -1;
    private int f3650j = -1;
    private float f3651k;
    private String f3652l;
    private C1649e f3653m;
    private Alignment f3654n;

    public int m3989a() {
        int i = 0;
        if (this.f3648h == -1 && this.f3649i == -1) {
            return -1;
        }
        int i2 = this.f3648h == 1 ? 1 : 0;
        if (this.f3649i == 1) {
            i = 2;
        }
        return i2 | i;
    }

    public boolean m3999b() {
        return this.f3646f == 1;
    }

    public C1649e m3995a(boolean z) {
        boolean z2;
        int i = 1;
        if (this.f3653m == null) {
            z2 = true;
        } else {
            z2 = false;
        }
        C1392a.m2711b(z2);
        if (!z) {
            i = 0;
        }
        this.f3646f = i;
        return this;
    }

    public boolean m4002c() {
        return this.f3647g == 1;
    }

    public C1649e m3998b(boolean z) {
        boolean z2;
        int i = 1;
        if (this.f3653m == null) {
            z2 = true;
        } else {
            z2 = false;
        }
        C1392a.m2711b(z2);
        if (!z) {
            i = 0;
        }
        this.f3647g = i;
        return this;
    }

    public C1649e m4001c(boolean z) {
        boolean z2;
        int i = 1;
        if (this.f3653m == null) {
            z2 = true;
        } else {
            z2 = false;
        }
        C1392a.m2711b(z2);
        if (!z) {
            i = 0;
        }
        this.f3648h = i;
        return this;
    }

    public C1649e m4003d(boolean z) {
        boolean z2;
        int i = 1;
        if (this.f3653m == null) {
            z2 = true;
        } else {
            z2 = false;
        }
        C1392a.m2711b(z2);
        if (!z) {
            i = 0;
        }
        this.f3649i = i;
        return this;
    }

    public String m4004d() {
        return this.f3641a;
    }

    public C1649e m3994a(String str) {
        C1392a.m2711b(this.f3653m == null);
        this.f3641a = str;
        return this;
    }

    public int m4005e() {
        if (this.f3643c) {
            return this.f3642b;
        }
        throw new IllegalStateException("Font color has not been defined.");
    }

    public C1649e m3991a(int i) {
        C1392a.m2711b(this.f3653m == null);
        this.f3642b = i;
        this.f3643c = true;
        return this;
    }

    public boolean m4006f() {
        return this.f3643c;
    }

    public int m4007g() {
        if (this.f3645e) {
            return this.f3644d;
        }
        throw new IllegalStateException("Background color has not been defined.");
    }

    public C1649e m3996b(int i) {
        this.f3644d = i;
        this.f3645e = true;
        return this;
    }

    public boolean m4008h() {
        return this.f3645e;
    }

    public C1649e m3993a(C1649e c1649e) {
        return m3988a(c1649e, true);
    }

    private C1649e m3988a(C1649e c1649e, boolean z) {
        if (c1649e != null) {
            if (!this.f3643c && c1649e.f3643c) {
                m3991a(c1649e.f3642b);
            }
            if (this.f3648h == -1) {
                this.f3648h = c1649e.f3648h;
            }
            if (this.f3649i == -1) {
                this.f3649i = c1649e.f3649i;
            }
            if (this.f3641a == null) {
                this.f3641a = c1649e.f3641a;
            }
            if (this.f3646f == -1) {
                this.f3646f = c1649e.f3646f;
            }
            if (this.f3647g == -1) {
                this.f3647g = c1649e.f3647g;
            }
            if (this.f3654n == null) {
                this.f3654n = c1649e.f3654n;
            }
            if (this.f3650j == -1) {
                this.f3650j = c1649e.f3650j;
                this.f3651k = c1649e.f3651k;
            }
            if (z && !this.f3645e && c1649e.f3645e) {
                m3996b(c1649e.f3644d);
            }
        }
        return this;
    }

    public C1649e m3997b(String str) {
        this.f3652l = str;
        return this;
    }

    public String m4009i() {
        return this.f3652l;
    }

    public Alignment m4010j() {
        return this.f3654n;
    }

    public C1649e m3992a(Alignment alignment) {
        this.f3654n = alignment;
        return this;
    }

    public C1649e m3990a(float f) {
        this.f3651k = f;
        return this;
    }

    public C1649e m4000c(int i) {
        this.f3650j = i;
        return this;
    }

    public int m4011k() {
        return this.f3650j;
    }

    public float m4012l() {
        return this.f3651k;
    }
}
