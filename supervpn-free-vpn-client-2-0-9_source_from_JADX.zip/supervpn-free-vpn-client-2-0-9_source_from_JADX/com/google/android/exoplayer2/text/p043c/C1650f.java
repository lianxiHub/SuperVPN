package com.google.android.exoplayer2.text.p043c;

import com.google.android.exoplayer2.p031c.C1414r;
import com.google.android.exoplayer2.text.C1635e;
import java.util.Collections;
import java.util.List;
import java.util.Map;

final class C1650f implements C1635e {
    private final C1646b f3655a;
    private final long[] f3656b;
    private final Map f3657c;
    private final Map f3658d;

    public C1650f(C1646b c1646b, Map map, Map map2) {
        this.f3655a = c1646b;
        this.f3658d = map2;
        this.f3657c = map != null ? Collections.unmodifiableMap(map) : Collections.emptyMap();
        this.f3656b = c1646b.m3983b();
    }

    public int mo2299a(long j) {
        int b = C1414r.m2826b(this.f3656b, j, false, false);
        return b < this.f3656b.length ? b : -1;
    }

    public int mo2301b() {
        return this.f3656b.length;
    }

    public long mo2300a(int i) {
        return this.f3656b[i];
    }

    public List mo2302b(long j) {
        return this.f3655a.m3980a(j, this.f3657c, this.f3658d);
    }
}
