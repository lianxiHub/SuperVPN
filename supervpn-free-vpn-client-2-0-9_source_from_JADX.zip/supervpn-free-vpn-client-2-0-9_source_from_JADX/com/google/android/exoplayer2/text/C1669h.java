package com.google.android.exoplayer2.text;

import com.google.android.exoplayer2.p030a.C1347e;

public final class C1669h extends C1347e implements Comparable {
    public long f3723d;

    public /* synthetic */ int compareTo(Object obj) {
        return m4115a((C1669h) obj);
    }

    public C1669h() {
        super(1);
    }

    public int m4115a(C1669h c1669h) {
        long j = this.c - c1669h.c;
        if (j == 0) {
            return 0;
        }
        return j > 0 ? 1 : -1;
    }
}
