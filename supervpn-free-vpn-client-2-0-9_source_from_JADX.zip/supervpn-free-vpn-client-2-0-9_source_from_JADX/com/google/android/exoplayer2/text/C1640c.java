package com.google.android.exoplayer2.text;

import com.google.android.exoplayer2.p030a.C1347e;
import com.google.android.exoplayer2.p030a.C1348f;
import com.google.android.exoplayer2.p030a.C1350g;
import java.nio.ByteBuffer;

public abstract class C1640c extends C1350g implements C1632f {
    private final String f3603a;

    protected abstract C1635e mo2310a(byte[] bArr, int i);

    protected /* synthetic */ C1347e mo2306g() {
        return mo2308i();
    }

    protected /* synthetic */ C1348f mo2307h() {
        return mo2309j();
    }

    protected C1640c(String str) {
        super(new C1669h[2], new C1636i[2]);
        this.f3603a = str;
        m2451a(1024);
    }

    public void mo2292a(long j) {
    }

    protected final C1669h mo2308i() {
        return new C1669h();
    }

    protected final C1636i mo2309j() {
        return new C1653d(this);
    }

    protected final void m3946a(C1636i c1636i) {
        super.mo2305a((C1348f) c1636i);
    }

    protected final SubtitleDecoderException m3941a(C1669h c1669h, C1636i c1636i, boolean z) {
        try {
            ByteBuffer byteBuffer = c1669h.b;
            C1635e a = mo2310a(byteBuffer.array(), byteBuffer.limit());
            c1636i.m3929a(c1669h.c, a, c1669h.f3723d);
            return null;
        } catch (SubtitleDecoderException e) {
            return e;
        }
    }
}
