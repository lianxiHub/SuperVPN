package com.google.android.exoplayer2.text;

import java.util.List;

public interface C1635e {
    int mo2299a(long j);

    long mo2300a(int i);

    int mo2301b();

    List mo2302b(long j);
}
