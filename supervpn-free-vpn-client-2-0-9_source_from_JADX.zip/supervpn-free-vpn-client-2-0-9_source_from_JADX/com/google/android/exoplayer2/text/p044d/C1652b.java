package com.google.android.exoplayer2.text.p044d;

import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.text.C1635e;
import com.google.android.exoplayer2.text.C1643b;
import java.util.Collections;
import java.util.List;

final class C1652b implements C1635e {
    public static final C1652b f3660a = new C1652b();
    private final List f3661b;

    public C1652b(C1643b c1643b) {
        this.f3661b = Collections.singletonList(c1643b);
    }

    private C1652b() {
        this.f3661b = Collections.emptyList();
    }

    public int mo2299a(long j) {
        return j < 0 ? 0 : -1;
    }

    public int mo2301b() {
        return 1;
    }

    public long mo2300a(int i) {
        C1392a.m2709a(i == 0);
        return 0;
    }

    public List mo2302b(long j) {
        return j >= 0 ? this.f3661b : Collections.emptyList();
    }
}
