package com.google.android.exoplayer2.text.p044d;

import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.text.C1635e;
import com.google.android.exoplayer2.text.C1640c;
import com.google.android.exoplayer2.text.C1643b;

public final class C1651a extends C1640c {
    private final C1403k f3659a = new C1403k();

    public C1651a() {
        super("Tx3gDecoder");
    }

    protected C1635e mo2310a(byte[] bArr, int i) {
        this.f3659a.m2755a(bArr, i);
        int h = this.f3659a.m2767h();
        if (h == 0) {
            return C1652b.f3660a;
        }
        return new C1652b(new C1643b(this.f3659a.m2764e(h)));
    }
}
