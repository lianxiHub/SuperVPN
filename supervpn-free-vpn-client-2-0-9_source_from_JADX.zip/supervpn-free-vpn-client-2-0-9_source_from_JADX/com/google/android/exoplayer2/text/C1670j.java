package com.google.android.exoplayer2.text;

import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Looper;
import android.os.Message;
import com.google.android.exoplayer2.C1354a;
import com.google.android.exoplayer2.C1581h;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1398h;
import java.util.Collections;
import java.util.List;

public final class C1670j extends C1354a implements Callback {
    private final Handler f3724a;
    private final C1590a f3725b;
    private final C1667g f3726c;
    private final C1581h f3727d;
    private boolean f3728e;
    private boolean f3729f;
    private C1632f f3730g;
    private C1669h f3731h;
    private C1636i f3732i;
    private C1636i f3733j;
    private int f3734k;

    public interface C1590a {
        void mo2245a(List list);
    }

    public C1670j(C1590a c1590a, Looper looper) {
        this(c1590a, looper, C1667g.f3722a);
    }

    public C1670j(C1590a c1590a, Looper looper, C1667g c1667g) {
        super(3);
        this.f3725b = (C1590a) C1392a.m2707a((Object) c1590a);
        this.f3724a = looper == null ? null : new Handler(looper, this);
        this.f3726c = c1667g;
        this.f3727d = new C1581h();
    }

    public int mo2119a(Format format) {
        if (this.f3726c.mo2311a(format)) {
            return 3;
        }
        return C1398h.m2732c(format.f2183e) ? 1 : 0;
    }

    protected void mo2153a(Format[] formatArr) {
        if (this.f3730g != null) {
            this.f3730g.mo2095d();
            this.f3731h = null;
        }
        this.f3730g = this.f3726c.mo2312b(formatArr[0]);
    }

    protected void mo2121a(long j, boolean z) {
        this.f3728e = false;
        this.f3729f = false;
        if (this.f3732i != null) {
            this.f3732i.mo2303d();
            this.f3732i = null;
        }
        if (this.f3733j != null) {
            this.f3733j.mo2303d();
            this.f3733j = null;
        }
        this.f3731h = null;
        m4119u();
        this.f3730g.mo2094c();
    }

    public void mo2120a(long j, long j2) {
        if (!this.f3729f) {
            if (this.f3733j == null) {
                this.f3730g.mo2292a(j);
                try {
                    this.f3733j = (C1636i) this.f3730g.mo2093b();
                } catch (Exception e) {
                    throw ExoPlaybackException.m2399a(e, m2509p());
                }
            }
            if (mo2104d() == 2) {
                boolean z = false;
                if (this.f3732i != null) {
                    long t = m4118t();
                    while (t <= j) {
                        this.f3734k++;
                        t = m4118t();
                        z = true;
                    }
                }
                if (this.f3733j != null) {
                    if (this.f3733j.m2424c()) {
                        if (!z && m4118t() == Long.MAX_VALUE) {
                            if (this.f3732i != null) {
                                this.f3732i.mo2303d();
                                this.f3732i = null;
                            }
                            this.f3733j.mo2303d();
                            this.f3733j = null;
                            this.f3729f = true;
                        }
                    } else if (this.f3733j.a <= j) {
                        if (this.f3732i != null) {
                            this.f3732i.mo2303d();
                        }
                        this.f3732i = this.f3733j;
                        this.f3733j = null;
                        this.f3734k = this.f3732i.mo2299a(j);
                        z = true;
                    }
                }
                if (z) {
                    m4116a(this.f3732i.mo2302b(j));
                }
                while (!this.f3728e) {
                    if (this.f3731h == null) {
                        this.f3731h = (C1669h) this.f3730g.mo2091a();
                        if (this.f3731h == null) {
                            return;
                        }
                    }
                    int a = m2485a(this.f3727d, this.f3731h);
                    if (a == -4) {
                        this.f3731h.m2423c(Integer.MIN_VALUE);
                        if (this.f3731h.m2424c()) {
                            this.f3728e = true;
                        } else {
                            try {
                                this.f3731h.f3723d = this.f3727d.f3419a.f2199u;
                                this.f3731h.m2439e();
                            } catch (Exception e2) {
                                throw ExoPlaybackException.m2399a(e2, m2509p());
                            }
                        }
                        this.f3730g.mo2092a(this.f3731h);
                        this.f3731h = null;
                    } else if (a == -3) {
                        return;
                    }
                }
            }
        }
    }

    protected void mo2125o() {
        if (this.f3732i != null) {
            this.f3732i.mo2303d();
            this.f3732i = null;
        }
        if (this.f3733j != null) {
            this.f3733j.mo2303d();
            this.f3733j = null;
        }
        this.f3730g.mo2095d();
        this.f3730g = null;
        this.f3731h = null;
        m4119u();
        super.mo2125o();
    }

    public boolean mo2127s() {
        return this.f3729f;
    }

    public boolean mo2126r() {
        return true;
    }

    private long m4118t() {
        if (this.f3734k == -1 || this.f3734k >= this.f3732i.mo2301b()) {
            return Long.MAX_VALUE;
        }
        return this.f3732i.mo2300a(this.f3734k);
    }

    private void m4116a(List list) {
        if (this.f3724a != null) {
            this.f3724a.obtainMessage(0, list).sendToTarget();
        } else {
            m4117b(list);
        }
    }

    private void m4119u() {
        m4116a(Collections.emptyList());
    }

    public boolean handleMessage(Message message) {
        switch (message.what) {
            case 0:
                m4117b((List) message.obj);
                return true;
            default:
                return false;
        }
    }

    private void m4117b(List list) {
        this.f3725b.mo2245a(list);
    }
}
