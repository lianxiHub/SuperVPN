package com.google.android.exoplayer2.text;

final class C1653d extends C1636i {
    private C1640c f3662c;

    public C1653d(C1640c c1640c) {
        this.f3662c = c1640c;
    }

    public final void mo2303d() {
        this.f3662c.m3946a((C1636i) this);
    }
}
