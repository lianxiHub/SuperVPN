package com.google.android.exoplayer2.text.p041a;

import com.google.android.exoplayer2.text.C1635e;
import com.google.android.exoplayer2.text.C1643b;
import java.util.Collections;
import java.util.List;

final class C1638d implements C1635e {
    private final List f3595a;

    public C1638d(C1643b c1643b) {
        if (c1643b == null) {
            this.f3595a = Collections.emptyList();
        } else {
            this.f3595a = Collections.singletonList(c1643b);
        }
    }

    public int mo2299a(long j) {
        return 0;
    }

    public int mo2301b() {
        return 1;
    }

    public long mo2300a(int i) {
        return 0;
    }

    public List mo2302b(long j) {
        return this.f3595a;
    }
}
