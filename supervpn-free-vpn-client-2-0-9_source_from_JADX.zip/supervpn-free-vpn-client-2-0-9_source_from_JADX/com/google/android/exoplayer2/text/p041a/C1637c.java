package com.google.android.exoplayer2.text.p041a;

import com.google.android.exoplayer2.text.C1636i;

public final class C1637c extends C1636i {
    private final C1633b f3594c;

    public C1637c(C1633b c1633b) {
        this.f3594c = c1633b;
    }

    public final void mo2303d() {
        this.f3594c.m3889a((C1636i) this);
    }
}
