package com.google.android.exoplayer2.text.p041a;

import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.text.C1632f;
import com.google.android.exoplayer2.text.C1635e;
import com.google.android.exoplayer2.text.C1636i;
import com.google.android.exoplayer2.text.C1669h;
import java.util.LinkedList;
import java.util.TreeSet;

abstract class C1633b implements C1632f {
    private final LinkedList f3574a = new LinkedList();
    private final LinkedList f3575b;
    private final TreeSet f3576c;
    private C1669h f3577d;
    private long f3578e;

    protected abstract void mo2293a(C1669h c1669h);

    protected abstract boolean mo2295e();

    protected abstract C1635e mo2296f();

    public /* synthetic */ Object mo2091a() {
        return mo2298h();
    }

    public /* synthetic */ void mo2092a(Object obj) {
        mo2294b((C1669h) obj);
    }

    public /* synthetic */ Object mo2093b() {
        return mo2297g();
    }

    public C1633b() {
        int i = 0;
        for (int i2 = 0; i2 < 10; i2++) {
            this.f3574a.add(new C1669h());
        }
        this.f3575b = new LinkedList();
        while (i < 2) {
            this.f3575b.add(new C1637c(this));
            i++;
        }
        this.f3576c = new TreeSet();
    }

    public void mo2292a(long j) {
        this.f3578e = j;
    }

    public C1669h mo2298h() {
        C1392a.m2711b(this.f3577d == null);
        if (this.f3574a.isEmpty()) {
            return null;
        }
        this.f3577d = (C1669h) this.f3574a.pollFirst();
        return this.f3577d;
    }

    public void mo2294b(C1669h c1669h) {
        boolean z;
        boolean z2 = true;
        if (c1669h != null) {
            z = true;
        } else {
            z = false;
        }
        C1392a.m2709a(z);
        if (c1669h != this.f3577d) {
            z2 = false;
        }
        C1392a.m2709a(z2);
        this.f3576c.add(c1669h);
        this.f3577d = null;
    }

    public C1636i mo2297g() {
        if (this.f3575b.isEmpty()) {
            return null;
        }
        while (!this.f3576c.isEmpty() && ((C1669h) this.f3576c.first()).c <= this.f3578e) {
            C1669h c1669h = (C1669h) this.f3576c.pollFirst();
            if (c1669h.m2424c()) {
                C1636i c1636i = (C1636i) this.f3575b.pollFirst();
                c1636i.m2422b(4);
                m3885c(c1669h);
                return c1636i;
            }
            mo2293a(c1669h);
            if (mo2295e()) {
                C1635e f = mo2296f();
                if (!c1669h.b_()) {
                    c1636i = (C1636i) this.f3575b.pollFirst();
                    c1636i.m3929a(c1669h.c, f, 0);
                    m3885c(c1669h);
                    return c1636i;
                }
            }
            m3885c(c1669h);
        }
        return null;
    }

    private void m3885c(C1669h c1669h) {
        c1669h.mo2090a();
        this.f3574a.add(c1669h);
    }

    protected void m3889a(C1636i c1636i) {
        c1636i.mo2090a();
        this.f3575b.add(c1636i);
    }

    public void mo2094c() {
        this.f3578e = 0;
        while (!this.f3576c.isEmpty()) {
            m3885c((C1669h) this.f3576c.pollFirst());
        }
        if (this.f3577d != null) {
            m3885c(this.f3577d);
            this.f3577d = null;
        }
    }

    public void mo2095d() {
    }
}
