package com.google.android.exoplayer2.text.p041a;

import android.support.v7.widget.helper.ItemTouchHelper.Callback;
import android.text.TextUtils;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.text.C1635e;
import com.google.android.exoplayer2.text.C1636i;
import com.google.android.exoplayer2.text.C1643b;
import com.google.android.exoplayer2.text.C1669h;

public final class C1634a extends C1633b {
    private static final int[] f3579a = new int[]{32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 225, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 233, 93, 237, 243, Callback.DEFAULT_SWIPE_ANIMATION_DURATION, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 231, 247, 209, 241, 9632};
    private static final int[] f3580b = new int[]{174, 176, 189, 191, 8482, 162, 163, 9834, 224, 32, 232, 226, 234, 238, 244, 251};
    private static final int[] f3581c = new int[]{193, 201, 211, 218, 220, 252, 8216, 161, 42, 39, 8212, 169, 8480, 8226, 8220, 8221, 192, 194, 199, Callback.DEFAULT_DRAG_ANIMATION_DURATION, 202, 203, 235, 206, 207, 239, 212, 217, 249, 219, 171, 187};
    private static final int[] f3582d = new int[]{195, 227, 205, 204, 236, 210, 242, 213, 245, 123, 125, 92, 94, 95, 124, 126, 196, 228, 214, 246, 223, 165, 164, 9474, 197, 229, 216, 248, 9484, 9488, 9492, 9496};
    private final C1403k f3583e = new C1403k();
    private final StringBuilder f3584f = new StringBuilder();
    private int f3585g;
    private int f3586h;
    private String f3587i;
    private String f3588j;
    private boolean f3589k;
    private byte f3590l;
    private byte f3591m;

    public /* bridge */ /* synthetic */ C1636i mo2297g() {
        return super.mo2297g();
    }

    public /* bridge */ /* synthetic */ C1669h mo2298h() {
        return super.mo2298h();
    }

    public C1634a() {
        m3900a(0);
        this.f3586h = 4;
    }

    public void mo2094c() {
        super.mo2094c();
        m3900a(0);
        this.f3586h = 4;
        this.f3584f.setLength(0);
        this.f3587i = null;
        this.f3588j = null;
        this.f3589k = false;
        this.f3590l = (byte) 0;
        this.f3591m = (byte) 0;
    }

    public void mo2095d() {
    }

    protected boolean mo2295e() {
        return !TextUtils.equals(this.f3587i, this.f3588j);
    }

    protected C1635e mo2296f() {
        this.f3588j = this.f3587i;
        return new C1638d(new C1643b(this.f3587i));
    }

    protected void mo2293a(C1669h c1669h) {
        this.f3583e.m2755a(c1669h.b.array(), c1669h.b.limit());
        boolean z = false;
        boolean z2 = false;
        while (this.f3583e.m2757b() > 0) {
            byte g = (byte) (this.f3583e.m2766g() & 127);
            byte g2 = (byte) (this.f3583e.m2766g() & 127);
            if (((byte) (this.f3583e.m2766g() & 7)) == (byte) 4 && !(g == (byte) 0 && g2 == (byte) 0)) {
                if ((g == (byte) 17 || g == (byte) 25) && (g2 & 112) == 48) {
                    this.f3584f.append(C1634a.m3905c(g2));
                    z2 = true;
                } else {
                    if ((g2 & 96) == 32) {
                        if (g == (byte) 18 || g == (byte) 26) {
                            m3910i();
                            this.f3584f.append(C1634a.m3907d(g2));
                            z2 = true;
                        } else if (g == (byte) 19 || g == (byte) 27) {
                            m3910i();
                            this.f3584f.append(C1634a.m3908e(g2));
                            z2 = true;
                        }
                    }
                    if (g < (byte) 32) {
                        z = m3901a(g, g2);
                        z2 = true;
                    } else {
                        this.f3584f.append(C1634a.m3903b(g));
                        if (g2 >= (byte) 32) {
                            this.f3584f.append(C1634a.m3903b(g2));
                        }
                        z2 = true;
                    }
                }
            }
        }
        if (z2) {
            if (!z) {
                this.f3589k = false;
            }
            if (this.f3585g == 1 || this.f3585g == 3) {
                this.f3587i = m3912k();
            }
        }
    }

    private boolean m3901a(byte b, byte b2) {
        boolean f = C1634a.m3909f(b);
        if (f) {
            if (this.f3589k && this.f3590l == b && this.f3591m == b2) {
                this.f3589k = false;
                return true;
            }
            this.f3589k = true;
            this.f3590l = b;
            this.f3591m = b2;
        }
        if (C1634a.m3904b(b, b2)) {
            m3899a(b2);
        } else if (C1634a.m3906c(b, b2)) {
            m3911j();
        }
        return f;
    }

    private void m3899a(byte b) {
        switch (b) {
            case (byte) 32:
                m3900a(2);
                return;
            case (byte) 37:
                this.f3586h = 2;
                m3900a(1);
                return;
            case (byte) 38:
                this.f3586h = 3;
                m3900a(1);
                return;
            case (byte) 39:
                this.f3586h = 4;
                m3900a(1);
                return;
            case (byte) 41:
                m3900a(3);
                return;
            default:
                if (this.f3585g != 0) {
                    switch (b) {
                        case (byte) 33:
                            if (this.f3584f.length() > 0) {
                                this.f3584f.setLength(this.f3584f.length() - 1);
                                return;
                            }
                            return;
                        case (byte) 44:
                            this.f3587i = null;
                            if (this.f3585g == 1 || this.f3585g == 3) {
                                this.f3584f.setLength(0);
                                return;
                            }
                            return;
                        case (byte) 45:
                            m3911j();
                            return;
                        case (byte) 46:
                            this.f3584f.setLength(0);
                            return;
                        case (byte) 47:
                            this.f3587i = m3912k();
                            this.f3584f.setLength(0);
                            return;
                        default:
                            return;
                    }
                }
                return;
        }
    }

    private void m3910i() {
        if (this.f3584f.length() > 0) {
            this.f3584f.setLength(this.f3584f.length() - 1);
        }
    }

    private void m3911j() {
        int length = this.f3584f.length();
        if (length > 0 && this.f3584f.charAt(length - 1) != '\n') {
            this.f3584f.append('\n');
        }
    }

    private String m3912k() {
        int length = this.f3584f.length();
        if (length == 0) {
            return null;
        }
        int i;
        if (this.f3584f.charAt(length - 1) == '\n') {
            i = 1;
        } else {
            i = 0;
        }
        if (length == 1 && i != 0) {
            return null;
        }
        if (i != 0) {
            length--;
        }
        if (this.f3585g != 1) {
            return this.f3584f.substring(0, length);
        }
        int i2;
        i = length;
        for (i2 = 0; i2 < this.f3586h && i != -1; i2++) {
            i = this.f3584f.lastIndexOf("\n", i - 1);
        }
        if (i != -1) {
            i2 = i + 1;
        } else {
            i2 = 0;
        }
        this.f3584f.delete(0, i2);
        return this.f3584f.substring(0, length - i2);
    }

    private void m3900a(int i) {
        if (this.f3585g != i) {
            this.f3585g = i;
            this.f3584f.setLength(0);
            if (i == 1 || i == 0) {
                this.f3587i = null;
            }
        }
    }

    private static char m3903b(byte b) {
        return (char) f3579a[(b & 127) - 32];
    }

    private static char m3905c(byte b) {
        return (char) f3580b[b & 15];
    }

    private static char m3907d(byte b) {
        return (char) f3581c[b & 31];
    }

    private static char m3908e(byte b) {
        return (char) f3582d[b & 31];
    }

    private static boolean m3904b(byte b, byte b2) {
        return (b == (byte) 20 || b == (byte) 28) && b2 >= (byte) 32 && b2 <= (byte) 47;
    }

    private static boolean m3906c(byte b, byte b2) {
        return b >= (byte) 16 && b <= (byte) 31 && b2 >= (byte) 64 && b2 <= Byte.MAX_VALUE;
    }

    private static boolean m3909f(byte b) {
        return b >= (byte) 16 && b <= (byte) 31;
    }

    public static boolean m3902a(int i, int i2, C1403k c1403k) {
        if (i != 4 || i2 < 8) {
            return false;
        }
        int d = c1403k.m2761d();
        int g = c1403k.m2766g();
        int h = c1403k.m2767h();
        int n = c1403k.m2773n();
        int g2 = c1403k.m2766g();
        c1403k.m2760c(d);
        if (g == 181 && h == 49 && n == 1195456820 && g2 == 3) {
            return true;
        }
        return false;
    }
}
