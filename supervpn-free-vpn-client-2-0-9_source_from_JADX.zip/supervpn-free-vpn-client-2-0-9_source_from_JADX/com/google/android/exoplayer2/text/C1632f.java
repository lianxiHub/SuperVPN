package com.google.android.exoplayer2.text;

import com.google.android.exoplayer2.p030a.C1345c;

public interface C1632f extends C1345c {
    void mo2292a(long j);
}
