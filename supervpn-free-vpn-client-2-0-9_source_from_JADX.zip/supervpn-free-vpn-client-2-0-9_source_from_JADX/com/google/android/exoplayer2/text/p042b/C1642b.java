package com.google.android.exoplayer2.text.p042b;

import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1414r;
import com.google.android.exoplayer2.text.C1635e;
import com.google.android.exoplayer2.text.C1643b;
import java.util.Collections;
import java.util.List;

final class C1642b implements C1635e {
    private final C1643b[] f3607a;
    private final long[] f3608b;

    public C1642b(C1643b[] c1643bArr, long[] jArr) {
        this.f3607a = c1643bArr;
        this.f3608b = jArr;
    }

    public int mo2299a(long j) {
        int b = C1414r.m2826b(this.f3608b, j, false, false);
        return b < this.f3608b.length ? b : -1;
    }

    public int mo2301b() {
        return this.f3608b.length;
    }

    public long mo2300a(int i) {
        boolean z;
        boolean z2 = true;
        if (i >= 0) {
            z = true;
        } else {
            z = false;
        }
        C1392a.m2709a(z);
        if (i >= this.f3608b.length) {
            z2 = false;
        }
        C1392a.m2709a(z2);
        return this.f3608b[i];
    }

    public List mo2302b(long j) {
        int a = C1414r.m2815a(this.f3608b, j, true, false);
        if (a == -1 || this.f3607a[a] == null) {
            return Collections.emptyList();
        }
        return Collections.singletonList(this.f3607a[a]);
    }
}
