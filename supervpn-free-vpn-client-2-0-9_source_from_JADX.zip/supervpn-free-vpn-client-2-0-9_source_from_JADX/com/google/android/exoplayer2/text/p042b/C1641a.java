package com.google.android.exoplayer2.text.p042b;

import android.text.Html;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.exoplayer2.p031c.C1397f;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.text.C1635e;
import com.google.android.exoplayer2.text.C1640c;
import com.google.android.exoplayer2.text.C1643b;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class C1641a extends C1640c {
    private static final Pattern f3604a = Pattern.compile("(\\S*)\\s*-->\\s*(\\S*)");
    private static final Pattern f3605b = Pattern.compile("(?:(\\d+):)?(\\d+):(\\d+),(\\d+)");
    private final StringBuilder f3606c = new StringBuilder();

    protected /* synthetic */ C1635e mo2310a(byte[] bArr, int i) {
        return m3953b(bArr, i);
    }

    public C1641a() {
        super("SubripDecoder");
    }

    protected C1642b m3953b(byte[] bArr, int i) {
        ArrayList arrayList = new ArrayList();
        C1397f c1397f = new C1397f();
        C1403k c1403k = new C1403k(bArr, i);
        while (true) {
            String x = c1403k.m2783x();
            if (x == null) {
                C1643b[] c1643bArr = new C1643b[arrayList.size()];
                arrayList.toArray(c1643bArr);
                return new C1642b(c1643bArr, c1397f.m2729b());
            } else if (x.length() != 0) {
                try {
                    Integer.parseInt(x);
                    Object x2 = c1403k.m2783x();
                    Matcher matcher = f3604a.matcher(x2);
                    if (matcher.find()) {
                        int i2;
                        c1397f.m2728a(C1641a.m3951a(matcher.group(1)));
                        if (TextUtils.isEmpty(matcher.group(2))) {
                            i2 = 0;
                        } else {
                            c1397f.m2728a(C1641a.m3951a(matcher.group(2)));
                            i2 = 1;
                        }
                        this.f3606c.setLength(0);
                        while (true) {
                            Object x3 = c1403k.m2783x();
                            if (TextUtils.isEmpty(x3)) {
                                break;
                            }
                            if (this.f3606c.length() > 0) {
                                this.f3606c.append("<br>");
                            }
                            this.f3606c.append(x3.trim());
                        }
                        arrayList.add(new C1643b(Html.fromHtml(this.f3606c.toString())));
                        if (i2 != 0) {
                            arrayList.add(null);
                        }
                    } else {
                        Log.w("SubripDecoder", "Skipping invalid timing: " + x2);
                    }
                } catch (NumberFormatException e) {
                    Log.w("SubripDecoder", "Skipping invalid index: " + x);
                }
            }
        }
    }

    private static long m3951a(String str) {
        Matcher matcher = f3605b.matcher(str);
        if (matcher.matches()) {
            return (Long.parseLong(matcher.group(4)) + (((((Long.parseLong(matcher.group(1)) * 60) * 60) * 1000) + ((Long.parseLong(matcher.group(2)) * 60) * 1000)) + (Long.parseLong(matcher.group(3)) * 1000))) * 1000;
        }
        throw new NumberFormatException("has invalid format");
    }
}
