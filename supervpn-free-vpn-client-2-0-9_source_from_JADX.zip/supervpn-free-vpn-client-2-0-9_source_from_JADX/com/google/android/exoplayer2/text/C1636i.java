package com.google.android.exoplayer2.text;

import com.google.android.exoplayer2.p030a.C1348f;
import java.util.List;

public abstract class C1636i extends C1348f implements C1635e {
    private C1635e f3592c;
    private long f3593d;

    public abstract void mo2303d();

    public void m3929a(long j, C1635e c1635e, long j2) {
        this.a = j;
        this.f3592c = c1635e;
        if (j2 == Long.MAX_VALUE) {
            j2 = this.a;
        }
        this.f3593d = j2;
    }

    public int mo2301b() {
        return this.f3592c.mo2301b();
    }

    public long mo2300a(int i) {
        return this.f3592c.mo2300a(i) + this.f3593d;
    }

    public int mo2299a(long j) {
        return this.f3592c.mo2299a(j - this.f3593d);
    }

    public List mo2302b(long j) {
        return this.f3592c.mo2302b(j - this.f3593d);
    }

    public void mo2090a() {
        super.mo2090a();
        this.f3592c = null;
    }
}
