package com.google.android.exoplayer2.text.p045e;

import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.text.C1635e;
import java.util.Collections;
import java.util.List;

final class C1656c implements C1635e {
    private final List f3671a;

    public C1656c(List list) {
        this.f3671a = Collections.unmodifiableList(list);
    }

    public int mo2299a(long j) {
        return j < 0 ? 0 : -1;
    }

    public int mo2301b() {
        return 1;
    }

    public long mo2300a(int i) {
        C1392a.m2709a(i == 0);
        return 0;
    }

    public List mo2302b(long j) {
        return j >= 0 ? this.f3671a : Collections.emptyList();
    }
}
