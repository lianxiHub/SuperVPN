package com.google.android.exoplayer2.text.p045e;

import android.text.Layout.Alignment;
import android.text.SpannableStringBuilder;
import android.util.Log;
import com.google.android.exoplayer2.text.C1643b;

final class C1660e extends C1643b {
    public final long f3699i;
    public final long f3700j;

    static /* synthetic */ class C16581 {
        static final /* synthetic */ int[] f3688a = new int[Alignment.values().length];

        static {
            try {
                f3688a[Alignment.ALIGN_NORMAL.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                f3688a[Alignment.ALIGN_CENTER.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                f3688a[Alignment.ALIGN_OPPOSITE.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
        }
    }

    public static final class C1659a {
        private long f3689a;
        private long f3690b;
        private SpannableStringBuilder f3691c;
        private Alignment f3692d;
        private float f3693e;
        private int f3694f;
        private int f3695g;
        private float f3696h;
        private int f3697i;
        private float f3698j;

        public C1659a() {
            m4073a();
        }

        public void m4073a() {
            this.f3689a = 0;
            this.f3690b = 0;
            this.f3691c = null;
            this.f3692d = null;
            this.f3693e = Float.MIN_VALUE;
            this.f3694f = Integer.MIN_VALUE;
            this.f3695g = Integer.MIN_VALUE;
            this.f3696h = Float.MIN_VALUE;
            this.f3697i = Integer.MIN_VALUE;
            this.f3698j = Float.MIN_VALUE;
        }

        public C1660e m4077b() {
            if (this.f3696h != Float.MIN_VALUE && this.f3697i == Integer.MIN_VALUE) {
                m4067c();
            }
            return new C1660e(this.f3689a, this.f3690b, this.f3691c, this.f3692d, this.f3693e, this.f3694f, this.f3695g, this.f3696h, this.f3697i, this.f3698j);
        }

        public C1659a m4070a(long j) {
            this.f3689a = j;
            return this;
        }

        public C1659a m4076b(long j) {
            this.f3690b = j;
            return this;
        }

        public C1659a m4072a(SpannableStringBuilder spannableStringBuilder) {
            this.f3691c = spannableStringBuilder;
            return this;
        }

        public C1659a m4071a(Alignment alignment) {
            this.f3692d = alignment;
            return this;
        }

        public C1659a m4068a(float f) {
            this.f3693e = f;
            return this;
        }

        public C1659a m4069a(int i) {
            this.f3694f = i;
            return this;
        }

        public C1659a m4075b(int i) {
            this.f3695g = i;
            return this;
        }

        public C1659a m4074b(float f) {
            this.f3696h = f;
            return this;
        }

        public C1659a m4079c(int i) {
            this.f3697i = i;
            return this;
        }

        public C1659a m4078c(float f) {
            this.f3698j = f;
            return this;
        }

        private C1659a m4067c() {
            if (this.f3692d != null) {
                switch (C16581.f3688a[this.f3692d.ordinal()]) {
                    case 1:
                        this.f3697i = 0;
                        break;
                    case 2:
                        this.f3697i = 1;
                        break;
                    case 3:
                        this.f3697i = 2;
                        break;
                    default:
                        Log.w("WebvttCueBuilder", "Unrecognized alignment: " + this.f3692d);
                        this.f3697i = 0;
                        break;
                }
            }
            this.f3697i = Integer.MIN_VALUE;
            return this;
        }
    }

    public C1660e(CharSequence charSequence) {
        this(0, 0, charSequence);
    }

    public C1660e(long j, long j2, CharSequence charSequence) {
        this(j, j2, charSequence, null, Float.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE, Float.MIN_VALUE, Integer.MIN_VALUE, Float.MIN_VALUE);
    }

    public C1660e(long j, long j2, CharSequence charSequence, Alignment alignment, float f, int i, int i2, float f2, int i3, float f3) {
        super(charSequence, alignment, f, i, i2, f2, i3, f3);
        this.f3699i = j;
        this.f3700j = j2;
    }

    public boolean m4080a() {
        return this.c == Float.MIN_VALUE && this.f == Float.MIN_VALUE;
    }
}
