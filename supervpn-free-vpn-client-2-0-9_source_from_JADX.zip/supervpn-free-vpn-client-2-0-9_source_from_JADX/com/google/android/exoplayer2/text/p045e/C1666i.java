package com.google.android.exoplayer2.text.p045e;

import android.text.SpannableStringBuilder;
import com.google.android.exoplayer2.p031c.C1392a;
import com.google.android.exoplayer2.p031c.C1414r;
import com.google.android.exoplayer2.text.C1635e;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

final class C1666i implements C1635e {
    private final List f3718a;
    private final int f3719b;
    private final long[] f3720c = new long[(this.f3719b * 2)];
    private final long[] f3721d;

    public C1666i(List list) {
        this.f3718a = list;
        this.f3719b = list.size();
        for (int i = 0; i < this.f3719b; i++) {
            C1660e c1660e = (C1660e) list.get(i);
            int i2 = i * 2;
            this.f3720c[i2] = c1660e.f3699i;
            this.f3720c[i2 + 1] = c1660e.f3700j;
        }
        this.f3721d = Arrays.copyOf(this.f3720c, this.f3720c.length);
        Arrays.sort(this.f3721d);
    }

    public int mo2299a(long j) {
        int b = C1414r.m2826b(this.f3721d, j, false, false);
        return b < this.f3721d.length ? b : -1;
    }

    public int mo2301b() {
        return this.f3721d.length;
    }

    public long mo2300a(int i) {
        boolean z;
        boolean z2 = true;
        if (i >= 0) {
            z = true;
        } else {
            z = false;
        }
        C1392a.m2709a(z);
        if (i >= this.f3721d.length) {
            z2 = false;
        }
        C1392a.m2709a(z2);
        return this.f3721d[i];
    }

    public List mo2302b(long j) {
        CharSequence charSequence = null;
        int i = 0;
        C1660e c1660e = null;
        ArrayList arrayList = null;
        while (i < this.f3719b) {
            CharSequence charSequence2;
            C1660e c1660e2;
            ArrayList arrayList2;
            CharSequence charSequence3;
            if (this.f3720c[i * 2] > j || j >= this.f3720c[(i * 2) + 1]) {
                charSequence2 = charSequence;
                c1660e2 = c1660e;
                arrayList2 = arrayList;
                charSequence3 = charSequence2;
            } else {
                ArrayList arrayList3;
                if (arrayList == null) {
                    arrayList3 = new ArrayList();
                } else {
                    arrayList3 = arrayList;
                }
                C1660e c1660e3 = (C1660e) this.f3718a.get(i);
                if (!c1660e3.m4080a()) {
                    arrayList3.add(c1660e3);
                    charSequence3 = charSequence;
                    c1660e2 = c1660e;
                    arrayList2 = arrayList3;
                } else if (c1660e == null) {
                    arrayList2 = arrayList3;
                    C1660e c1660e4 = c1660e3;
                    charSequence3 = charSequence;
                    c1660e2 = c1660e4;
                } else if (charSequence == null) {
                    SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
                    spannableStringBuilder.append(c1660e.a).append("\n").append(c1660e3.a);
                    Object obj = spannableStringBuilder;
                    c1660e2 = c1660e;
                    arrayList2 = arrayList3;
                } else {
                    charSequence.append("\n").append(c1660e3.a);
                    charSequence3 = charSequence;
                    c1660e2 = c1660e;
                    arrayList2 = arrayList3;
                }
            }
            i++;
            charSequence2 = charSequence3;
            arrayList = arrayList2;
            c1660e = c1660e2;
            charSequence = charSequence2;
        }
        if (charSequence != null) {
            arrayList.add(new C1660e(charSequence));
        } else if (c1660e != null) {
            arrayList.add(c1660e);
        }
        return arrayList != null ? arrayList : Collections.emptyList();
    }
}
