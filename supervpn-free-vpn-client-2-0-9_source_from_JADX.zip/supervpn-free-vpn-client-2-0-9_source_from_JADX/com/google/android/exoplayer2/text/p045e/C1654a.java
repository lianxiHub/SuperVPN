package com.google.android.exoplayer2.text.p045e;

import android.text.TextUtils;
import com.google.android.exoplayer2.p031c.C1394c;
import com.google.android.exoplayer2.p031c.C1403k;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class C1654a {
    private static final Pattern f3663a = Pattern.compile("\\[voice=\"([^\"]*)\"\\]");
    private final C1403k f3664b = new C1403k();
    private final StringBuilder f3665c = new StringBuilder();

    public C1657d m4035a(C1403k c1403k) {
        this.f3665c.setLength(0);
        int d = c1403k.m2761d();
        C1654a.m4030c(c1403k);
        this.f3664b.m2755a(c1403k.f2479a, c1403k.m2761d());
        this.f3664b.m2760c(d);
        String b = C1654a.m4027b(this.f3664b, this.f3665c);
        if (b == null || !"{".equals(C1654a.m4024a(this.f3664b, this.f3665c))) {
            return null;
        }
        C1657d c1657d = new C1657d();
        m4026a(c1657d, b);
        int i = 0;
        Object obj = null;
        while (i == 0) {
            int d2 = this.f3664b.m2761d();
            obj = C1654a.m4024a(this.f3664b, this.f3665c);
            if (obj == null || "}".equals(obj)) {
                i = 1;
            } else {
                i = 0;
            }
            if (i == 0) {
                this.f3664b.m2760c(d2);
                C1654a.m4025a(this.f3664b, c1657d, this.f3665c);
            }
        }
        return !"}".equals(obj) ? null : c1657d;
    }

    private static String m4027b(C1403k c1403k, StringBuilder stringBuilder) {
        C1654a.m4028b(c1403k);
        if (c1403k.m2757b() < 5) {
            return null;
        }
        if (!"::cue".equals(c1403k.m2764e(5))) {
            return null;
        }
        int d = c1403k.m2761d();
        String a = C1654a.m4024a(c1403k, stringBuilder);
        if (a == null) {
            return null;
        }
        if ("{".equals(a)) {
            c1403k.m2760c(d);
            return "";
        }
        String d2;
        if ("(".equals(a)) {
            d2 = C1654a.m4031d(c1403k);
        } else {
            d2 = null;
        }
        a = C1654a.m4024a(c1403k, stringBuilder);
        if (!")".equals(a) || a == null) {
            return null;
        }
        return d2;
    }

    private static String m4031d(C1403k c1403k) {
        int d = c1403k.m2761d();
        int c = c1403k.m2759c();
        int i = d;
        Object obj = null;
        while (i < c && r0 == null) {
            int i2 = i + 1;
            if (((char) c1403k.f2479a[i]) == ')') {
                obj = 1;
            } else {
                obj = null;
            }
            i = i2;
        }
        return c1403k.m2764e((i - 1) - c1403k.m2761d()).trim();
    }

    private static void m4025a(C1403k c1403k, C1657d c1657d, StringBuilder stringBuilder) {
        C1654a.m4028b(c1403k);
        String d = C1654a.m4032d(c1403k, stringBuilder);
        if (!"".equals(d) && ":".equals(C1654a.m4024a(c1403k, stringBuilder))) {
            C1654a.m4028b(c1403k);
            String c = C1654a.m4029c(c1403k, stringBuilder);
            if (c != null && !"".equals(c)) {
                int d2 = c1403k.m2761d();
                String a = C1654a.m4024a(c1403k, stringBuilder);
                if (!";".equals(a)) {
                    if ("}".equals(a)) {
                        c1403k.m2760c(d2);
                    } else {
                        return;
                    }
                }
                if ("color".equals(d)) {
                    c1657d.m4045a(C1394c.m2720b(c));
                } else if ("background-color".equals(d)) {
                    c1657d.m4051b(C1394c.m2720b(c));
                } else if ("text-decoration".equals(d)) {
                    if ("underline".equals(c)) {
                        c1657d.m4046a(true);
                    }
                } else if ("font-family".equals(d)) {
                    c1657d.m4057d(c);
                } else if ("font-weight".equals(d)) {
                    if ("bold".equals(c)) {
                        c1657d.m4052b(true);
                    }
                } else if ("font-style".equals(d) && "italic".equals(c)) {
                    c1657d.m4054c(true);
                }
            }
        }
    }

    static void m4028b(C1403k c1403k) {
        Object obj = 1;
        while (c1403k.m2757b() > 0 && r0 != null) {
            obj = (C1654a.m4033e(c1403k) || C1654a.m4034f(c1403k)) ? 1 : null;
        }
    }

    static String m4024a(C1403k c1403k, StringBuilder stringBuilder) {
        C1654a.m4028b(c1403k);
        if (c1403k.m2757b() == 0) {
            return null;
        }
        String d = C1654a.m4032d(c1403k, stringBuilder);
        return "".equals(d) ? "" + ((char) c1403k.m2766g()) : d;
    }

    private static boolean m4033e(C1403k c1403k) {
        switch (C1654a.m4023a(c1403k, c1403k.m2761d())) {
            case '\t':
            case '\n':
            case '\f':
            case '\r':
            case ' ':
                c1403k.m2762d(1);
                return true;
            default:
                return false;
        }
    }

    static void m4030c(C1403k c1403k) {
        do {
        } while (!TextUtils.isEmpty(c1403k.m2783x()));
    }

    private static char m4023a(C1403k c1403k, int i) {
        return (char) c1403k.f2479a[i];
    }

    private static String m4029c(C1403k c1403k, StringBuilder stringBuilder) {
        StringBuilder stringBuilder2 = new StringBuilder();
        Object obj = null;
        while (obj == null) {
            int d = c1403k.m2761d();
            String a = C1654a.m4024a(c1403k, stringBuilder);
            if (a == null) {
                return null;
            }
            if ("}".equals(a) || ";".equals(a)) {
                c1403k.m2760c(d);
                obj = 1;
            } else {
                stringBuilder2.append(a);
            }
        }
        return stringBuilder2.toString();
    }

    private static boolean m4034f(C1403k c1403k) {
        int d = c1403k.m2761d();
        int c = c1403k.m2759c();
        byte[] bArr = c1403k.f2479a;
        if (d + 2 <= c) {
            int i = d + 1;
            if (bArr[d] == (byte) 47) {
                d = i + 1;
                if (bArr[i] == (byte) 42) {
                    i = d;
                    while (i + 1 < c) {
                        d = i + 1;
                        if (((char) bArr[i]) == '*' && ((char) bArr[d]) == '/') {
                            c = d + 1;
                            d = c;
                        }
                        i = d;
                    }
                    c1403k.m2762d(c - c1403k.m2761d());
                    return true;
                }
            }
        }
        return false;
    }

    private static String m4032d(C1403k c1403k, StringBuilder stringBuilder) {
        int i = 0;
        stringBuilder.setLength(0);
        int d = c1403k.m2761d();
        int c = c1403k.m2759c();
        while (d < c && r0 == 0) {
            char c2 = (char) c1403k.f2479a[d];
            if ((c2 < 'A' || c2 > 'Z') && ((c2 < 'a' || c2 > 'z') && !((c2 >= '0' && c2 <= '9') || c2 == '#' || c2 == '-' || c2 == '.' || c2 == '_'))) {
                i = 1;
            } else {
                d++;
                stringBuilder.append(c2);
            }
        }
        c1403k.m2762d(d - c1403k.m2761d());
        return stringBuilder.toString();
    }

    private void m4026a(C1657d c1657d, String str) {
        if (!"".equals(str)) {
            int indexOf = str.indexOf(91);
            if (indexOf != -1) {
                Matcher matcher = f3663a.matcher(str.substring(indexOf));
                if (matcher.matches()) {
                    c1657d.m4055c(matcher.group(1));
                }
                str = str.substring(0, indexOf);
            }
            String[] split = str.split("\\.");
            String str2 = split[0];
            int indexOf2 = str2.indexOf(35);
            if (indexOf2 != -1) {
                c1657d.m4053b(str2.substring(0, indexOf2));
                c1657d.m4048a(str2.substring(indexOf2 + 1));
            } else {
                c1657d.m4053b(str2);
            }
            if (split.length > 1) {
                c1657d.m4049a((String[]) Arrays.copyOfRange(split, 1, split.length));
            }
        }
    }
}
