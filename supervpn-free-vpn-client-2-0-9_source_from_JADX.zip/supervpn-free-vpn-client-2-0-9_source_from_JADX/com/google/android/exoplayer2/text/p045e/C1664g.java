package com.google.android.exoplayer2.text.p045e;

import android.text.TextUtils;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.text.C1635e;
import com.google.android.exoplayer2.text.C1640c;
import com.google.android.exoplayer2.text.SubtitleDecoderException;
import com.google.android.exoplayer2.text.p045e.C1660e.C1659a;
import java.util.ArrayList;
import java.util.List;

public final class C1664g extends C1640c {
    private final C1663f f3711a = new C1663f();
    private final C1403k f3712b = new C1403k();
    private final C1659a f3713c = new C1659a();
    private final C1654a f3714d = new C1654a();
    private final List f3715e = new ArrayList();

    protected /* synthetic */ C1635e mo2310a(byte[] bArr, int i) {
        return m4102b(bArr, i);
    }

    public C1664g() {
        super("WebvttDecoder");
    }

    protected C1666i m4102b(byte[] bArr, int i) {
        this.f3712b.m2755a(bArr, i);
        this.f3713c.m4073a();
        this.f3715e.clear();
        C1665h.m4104a(this.f3712b);
        do {
        } while (!TextUtils.isEmpty(this.f3712b.m2783x()));
        List arrayList = new ArrayList();
        while (true) {
            int a = C1664g.m4099a(this.f3712b);
            if (a == 0) {
                return new C1666i(arrayList);
            }
            if (a == 1) {
                C1664g.m4100b(this.f3712b);
            } else if (a == 2) {
                if (arrayList.isEmpty()) {
                    this.f3712b.m2783x();
                    C1657d a2 = this.f3714d.m4035a(this.f3712b);
                    if (a2 != null) {
                        this.f3715e.add(a2);
                    }
                } else {
                    throw new SubtitleDecoderException("A style block was found after the first cue.");
                }
            } else if (a == 3 && this.f3711a.m4098a(this.f3712b, this.f3713c, this.f3715e)) {
                arrayList.add(this.f3713c.m4077b());
                this.f3713c.m4073a();
            }
        }
    }

    private static int m4099a(C1403k c1403k) {
        int i = 0;
        int i2 = -1;
        while (i2 == -1) {
            i2 = c1403k.m2761d();
            String x = c1403k.m2783x();
            if (x == null) {
                i = 0;
            } else if ("STYLE".equals(x)) {
                i = 2;
            } else if ("NOTE".startsWith(x)) {
                i = 1;
            } else {
                i = 3;
            }
            int i3 = i2;
            i2 = i;
            i = i3;
        }
        c1403k.m2760c(i);
        return i2;
    }

    private static void m4100b(C1403k c1403k) {
        do {
        } while (!TextUtils.isEmpty(c1403k.m2783x()));
    }
}
