package com.google.android.exoplayer2.text.p045e;

import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.p031c.C1414r;
import com.google.android.exoplayer2.text.C1635e;
import com.google.android.exoplayer2.text.C1640c;
import com.google.android.exoplayer2.text.C1643b;
import com.google.android.exoplayer2.text.SubtitleDecoderException;
import com.google.android.exoplayer2.text.p045e.C1660e.C1659a;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class C1655b extends C1640c {
    private static final int f3666a = C1414r.m2830e("payl");
    private static final int f3667b = C1414r.m2830e("sttg");
    private static final int f3668c = C1414r.m2830e("vttc");
    private final C1403k f3669d = new C1403k();
    private final C1659a f3670e = new C1659a();

    protected /* synthetic */ C1635e mo2310a(byte[] bArr, int i) {
        return m4038b(bArr, i);
    }

    public C1655b() {
        super("Mp4WebvttDecoder");
    }

    protected C1656c m4038b(byte[] bArr, int i) {
        this.f3669d.m2755a(bArr, i);
        List arrayList = new ArrayList();
        while (this.f3669d.m2757b() > 0) {
            if (this.f3669d.m2757b() < 8) {
                throw new SubtitleDecoderException("Incomplete Mp4Webvtt Top Level box header found.");
            }
            int n = this.f3669d.m2773n();
            if (this.f3669d.m2773n() == f3668c) {
                arrayList.add(C1655b.m4036a(this.f3669d, this.f3670e, n - 8));
            } else {
                this.f3669d.m2762d(n - 8);
            }
        }
        return new C1656c(arrayList);
    }

    private static C1643b m4036a(C1403k c1403k, C1659a c1659a, int i) {
        c1659a.m4073a();
        while (i > 0) {
            if (i < 8) {
                throw new SubtitleDecoderException("Incomplete vtt cue box header found.");
            }
            int n = c1403k.m2773n();
            int n2 = c1403k.m2773n();
            int i2 = i - 8;
            n -= 8;
            String str = new String(c1403k.f2479a, c1403k.m2761d(), n);
            c1403k.m2762d(n);
            i = i2 - n;
            if (n2 == f3667b) {
                C1663f.m4088a(str, c1659a);
            } else if (n2 == f3666a) {
                C1663f.m4090a(null, str.trim(), c1659a, Collections.emptyList());
            }
        }
        return c1659a.m4077b();
    }
}
