package com.google.android.exoplayer2.text.p045e;

import android.text.Layout.Alignment;
import android.text.SpannableStringBuilder;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.AlignmentSpan.Standard;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;
import android.text.style.UnderlineSpan;
import android.util.Log;
import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.text.p045e.C1660e.C1659a;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class C1663f {
    public static final Pattern f3708a = Pattern.compile("^(\\S+)\\s+-->\\s+(\\S+)(.*)?$");
    private static final Pattern f3709b = Pattern.compile("(\\S+?):(\\S+)");
    private final StringBuilder f3710c = new StringBuilder();

    private static final class C1661a {
        private static final String[] f3701e = new String[0];
        public final String f3702a;
        public final int f3703b;
        public final String f3704c;
        public final String[] f3705d;

        private C1661a(String str, int i, String str2, String[] strArr) {
            this.f3703b = i;
            this.f3702a = str;
            this.f3704c = str2;
            this.f3705d = strArr;
        }

        public static C1661a m4082a(String str, int i) {
            String trim = str.trim();
            if (trim.isEmpty()) {
                return null;
            }
            String str2;
            int indexOf = trim.indexOf(" ");
            if (indexOf == -1) {
                str2 = trim;
                trim = "";
            } else {
                String trim2 = trim.substring(indexOf).trim();
                str2 = trim.substring(0, indexOf);
                trim = trim2;
            }
            String[] split = str2.split("\\.");
            String str3 = split[0];
            if (split.length > 1) {
                split = (String[]) Arrays.copyOfRange(split, 1, split.length);
            } else {
                split = f3701e;
            }
            return new C1661a(str3, i, trim, split);
        }

        public static C1661a m4081a() {
            return new C1661a("", 0, "", new String[0]);
        }
    }

    private static final class C1662b implements Comparable {
        public final int f3706a;
        public final C1657d f3707b;

        public /* synthetic */ int compareTo(Object obj) {
            return m4083a((C1662b) obj);
        }

        public C1662b(int i, C1657d c1657d) {
            this.f3706a = i;
            this.f3707b = c1657d;
        }

        public int m4083a(C1662b c1662b) {
            return this.f3706a - c1662b.f3706a;
        }
    }

    boolean m4098a(C1403k c1403k, C1659a c1659a, List list) {
        Object x = c1403k.m2783x();
        Matcher matcher = f3708a.matcher(x);
        if (matcher.matches()) {
            return C1663f.m4092a(null, matcher, c1403k, c1659a, this.f3710c, list);
        }
        matcher = f3708a.matcher(c1403k.m2783x());
        if (!matcher.matches()) {
            return false;
        }
        return C1663f.m4092a(x.trim(), matcher, c1403k, c1659a, this.f3710c, list);
    }

    static void m4088a(String str, C1659a c1659a) {
        Matcher matcher = f3709b.matcher(str);
        while (matcher.find()) {
            String group = matcher.group(1);
            String group2 = matcher.group(2);
            try {
                if ("line".equals(group)) {
                    C1663f.m4094b(group2, c1659a);
                } else if ("align".equals(group)) {
                    c1659a.m4071a(C1663f.m4093b(group2));
                } else if ("position".equals(group)) {
                    C1663f.m4095c(group2, c1659a);
                } else if ("size".equals(group)) {
                    c1659a.m4078c(C1665h.m4105b(group2));
                } else {
                    Log.w("WebvttCueParser", "Unknown cue setting " + group + ":" + group2);
                }
            } catch (NumberFormatException e) {
                Log.w("WebvttCueParser", "Skipping bad cue setting: " + matcher.group());
            }
        }
    }

    static void m4090a(String str, String str2, C1659a c1659a, List list) {
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        Stack stack = new Stack();
        List arrayList = new ArrayList();
        int i = 0;
        while (i < str2.length()) {
            char charAt = str2.charAt(i);
            int indexOf;
            switch (charAt) {
                case '&':
                    indexOf = str2.indexOf(59, i + 1);
                    int indexOf2 = str2.indexOf(32, i + 1);
                    if (indexOf == -1) {
                        indexOf = indexOf2;
                    } else if (indexOf2 != -1) {
                        indexOf = Math.min(indexOf, indexOf2);
                    }
                    if (indexOf == -1) {
                        spannableStringBuilder.append(charAt);
                        i++;
                        break;
                    }
                    C1663f.m4087a(str2.substring(i + 1, indexOf), spannableStringBuilder);
                    if (indexOf == indexOf2) {
                        spannableStringBuilder.append(" ");
                    }
                    i = indexOf + 1;
                    break;
                case '<':
                    if (i + 1 < str2.length()) {
                        Object obj = str2.charAt(i + 1) == '/' ? 1 : null;
                        indexOf = C1663f.m4085a(str2, i + 1);
                        Object obj2 = str2.charAt(indexOf + -2) == '/' ? 1 : null;
                        String substring = str2.substring((obj != null ? 2 : 1) + i, obj2 != null ? indexOf - 2 : indexOf - 1);
                        String d = C1663f.m4097d(substring);
                        if (d != null) {
                            if (C1663f.m4096c(d)) {
                                if (obj == null) {
                                    if (obj2 == null) {
                                        stack.push(C1661a.m4082a(substring, spannableStringBuilder.length()));
                                        i = indexOf;
                                        break;
                                    }
                                }
                                while (!stack.isEmpty()) {
                                    C1661a c1661a = (C1661a) stack.pop();
                                    C1663f.m4089a(str, c1661a, spannableStringBuilder, list, arrayList);
                                    if (c1661a.f3702a.equals(d)) {
                                        i = indexOf;
                                        break;
                                    }
                                }
                                i = indexOf;
                            } else {
                                i = indexOf;
                                break;
                            }
                        }
                        i = indexOf;
                        break;
                    }
                    i++;
                    break;
                default:
                    spannableStringBuilder.append(charAt);
                    i++;
                    break;
            }
        }
        while (!stack.isEmpty()) {
            C1663f.m4089a(str, (C1661a) stack.pop(), spannableStringBuilder, list, arrayList);
        }
        C1663f.m4089a(str, C1661a.m4081a(), spannableStringBuilder, list, arrayList);
        c1659a.m4072a(spannableStringBuilder);
    }

    private static boolean m4092a(String str, Matcher matcher, C1403k c1403k, C1659a c1659a, StringBuilder stringBuilder, List list) {
        try {
            c1659a.m4070a(C1665h.m4103a(matcher.group(1))).m4076b(C1665h.m4103a(matcher.group(2)));
            C1663f.m4088a(matcher.group(3), c1659a);
            stringBuilder.setLength(0);
            while (true) {
                String x = c1403k.m2783x();
                if (x == null || x.isEmpty()) {
                    C1663f.m4090a(str, stringBuilder.toString(), c1659a, list);
                } else {
                    if (stringBuilder.length() > 0) {
                        stringBuilder.append("\n");
                    }
                    stringBuilder.append(x.trim());
                }
            }
            C1663f.m4090a(str, stringBuilder.toString(), c1659a, list);
            return true;
        } catch (NumberFormatException e) {
            Log.w("WebvttCueParser", "Skipping cue with bad header: " + matcher.group());
            return false;
        }
    }

    private static void m4094b(String str, C1659a c1659a) {
        int indexOf = str.indexOf(44);
        if (indexOf != -1) {
            c1659a.m4075b(C1663f.m4084a(str.substring(indexOf + 1)));
            str = str.substring(0, indexOf);
        } else {
            c1659a.m4075b(Integer.MIN_VALUE);
        }
        if (str.endsWith("%")) {
            c1659a.m4068a(C1665h.m4105b(str)).m4069a(0);
        } else {
            c1659a.m4068a((float) Integer.parseInt(str)).m4069a(1);
        }
    }

    private static void m4095c(String str, C1659a c1659a) {
        int indexOf = str.indexOf(44);
        if (indexOf != -1) {
            c1659a.m4079c(C1663f.m4084a(str.substring(indexOf + 1)));
            str = str.substring(0, indexOf);
        } else {
            c1659a.m4079c(Integer.MIN_VALUE);
        }
        c1659a.m4074b(C1665h.m4105b(str));
    }

    private static int m4084a(String str) {
        int i = -1;
        switch (str.hashCode()) {
            case -1364013995:
                if (str.equals("center")) {
                    i = 1;
                    break;
                }
                break;
            case -1074341483:
                if (str.equals("middle")) {
                    i = 2;
                    break;
                }
                break;
            case 100571:
                if (str.equals("end")) {
                    i = 3;
                    break;
                }
                break;
            case 109757538:
                if (str.equals("start")) {
                    i = 0;
                    break;
                }
                break;
        }
        switch (i) {
            case 0:
                return 0;
            case 1:
            case 2:
                return 1;
            case 3:
                return 2;
            default:
                Log.w("WebvttCueParser", "Invalid anchor value: " + str);
                return Integer.MIN_VALUE;
        }
    }

    private static Alignment m4093b(String str) {
        Object obj = -1;
        switch (str.hashCode()) {
            case -1364013995:
                if (str.equals("center")) {
                    obj = 2;
                    break;
                }
                break;
            case -1074341483:
                if (str.equals("middle")) {
                    obj = 3;
                    break;
                }
                break;
            case 100571:
                if (str.equals("end")) {
                    obj = 4;
                    break;
                }
                break;
            case 3317767:
                if (str.equals("left")) {
                    obj = 1;
                    break;
                }
                break;
            case 108511772:
                if (str.equals("right")) {
                    obj = 5;
                    break;
                }
                break;
            case 109757538:
                if (str.equals("start")) {
                    obj = null;
                    break;
                }
                break;
        }
        switch (obj) {
            case null:
            case 1:
                return Alignment.ALIGN_NORMAL;
            case 2:
            case 3:
                return Alignment.ALIGN_CENTER;
            case 4:
            case 5:
                return Alignment.ALIGN_OPPOSITE;
            default:
                Log.w("WebvttCueParser", "Invalid alignment value: " + str);
                return null;
        }
    }

    private static int m4085a(String str, int i) {
        int indexOf = str.indexOf(62, i);
        return indexOf == -1 ? str.length() : indexOf + 1;
    }

    private static void m4087a(String str, SpannableStringBuilder spannableStringBuilder) {
        Object obj = -1;
        switch (str.hashCode()) {
            case 3309:
                if (str.equals("gt")) {
                    obj = 1;
                    break;
                }
                break;
            case 3464:
                if (str.equals("lt")) {
                    obj = null;
                    break;
                }
                break;
            case 96708:
                if (str.equals("amp")) {
                    obj = 3;
                    break;
                }
                break;
            case 3374865:
                if (str.equals("nbsp")) {
                    obj = 2;
                    break;
                }
                break;
        }
        switch (obj) {
            case null:
                spannableStringBuilder.append('<');
                return;
            case 1:
                spannableStringBuilder.append('>');
                return;
            case 2:
                spannableStringBuilder.append(' ');
                return;
            case 3:
                spannableStringBuilder.append('&');
                return;
            default:
                Log.w("WebvttCueParser", "ignoring unsupported entity: '&" + str + ";'");
                return;
        }
    }

    private static boolean m4096c(String str) {
        boolean z = true;
        switch (str.hashCode()) {
            case 98:
                if (str.equals("b")) {
                    z = false;
                    break;
                }
                break;
            case 99:
                if (str.equals("c")) {
                    z = true;
                    break;
                }
                break;
            case 105:
                if (str.equals("i")) {
                    z = true;
                    break;
                }
                break;
            case 117:
                if (str.equals("u")) {
                    z = true;
                    break;
                }
                break;
            case 118:
                if (str.equals("v")) {
                    z = true;
                    break;
                }
                break;
            case 3314158:
                if (str.equals("lang")) {
                    z = true;
                    break;
                }
                break;
        }
        switch (z) {
            case false:
            case true:
            case true:
            case true:
            case true:
            case true:
                return true;
            default:
                return false;
        }
    }

    private static void m4089a(String str, C1661a c1661a, SpannableStringBuilder spannableStringBuilder, List list, List list2) {
        int i = c1661a.f3703b;
        int length = spannableStringBuilder.length();
        String str2 = c1661a.f3702a;
        int i2 = -1;
        switch (str2.hashCode()) {
            case 0:
                if (str2.equals("")) {
                    i2 = 6;
                    break;
                }
                break;
            case 98:
                if (str2.equals("b")) {
                    i2 = 0;
                    break;
                }
                break;
            case 99:
                if (str2.equals("c")) {
                    i2 = 3;
                    break;
                }
                break;
            case 105:
                if (str2.equals("i")) {
                    i2 = 1;
                    break;
                }
                break;
            case 117:
                if (str2.equals("u")) {
                    i2 = 2;
                    break;
                }
                break;
            case 118:
                if (str2.equals("v")) {
                    i2 = 5;
                    break;
                }
                break;
            case 3314158:
                if (str2.equals("lang")) {
                    i2 = 4;
                    break;
                }
                break;
        }
        switch (i2) {
            case 0:
                spannableStringBuilder.setSpan(new StyleSpan(1), i, length, 33);
                break;
            case 1:
                spannableStringBuilder.setSpan(new StyleSpan(2), i, length, 33);
                break;
            case 2:
                spannableStringBuilder.setSpan(new UnderlineSpan(), i, length, 33);
                break;
            case 3:
            case 4:
            case 5:
            case 6:
                break;
            default:
                return;
        }
        list2.clear();
        C1663f.m4091a(list, str, c1661a, list2);
        int size = list2.size();
        for (i2 = 0; i2 < size; i2++) {
            C1663f.m4086a(spannableStringBuilder, ((C1662b) list2.get(i2)).f3707b, i, length);
        }
    }

    private static void m4086a(SpannableStringBuilder spannableStringBuilder, C1657d c1657d, int i, int i2) {
        if (c1657d != null) {
            if (c1657d.m4050b() != -1) {
                spannableStringBuilder.setSpan(new StyleSpan(c1657d.m4050b()), i, i2, 33);
            }
            if (c1657d.m4056c()) {
                spannableStringBuilder.setSpan(new StrikethroughSpan(), i, i2, 33);
            }
            if (c1657d.m4058d()) {
                spannableStringBuilder.setSpan(new UnderlineSpan(), i, i2, 33);
            }
            if (c1657d.m4061g()) {
                spannableStringBuilder.setSpan(new ForegroundColorSpan(c1657d.m4060f()), i, i2, 33);
            }
            if (c1657d.m4063i()) {
                spannableStringBuilder.setSpan(new BackgroundColorSpan(c1657d.m4062h()), i, i2, 33);
            }
            if (c1657d.m4059e() != null) {
                spannableStringBuilder.setSpan(new TypefaceSpan(c1657d.m4059e()), i, i2, 33);
            }
            if (c1657d.m4064j() != null) {
                spannableStringBuilder.setSpan(new Standard(c1657d.m4064j()), i, i2, 33);
            }
            if (c1657d.m4065k() != -1) {
                switch (c1657d.m4065k()) {
                    case 1:
                        spannableStringBuilder.setSpan(new AbsoluteSizeSpan((int) c1657d.m4066l(), true), i, i2, 33);
                        return;
                    case 2:
                        spannableStringBuilder.setSpan(new RelativeSizeSpan(c1657d.m4066l()), i, i2, 33);
                        return;
                    case 3:
                        spannableStringBuilder.setSpan(new RelativeSizeSpan(c1657d.m4066l() / 100.0f), i, i2, 33);
                        return;
                    default:
                        return;
                }
            }
        }
    }

    private static String m4097d(String str) {
        String trim = str.trim();
        if (trim.isEmpty()) {
            return null;
        }
        return trim.split("[ \\.]")[0];
    }

    private static void m4091a(List list, String str, C1661a c1661a, List list2) {
        int size = list.size();
        for (int i = 0; i < size; i++) {
            C1657d c1657d = (C1657d) list.get(i);
            int a = c1657d.m4044a(str, c1661a.f3702a, c1661a.f3705d, c1661a.f3704c);
            if (a > 0) {
                list2.add(new C1662b(a, c1657d));
            }
        }
        Collections.sort(list2);
    }
}
