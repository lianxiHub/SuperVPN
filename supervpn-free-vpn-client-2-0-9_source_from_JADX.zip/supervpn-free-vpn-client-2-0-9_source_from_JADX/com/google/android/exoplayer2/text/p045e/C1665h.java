package com.google.android.exoplayer2.text.p045e;

import com.google.android.exoplayer2.p031c.C1403k;
import com.google.android.exoplayer2.text.SubtitleDecoderException;
import java.util.regex.Pattern;

public final class C1665h {
    private static final Pattern f3716a = Pattern.compile("^NOTE(( |\t).*)?$");
    private static final Pattern f3717b = Pattern.compile("^﻿?WEBVTT(( |\t).*)?$");

    public static void m4104a(C1403k c1403k) {
        Object x = c1403k.m2783x();
        if (x == null || !f3717b.matcher(x).matches()) {
            throw new SubtitleDecoderException("Expected WEBVTT. Got " + x);
        }
    }

    public static long m4103a(String str) {
        int i = 0;
        long j = 0;
        String[] split = str.split("\\.", 2);
        String[] split2 = split[0].split(":");
        while (i < split2.length) {
            j = (j * 60) + Long.parseLong(split2[i]);
            i++;
        }
        return (Long.parseLong(split[1]) + (j * 1000)) * 1000;
    }

    public static float m4105b(String str) {
        if (str.endsWith("%")) {
            return Float.parseFloat(str.substring(0, str.length() - 1)) / 100.0f;
        }
        throw new NumberFormatException("Percentages must end with %");
    }
}
