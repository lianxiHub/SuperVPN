package com.google.android.exoplayer2.text;

import android.annotation.TargetApi;
import android.graphics.Typeface;
import android.view.accessibility.CaptioningManager.CaptionStyle;
import com.google.android.exoplayer2.p031c.C1414r;

public final class C1639a {
    public static final C1639a f3596a = new C1639a(-1, -16777216, 0, 0, -1, null);
    public final int f3597b;
    public final int f3598c;
    public final int f3599d;
    public final int f3600e;
    public final int f3601f;
    public final Typeface f3602g;

    @TargetApi(19)
    public static C1639a m3938a(CaptionStyle captionStyle) {
        if (C1414r.f2503a >= 21) {
            return C1639a.m3940c(captionStyle);
        }
        return C1639a.m3939b(captionStyle);
    }

    public C1639a(int i, int i2, int i3, int i4, int i5, Typeface typeface) {
        this.f3597b = i;
        this.f3598c = i2;
        this.f3599d = i3;
        this.f3600e = i4;
        this.f3601f = i5;
        this.f3602g = typeface;
    }

    @TargetApi(19)
    private static C1639a m3939b(CaptionStyle captionStyle) {
        return new C1639a(captionStyle.foregroundColor, captionStyle.backgroundColor, 0, captionStyle.edgeType, captionStyle.edgeColor, captionStyle.getTypeface());
    }

    @TargetApi(21)
    private static C1639a m3940c(CaptionStyle captionStyle) {
        return new C1639a(captionStyle.hasForegroundColor() ? captionStyle.foregroundColor : f3596a.f3597b, captionStyle.hasBackgroundColor() ? captionStyle.backgroundColor : f3596a.f3598c, captionStyle.hasWindowColor() ? captionStyle.windowColor : f3596a.f3599d, captionStyle.hasEdgeType() ? captionStyle.edgeType : f3596a.f3600e, captionStyle.hasEdgeColor() ? captionStyle.edgeColor : f3596a.f3601f, captionStyle.getTypeface());
    }
}
