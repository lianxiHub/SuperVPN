package com.google.android.gms.internal;

@avl
public final class cr {
    public final String f5576a;
    public final int f5577b;
    public final long f5578c;
    private String f5579d;

    private cr(ct ctVar) {
        this.f5579d = ctVar.f5580a;
        this.f5576a = ctVar.f5581b;
        this.f5577b = ctVar.f5582c;
        this.f5578c = ctVar.f5583d;
    }
}
