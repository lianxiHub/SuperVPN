package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.Parcel;

public final class agt extends xq implements agr {
    agt(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.client.IVideoLifecycleCallbacks");
    }

    public final void mo2805a() {
        zzb(1, zzax());
    }

    public final void mo2806a(boolean z) {
        Parcel zzax = zzax();
        zm.m8273a(zzax, z);
        zzb(5, zzax);
    }

    public final void mo2807b() {
        zzb(2, zzax());
    }

    public final void mo2808c() {
        zzb(3, zzax());
    }

    public final void mo2809d() {
        zzb(4, zzax());
    }
}
