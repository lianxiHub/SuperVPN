package com.google.android.gms.internal;

final class tf implements Runnable {
    private /* synthetic */ int f6800a;
    private /* synthetic */ boolean f6801b;
    private /* synthetic */ td f6802c;

    tf(td tdVar, int i, boolean z) {
        this.f6802c = tdVar;
        this.f6800a = i;
        this.f6801b = z;
    }

    public final void run() {
        oh b = this.f6802c.m7658b(this.f6800a, this.f6801b);
        this.f6802c.f6793l = b;
        if (td.m7650b(this.f6800a, b)) {
            this.f6802c.m7656a(this.f6800a + 1, this.f6801b);
        }
    }
}
