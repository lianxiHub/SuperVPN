package com.google.android.gms.internal;

public final class pv extends zp {
    public Long f6561a;
    private String f6562b;
    private byte[] f6563c;

    public pv() {
        this.f6561a = null;
        this.f6562b = null;
        this.f6563c = null;
        this.S = -1;
    }

    protected final int mo2733a() {
        int a = super.mo2733a();
        if (this.f6561a != null) {
            a += zo.m8317c(1, this.f6561a.longValue());
        }
        if (this.f6562b != null) {
            a += zo.m8312b(3, this.f6562b);
        }
        return this.f6563c != null ? a + zo.m8313b(4, this.f6563c) : a;
    }

    public final /* synthetic */ zu mo2737a(zn znVar) {
        while (true) {
            int a = znVar.m8281a();
            switch (a) {
                case 0:
                    break;
                case 8:
                    this.f6561a = Long.valueOf(znVar.m8296h());
                    continue;
                case 26:
                    this.f6562b = znVar.m8292e();
                    continue;
                case 34:
                    this.f6563c = znVar.m8294f();
                    continue;
                default:
                    if (!super.m4550a(znVar, a)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }

    public final void mo2734a(zo zoVar) {
        if (this.f6561a != null) {
            zoVar.m8328b(1, this.f6561a.longValue());
        }
        if (this.f6562b != null) {
            zoVar.m8324a(3, this.f6562b);
        }
        if (this.f6563c != null) {
            zoVar.m8326a(4, this.f6563c);
        }
        super.mo2734a(zoVar);
    }
}
