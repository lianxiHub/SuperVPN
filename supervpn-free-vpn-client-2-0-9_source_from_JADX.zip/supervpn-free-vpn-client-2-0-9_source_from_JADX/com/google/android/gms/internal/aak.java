package com.google.android.gms.internal;

import android.support.customtabs.C0078b;

public interface aak {
    void mo2844a();

    void mo2845a(C0078b c0078b);
}
