package com.google.android.gms.internal;

@avl
public final class acz {
    private final float f4344a;
    private final float f4345b;
    private final float f4346c;
    private final float f4347d;
    private final int f4348e;

    public acz(float f, float f2, float f3, float f4, int i) {
        this.f4344a = f;
        this.f4345b = f2;
        this.f4346c = f + f3;
        this.f4347d = f2 + f4;
        this.f4348e = i;
    }

    final float m4803a() {
        return this.f4344a;
    }

    final float m4804b() {
        return this.f4345b;
    }

    final float m4805c() {
        return this.f4346c;
    }

    final float m4806d() {
        return this.f4347d;
    }

    final int m4807e() {
        return this.f4348e;
    }
}
