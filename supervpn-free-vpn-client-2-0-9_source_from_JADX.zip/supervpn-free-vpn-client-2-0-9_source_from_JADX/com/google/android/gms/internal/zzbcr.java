package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzd;

public final class zzbcr extends zza {
    public static final Creator CREATOR = new pq();
    private int f7354a;
    private final zzbct f7355b;

    zzbcr(int i, zzbct com_google_android_gms_internal_zzbct) {
        this.f7354a = i;
        this.f7355b = com_google_android_gms_internal_zzbct;
    }

    private zzbcr(zzbct com_google_android_gms_internal_zzbct) {
        this.f7354a = 1;
        this.f7355b = com_google_android_gms_internal_zzbct;
    }

    public static zzbcr m8374a(pu puVar) {
        if (puVar instanceof zzbct) {
            return new zzbcr((zzbct) puVar);
        }
        throw new IllegalArgumentException("Unsupported safe parcelable field converter class.");
    }

    public final pu m8375a() {
        if (this.f7355b != null) {
            return this.f7355b;
        }
        throw new IllegalStateException("There was no converter wrapped in this ConverterWrapper.");
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int zze = zzd.zze(parcel);
        zzd.zzc(parcel, 1, this.f7354a);
        zzd.zza(parcel, 2, this.f7355b, i, false);
        zzd.zzai(parcel, zze);
    }
}
