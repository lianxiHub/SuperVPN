package com.google.android.gms.internal;

final class aip extends aio {
    aip() {
    }

    public final String mo2832a(String str, String str2) {
        return str2;
    }
}
