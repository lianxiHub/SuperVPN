package com.google.android.gms.internal;

import java.util.Comparator;

public final class adl implements Comparator {
    public adl(adk com_google_android_gms_internal_adk) {
    }

    public final /* synthetic */ int compare(Object obj, Object obj2) {
        acz com_google_android_gms_internal_acz = (acz) obj;
        acz com_google_android_gms_internal_acz2 = (acz) obj2;
        if (com_google_android_gms_internal_acz.m4804b() < com_google_android_gms_internal_acz2.m4804b()) {
            return -1;
        }
        if (com_google_android_gms_internal_acz.m4804b() > com_google_android_gms_internal_acz2.m4804b()) {
            return 1;
        }
        if (com_google_android_gms_internal_acz.m4803a() < com_google_android_gms_internal_acz2.m4803a()) {
            return -1;
        }
        if (com_google_android_gms_internal_acz.m4803a() > com_google_android_gms_internal_acz2.m4803a()) {
            return 1;
        }
        float d = (com_google_android_gms_internal_acz.m4806d() - com_google_android_gms_internal_acz.m4804b()) * (com_google_android_gms_internal_acz.m4805c() - com_google_android_gms_internal_acz.m4803a());
        float d2 = (com_google_android_gms_internal_acz2.m4806d() - com_google_android_gms_internal_acz2.m4804b()) * (com_google_android_gms_internal_acz2.m4805c() - com_google_android_gms_internal_acz2.m4803a());
        return d <= d2 ? d < d2 ? 1 : 0 : -1;
    }
}
