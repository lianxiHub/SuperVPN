package com.google.android.gms.internal;

import com.google.android.gms.common.internal.zzbp;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public final class qc implements ThreadFactory {
    private final String f6565a;
    private final int f6566b;
    private final AtomicInteger f6567c;
    private final ThreadFactory f6568d;

    public qc(String str) {
        this(str, 0);
    }

    private qc(String str, int i) {
        this.f6567c = new AtomicInteger();
        this.f6568d = Executors.defaultThreadFactory();
        this.f6565a = (String) zzbp.zzb((Object) str, (Object) "Name must not be null");
        this.f6566b = 0;
    }

    public final Thread newThread(Runnable runnable) {
        Thread newThread = this.f6568d.newThread(new qd(runnable, 0));
        String str = this.f6565a;
        newThread.setName(new StringBuilder(String.valueOf(str).length() + 13).append(str).append("[").append(this.f6567c.getAndIncrement()).append("]").toString());
        return newThread;
    }
}
