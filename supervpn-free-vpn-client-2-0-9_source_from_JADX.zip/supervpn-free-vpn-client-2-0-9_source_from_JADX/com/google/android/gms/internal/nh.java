package com.google.android.gms.internal;

import com.google.android.gms.common.util.zzd;

public final class nh {
    private final long f6371a;
    private final int f6372b;
    private double f6373c;
    private long f6374d;
    private final Object f6375e;
    private final String f6376f;
    private final zzd f6377g;

    private nh(int i, long j, String str, zzd com_google_android_gms_common_util_zzd) {
        this.f6375e = new Object();
        this.f6372b = 60;
        this.f6373c = (double) this.f6372b;
        this.f6371a = 2000;
        this.f6376f = str;
        this.f6377g = com_google_android_gms_common_util_zzd;
    }

    public nh(String str, zzd com_google_android_gms_common_util_zzd) {
        this(60, 2000, str, com_google_android_gms_common_util_zzd);
    }

    public final boolean m7342a() {
        boolean z;
        synchronized (this.f6375e) {
            long currentTimeMillis = this.f6377g.currentTimeMillis();
            if (this.f6373c < ((double) this.f6372b)) {
                double d = ((double) (currentTimeMillis - this.f6374d)) / ((double) this.f6371a);
                if (d > 0.0d) {
                    this.f6373c = Math.min((double) this.f6372b, d + this.f6373c);
                }
            }
            this.f6374d = currentTimeMillis;
            if (this.f6373c >= 1.0d) {
                this.f6373c -= 1.0d;
                z = true;
            } else {
                String str = this.f6376f;
                ni.m7346b(new StringBuilder(String.valueOf(str).length() + 34).append("Excessive ").append(str).append(" detected; call ignored.").toString());
                z = false;
            }
        }
        return z;
    }
}
