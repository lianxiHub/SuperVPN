package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import java.io.IOException;

final class ec implements Runnable {
    private /* synthetic */ Context f5643a;
    private /* synthetic */ iw f5644b;

    ec(eb ebVar, Context context, iw iwVar) {
        this.f5643a = context;
        this.f5644b = iwVar;
    }

    public final void run() {
        Throwable e;
        try {
            this.f5644b.set(AdvertisingIdClient.getAdvertisingIdInfo(this.f5643a));
            return;
        } catch (IOException e2) {
            e = e2;
        } catch (IllegalStateException e3) {
            e = e3;
        } catch (GooglePlayServicesNotAvailableException e4) {
            e = e4;
        } catch (GooglePlayServicesRepairableException e5) {
            e = e5;
        }
        this.f5644b.setException(e);
        ii.m6517b("Exception while getting advertising Id info", e);
    }
}
