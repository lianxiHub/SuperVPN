package com.google.android.gms.internal;

abstract class fu extends er {
    private fu() {
    }

    public final void onStop() {
    }
}
