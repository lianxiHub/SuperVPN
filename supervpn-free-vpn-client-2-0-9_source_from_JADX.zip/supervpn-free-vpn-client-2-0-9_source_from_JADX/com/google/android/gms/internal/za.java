package com.google.android.gms.internal;

import java.util.AbstractSet;
import java.util.Iterator;
import java.util.Map.Entry;

final class za extends AbstractSet {
    private /* synthetic */ yt f7120a;

    private za(yt ytVar) {
        this.f7120a = ytVar;
    }

    public final /* synthetic */ boolean add(Object obj) {
        Entry entry = (Entry) obj;
        if (contains(entry)) {
            return false;
        }
        this.f7120a.m8198a((Comparable) entry.getKey(), entry.getValue());
        return true;
    }

    public final void clear() {
        this.f7120a.clear();
    }

    public final boolean contains(Object obj) {
        Entry entry = (Entry) obj;
        Object obj2 = this.f7120a.get(entry.getKey());
        Object value = entry.getValue();
        return obj2 == value || (obj2 != null && obj2.equals(value));
    }

    public final Iterator iterator() {
        return new yz(this.f7120a);
    }

    public final boolean remove(Object obj) {
        Entry entry = (Entry) obj;
        if (!contains(entry)) {
            return false;
        }
        this.f7120a.remove(entry.getKey());
        return true;
    }

    public final int size() {
        return this.f7120a.size();
    }
}
