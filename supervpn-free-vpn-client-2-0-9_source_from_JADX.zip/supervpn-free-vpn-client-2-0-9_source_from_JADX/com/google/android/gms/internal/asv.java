package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import com.google.android.gms.ads.internal.zzbv;
import java.util.Map;

@avl
public final class asv extends asw implements anb {
    private final jk f5223a;
    private final Context f5224b;
    private final WindowManager f5225c;
    private final ahr f5226d;
    private DisplayMetrics f5227e;
    private float f5228f;
    private int f5229g = -1;
    private int f5230h = -1;
    private int f5231i;
    private int f5232j = -1;
    private int f5233k = -1;
    private int f5234l = -1;
    private int f5235m = -1;

    public asv(jk jkVar, Context context, ahr com_google_android_gms_internal_ahr) {
        super(jkVar);
        this.f5223a = jkVar;
        this.f5224b = context;
        this.f5226d = com_google_android_gms_internal_ahr;
        this.f5225c = (WindowManager) context.getSystemService("window");
    }

    public final void m6073a(int i, int i2) {
        int i3 = this.f5224b instanceof Activity ? zzbv.zzea().m6647c((Activity) this.f5224b)[0] : 0;
        if (this.f5223a.mo3255j() == null || !this.f5223a.mo3255j().f7632d) {
            afc.m4920a();
            this.f5234l = ie.m6793b(this.f5224b, this.f5223a.getWidth());
            afc.m4920a();
            this.f5235m = ie.m6793b(this.f5224b, this.f5223a.getHeight());
        }
        m6044b(i, i2 - i3, this.f5234l, this.f5235m);
        this.f5223a.mo3256k().m6894a(i, i2);
    }

    public final void zza(jk jkVar, Map map) {
        int[] a;
        this.f5227e = new DisplayMetrics();
        Display defaultDisplay = this.f5225c.getDefaultDisplay();
        defaultDisplay.getMetrics(this.f5227e);
        this.f5228f = this.f5227e.density;
        this.f5231i = defaultDisplay.getRotation();
        afc.m4920a();
        this.f5229g = ie.m6794b(this.f5227e, this.f5227e.widthPixels);
        afc.m4920a();
        this.f5230h = ie.m6794b(this.f5227e, this.f5227e.heightPixels);
        Activity e = this.f5223a.mo3250e();
        if (e == null || e.getWindow() == null) {
            this.f5232j = this.f5229g;
            this.f5233k = this.f5230h;
        } else {
            zzbv.zzea();
            a = gd.m6601a(e);
            afc.m4920a();
            this.f5232j = ie.m6794b(this.f5227e, a[0]);
            afc.m4920a();
            this.f5233k = ie.m6794b(this.f5227e, a[1]);
        }
        if (this.f5223a.mo3255j().f7632d) {
            this.f5234l = this.f5229g;
            this.f5235m = this.f5230h;
        } else {
            this.f5223a.measure(0, 0);
        }
        m6042a(this.f5229g, this.f5230h, this.f5232j, this.f5233k, this.f5228f, this.f5231i);
        this.f5223a.zzb("onDeviceFeaturesReceived", new asr(new asu().m6069b(this.f5226d.m5130a()).m6068a(this.f5226d.m5131b()).m6070c(this.f5226d.m5133d()).m6071d(this.f5226d.m5132c()).m6072e(true)).m6062a());
        a = new int[2];
        this.f5223a.getLocationOnScreen(a);
        afc.m4920a();
        int b = ie.m6793b(this.f5224b, a[0]);
        afc.m4920a();
        m6073a(b, ie.m6793b(this.f5224b, a[1]));
        if (ii.m6515a(2)) {
            ii.m6520d("Dispatching Ready Event.");
        }
        m6045b(this.f5223a.mo3262n().f7336a);
    }
}
