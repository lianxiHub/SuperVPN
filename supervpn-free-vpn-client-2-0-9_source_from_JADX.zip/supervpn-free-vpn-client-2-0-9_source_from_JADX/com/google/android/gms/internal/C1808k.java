package com.google.android.gms.internal;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.os.Bundle;
import java.util.List;
import java.util.concurrent.Future;

@avl
public final class C1808k {
    public final float f6075A;
    public final boolean f6076B;
    public final int f6077C;
    public final int f6078D;
    public final boolean f6079E;
    public final boolean f6080F;
    public final Future f6081G;
    public final String f6082H;
    public final boolean f6083I;
    public final int f6084J;
    public final Bundle f6085K;
    public final String f6086L;
    public final zzle f6087M;
    public final boolean f6088N;
    public final Bundle f6089O;
    public final boolean f6090P;
    public final Future f6091Q;
    public final List f6092R;
    public final String f6093S;
    public final int f6094T;
    public final boolean f6095U;
    public final boolean f6096V;
    public final Bundle f6097a;
    public final zzix f6098b;
    public final zzjb f6099c;
    public final String f6100d;
    public final ApplicationInfo f6101e;
    public final PackageInfo f6102f;
    public final String f6103g;
    public final String f6104h;
    public final Bundle f6105i;
    public final zzajk f6106j;
    public final int f6107k;
    public final List f6108l;
    public final List f6109m;
    public final List f6110n;
    public final Bundle f6111o;
    public final boolean f6112p;
    public final int f6113q;
    public final int f6114r;
    public final float f6115s;
    public final String f6116t;
    public final long f6117u;
    public final String f6118v;
    public final List f6119w;
    public final String f6120x;
    public final zzot f6121y;
    public final String f6122z;

    public C1808k(Bundle bundle, zzix com_google_android_gms_internal_zzix, zzjb com_google_android_gms_internal_zzjb, String str, ApplicationInfo applicationInfo, PackageInfo packageInfo, String str2, String str3, zzajk com_google_android_gms_internal_zzajk, Bundle bundle2, List list, List list2, Bundle bundle3, boolean z, int i, int i2, float f, String str4, long j, String str5, List list3, String str6, zzot com_google_android_gms_internal_zzot, String str7, float f2, boolean z2, int i3, int i4, boolean z3, boolean z4, Future future, String str8, boolean z5, int i5, Bundle bundle4, String str9, zzle com_google_android_gms_internal_zzle, boolean z6, Bundle bundle5, boolean z7, Future future2, List list4, String str10, List list5, int i6, boolean z8, boolean z9) {
        this.f6097a = bundle;
        this.f6098b = com_google_android_gms_internal_zzix;
        this.f6099c = com_google_android_gms_internal_zzjb;
        this.f6100d = str;
        this.f6101e = applicationInfo;
        this.f6102f = packageInfo;
        this.f6103g = str2;
        this.f6104h = str3;
        this.f6106j = com_google_android_gms_internal_zzajk;
        this.f6105i = bundle2;
        this.f6112p = z;
        this.f6113q = i;
        this.f6114r = i2;
        this.f6115s = f;
        if (list == null || list.size() <= 0) {
            this.f6107k = 0;
            this.f6108l = null;
            this.f6109m = null;
        } else {
            this.f6107k = 3;
            this.f6108l = list;
            this.f6109m = list2;
        }
        this.f6111o = bundle3;
        this.f6116t = str4;
        this.f6117u = j;
        this.f6118v = str5;
        this.f6119w = list3;
        this.f6120x = str6;
        this.f6121y = com_google_android_gms_internal_zzot;
        this.f6122z = str7;
        this.f6075A = f2;
        this.f6076B = z2;
        this.f6077C = i3;
        this.f6078D = i4;
        this.f6079E = z3;
        this.f6080F = z4;
        this.f6081G = future;
        this.f6082H = str8;
        this.f6083I = z5;
        this.f6084J = i5;
        this.f6085K = bundle4;
        this.f6086L = str9;
        this.f6087M = com_google_android_gms_internal_zzle;
        this.f6088N = z6;
        this.f6089O = bundle5;
        this.f6090P = z7;
        this.f6091Q = future2;
        this.f6092R = list4;
        this.f6093S = str10;
        this.f6110n = list5;
        this.f6094T = i6;
        this.f6095U = z8;
        this.f6096V = z9;
    }
}
