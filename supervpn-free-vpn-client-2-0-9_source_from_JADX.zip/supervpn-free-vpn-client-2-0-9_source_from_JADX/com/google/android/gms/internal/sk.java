package com.google.android.gms.internal;

import android.os.IInterface;
import com.google.android.gms.common.internal.zzam;

public interface sk extends IInterface {
    void mo3307a(int i);

    void mo3308a(zzam com_google_android_gms_common_internal_zzam, int i, boolean z);

    void mo3309a(zzcpx com_google_android_gms_internal_zzcpx, si siVar);
}
