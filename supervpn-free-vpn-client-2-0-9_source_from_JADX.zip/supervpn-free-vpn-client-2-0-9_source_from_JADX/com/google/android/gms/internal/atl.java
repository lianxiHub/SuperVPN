package com.google.android.gms.internal;

import android.os.IBinder;

public final class atl extends xq implements atj {
    atl(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.purchase.client.IInAppPurchaseManager");
    }
}
