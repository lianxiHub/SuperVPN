package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

final class fg extends fu {
    private /* synthetic */ Context f5794a;
    private /* synthetic */ fv f5795b;

    fg(Context context, fv fvVar) {
        this.f5794a = context;
        this.f5795b = fvVar;
        super();
    }

    public final void zzdc() {
        SharedPreferences sharedPreferences = this.f5794a.getSharedPreferences("admob", 0);
        Bundle bundle = new Bundle();
        bundle.putBoolean("use_https", sharedPreferences.getBoolean("use_https", true));
        if (this.f5795b != null) {
            this.f5795b.mo3185a(bundle);
        }
    }
}
