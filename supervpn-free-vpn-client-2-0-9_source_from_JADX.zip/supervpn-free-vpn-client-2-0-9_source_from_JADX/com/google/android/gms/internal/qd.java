package com.google.android.gms.internal;

import android.os.Process;

final class qd implements Runnable {
    private final Runnable f6569a;
    private final int f6570b;

    public qd(Runnable runnable, int i) {
        this.f6569a = runnable;
        this.f6570b = i;
    }

    public final void run() {
        Process.setThreadPriority(this.f6570b);
        this.f6569a.run();
    }
}
