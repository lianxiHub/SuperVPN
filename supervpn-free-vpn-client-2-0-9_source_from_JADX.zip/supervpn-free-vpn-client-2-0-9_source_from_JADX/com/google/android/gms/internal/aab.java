package com.google.android.gms.internal;

public final class aab extends zp {
    public aaa[] f4114a;
    private aac f4115b;
    private byte[] f4116c;
    private byte[] f4117d;
    private Integer f4118e;

    public aab() {
        this.f4115b = null;
        this.f4114a = aaa.m4553b();
        this.f4116c = null;
        this.f4117d = null;
        this.f4118e = null;
        this.R = null;
        this.S = -1;
    }

    protected final int mo2733a() {
        int a = super.mo2733a();
        if (this.f4115b != null) {
            a += zo.m8311b(1, this.f4115b);
        }
        if (this.f4114a != null && this.f4114a.length > 0) {
            int i = a;
            for (zu zuVar : this.f4114a) {
                if (zuVar != null) {
                    i += zo.m8311b(2, zuVar);
                }
            }
            a = i;
        }
        if (this.f4116c != null) {
            a += zo.m8313b(3, this.f4116c);
        }
        if (this.f4117d != null) {
            a += zo.m8313b(4, this.f4117d);
        }
        return this.f4118e != null ? a + zo.m8310b(5, this.f4118e.intValue()) : a;
    }

    public final /* synthetic */ zu mo2737a(zn znVar) {
        while (true) {
            int a = znVar.m8281a();
            switch (a) {
                case 0:
                    break;
                case 10:
                    if (this.f4115b == null) {
                        this.f4115b = new aac();
                    }
                    znVar.m8283a(this.f4115b);
                    continue;
                case 18:
                    int a2 = zx.m8356a(znVar, 18);
                    a = this.f4114a == null ? 0 : this.f4114a.length;
                    Object obj = new aaa[(a2 + a)];
                    if (a != 0) {
                        System.arraycopy(this.f4114a, 0, obj, 0, a);
                    }
                    while (a < obj.length - 1) {
                        obj[a] = new aaa();
                        znVar.m8283a(obj[a]);
                        znVar.m8281a();
                        a++;
                    }
                    obj[a] = new aaa();
                    znVar.m8283a(obj[a]);
                    this.f4114a = obj;
                    continue;
                case 26:
                    this.f4116c = znVar.m8294f();
                    continue;
                case 34:
                    this.f4117d = znVar.m8294f();
                    continue;
                case 40:
                    this.f4118e = Integer.valueOf(znVar.m8288c());
                    continue;
                default:
                    if (!super.m4550a(znVar, a)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }

    public final void mo2734a(zo zoVar) {
        if (this.f4115b != null) {
            zoVar.m8323a(1, this.f4115b);
        }
        if (this.f4114a != null && this.f4114a.length > 0) {
            for (zu zuVar : this.f4114a) {
                if (zuVar != null) {
                    zoVar.m8323a(2, zuVar);
                }
            }
        }
        if (this.f4116c != null) {
            zoVar.m8326a(3, this.f4116c);
        }
        if (this.f4117d != null) {
            zoVar.m8326a(4, this.f4117d);
        }
        if (this.f4118e != null) {
            zoVar.m8321a(5, this.f4118e.intValue());
        }
        super.mo2734a(zoVar);
    }
}
