package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.os.Message;
import android.support.v4.media.session.PlaybackStateCompat;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.GeolocationPermissions.Callback;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebChromeClient.CustomViewCallback;
import android.webkit.WebStorage.QuotaUpdater;
import android.webkit.WebView;
import android.webkit.WebView.WebViewTransport;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.gms.ads.internal.overlay.zzm;
import com.google.android.gms.ads.internal.zzbv;
import com.google.android.gms.ads.internal.zzw;

@avl
@TargetApi(11)
public class kg extends WebChromeClient {
    private final jk f6147a;

    public kg(jk jkVar) {
        this.f6147a = jkVar;
    }

    private static Context m7057a(WebView webView) {
        if (!(webView instanceof jk)) {
            return webView.getContext();
        }
        jk jkVar = (jk) webView;
        Context e = jkVar.mo3250e();
        return e == null ? jkVar.getContext() : e;
    }

    private final boolean m7058a(Context context, String str, String str2, String str3, String str4, JsResult jsResult, JsPromptResult jsPromptResult, boolean z) {
        try {
            if (!(this.f6147a == null || this.f6147a.mo3256k() == null || this.f6147a.mo3256k().m6893a() == null)) {
                zzw a = this.f6147a.mo3256k().m6893a();
                if (!(a == null || a.zzcq())) {
                    a.zzs(new StringBuilder((String.valueOf(str).length() + 11) + String.valueOf(str3).length()).append("window.").append(str).append("('").append(str3).append("')").toString());
                    return false;
                }
            }
            Builder builder = new Builder(context);
            builder.setTitle(str2);
            if (z) {
                View linearLayout = new LinearLayout(context);
                linearLayout.setOrientation(1);
                View textView = new TextView(context);
                textView.setText(str3);
                View editText = new EditText(context);
                editText.setText(str4);
                linearLayout.addView(textView);
                linearLayout.addView(editText);
                builder.setView(linearLayout).setPositiveButton(17039370, new km(jsPromptResult, editText)).setNegativeButton(17039360, new kl(jsPromptResult)).setOnCancelListener(new kk(jsPromptResult)).create().show();
                return true;
            }
            builder.setMessage(str3).setPositiveButton(17039370, new kj(jsResult)).setNegativeButton(17039360, new ki(jsResult)).setOnCancelListener(new kh(jsResult)).create().show();
            return true;
        } catch (Throwable e) {
            ii.m6519c("Fail to display Dialog.", e);
            return true;
        }
    }

    protected final void m7059a(View view, int i, CustomViewCallback customViewCallback) {
        zzm h = this.f6147a.mo3253h();
        if (h == null) {
            ii.m6521e("Could not get ad overlay when showing custom view.");
            customViewCallback.onCustomViewHidden();
            return;
        }
        h.zza(view, customViewCallback);
        h.setRequestedOrientation(i);
    }

    public final void onCloseWindow(WebView webView) {
        if (webView instanceof jk) {
            zzm h = ((jk) webView).mo3253h();
            if (h == null) {
                ii.m6521e("Tried to close an AdWebView not associated with an overlay.");
                return;
            } else {
                h.close();
                return;
            }
        }
        ii.m6521e("Tried to close a WebView that wasn't an AdWebView.");
    }

    public final boolean onConsoleMessage(ConsoleMessage consoleMessage) {
        String message = consoleMessage.message();
        String sourceId = consoleMessage.sourceId();
        message = new StringBuilder((String.valueOf(message).length() + 19) + String.valueOf(sourceId).length()).append("JS: ").append(message).append(" (").append(sourceId).append(":").append(consoleMessage.lineNumber()).append(")").toString();
        if (message.contains("Application Cache")) {
            return super.onConsoleMessage(consoleMessage);
        }
        switch (kn.f6155a[consoleMessage.messageLevel().ordinal()]) {
            case 1:
                ii.m6518c(message);
                break;
            case 2:
                ii.m6521e(message);
                break;
            case 3:
            case 4:
                ii.m6520d(message);
                break;
            case 5:
                ii.m6516b(message);
                break;
            default:
                ii.m6520d(message);
                break;
        }
        return super.onConsoleMessage(consoleMessage);
    }

    public final boolean onCreateWindow(WebView webView, boolean z, boolean z2, Message message) {
        WebViewTransport webViewTransport = (WebViewTransport) message.obj;
        WebView webView2 = new WebView(webView.getContext());
        webView2.setWebViewClient(this.f6147a.mo3256k());
        webViewTransport.setWebView(webView2);
        message.sendToTarget();
        return true;
    }

    public final void onExceededDatabaseQuota(String str, String str2, long j, long j2, long j3, QuotaUpdater quotaUpdater) {
        long j4 = 5242880 - j3;
        if (j4 <= 0) {
            quotaUpdater.updateQuota(j);
            return;
        }
        if (j != 0) {
            if (j2 == 0) {
                j = Math.min(Math.min(PlaybackStateCompat.ACTION_PREPARE_FROM_URI, j4) + j, PlaybackStateCompat.ACTION_SET_CAPTIONING_ENABLED);
            } else if (j2 <= Math.min(PlaybackStateCompat.ACTION_SET_CAPTIONING_ENABLED - j, j4)) {
                j += j2;
            }
            j2 = j;
        } else if (j2 > j4 || j2 > PlaybackStateCompat.ACTION_SET_CAPTIONING_ENABLED) {
            j2 = 0;
        }
        quotaUpdater.updateQuota(j2);
    }

    public final void onGeolocationPermissionsShowPrompt(String str, Callback callback) {
        if (callback != null) {
            boolean z;
            zzbv.zzea();
            if (!gd.m6598a(this.f6147a.getContext(), this.f6147a.getContext().getPackageName(), "android.permission.ACCESS_FINE_LOCATION")) {
                zzbv.zzea();
                if (!gd.m6598a(this.f6147a.getContext(), this.f6147a.getContext().getPackageName(), "android.permission.ACCESS_COARSE_LOCATION")) {
                    z = false;
                    callback.invoke(str, z, true);
                }
            }
            z = true;
            callback.invoke(str, z, true);
        }
    }

    public final void onHideCustomView() {
        zzm h = this.f6147a.mo3253h();
        if (h == null) {
            ii.m6521e("Could not get ad overlay when hiding custom view.");
        } else {
            h.zzml();
        }
    }

    public final boolean onJsAlert(WebView webView, String str, String str2, JsResult jsResult) {
        return m7058a(m7057a(webView), "alert", str, str2, null, jsResult, null, false);
    }

    public final boolean onJsBeforeUnload(WebView webView, String str, String str2, JsResult jsResult) {
        return m7058a(m7057a(webView), "onBeforeUnload", str, str2, null, jsResult, null, false);
    }

    public final boolean onJsConfirm(WebView webView, String str, String str2, JsResult jsResult) {
        return m7058a(m7057a(webView), "confirm", str, str2, null, jsResult, null, false);
    }

    public final boolean onJsPrompt(WebView webView, String str, String str2, String str3, JsPromptResult jsPromptResult) {
        return m7058a(m7057a(webView), "prompt", str, str2, str3, null, jsPromptResult, true);
    }

    public final void onReachedMaxAppCacheSize(long j, long j2, QuotaUpdater quotaUpdater) {
        long j3 = PlaybackStateCompat.ACTION_PREPARE_FROM_URI + j;
        if (5242880 - j2 < j3) {
            quotaUpdater.updateQuota(0);
        } else {
            quotaUpdater.updateQuota(j3);
        }
    }

    public final void onShowCustomView(View view, CustomViewCallback customViewCallback) {
        m7059a(view, -1, customViewCallback);
    }
}
