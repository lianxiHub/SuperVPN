package com.google.android.gms.internal;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import org.json.JSONObject;

final class ahx extends ahw {
    ahx(int i, String str, Boolean bool) {
        super(i, str, bool);
    }

    public final /* synthetic */ Object mo2829a(SharedPreferences sharedPreferences) {
        return Boolean.valueOf(sharedPreferences.getBoolean(m5145a(), ((Boolean) m5147b()).booleanValue()));
    }

    public final /* synthetic */ Object mo2830a(JSONObject jSONObject) {
        return Boolean.valueOf(jSONObject.optBoolean(m5145a(), ((Boolean) m5147b()).booleanValue()));
    }

    public final /* synthetic */ void mo2831a(Editor editor, Object obj) {
        editor.putBoolean(m5145a(), ((Boolean) obj).booleanValue());
    }
}
