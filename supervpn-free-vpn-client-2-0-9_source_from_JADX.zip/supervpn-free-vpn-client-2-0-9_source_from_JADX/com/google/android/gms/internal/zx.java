package com.google.android.gms.internal;

public final class zx {
    public static final int[] f7185a = new int[0];
    public static final long[] f7186b = new long[0];
    public static final float[] f7187c = new float[0];
    public static final boolean[] f7188d = new boolean[0];
    public static final String[] f7189e = new String[0];
    public static final byte[][] f7190f = new byte[0][];
    public static final byte[] f7191g = new byte[0];
    private static int f7192h = 11;
    private static int f7193i = 12;
    private static int f7194j = 16;
    private static int f7195k = 26;
    private static double[] f7196l = new double[0];

    public static final int m8356a(zn znVar, int i) {
        int i2 = 1;
        int l = znVar.m8300l();
        znVar.m8287b(i);
        while (znVar.m8281a() == i) {
            znVar.m8287b(i);
            i2++;
        }
        znVar.m8286b(l, i);
        return i2;
    }
}
