package com.google.android.gms.internal;

import com.google.android.gms.ads.reward.RewardedVideoAdListener;

@avl
public final class cl extends ch {
    private final RewardedVideoAdListener f5552a;

    public cl(RewardedVideoAdListener rewardedVideoAdListener) {
        this.f5552a = rewardedVideoAdListener;
    }

    public final void mo2970a() {
        if (this.f5552a != null) {
            this.f5552a.onRewardedVideoAdLoaded();
        }
    }

    public final void mo2971a(int i) {
        if (this.f5552a != null) {
            this.f5552a.onRewardedVideoAdFailedToLoad(i);
        }
    }

    public final void mo2972a(by byVar) {
        if (this.f5552a != null) {
            this.f5552a.onRewarded(new cj(byVar));
        }
    }

    public final void mo2973b() {
        if (this.f5552a != null) {
            this.f5552a.onRewardedVideoAdOpened();
        }
    }

    public final void mo2974c() {
        if (this.f5552a != null) {
            this.f5552a.onRewardedVideoStarted();
        }
    }

    public final void mo2975d() {
        if (this.f5552a != null) {
            this.f5552a.onRewardedVideoAdClosed();
        }
    }

    public final void mo2976e() {
        if (this.f5552a != null) {
            this.f5552a.onRewardedVideoAdLeftApplication();
        }
    }
}
