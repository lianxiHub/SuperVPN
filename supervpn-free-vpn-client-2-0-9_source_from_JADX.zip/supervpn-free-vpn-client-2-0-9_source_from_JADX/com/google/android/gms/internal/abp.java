package com.google.android.gms.internal;

import com.mopub.volley.DefaultRetryPolicy;

public final class abp implements ass {
    private int f4229a;
    private int f4230b;
    private final int f4231c;
    private final float f4232d;

    public abp() {
        this(DefaultRetryPolicy.DEFAULT_TIMEOUT_MS, 1, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
    }

    private abp(int i, int i2, float f) {
        this.f4229a = DefaultRetryPolicy.DEFAULT_TIMEOUT_MS;
        this.f4231c = 1;
        this.f4232d = DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;
    }

    public final int mo2769a() {
        return this.f4229a;
    }

    public final void mo2770a(zzaa com_google_android_gms_internal_zzaa) {
        this.f4230b++;
        this.f4229a = (int) (((float) this.f4229a) + (((float) this.f4229a) * this.f4232d));
        if ((this.f4230b <= this.f4231c ? 1 : null) == null) {
            throw com_google_android_gms_internal_zzaa;
        }
    }

    public final int mo2771b() {
        return this.f4230b;
    }
}
