package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.Parcel;

public final class afk extends xq implements afi {
    afk(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.client.IAdListener");
    }

    public final void mo2781a() {
        zzb(1, zzax());
    }

    public final void mo2782a(int i) {
        Parcel zzax = zzax();
        zzax.writeInt(i);
        zzb(2, zzax);
    }

    public final void mo2783b() {
        zzb(3, zzax());
    }

    public final void mo2784c() {
        zzb(4, zzax());
    }

    public final void mo2785d() {
        zzb(5, zzax());
    }

    public final void mo2786e() {
        zzb(6, zzax());
    }

    public final void mo2787f() {
        zzb(7, zzax());
    }
}
