package com.google.android.gms.internal;

import java.util.logging.Logger;

public final class vg {
    private static final Logger f6958a = Logger.getLogger(vg.class.getName());

    public static void m8023a() {
        uj.f6928a.m7939a("type.googleapis.com/google.cloud.crypto.tink.HmacKey", new ve());
    }
}
