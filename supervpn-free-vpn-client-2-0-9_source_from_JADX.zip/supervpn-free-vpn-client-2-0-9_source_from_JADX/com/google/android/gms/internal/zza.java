package com.google.android.gms.internal;

public final class zza extends zzaa {
    public zza(aim com_google_android_gms_internal_aim) {
        super(com_google_android_gms_internal_aim);
    }
}
