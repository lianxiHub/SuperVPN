package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.zzw;
import com.google.android.gms.common.util.zze;
import java.util.Map;

@avl
public final class ann implements anb {
    private static Map f4894c = zze.zza("resize", Integer.valueOf(1), "playVideo", Integer.valueOf(2), "storePicture", Integer.valueOf(3), "createCalendarEvent", Integer.valueOf(4), "setOrientationProperties", Integer.valueOf(5), "closeResizedAd", Integer.valueOf(6));
    private final zzw f4895a;
    private final asl f4896b;

    public ann(zzw com_google_android_gms_ads_internal_zzw, asl com_google_android_gms_internal_asl) {
        this.f4895a = com_google_android_gms_ads_internal_zzw;
        this.f4896b = com_google_android_gms_internal_asl;
    }

    public final void zza(jk jkVar, Map map) {
        int intValue = ((Integer) f4894c.get((String) map.get("a"))).intValue();
        if (intValue == 5 || this.f4895a == null || this.f4895a.zzcq()) {
            switch (intValue) {
                case 1:
                    this.f4896b.m6056a(map);
                    return;
                case 3:
                    new aso(jkVar, map).m6061a();
                    return;
                case 4:
                    new asi(jkVar, map).m6050a();
                    return;
                case 5:
                    new asn(jkVar, map).m6059a();
                    return;
                case 6:
                    this.f4896b.m6057a(true);
                    return;
                default:
                    ii.m6520d("Unknown MRAID command called.");
                    return;
            }
        }
        this.f4895a.zzs(null);
    }
}
