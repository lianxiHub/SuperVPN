package com.google.android.gms.internal;

public final class nb extends mo {
    public nb(lr lrVar) {
        super(lrVar, new nc(lrVar));
    }
}
