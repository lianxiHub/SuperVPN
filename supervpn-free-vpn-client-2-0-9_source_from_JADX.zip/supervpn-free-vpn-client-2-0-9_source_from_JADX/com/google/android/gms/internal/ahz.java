package com.google.android.gms.internal;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import org.json.JSONObject;

final class ahz extends ahw {
    ahz(int i, String str, Long l) {
        super(i, str, l);
    }

    public final /* synthetic */ Object mo2829a(SharedPreferences sharedPreferences) {
        return Long.valueOf(sharedPreferences.getLong(m5145a(), ((Long) m5147b()).longValue()));
    }

    public final /* synthetic */ Object mo2830a(JSONObject jSONObject) {
        return Long.valueOf(jSONObject.optLong(m5145a(), ((Long) m5147b()).longValue()));
    }

    public final /* synthetic */ void mo2831a(Editor editor, Object obj) {
        editor.putLong(m5145a(), ((Long) obj).longValue());
    }
}
