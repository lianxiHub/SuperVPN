package com.google.android.gms.internal;

public final class vn {
    private byte[] f6969a;
    private byte[] f6970b;

    public vn(byte[] bArr, byte[] bArr2) {
        this.f6969a = bArr;
        this.f6970b = bArr2;
    }

    public final byte[] m8039a() {
        return this.f6969a;
    }

    public final byte[] m8040b() {
        return this.f6970b;
    }
}
