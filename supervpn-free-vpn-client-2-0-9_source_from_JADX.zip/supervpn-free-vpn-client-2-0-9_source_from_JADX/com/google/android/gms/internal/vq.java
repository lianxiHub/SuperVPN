package com.google.android.gms.internal;

import java.security.Provider;

public interface vq {
    Object mo3342a(String str, Provider provider);
}
