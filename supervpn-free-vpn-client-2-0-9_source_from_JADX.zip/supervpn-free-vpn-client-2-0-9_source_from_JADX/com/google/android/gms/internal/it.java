package com.google.android.gms.internal;

import java.util.concurrent.Executor;

@avl
public final class it {
    public static final Executor f5969a = new iu();
    public static final Executor f5970b = new iv();
}
