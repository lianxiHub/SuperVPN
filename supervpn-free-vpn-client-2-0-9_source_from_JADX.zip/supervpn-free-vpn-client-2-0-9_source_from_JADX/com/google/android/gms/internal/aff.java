package com.google.android.gms.internal;

import android.os.IInterface;

public interface aff extends IInterface {
    void mo2780a();
}
