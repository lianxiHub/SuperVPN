package com.google.android.gms.internal;

import com.facebook.ads.AdError;

public final class mz {
    public static na f6312A = na.m7318a("analytics.service_client.idle_disconnect_millis", 10000, 10000);
    public static na f6313B = na.m7318a("analytics.service_client.connect_timeout_millis", 5000, 5000);
    public static na f6314C = na.m7318a("analytics.service_client.reconnect_throttle_millis", 1800000, 1800000);
    public static na f6315D = na.m7318a("analytics.monitoring.sample_period_millis", 86400000, 86400000);
    public static na f6316E = na.m7318a("analytics.initialization_warning_threshold", 5000, 5000);
    private static na f6317F = na.m7320a("analytics.service_enabled", false, false);
    private static na f6318G = na.m7318a("analytics.max_tokens", 60, 60);
    private static na f6319H = na.m7316a("analytics.tokens_per_sec", 0.5f, 0.5f);
    private static na f6320I = na.m7317a("analytics.max_stored_hits_per_app", (int) AdError.SERVER_ERROR_CODE, (int) AdError.SERVER_ERROR_CODE);
    private static na f6321J = na.m7318a("analytics.min_local_dispatch_millis", 120000, 120000);
    private static na f6322K = na.m7318a("analytics.max_local_dispatch_millis", 7200000, 7200000);
    private static na f6323L = na.m7317a("analytics.max_hits_per_request.k", 20, 20);
    private static na f6324M = na.m7318a("analytics.service_monitor_interval", 86400000, 86400000);
    private static na f6325N;
    private static na f6326O = na.m7317a("analytics.first_party_experiment_variant", 0, 0);
    private static na f6327P = na.m7318a("analytics.service_client.second_connect_delay_millis", 5000, 5000);
    private static na f6328Q = na.m7318a("analytics.service_client.unexpected_reconnect_millis", 60000, 60000);
    public static na f6329a = na.m7320a("analytics.service_client_enabled", true, true);
    public static na f6330b = na.m7319a("analytics.log_tag", "GAv4", "GAv4-SVC");
    public static na f6331c = na.m7317a("analytics.max_stored_hits", (int) AdError.SERVER_ERROR_CODE, 20000);
    public static na f6332d = na.m7317a("analytics.max_stored_properties_per_app", 100, 100);
    public static na f6333e = na.m7318a("analytics.local_dispatch_millis", 1800000, 120000);
    public static na f6334f = na.m7318a("analytics.initial_local_dispatch_millis", 5000, 5000);
    public static na f6335g = na.m7318a("analytics.dispatch_alarm_millis", 7200000, 7200000);
    public static na f6336h = na.m7318a("analytics.max_dispatch_alarm_millis", 32400000, 32400000);
    public static na f6337i = na.m7317a("analytics.max_hits_per_dispatch", 20, 20);
    public static na f6338j = na.m7317a("analytics.max_hits_per_batch", 20, 20);
    public static na f6339k;
    public static na f6340l;
    public static na f6341m;
    public static na f6342n;
    public static na f6343o = na.m7317a("analytics.max_get_length", 2036, 2036);
    public static na f6344p = na.m7319a("analytics.batching_strategy.k", zzank.f7342b.name(), zzank.f7342b.name());
    public static na f6345q;
    public static na f6346r = na.m7317a("analytics.max_hit_length.k", 8192, 8192);
    public static na f6347s = na.m7317a("analytics.max_post_length.k", 8192, 8192);
    public static na f6348t = na.m7317a("analytics.max_batch_post_length", 8192, 8192);
    public static na f6349u;
    public static na f6350v = na.m7317a("analytics.batch_retry_interval.seconds.k", 3600, 3600);
    public static na f6351w = na.m7317a("analytics.http_connection.connect_timeout_millis", 60000, 60000);
    public static na f6352x = na.m7317a("analytics.http_connection.read_timeout_millis", 61000, 61000);
    public static na f6353y = na.m7318a("analytics.campaigns.time_limit", 86400000, 86400000);
    public static na f6354z = na.m7320a("analytics.test.disable_receiver", false, false);

    static {
        String str = "http://www.google-analytics.com";
        f6339k = na.m7319a("analytics.insecure_host", str, str);
        str = "https://ssl.google-analytics.com";
        f6340l = na.m7319a("analytics.secure_host", str, str);
        str = "/collect";
        f6341m = na.m7319a("analytics.simple_endpoint", str, str);
        str = "/batch";
        f6342n = na.m7319a("analytics.batching_endpoint", str, str);
        str = zzanq.GZIP.name();
        f6345q = na.m7319a("analytics.compression_strategy.k", str, str);
        str = "404,502";
        f6349u = na.m7319a("analytics.fallback_responses.k", str, str);
        str = "";
        f6325N = na.m7319a("analytics.first_party_experiment_id", str, str);
    }
}
