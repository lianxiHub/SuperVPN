package com.google.android.gms.internal;

import android.annotation.TargetApi;

@avl
@TargetApi(17)
public final class ia {
    private static ia f5934b = null;
    String f5935a;

    private ia() {
    }

    public static ia m6774a() {
        if (f5934b == null) {
            f5934b = new ia();
        }
        return f5934b;
    }
}
