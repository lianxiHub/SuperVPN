package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.zzbv;
import java.util.Map;

@avl
public final class asn {
    private final jk f5204a;
    private final boolean f5205b;
    private final String f5206c;

    public asn(jk jkVar, Map map) {
        this.f5204a = jkVar;
        this.f5206c = (String) map.get("forceOrientation");
        if (map.containsKey("allowOrientationChange")) {
            this.f5205b = Boolean.parseBoolean((String) map.get("allowOrientationChange"));
        } else {
            this.f5205b = true;
        }
    }

    public final void m6059a() {
        if (this.f5204a == null) {
            ii.m6521e("AdWebView is null");
            return;
        }
        int b = DeviceInfo.ORIENTATION_PORTRAIT.equalsIgnoreCase(this.f5206c) ? zzbv.zzec().mo3193b() : DeviceInfo.ORIENTATION_LANDSCAPE.equalsIgnoreCase(this.f5206c) ? zzbv.zzec().mo3191a() : this.f5205b ? -1 : zzbv.zzec().mo3210c();
        this.f5204a.mo3241b(b);
    }
}
