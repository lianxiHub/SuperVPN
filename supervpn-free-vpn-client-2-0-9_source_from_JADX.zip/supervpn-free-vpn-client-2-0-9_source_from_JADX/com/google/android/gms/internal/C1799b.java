package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.zzbv;
import com.google.android.gms.common.util.zzi;

final class C1799b implements C1798d {
    private /* synthetic */ Context f5410a;

    C1799b(Context context) {
        this.f5410a = context;
    }

    public final boolean mo3118a(zzajk com_google_android_gms_internal_zzajk) {
        afc.m4920a();
        boolean c = ie.m6797c(this.f5410a);
        boolean z = ((Boolean) zzbv.zzen().m5171a(aig.cG)).booleanValue() && com_google_android_gms_internal_zzajk.f7339d;
        if (C1793a.m4538b(this.f5410a, com_google_android_gms_internal_zzajk.f7339d) && c && !z) {
            if (!zzi.zzcl(this.f5410a)) {
                return false;
            }
            if (((Boolean) zzbv.zzen().m5171a(aig.f4576C)).booleanValue()) {
                return false;
            }
        }
        return true;
    }
}
