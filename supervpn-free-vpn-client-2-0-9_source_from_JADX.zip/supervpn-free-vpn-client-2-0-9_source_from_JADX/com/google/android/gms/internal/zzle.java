package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzd;

@avl
public final class zzle extends zza {
    public static final Creator CREATOR = new agu();
    public final int f7641a;

    public zzle(int i) {
        this.f7641a = i;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int zze = zzd.zze(parcel);
        zzd.zzc(parcel, 2, this.f7641a);
        zzd.zzai(parcel, zze);
    }
}
