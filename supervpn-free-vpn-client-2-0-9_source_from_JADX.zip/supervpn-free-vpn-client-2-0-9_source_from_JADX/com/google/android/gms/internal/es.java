package com.google.android.gms.internal;

final class es implements Runnable {
    private /* synthetic */ er f5768a;

    es(er erVar) {
        this.f5768a = erVar;
    }

    public final void run() {
        this.f5768a.zzdas = Thread.currentThread();
        this.f5768a.zzdc();
    }
}
