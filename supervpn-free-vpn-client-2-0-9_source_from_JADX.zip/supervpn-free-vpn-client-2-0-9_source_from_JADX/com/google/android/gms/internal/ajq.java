package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import com.google.android.gms.common.internal.zzbp;
import com.google.android.gms.dynamic.C1758a;
import com.google.android.gms.dynamic.C1761c;
import java.util.Map;

@avl
public final class ajq extends ajv {
    private are f4739b;
    private arh f4740c;
    private final ajs f4741d;
    private ajr f4742e;
    private boolean f4743f;
    private Object f4744g;

    private ajq(Context context, ajs com_google_android_gms_internal_ajs, sv svVar, ajt com_google_android_gms_internal_ajt) {
        super(context, com_google_android_gms_internal_ajs, null, svVar, null, com_google_android_gms_internal_ajt, null, null);
        this.f4743f = false;
        this.f4744g = new Object();
        this.f4741d = com_google_android_gms_internal_ajs;
    }

    public ajq(Context context, ajs com_google_android_gms_internal_ajs, sv svVar, are com_google_android_gms_internal_are, ajt com_google_android_gms_internal_ajt) {
        this(context, com_google_android_gms_internal_ajs, svVar, com_google_android_gms_internal_ajt);
        this.f4739b = com_google_android_gms_internal_are;
    }

    public ajq(Context context, ajs com_google_android_gms_internal_ajs, sv svVar, arh com_google_android_gms_internal_arh, ajt com_google_android_gms_internal_ajt) {
        this(context, com_google_android_gms_internal_ajs, svVar, com_google_android_gms_internal_ajt);
        this.f4740c = com_google_android_gms_internal_arh;
    }

    public final View mo2897a(OnClickListener onClickListener, boolean z) {
        synchronized (this.f4744g) {
            if (this.f4742e != null) {
                View a = this.f4742e.mo2897a(onClickListener, z);
                return a;
            }
            C1758a n;
            try {
                if (this.f4739b != null) {
                    n = this.f4739b.mo3038n();
                } else {
                    if (this.f4740c != null) {
                        n = this.f4740c.mo3054k();
                    }
                    n = null;
                }
            } catch (Throwable e) {
                ii.m6519c("Failed to call getAdChoicesContent", e);
            }
            if (n != null) {
                a = (View) C1761c.m4496a(n);
                return a;
            }
            return null;
        }
    }

    public final void mo2902a(View view, Map map) {
        zzbp.zzfx("recordImpression must be called on the main UI thread.");
        synchronized (this.f4744g) {
            this.f4727a = true;
            if (this.f4742e != null) {
                this.f4742e.mo2902a(view, map);
                this.f4741d.recordImpression();
            } else {
                try {
                    if (this.f4739b != null && !this.f4739b.mo3034j()) {
                        this.f4739b.mo3033i();
                        this.f4741d.recordImpression();
                    } else if (!(this.f4740c == null || this.f4740c.mo3051h())) {
                        this.f4740c.mo3050g();
                        this.f4741d.recordImpression();
                    }
                } catch (Throwable e) {
                    ii.m6519c("Failed to call recordImpression", e);
                }
            }
        }
    }

    public final void mo2903a(View view, Map map, Bundle bundle, View view2) {
        zzbp.zzfx("performClick must be called on the main UI thread.");
        synchronized (this.f4744g) {
            if (this.f4742e != null) {
                this.f4742e.mo2903a(view, map, bundle, view2);
                this.f4741d.onAdClicked();
            } else {
                try {
                    if (!(this.f4739b == null || this.f4739b.mo3035k())) {
                        this.f4739b.mo3023a(C1761c.m4495a((Object) view));
                        this.f4741d.onAdClicked();
                    }
                    if (!(this.f4740c == null || this.f4740c.mo3052i())) {
                        this.f4740c.mo3042a(C1761c.m4495a((Object) view));
                        this.f4741d.onAdClicked();
                    }
                } catch (Throwable e) {
                    ii.m6519c("Failed to call performClick", e);
                }
            }
        }
    }

    public final void mo2914a(View view, Map map, OnTouchListener onTouchListener, OnClickListener onClickListener) {
        synchronized (this.f4744g) {
            this.f4743f = true;
            try {
                if (this.f4739b != null) {
                    this.f4739b.mo3025b(C1761c.m4495a((Object) view));
                } else if (this.f4740c != null) {
                    this.f4740c.mo3044b(C1761c.m4495a((Object) view));
                }
            } catch (Throwable e) {
                ii.m6519c("Failed to call prepareAd", e);
            }
            this.f4743f = false;
        }
    }

    public final void m5421a(ajr com_google_android_gms_internal_ajr) {
        synchronized (this.f4744g) {
            this.f4742e = com_google_android_gms_internal_ajr;
        }
    }

    public final boolean mo2904a() {
        boolean a;
        synchronized (this.f4744g) {
            if (this.f4742e != null) {
                a = this.f4742e.mo2904a();
            } else {
                a = this.f4741d.zzco();
            }
        }
        return a;
    }

    public final void mo2907b(View view, Map map) {
        synchronized (this.f4744g) {
            try {
                if (this.f4739b != null) {
                    this.f4739b.mo3027c(C1761c.m4495a((Object) view));
                } else if (this.f4740c != null) {
                    this.f4740c.mo3046c(C1761c.m4495a((Object) view));
                }
            } catch (Throwable e) {
                ii.m6519c("Failed to call untrackView", e);
            }
        }
    }

    public final boolean m5424b() {
        boolean z;
        synchronized (this.f4744g) {
            z = this.f4743f;
        }
        return z;
    }

    public final ajr m5425c() {
        ajr com_google_android_gms_internal_ajr;
        synchronized (this.f4744g) {
            com_google_android_gms_internal_ajr = this.f4742e;
        }
        return com_google_android_gms_internal_ajr;
    }

    public final jk mo2915d() {
        return null;
    }

    public final void mo2910e() {
    }
}
