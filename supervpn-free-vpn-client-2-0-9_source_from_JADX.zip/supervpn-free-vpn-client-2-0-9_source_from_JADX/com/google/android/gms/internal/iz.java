package com.google.android.gms.internal;

import java.util.Map;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpHead;
import org.apache.http.client.methods.HttpOptions;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpTrace;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

public final class iz implements ly {
    private HttpClient f5972a;

    public iz(HttpClient httpClient) {
        this.f5972a = httpClient;
    }

    private static void m6817a(HttpEntityEnclosingRequestBase httpEntityEnclosingRequestBase, akm com_google_android_gms_internal_akm) {
        byte[] a = com_google_android_gms_internal_akm.mo3218a();
        if (a != null) {
            httpEntityEnclosingRequestBase.setEntity(new ByteArrayEntity(a));
        }
    }

    private static void m6818a(HttpUriRequest httpUriRequest, Map map) {
        for (String str : map.keySet()) {
            httpUriRequest.setHeader(str, (String) map.get(str));
        }
    }

    public final HttpResponse mo3221a(akm com_google_android_gms_internal_akm, Map map) {
        HttpUriRequest httpGet;
        HttpEntityEnclosingRequestBase httpPost;
        switch (com_google_android_gms_internal_akm.m5468c()) {
            case -1:
                httpGet = new HttpGet(com_google_android_gms_internal_akm.m5470e());
                break;
            case 0:
                httpGet = new HttpGet(com_google_android_gms_internal_akm.m5470e());
                break;
            case 1:
                httpPost = new HttpPost(com_google_android_gms_internal_akm.m5470e());
                httpPost.addHeader("Content-Type", akm.m5457h());
                m6817a(httpPost, com_google_android_gms_internal_akm);
                break;
            case 2:
                httpPost = new HttpPut(com_google_android_gms_internal_akm.m5470e());
                httpPost.addHeader("Content-Type", akm.m5457h());
                m6817a(httpPost, com_google_android_gms_internal_akm);
                break;
            case 3:
                httpGet = new HttpDelete(com_google_android_gms_internal_akm.m5470e());
                break;
            case 4:
                httpGet = new HttpHead(com_google_android_gms_internal_akm.m5470e());
                break;
            case 5:
                httpGet = new HttpOptions(com_google_android_gms_internal_akm.m5470e());
                break;
            case 6:
                httpGet = new HttpTrace(com_google_android_gms_internal_akm.m5470e());
                break;
            case 7:
                httpPost = new jz(com_google_android_gms_internal_akm.m5470e());
                httpPost.addHeader("Content-Type", akm.m5457h());
                m6817a(httpPost, com_google_android_gms_internal_akm);
                break;
            default:
                throw new IllegalStateException("Unknown request method.");
        }
        m6818a(httpGet, map);
        m6818a(httpGet, com_google_android_gms_internal_akm.mo3219b());
        HttpParams params = httpGet.getParams();
        int j = com_google_android_gms_internal_akm.m5474j();
        HttpConnectionParams.setConnectionTimeout(params, 5000);
        HttpConnectionParams.setSoTimeout(params, j);
        return this.f5972a.execute(httpGet);
    }
}
