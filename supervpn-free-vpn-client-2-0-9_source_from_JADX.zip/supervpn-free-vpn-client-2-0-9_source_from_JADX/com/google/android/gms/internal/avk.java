package com.google.android.gms.internal;

public final class avk implements avj {
    public final void mo3116a(Throwable th, String str) {
    }
}
