package com.google.android.gms.internal;

import java.util.List;

public final class wp extends wz {
    private List f7019d = null;

    public wp(td tdVar, String str, String str2, oh ohVar, int i, int i2) {
        super(tdVar, str, str2, ohVar, i, 31);
    }

    protected final void mo3344a() {
        this.b.f6480p = Long.valueOf(-1);
        this.b.f6481q = Long.valueOf(-1);
        if (this.f7019d == null) {
            this.f7019d = (List) this.c.invoke(null, new Object[]{this.a.m7654a()});
        }
        if (this.f7019d != null && this.f7019d.size() == 2) {
            synchronized (this.b) {
                this.b.f6480p = Long.valueOf(((Long) this.f7019d.get(0)).longValue());
                this.b.f6481q = Long.valueOf(((Long) this.f7019d.get(1)).longValue());
            }
        }
    }
}
