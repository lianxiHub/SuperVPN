package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Application;
import android.app.Application.ActivityLifecycleCallbacks;
import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.PowerManager;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.ViewTreeObserver.OnScrollChangedListener;
import android.view.Window;
import android.view.WindowManager;
import com.google.android.gms.ads.internal.zzbv;
import java.lang.ref.WeakReference;
import java.util.HashSet;
import java.util.Iterator;

@avl
@TargetApi(14)
public final class aby implements ActivityLifecycleCallbacks, OnAttachStateChangeListener, OnGlobalLayoutListener, OnScrollChangedListener {
    private static final long f4240a = ((Long) zzbv.zzen().m5171a(aig.aW)).longValue();
    private final Context f4241b;
    private Application f4242c;
    private final WindowManager f4243d;
    private final PowerManager f4244e;
    private final KeyguardManager f4245f;
    private BroadcastReceiver f4246g;
    private WeakReference f4247h;
    private WeakReference f4248i;
    private acd f4249j;
    private hw f4250k = new hw(f4240a);
    private boolean f4251l = false;
    private int f4252m = -1;
    private HashSet f4253n = new HashSet();
    private DisplayMetrics f4254o;

    public aby(Context context, View view) {
        this.f4241b = context.getApplicationContext();
        this.f4243d = (WindowManager) context.getSystemService("window");
        this.f4244e = (PowerManager) this.f4241b.getSystemService("power");
        this.f4245f = (KeyguardManager) context.getSystemService("keyguard");
        if (this.f4241b instanceof Application) {
            this.f4242c = (Application) this.f4241b;
            this.f4249j = new acd((Application) this.f4241b, this);
        }
        this.f4254o = context.getResources().getDisplayMetrics();
        View view2 = this.f4248i != null ? (View) this.f4248i.get() : null;
        if (view2 != null) {
            view2.removeOnAttachStateChangeListener(this);
            m4740b(view2);
        }
        this.f4248i = new WeakReference(view);
        if (view != null) {
            if (zzbv.zzec().mo3209a(view)) {
                m4736a(view);
            }
            view.addOnAttachStateChangeListener(this);
        }
    }

    private final Rect m4733a(Rect rect) {
        return new Rect(m4738b(rect.left), m4738b(rect.top), m4738b(rect.right), m4738b(rect.bottom));
    }

    private final void m4734a(int i) {
        if (this.f4253n.size() != 0 && this.f4248i != null) {
            View view = (View) this.f4248i.get();
            Object obj = i == 1 ? 1 : null;
            Object obj2 = view == null ? 1 : null;
            Rect rect = new Rect();
            Rect rect2 = new Rect();
            boolean z = false;
            Rect rect3 = new Rect();
            boolean z2 = false;
            Rect rect4 = new Rect();
            Rect rect5 = new Rect();
            rect5.right = this.f4243d.getDefaultDisplay().getWidth();
            rect5.bottom = this.f4243d.getDefaultDisplay().getHeight();
            int[] iArr = new int[2];
            int[] iArr2 = new int[2];
            if (view != null) {
                z = view.getGlobalVisibleRect(rect2);
                z2 = view.getLocalVisibleRect(rect3);
                view.getHitRect(rect4);
                try {
                    view.getLocationOnScreen(iArr);
                    view.getLocationInWindow(iArr2);
                } catch (Throwable e) {
                    ii.m6517b("Failure getting view location.", e);
                }
                rect.left = iArr[0];
                rect.top = iArr[1];
                rect.right = rect.left + view.getWidth();
                rect.bottom = rect.top + view.getHeight();
            }
            int windowVisibility = view != null ? view.getWindowVisibility() : 8;
            if (this.f4252m != -1) {
                windowVisibility = this.f4252m;
            }
            boolean z3 = obj2 == null && zzbv.zzea().m6643a(view, this.f4244e, this.f4245f) && z && z2 && windowVisibility == 0;
            if (obj != null && !this.f4250k.m6766a() && z3 == this.f4251l) {
                return;
            }
            if (z3 || this.f4251l || i != 1) {
                acb com_google_android_gms_internal_acb = new acb(zzbv.zzeg().elapsedRealtime(), this.f4244e.isScreenOn(), view != null ? zzbv.zzec().mo3209a(view) : false, view != null ? view.getWindowVisibility() : 8, m4733a(rect5), m4733a(rect), m4733a(rect2), z, m4733a(rect3), z2, m4733a(rect4), this.f4254o.density, z3);
                Iterator it = this.f4253n.iterator();
                while (it.hasNext()) {
                    ((acc) it.next()).mo3181a(com_google_android_gms_internal_acb);
                }
                this.f4251l = z3;
            }
        }
    }

    private final void m4735a(Activity activity, int i) {
        if (this.f4248i != null) {
            Window window = activity.getWindow();
            if (window != null) {
                View peekDecorView = window.peekDecorView();
                View view = (View) this.f4248i.get();
                if (view != null && peekDecorView != null && view.getRootView() == peekDecorView.getRootView()) {
                    this.f4252m = i;
                }
            }
        }
    }

    private final void m4736a(View view) {
        ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
        if (viewTreeObserver.isAlive()) {
            this.f4247h = new WeakReference(viewTreeObserver);
            viewTreeObserver.addOnScrollChangedListener(this);
            viewTreeObserver.addOnGlobalLayoutListener(this);
        }
        if (this.f4246g == null) {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.intent.action.SCREEN_ON");
            intentFilter.addAction("android.intent.action.SCREEN_OFF");
            intentFilter.addAction("android.intent.action.USER_PRESENT");
            this.f4246g = new aca(this);
            this.f4241b.registerReceiver(this.f4246g, intentFilter);
        }
        if (this.f4242c != null) {
            try {
                this.f4242c.registerActivityLifecycleCallbacks(this.f4249j);
            } catch (Throwable e) {
                ii.m6517b("Error registering activity lifecycle callbacks.", e);
            }
        }
    }

    private final int m4738b(int i) {
        return (int) (((float) i) / this.f4254o.density);
    }

    private final void m4739b() {
        zzbv.zzea();
        gd.f5832a.post(new abz(this));
    }

    private final void m4740b(View view) {
        ViewTreeObserver viewTreeObserver;
        try {
            if (this.f4247h != null) {
                viewTreeObserver = (ViewTreeObserver) this.f4247h.get();
                if (viewTreeObserver != null && viewTreeObserver.isAlive()) {
                    viewTreeObserver.removeOnScrollChangedListener(this);
                    viewTreeObserver.removeGlobalOnLayoutListener(this);
                }
                this.f4247h = null;
            }
        } catch (Throwable e) {
            ii.m6517b("Error while unregistering listeners from the last ViewTreeObserver.", e);
        }
        try {
            viewTreeObserver = view.getViewTreeObserver();
            if (viewTreeObserver.isAlive()) {
                viewTreeObserver.removeOnScrollChangedListener(this);
                viewTreeObserver.removeGlobalOnLayoutListener(this);
            }
        } catch (Throwable e2) {
            ii.m6517b("Error while unregistering listeners from the ViewTreeObserver.", e2);
        }
        if (this.f4246g != null) {
            try {
                this.f4241b.unregisterReceiver(this.f4246g);
            } catch (Throwable e22) {
                ii.m6517b("Failed trying to unregister the receiver", e22);
            } catch (Throwable e222) {
                zzbv.zzee().m6466a(e222, "ActiveViewUnit.stopScreenStatusMonitoring");
            }
            this.f4246g = null;
        }
        if (this.f4242c != null) {
            try {
                this.f4242c.unregisterActivityLifecycleCallbacks(this.f4249j);
            } catch (Throwable e2222) {
                ii.m6517b("Error registering activity lifecycle callbacks.", e2222);
            }
        }
    }

    public final void m4741a() {
        m4734a(4);
    }

    public final void m4742a(acc com_google_android_gms_internal_acc) {
        this.f4253n.add(com_google_android_gms_internal_acc);
        m4734a(3);
    }

    public final void m4743b(acc com_google_android_gms_internal_acc) {
        this.f4253n.remove(com_google_android_gms_internal_acc);
    }

    public final void onActivityCreated(Activity activity, Bundle bundle) {
        m4735a(activity, 0);
        m4734a(3);
        m4739b();
    }

    public final void onActivityDestroyed(Activity activity) {
        m4734a(3);
        m4739b();
    }

    public final void onActivityPaused(Activity activity) {
        m4735a(activity, 4);
        m4734a(3);
        m4739b();
    }

    public final void onActivityResumed(Activity activity) {
        m4735a(activity, 0);
        m4734a(3);
        m4739b();
    }

    public final void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
        m4734a(3);
        m4739b();
    }

    public final void onActivityStarted(Activity activity) {
        m4735a(activity, 0);
        m4734a(3);
        m4739b();
    }

    public final void onActivityStopped(Activity activity) {
        m4734a(3);
        m4739b();
    }

    public final void onGlobalLayout() {
        m4734a(2);
        m4739b();
    }

    public final void onScrollChanged() {
        m4734a(1);
    }

    public final void onViewAttachedToWindow(View view) {
        this.f4252m = -1;
        m4736a(view);
        m4734a(3);
    }

    public final void onViewDetachedFromWindow(View view) {
        this.f4252m = -1;
        m4734a(3);
        m4739b();
        m4740b(view);
    }
}
