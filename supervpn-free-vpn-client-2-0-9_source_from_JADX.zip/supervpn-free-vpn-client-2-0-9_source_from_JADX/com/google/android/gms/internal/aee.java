package com.google.android.gms.internal;

import android.content.Context;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.zzbv;
import com.google.android.gms.dynamic.C1761c;
import com.google.android.gms.dynamite.DynamiteModule;
import com.google.android.gms.dynamite.DynamiteModule.zzc;
import com.google.android.gms.dynamite.descriptors.com.google.android.gms.ads.dynamite.ModuleDescriptor;

@avl
public final class aee {
    aat f4397a;
    boolean f4398b;

    public aee(Context context) {
        aig.m5174a(context);
        if (((Boolean) zzbv.zzen().m5171a(aig.cE)).booleanValue()) {
            try {
                this.f4397a = aau.m4637a(DynamiteModule.m4505a(context, DynamiteModule.f4075a, ModuleDescriptor.MODULE_ID).m4516a("com.google.android.gms.ads.clearcut.DynamiteClearcutLogger"));
                C1761c.m4495a((Object) context);
                this.f4397a.mo2755a(C1761c.m4495a((Object) context), "GMA_SDK");
                this.f4398b = true;
                return;
            } catch (zzc e) {
            } catch (RemoteException e2) {
            } catch (NullPointerException e3) {
            }
        } else {
            return;
        }
        et.m6522a("Cannot dynamite load clearcut");
    }

    public aee(Context context, String str, String str2) {
        aig.m5174a(context);
        try {
            this.f4397a = aau.m4637a(DynamiteModule.m4505a(context, DynamiteModule.f4075a, ModuleDescriptor.MODULE_ID).m4516a("com.google.android.gms.ads.clearcut.DynamiteClearcutLogger"));
            C1761c.m4495a((Object) context);
            this.f4397a.mo2756a(C1761c.m4495a((Object) context), str, null);
            this.f4398b = true;
            return;
        } catch (zzc e) {
        } catch (RemoteException e2) {
        } catch (NullPointerException e3) {
        }
        et.m6522a("Cannot dynamite load clearcut");
    }

    public final aeg m4851a(byte[] bArr) {
        return new aeg(this, bArr);
    }
}
