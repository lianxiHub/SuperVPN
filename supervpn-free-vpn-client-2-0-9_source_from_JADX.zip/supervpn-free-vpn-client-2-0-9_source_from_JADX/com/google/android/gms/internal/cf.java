package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.dynamic.C1758a;

public final class cf extends xq implements ce {
    cf(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.reward.client.IRewardedVideoAdCreator");
    }

    public final IBinder mo3130a(C1758a c1758a, aqs com_google_android_gms_internal_aqs, int i) {
        Parcel zzax = zzax();
        zm.m8271a(zzax, (IInterface) c1758a);
        zm.m8271a(zzax, (IInterface) com_google_android_gms_internal_aqs);
        zzax.writeInt(11200000);
        zzax = zza(1, zzax);
        IBinder readStrongBinder = zzax.readStrongBinder();
        zzax.recycle();
        return readStrongBinder;
    }
}
