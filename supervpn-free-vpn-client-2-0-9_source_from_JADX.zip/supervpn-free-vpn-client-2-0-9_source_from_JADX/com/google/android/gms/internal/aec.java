package com.google.android.gms.internal;

@avl
final class aec implements Runnable {
    private final int f4395a;
    private /* synthetic */ aeb f4396b;

    public aec(aeb com_google_android_gms_internal_aeb, int i) {
        this.f4396b = com_google_android_gms_internal_aeb;
        this.f4395a = i;
    }

    public final void run() {
        synchronized (this.f4396b) {
            if (this.f4396b.f4393g == this.f4395a) {
                this.f4396b.m4845c();
            }
        }
    }
}
