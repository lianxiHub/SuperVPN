package com.google.android.gms.internal;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import com.facebook.internal.ServerProtocol;
import com.google.android.gms.analytics.C1724c;
import com.google.android.gms.analytics.C1745s;
import com.google.android.gms.common.internal.zzbp;
import com.google.android.gms.common.util.zzd;

public class lo {
    private final lr f3958a;

    protected lo(lr lrVar) {
        zzbp.zzu(lrVar);
        this.f3958a = lrVar;
    }

    private static String m4343a(Object obj) {
        return obj == null ? "" : obj instanceof String ? (String) obj : obj instanceof Boolean ? obj == Boolean.TRUE ? ServerProtocol.DIALOG_RETURN_SCOPES_TRUE : "false" : obj instanceof Throwable ? ((Throwable) obj).toString() : obj.toString();
    }

    private final void mo3297a(int i, String str, Object obj, Object obj2, Object obj3) {
        nj njVar = null;
        if (this.f3958a != null) {
            njVar = this.f3958a.m7166f();
        }
        if (njVar != null) {
            String str2 = (String) mz.f6330b.m7321a();
            if (Log.isLoggable(str2, i)) {
                Log.println(i, str2, m4345c(str, obj, obj2, obj3));
            }
            if (i >= 5) {
                njVar.mo3297a(i, str, obj, obj2, obj3);
                return;
            }
            return;
        }
        String str3 = (String) mz.f6330b.m7321a();
        if (Log.isLoggable(str3, i)) {
            Log.println(i, str3, m4345c(str, obj, obj2, obj3));
        }
    }

    protected static String m4345c(String str, Object obj, Object obj2, Object obj3) {
        if (str == null) {
            Object obj4 = "";
        }
        Object a = m4343a(obj);
        Object a2 = m4343a(obj2);
        Object a3 = m4343a(obj3);
        StringBuilder stringBuilder = new StringBuilder();
        String str2 = "";
        if (!TextUtils.isEmpty(obj4)) {
            stringBuilder.append(obj4);
            str2 = ": ";
        }
        if (!TextUtils.isEmpty(a)) {
            stringBuilder.append(str2);
            stringBuilder.append(a);
            str2 = ", ";
        }
        if (!TextUtils.isEmpty(a2)) {
            stringBuilder.append(str2);
            stringBuilder.append(a2);
            str2 = ", ";
        }
        if (!TextUtils.isEmpty(a3)) {
            stringBuilder.append(str2);
            stringBuilder.append(a3);
        }
        return stringBuilder.toString();
    }

    public static boolean m4346w() {
        return Log.isLoggable((String) mz.f6330b.m7321a(), 2);
    }

    public final void m4347a(String str, Object obj) {
        mo3297a(2, str, obj, null, null);
    }

    public final void m4348a(String str, Object obj, Object obj2) {
        mo3297a(2, str, obj, obj2, null);
    }

    public final void m4349a(String str, Object obj, Object obj2, Object obj3) {
        mo3297a(3, str, obj, obj2, obj3);
    }

    public final void m4350b(String str) {
        mo3297a(2, str, null, null, null);
    }

    public final void m4351b(String str, Object obj) {
        mo3297a(3, str, obj, null, null);
    }

    public final void m4352b(String str, Object obj, Object obj2) {
        mo3297a(3, str, obj, obj2, null);
    }

    public final void m4353b(String str, Object obj, Object obj2, Object obj3) {
        mo3297a(5, str, obj, obj2, obj3);
    }

    public final void m4354c(String str) {
        mo3297a(3, str, null, null, null);
    }

    public final void m4355c(String str, Object obj) {
        mo3297a(4, str, obj, null, null);
    }

    public final void m4356c(String str, Object obj, Object obj2) {
        mo3297a(5, str, obj, obj2, null);
    }

    public final void m4357d(String str) {
        mo3297a(4, str, null, null, null);
    }

    public final void m4358d(String str, Object obj) {
        mo3297a(5, str, obj, null, null);
    }

    public final void m4359d(String str, Object obj, Object obj2) {
        mo3297a(6, str, obj, obj2, null);
    }

    public final void m4360e(String str) {
        mo3297a(5, str, null, null, null);
    }

    public final void m4361e(String str, Object obj) {
        mo3297a(6, str, obj, null, null);
    }

    public final void m4362f(String str) {
        mo3297a(6, str, null, null, null);
    }

    public final lr m4363h() {
        return this.f3958a;
    }

    protected final zzd m4364i() {
        return this.f3958a.m7163c();
    }

    protected final Context m4365j() {
        return this.f3958a.m7161a();
    }

    protected final nj m4366k() {
        return this.f3958a.m7165e();
    }

    protected final mq m4367l() {
        return this.f3958a.m7164d();
    }

    protected final C1745s m4368m() {
        return this.f3958a.m7167g();
    }

    public final C1724c m4369n() {
        return this.f3958a.m7170j();
    }

    protected final lh m4370o() {
        return this.f3958a.m7168h();
    }

    protected final mv m4371p() {
        return this.f3958a.m7169i();
    }

    protected final nz m4372q() {
        return this.f3958a.m7171k();
    }

    protected final nn m4373r() {
        return this.f3958a.m7172l();
    }

    protected final mj m4374s() {
        return this.f3958a.m7175o();
    }

    protected final lg m4375t() {
        return this.f3958a.m7174n();
    }

    protected final md m4376u() {
        return this.f3958a.m7176p();
    }

    protected final mu m4377v() {
        return this.f3958a.m7177q();
    }
}
