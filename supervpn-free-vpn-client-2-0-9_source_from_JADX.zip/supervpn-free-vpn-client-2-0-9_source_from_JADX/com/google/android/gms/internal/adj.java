package com.google.android.gms.internal;

import java.nio.charset.Charset;
import java.security.MessageDigest;

@avl
public final class adj extends ada {
    private MessageDigest f4364b;
    private final int f4365c;
    private final int f4366d;

    public adj(int i) {
        int i2 = i / 8;
        if (i % 8 > 0) {
            i2++;
        }
        this.f4365c = i2;
        this.f4366d = i;
    }

    public final byte[] mo2776a(String str) {
        byte[] bArr;
        synchronized (this.a) {
            this.f4364b = m4808a();
            if (this.f4364b == null) {
                bArr = new byte[0];
            } else {
                this.f4364b.reset();
                this.f4364b.update(str.getBytes(Charset.forName(WebRequest.CHARSET_UTF_8)));
                Object digest = this.f4364b.digest();
                bArr = new byte[(digest.length > this.f4365c ? this.f4365c : digest.length)];
                System.arraycopy(digest, 0, bArr, 0, bArr.length);
                if (this.f4366d % 8 > 0) {
                    int i;
                    long j = 0;
                    for (i = 0; i < bArr.length; i++) {
                        if (i > 0) {
                            j <<= 8;
                        }
                        j += (long) (bArr[i] & 255);
                    }
                    j >>>= 8 - (this.f4366d % 8);
                    for (i = this.f4365c - 1; i >= 0; i--) {
                        bArr[i] = (byte) ((int) (255 & j));
                        j >>>= 8;
                    }
                }
            }
        }
        return bArr;
    }
}
