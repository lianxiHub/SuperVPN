package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.List;

final class ys extends xd {
    private static final ys f7103a;
    private final List f7104b;

    static {
        xd ysVar = new ys();
        f7103a = ysVar;
        ysVar.mo3348b();
    }

    ys() {
        this(new ArrayList(10));
    }

    private ys(List list) {
        this.f7104b = list;
    }

    public static ys m8187d() {
        return f7103a;
    }

    public final /* synthetic */ yg mo3372a(int i) {
        if (i < size()) {
            throw new IllegalArgumentException();
        }
        List arrayList = new ArrayList(i);
        arrayList.addAll(this.f7104b);
        return new ys(arrayList);
    }

    public final void add(int i, Object obj) {
        m8101c();
        this.f7104b.add(i, obj);
        this.modCount++;
    }

    public final Object get(int i) {
        return this.f7104b.get(i);
    }

    public final Object remove(int i) {
        m8101c();
        Object remove = this.f7104b.remove(i);
        this.modCount++;
        return remove;
    }

    public final Object set(int i, Object obj) {
        m8101c();
        Object obj2 = this.f7104b.set(i, obj);
        this.modCount++;
        return obj2;
    }

    public final int size() {
        return this.f7104b.size();
    }
}
