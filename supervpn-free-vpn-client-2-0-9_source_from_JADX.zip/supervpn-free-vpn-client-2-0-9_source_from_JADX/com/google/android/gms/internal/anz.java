package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.zzbv;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

@avl
public final class anz implements Iterable {
    private final List f4919a = new LinkedList();

    public static boolean m5600a(jk jkVar) {
        anx c = m5602c(jkVar);
        if (c == null) {
            return false;
        }
        c.f4916b.mo2967a();
        return true;
    }

    public static boolean m5601b(jk jkVar) {
        return m5602c(jkVar) != null;
    }

    private static anx m5602c(jk jkVar) {
        Iterator it = zzbv.zzex().iterator();
        while (it.hasNext()) {
            anx com_google_android_gms_internal_anx = (anx) it.next();
            if (com_google_android_gms_internal_anx.f4915a == jkVar) {
                return com_google_android_gms_internal_anx;
            }
        }
        return null;
    }

    public final int m5603a() {
        return this.f4919a.size();
    }

    public final void m5604a(anx com_google_android_gms_internal_anx) {
        this.f4919a.add(com_google_android_gms_internal_anx);
    }

    public final void m5605b(anx com_google_android_gms_internal_anx) {
        this.f4919a.remove(com_google_android_gms_internal_anx);
    }

    public final Iterator iterator() {
        return this.f4919a.iterator();
    }
}
