package com.google.android.gms.internal;

import android.content.Context;
import android.content.pm.PackageManager;
import com.google.android.gms.common.util.zzp;
import java.lang.reflect.InvocationTargetException;

public final class qe {
    private static Context f6571a;
    private static Boolean f6572b;

    public static synchronized boolean m7491a(Context context) {
        boolean booleanValue;
        synchronized (qe.class) {
            Context applicationContext = context.getApplicationContext();
            if (f6571a == null || f6572b == null || f6571a != applicationContext) {
                f6572b = null;
                if (zzp.isAtLeastO()) {
                    try {
                        f6572b = (Boolean) PackageManager.class.getDeclaredMethod("isInstantApp", new Class[0]).invoke(applicationContext.getPackageManager(), new Object[0]);
                    } catch (NoSuchMethodException e) {
                        f6572b = Boolean.valueOf(false);
                        f6571a = applicationContext;
                        booleanValue = f6572b.booleanValue();
                        return booleanValue;
                    } catch (InvocationTargetException e2) {
                        f6572b = Boolean.valueOf(false);
                        f6571a = applicationContext;
                        booleanValue = f6572b.booleanValue();
                        return booleanValue;
                    } catch (IllegalAccessException e3) {
                        f6572b = Boolean.valueOf(false);
                        f6571a = applicationContext;
                        booleanValue = f6572b.booleanValue();
                        return booleanValue;
                    }
                }
                try {
                    context.getClassLoader().loadClass("com.google.android.instantapps.supervisor.InstantAppsRuntime");
                    f6572b = Boolean.valueOf(true);
                } catch (ClassNotFoundException e4) {
                    f6572b = Boolean.valueOf(false);
                }
                f6571a = applicationContext;
                booleanValue = f6572b.booleanValue();
            } else {
                booleanValue = f6572b.booleanValue();
            }
        }
        return booleanValue;
    }
}
