package com.google.android.gms.internal;

public final class xw extends xc {
    private xu f7072a;

    public xw(xu xuVar) {
        this.f7072a = xuVar;
    }
}
