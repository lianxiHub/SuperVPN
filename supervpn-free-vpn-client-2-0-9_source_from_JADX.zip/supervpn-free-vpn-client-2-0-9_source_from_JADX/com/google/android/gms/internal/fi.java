package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences.Editor;

final class fi extends fu {
    private /* synthetic */ Context f5798a;

    fi(Context context) {
        this.f5798a = context;
        super();
    }

    public final void zzdc() {
        Editor edit = this.f5798a.getSharedPreferences("admob", 0).edit();
        edit.remove("native_advanced_settings");
        edit.apply();
    }
}
