package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;

public final class C1815r extends xq implements C1795p {
    C1815r(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.request.IAdRequestService");
    }

    public final zzaao mo2964a(zzaak com_google_android_gms_internal_zzaak) {
        Parcel zzax = zzax();
        zm.m8272a(zzax, (Parcelable) com_google_android_gms_internal_zzaak);
        Parcel zza = zza(1, zzax);
        zzaao com_google_android_gms_internal_zzaao = (zzaao) zm.m8270a(zza, zzaao.CREATOR);
        zza.recycle();
        return com_google_android_gms_internal_zzaao;
    }

    public final void mo2965a(zzaak com_google_android_gms_internal_zzaak, C1810s c1810s) {
        Parcel zzax = zzax();
        zm.m8272a(zzax, (Parcelable) com_google_android_gms_internal_zzaak);
        zm.m8271a(zzax, (IInterface) c1810s);
        zzb(2, zzax);
    }

    public final void mo2966a(zzabd com_google_android_gms_internal_zzabd, C1859v c1859v) {
        Parcel zzax = zzax();
        zm.m8272a(zzax, (Parcelable) com_google_android_gms_internal_zzabd);
        zm.m8271a(zzax, (IInterface) c1859v);
        zzb(3, zzax);
    }
}
