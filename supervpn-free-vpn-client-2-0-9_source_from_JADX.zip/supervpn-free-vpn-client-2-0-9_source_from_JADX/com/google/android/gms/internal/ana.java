package com.google.android.gms.internal;

import java.util.Map;

final class ana implements anb {
    ana() {
    }

    public final void zza(jk jkVar, Map map) {
        ajp D = jkVar.mo3227D();
        if (D != null) {
            D.mo2895a();
        }
    }
}
