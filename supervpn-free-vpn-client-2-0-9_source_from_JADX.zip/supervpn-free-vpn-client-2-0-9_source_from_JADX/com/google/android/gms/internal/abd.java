package com.google.android.gms.internal;

import android.view.View;
import java.lang.ref.WeakReference;

public final class abd implements acm {
    private WeakReference f4205a;

    public abd(ajr com_google_android_gms_internal_ajr) {
        this.f4205a = new WeakReference(com_google_android_gms_internal_ajr);
    }

    public final View mo2763a() {
        ajr com_google_android_gms_internal_ajr = (ajr) this.f4205a.get();
        return com_google_android_gms_internal_ajr != null ? com_google_android_gms_internal_ajr.mo2911f() : null;
    }

    public final boolean mo2764b() {
        return this.f4205a.get() == null;
    }

    public final acm mo2765c() {
        return new abf((ajr) this.f4205a.get());
    }
}
