package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.zzam;

public final class sl extends xq implements sk {
    sl(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.signin.internal.ISignInService");
    }

    public final void mo3307a(int i) {
        Parcel zzax = zzax();
        zzax.writeInt(i);
        zzb(7, zzax);
    }

    public final void mo3308a(zzam com_google_android_gms_common_internal_zzam, int i, boolean z) {
        Parcel zzax = zzax();
        zm.m8271a(zzax, (IInterface) com_google_android_gms_common_internal_zzam);
        zzax.writeInt(i);
        zm.m8273a(zzax, z);
        zzb(9, zzax);
    }

    public final void mo3309a(zzcpx com_google_android_gms_internal_zzcpx, si siVar) {
        Parcel zzax = zzax();
        zm.m8272a(zzax, (Parcelable) com_google_android_gms_internal_zzcpx);
        zm.m8271a(zzax, (IInterface) siVar);
        zzb(12, zzax);
    }
}
