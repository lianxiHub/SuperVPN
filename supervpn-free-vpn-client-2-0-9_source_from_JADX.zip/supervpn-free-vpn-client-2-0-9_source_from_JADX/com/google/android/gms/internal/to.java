package com.google.android.gms.internal;

import java.io.IOException;

public final class to {

    public static final class C1833a extends xu implements yp {
        private static final C1833a f6847g;
        private static volatile yr f6848h;
        private int f6849d;
        private C1837c f6850e;
        private zzedk f6851f = zzedk.f7556a;

        public static final class C1832a extends xv implements yp {
            private C1832a() {
                super(C1833a.f6847g);
            }

            public final C1832a m7794a(int i) {
                m7683b();
                ((C1833a) this.a).m7798a(0);
                return this;
            }

            public final C1832a m7795a(C1837c c1837c) {
                m7683b();
                ((C1833a) this.a).m7802a(c1837c);
                return this;
            }

            public final C1832a m7796a(zzedk com_google_android_gms_internal_zzedk) {
                m7683b();
                ((C1833a) this.a).m7803b(com_google_android_gms_internal_zzedk);
                return this;
            }
        }

        static {
            xu c1833a = new C1833a();
            f6847g = c1833a;
            c1833a.mo3331a(yb.f7083d, null, null);
            c1833a.f6809b.m8217b();
        }

        private C1833a() {
        }

        public static C1833a m7797a(zzedk com_google_android_gms_internal_zzedk) {
            return (C1833a) xu.m7699a(f6847g, com_google_android_gms_internal_zzedk);
        }

        private final void m7798a(int i) {
            this.f6849d = i;
        }

        private final void m7802a(C1837c c1837c) {
            if (c1837c == null) {
                throw new NullPointerException();
            }
            this.f6850e = c1837c;
        }

        private final void m7803b(zzedk com_google_android_gms_internal_zzedk) {
            if (com_google_android_gms_internal_zzedk == null) {
                throw new NullPointerException();
            }
            this.f6851f = com_google_android_gms_internal_zzedk;
        }

        public static C1832a m7804c() {
            xu xuVar = f6847g;
            xv xvVar = (xv) xuVar.mo3331a(yb.f7085f, null, null);
            xvVar.m7682a(xuVar);
            return (C1832a) xvVar;
        }

        public final int m7806a() {
            return this.f6849d;
        }

        protected final Object mo3331a(int i, Object obj, Object obj2) {
            boolean z = true;
            switch (tp.f6858a[i - 1]) {
                case 1:
                    return new C1833a();
                case 2:
                    return f6847g;
                case 3:
                    return null;
                case 4:
                    return new C1832a();
                case 5:
                    yc ycVar = (yc) obj;
                    C1833a c1833a = (C1833a) obj2;
                    this.f6849d = ycVar.mo3364a(this.f6849d != 0, this.f6849d, c1833a.f6849d != 0, c1833a.f6849d);
                    this.f6850e = (C1837c) ycVar.mo3366a(this.f6850e, c1833a.f6850e);
                    boolean z2 = this.f6851f != zzedk.f7556a;
                    zzedk com_google_android_gms_internal_zzedk = this.f6851f;
                    if (c1833a.f6851f == zzedk.f7556a) {
                        z = false;
                    }
                    this.f6851f = ycVar.mo3368a(z2, com_google_android_gms_internal_zzedk, z, c1833a.f6851f);
                    return this;
                case 6:
                    xk xkVar = (xk) obj;
                    xp xpVar = (xp) obj2;
                    boolean z3 = false;
                    while (!z3) {
                        try {
                            int a = xkVar.mo3350a();
                            switch (a) {
                                case 0:
                                    z3 = true;
                                    break;
                                case 8:
                                    this.f6849d = xkVar.mo3353b();
                                    break;
                                case 18:
                                    xv xvVar;
                                    if (this.f6850e != null) {
                                        xu xuVar = this.f6850e;
                                        xv xvVar2 = (xv) xuVar.mo3331a(yb.f7085f, null, null);
                                        xvVar2.m7682a(xuVar);
                                        xvVar = (C1836a) xvVar2;
                                    } else {
                                        xvVar = null;
                                    }
                                    this.f6850e = (C1837c) xkVar.mo3351a(C1837c.m7818a(), xpVar);
                                    if (xvVar == null) {
                                        break;
                                    }
                                    xvVar.m7682a(this.f6850e);
                                    this.f6850e = (C1837c) xvVar.m7684c();
                                    break;
                                case 26:
                                    this.f6851f = xkVar.mo3357d();
                                    break;
                                default:
                                    if (!xkVar.mo3354b(a)) {
                                        z3 = true;
                                        break;
                                    }
                                    break;
                            }
                        } catch (zzeer e) {
                            throw new RuntimeException(e.m8566a(this));
                        } catch (IOException e2) {
                            throw new RuntimeException(new zzeer(e2.getMessage()).m8566a(this));
                        }
                    }
                    break;
                case 7:
                    break;
                case 8:
                    if (f6848h == null) {
                        synchronized (C1833a.class) {
                            if (f6848h == null) {
                                f6848h = new xw(f6847g);
                            }
                        }
                    }
                    return f6848h;
                default:
                    throw new UnsupportedOperationException();
            }
            return f6847g;
        }

        public final void mo3332a(zzedw com_google_android_gms_internal_zzedw) {
            if (this.f6849d != 0) {
                com_google_android_gms_internal_zzedw.mo3410b(1, this.f6849d);
            }
            if (this.f6850e != null) {
                com_google_android_gms_internal_zzedw.mo3401a(2, this.f6850e == null ? C1837c.m7818a() : this.f6850e);
            }
            if (!this.f6851f.m8504b()) {
                com_google_android_gms_internal_zzedw.mo3402a(3, this.f6851f);
            }
        }

        public final zzedk m7809b() {
            return this.f6851f;
        }

        public final int mo3333d() {
            int i = this.c;
            if (i == -1) {
                i = 0;
                if (this.f6849d != 0) {
                    i = zzedw.m8528c(1, this.f6849d) + 0;
                }
                if (this.f6850e != null) {
                    i += zzedw.m8523b(2, this.f6850e == null ? C1837c.m7818a() : this.f6850e);
                }
                if (!this.f6851f.m8504b()) {
                    i += zzedw.m8524b(3, this.f6851f);
                }
                this.c = i;
            }
            return i;
        }
    }

    public static final class C1835b extends xu implements yp {
        private static final C1835b f6852f;
        private static volatile yr f6853g;
        private C1837c f6854d;
        private int f6855e;

        public static final class C1834a extends xv implements yp {
            private C1834a() {
                super(C1835b.f6852f);
            }
        }

        static {
            xu c1835b = new C1835b();
            f6852f = c1835b;
            c1835b.mo3331a(yb.f7083d, null, null);
            c1835b.f6809b.m8217b();
        }

        private C1835b() {
        }

        public static C1835b m7811a(zzedk com_google_android_gms_internal_zzedk) {
            return (C1835b) xu.m7699a(f6852f, com_google_android_gms_internal_zzedk);
        }

        public final C1837c m7813a() {
            return this.f6854d == null ? C1837c.m7818a() : this.f6854d;
        }

        protected final Object mo3331a(int i, Object obj, Object obj2) {
            boolean z = true;
            switch (tp.f6858a[i - 1]) {
                case 1:
                    return new C1835b();
                case 2:
                    return f6852f;
                case 3:
                    return null;
                case 4:
                    return new C1834a();
                case 5:
                    yc ycVar = (yc) obj;
                    C1835b c1835b = (C1835b) obj2;
                    this.f6854d = (C1837c) ycVar.mo3366a(this.f6854d, c1835b.f6854d);
                    boolean z2 = this.f6855e != 0;
                    int i2 = this.f6855e;
                    if (c1835b.f6855e == 0) {
                        z = false;
                    }
                    this.f6855e = ycVar.mo3364a(z2, i2, z, c1835b.f6855e);
                    return this;
                case 6:
                    xk xkVar = (xk) obj;
                    xp xpVar = (xp) obj2;
                    boolean z3 = false;
                    while (!z3) {
                        try {
                            int a = xkVar.mo3350a();
                            switch (a) {
                                case 0:
                                    z3 = true;
                                    break;
                                case 10:
                                    xv xvVar;
                                    if (this.f6854d != null) {
                                        xu xuVar = this.f6854d;
                                        xv xvVar2 = (xv) xuVar.mo3331a(yb.f7085f, null, null);
                                        xvVar2.m7682a(xuVar);
                                        xvVar = (C1836a) xvVar2;
                                    } else {
                                        xvVar = null;
                                    }
                                    this.f6854d = (C1837c) xkVar.mo3351a(C1837c.m7818a(), xpVar);
                                    if (xvVar == null) {
                                        break;
                                    }
                                    xvVar.m7682a(this.f6854d);
                                    this.f6854d = (C1837c) xvVar.m7684c();
                                    break;
                                case 16:
                                    this.f6855e = xkVar.mo3353b();
                                    break;
                                default:
                                    if (!xkVar.mo3354b(a)) {
                                        z3 = true;
                                        break;
                                    }
                                    break;
                            }
                        } catch (zzeer e) {
                            throw new RuntimeException(e.m8566a(this));
                        } catch (IOException e2) {
                            throw new RuntimeException(new zzeer(e2.getMessage()).m8566a(this));
                        }
                    }
                    break;
                case 7:
                    break;
                case 8:
                    if (f6853g == null) {
                        synchronized (C1835b.class) {
                            if (f6853g == null) {
                                f6853g = new xw(f6852f);
                            }
                        }
                    }
                    return f6853g;
                default:
                    throw new UnsupportedOperationException();
            }
            return f6852f;
        }

        public final void mo3332a(zzedw com_google_android_gms_internal_zzedw) {
            if (this.f6854d != null) {
                com_google_android_gms_internal_zzedw.mo3401a(1, this.f6854d == null ? C1837c.m7818a() : this.f6854d);
            }
            if (this.f6855e != 0) {
                com_google_android_gms_internal_zzedw.mo3410b(2, this.f6855e);
            }
        }

        public final int m7816b() {
            return this.f6855e;
        }

        public final int mo3333d() {
            int i = this.c;
            if (i == -1) {
                i = 0;
                if (this.f6854d != null) {
                    i = zzedw.m8523b(1, this.f6854d == null ? C1837c.m7818a() : this.f6854d) + 0;
                }
                if (this.f6855e != 0) {
                    i += zzedw.m8528c(2, this.f6855e);
                }
                this.c = i;
            }
            return i;
        }
    }

    public static final class C1837c extends xu implements yp {
        private static final C1837c f6856d;
        private static volatile yr f6857e;

        public static final class C1836a extends xv implements yp {
            private C1836a() {
                super(C1837c.f6856d);
            }
        }

        static {
            xu c1837c = new C1837c();
            f6856d = c1837c;
            c1837c.mo3331a(yb.f7083d, null, null);
            c1837c.f6809b.m8217b();
        }

        private C1837c() {
        }

        public static C1837c m7818a() {
            return f6856d;
        }

        protected final Object mo3331a(int i, Object obj, Object obj2) {
            switch (tp.f6858a[i - 1]) {
                case 1:
                    return new C1837c();
                case 2:
                    return f6856d;
                case 3:
                    return null;
                case 4:
                    return new C1836a();
                case 5:
                    return this;
                case 6:
                    xk xkVar = (xk) obj;
                    Object obj3 = null;
                    while (obj3 == null) {
                        try {
                            int a = xkVar.mo3350a();
                            switch (a) {
                                case 0:
                                    obj3 = 1;
                                    break;
                                default:
                                    if (!xkVar.mo3354b(a)) {
                                        obj3 = 1;
                                        break;
                                    }
                                    break;
                            }
                        } catch (zzeer e) {
                            throw new RuntimeException(e.m8566a(this));
                        } catch (IOException e2) {
                            throw new RuntimeException(new zzeer(e2.getMessage()).m8566a(this));
                        }
                    }
                    break;
                case 7:
                    break;
                case 8:
                    if (f6857e == null) {
                        synchronized (C1837c.class) {
                            if (f6857e == null) {
                                f6857e = new xw(f6856d);
                            }
                        }
                    }
                    return f6857e;
                default:
                    throw new UnsupportedOperationException();
            }
            return f6856d;
        }

        public final void mo3332a(zzedw com_google_android_gms_internal_zzedw) {
        }

        public final int mo3333d() {
            int i = this.c;
            if (i != -1) {
                return i;
            }
            this.c = 0;
            return 0;
        }
    }
}
