package com.google.android.gms.internal;

@avl
final class acy {
    final int f4342a;
    final int f4343b;

    acy(acu com_google_android_gms_internal_acu, int i, int i2) {
        this.f4342a = i;
        this.f4343b = i2;
    }
}
