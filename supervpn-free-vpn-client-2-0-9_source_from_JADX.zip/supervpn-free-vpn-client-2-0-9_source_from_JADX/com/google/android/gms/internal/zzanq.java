package com.google.android.gms.internal;

public enum zzanq {
    NONE,
    GZIP;

    public static zzanq m8373a(String str) {
        return "GZIP".equalsIgnoreCase(str) ? GZIP : NONE;
    }
}
