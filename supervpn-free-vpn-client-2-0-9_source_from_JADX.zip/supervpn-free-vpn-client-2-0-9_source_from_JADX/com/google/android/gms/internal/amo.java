package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.zzbv;
import java.util.Map;

final class amo implements anb {
    amo() {
    }

    public final void zza(jk jkVar, Map map) {
        if (((Boolean) zzbv.zzen().m5171a(aig.bc)).booleanValue()) {
            jkVar.mo3246c(!Boolean.parseBoolean((String) map.get("disabled")));
        }
    }
}
