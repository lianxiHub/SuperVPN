package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.zzv;
import com.google.android.gms.dynamic.C1758a;
import com.google.android.gms.dynamic.C1761c;

@avl
public final class bt extends cc {
    private final Context f5533a;
    private final Object f5534b;
    private final zzajk f5535c;
    private final bu f5536d;

    public bt(Context context, zzv com_google_android_gms_ads_internal_zzv, aqs com_google_android_gms_internal_aqs, zzajk com_google_android_gms_internal_zzajk) {
        this(context, com_google_android_gms_internal_zzajk, new bu(context, com_google_android_gms_ads_internal_zzv, zzjb.m8580a(), com_google_android_gms_internal_aqs, com_google_android_gms_internal_zzajk));
    }

    private bt(Context context, zzajk com_google_android_gms_internal_zzajk, bu buVar) {
        this.f5534b = new Object();
        this.f5533a = context;
        this.f5535c = com_google_android_gms_internal_zzajk;
        this.f5536d = buVar;
    }

    public final void mo2815a() {
        synchronized (this.f5534b) {
            this.f5536d.m6249b();
        }
    }

    public final void mo2816a(C1758a c1758a) {
        synchronized (this.f5534b) {
            this.f5536d.pause();
        }
    }

    public final void mo2817a(cg cgVar) {
        synchronized (this.f5534b) {
            this.f5536d.zza(cgVar);
        }
    }

    public final void mo2818a(zzadp com_google_android_gms_internal_zzadp) {
        synchronized (this.f5534b) {
            this.f5536d.m6247a(com_google_android_gms_internal_zzadp);
        }
    }

    public final void mo2819a(String str) {
        ii.m6521e("RewardedVideoAd.setUserId() is deprecated. Please do not call this method.");
    }

    public final void mo2820a(boolean z) {
        synchronized (this.f5534b) {
            this.f5536d.setImmersiveMode(z);
        }
    }

    public final void mo2821b(C1758a c1758a) {
        synchronized (this.f5534b) {
            Context context = c1758a == null ? null : (Context) C1761c.m4496a(c1758a);
            if (context != null) {
                try {
                    this.f5536d.m6246a(context);
                } catch (Throwable e) {
                    ii.m6519c("Unable to extract updated context.", e);
                }
            }
            this.f5536d.resume();
        }
    }

    public final boolean mo2822b() {
        boolean c;
        synchronized (this.f5534b) {
            c = this.f5536d.m6250c();
        }
        return c;
    }

    public final void mo2823c() {
        mo2816a(null);
    }

    public final void mo2824c(C1758a c1758a) {
        synchronized (this.f5534b) {
            this.f5536d.destroy();
        }
    }

    public final void mo2825d() {
        mo2821b(null);
    }

    public final void mo2826e() {
        mo2824c(null);
    }

    public final String mo2827f() {
        String mediationAdapterClassName;
        synchronized (this.f5534b) {
            mediationAdapterClassName = this.f5536d.getMediationAdapterClassName();
        }
        return mediationAdapterClassName;
    }
}
