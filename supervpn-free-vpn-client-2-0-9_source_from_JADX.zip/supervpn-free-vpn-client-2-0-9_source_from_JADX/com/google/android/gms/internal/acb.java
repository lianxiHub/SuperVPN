package com.google.android.gms.internal;

import android.graphics.Rect;

public final class acb {
    public final boolean f4259a;
    private long f4260b;
    private boolean f4261c;
    private boolean f4262d;
    private int f4263e;
    private Rect f4264f;
    private Rect f4265g;
    private Rect f4266h;
    private boolean f4267i;
    private Rect f4268j;
    private boolean f4269k;
    private Rect f4270l;
    private float f4271m;

    public acb(long j, boolean z, boolean z2, int i, Rect rect, Rect rect2, Rect rect3, boolean z3, Rect rect4, boolean z4, Rect rect5, float f, boolean z5) {
        this.f4260b = j;
        this.f4261c = z;
        this.f4262d = z2;
        this.f4263e = i;
        this.f4264f = rect;
        this.f4265g = rect2;
        this.f4266h = rect3;
        this.f4267i = z3;
        this.f4268j = rect4;
        this.f4269k = z4;
        this.f4270l = rect5;
        this.f4271m = f;
        this.f4259a = z5;
    }
}
