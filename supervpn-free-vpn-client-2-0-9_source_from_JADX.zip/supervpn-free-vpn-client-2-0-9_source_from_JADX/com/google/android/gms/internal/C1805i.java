package com.google.android.gms.internal;

import android.content.Context;
import android.os.Binder;
import android.os.Bundle;
import android.os.DeadObjectException;
import com.facebook.internal.NativeProtocol;
import com.google.android.gms.ads.internal.zzbv;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.zzf;
import com.google.android.gms.common.internal.zzg;

@avl
public final class C1805i extends C1801e implements zzf, zzg {
    private Context f5928a;
    private zzajk f5929b;
    private iy f5930c;
    private final C1797c f5931d;
    private final Object f5932e = new Object();
    private C1807j f5933f;

    public C1805i(Context context, zzajk com_google_android_gms_internal_zzajk, iy iyVar, C1797c c1797c) {
        super(iyVar, c1797c);
        this.f5928a = context;
        this.f5929b = com_google_android_gms_internal_zzajk;
        this.f5930c = iyVar;
        this.f5931d = c1797c;
        this.f5933f = new C1807j(context, ((Boolean) zzbv.zzen().m5171a(aig.f4575B)).booleanValue() ? zzbv.zzer().m6761a() : context.getMainLooper(), this, this, this.f5929b.f7338c);
        this.f5933f.zzajf();
    }

    public final void mo3213a() {
        synchronized (this.f5932e) {
            if (this.f5933f.isConnected() || this.f5933f.isConnecting()) {
                this.f5933f.disconnect();
            }
            Binder.flushPendingCommands();
        }
    }

    public final C1795p mo3214b() {
        C1795p a;
        synchronized (this.f5932e) {
            try {
                a = this.f5933f.m6820a();
            } catch (IllegalStateException e) {
                a = null;
                return a;
            } catch (DeadObjectException e2) {
                a = null;
                return a;
            }
        }
        return a;
    }

    public final void onConnected(Bundle bundle) {
        zzns();
    }

    public final void onConnectionFailed(ConnectionResult connectionResult) {
        ii.m6516b("Cannot connect to remote service, fallback to local instance.");
        new C1804h(this.f5928a, this.f5930c, this.f5931d).zzns();
        Bundle bundle = new Bundle();
        bundle.putString(NativeProtocol.WEB_DIALOG_ACTION, "gms_connection_failed_fallback_to_local");
        zzbv.zzea().m6644b(this.f5928a, this.f5929b.f7336a, "gmob-apps", bundle, true);
    }

    public final void onConnectionSuspended(int i) {
        ii.m6516b("Disconnected from remote ad request service.");
    }
}
