package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import com.google.android.gms.common.internal.zzd;
import com.google.android.gms.common.internal.zzf;
import com.google.android.gms.common.internal.zzg;

@avl
public final class C1807j extends zzd {
    private int f5973a;

    public C1807j(Context context, Looper looper, zzf com_google_android_gms_common_internal_zzf, zzg com_google_android_gms_common_internal_zzg, int i) {
        super(context, looper, 8, com_google_android_gms_common_internal_zzf, com_google_android_gms_common_internal_zzg, null);
        this.f5973a = i;
    }

    public final C1795p m6820a() {
        return (C1795p) super.zzajj();
    }

    protected final /* synthetic */ IInterface zze(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.request.IAdRequestService");
        return queryLocalInterface instanceof C1795p ? (C1795p) queryLocalInterface : new C1815r(iBinder);
    }

    protected final String zzhc() {
        return "com.google.android.gms.ads.service.START";
    }

    protected final String zzhd() {
        return "com.google.android.gms.ads.internal.request.IAdRequestService";
    }
}
