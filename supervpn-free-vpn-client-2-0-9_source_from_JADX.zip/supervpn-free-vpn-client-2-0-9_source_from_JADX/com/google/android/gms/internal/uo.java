package com.google.android.gms.internal;

import java.math.BigInteger;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECParameterSpec;
import java.security.spec.ECPoint;
import java.security.spec.ECPublicKeySpec;

public final class uo {
    public static zzdhu m7942a(zzdfu com_google_android_gms_internal_zzdfu) {
        switch (com_google_android_gms_internal_zzdfu) {
            case COMPRESSED:
                return zzdhu.COMPRESSED;
            case UNCOMPRESSED:
                return zzdhu.UNCOMPRESSED;
            default:
                String valueOf = String.valueOf(com_google_android_gms_internal_zzdfu);
                throw new GeneralSecurityException(new StringBuilder(String.valueOf(valueOf).length() + 25).append("Unsupported point format:").append(valueOf).toString());
        }
    }

    public static String m7943a(zzdfy com_google_android_gms_internal_zzdfy) {
        switch (com_google_android_gms_internal_zzdfy) {
            case SHA1:
                return "HmacSha1";
            case SHA256:
                return "HmacSha256";
            case SHA512:
                return "HmacSha512";
            default:
                String valueOf = String.valueOf(com_google_android_gms_internal_zzdfy);
                throw new NoSuchAlgorithmException(new StringBuilder(String.valueOf(valueOf).length() + 27).append("hash unsupported for HMAC: ").append(valueOf).toString());
        }
    }

    public static ECPublicKey m7944a(zzdfw com_google_android_gms_internal_zzdfw, byte[] bArr, byte[] bArr2) {
        ECParameterSpec a = m7945a(com_google_android_gms_internal_zzdfw);
        ECPoint eCPoint = new ECPoint(new BigInteger(1, bArr), new BigInteger(1, bArr2));
        vk.m8034a(eCPoint, a.getCurve());
        return (ECPublicKey) KeyFactory.getInstance("EC").generatePublic(new ECPublicKeySpec(eCPoint, a));
    }

    public static ECParameterSpec m7945a(zzdfw com_google_android_gms_internal_zzdfw) {
        switch (com_google_android_gms_internal_zzdfw) {
            case NIST_P256:
                return vk.m8032a();
            case NIST_P384:
                return vk.m8036b();
            case NIST_P521:
                return vk.m8037c();
            default:
                String valueOf = String.valueOf(com_google_android_gms_internal_zzdfw);
                throw new NoSuchAlgorithmException(new StringBuilder(String.valueOf(valueOf).length() + 22).append("curve not implemented:").append(valueOf).toString());
        }
    }
}
