package com.google.android.gms.internal;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.view.View;
import com.google.android.gms.ads.internal.zzbv;
import java.util.Map;

final class amv implements anb {
    amv() {
    }

    public final void zza(jk jkVar, Map map) {
        String str = (String) map.get("u");
        if (str == null) {
            ii.m6521e("URL missing from click GMSG.");
            return;
        }
        Uri parse = Uri.parse(str);
        try {
            Uri uri;
            sv m = jkVar.mo3261m();
            if (m == null || !m.m7623b(parse)) {
                uri = parse;
            } else {
                Context context = jkVar.getContext();
                if (jkVar == null) {
                    throw null;
                }
                uri = m.m7617a(parse, context, (View) jkVar);
            }
            parse = uri;
        } catch (zzcw e) {
            String str2 = "Unable to append parameter to URL: ";
            str = String.valueOf(str);
            ii.m6521e(str.length() != 0 ? str2.concat(str) : new String(str2));
        }
        Object obj = (((Boolean) zzbv.zzen().m5171a(aig.al)).booleanValue() && zzbv.zzez().m6399a(jkVar.getContext())) ? 1 : null;
        if (obj != null && TextUtils.isEmpty(parse.getQueryParameter("fbs_aeid"))) {
            str = zzbv.zzez().m6413i(jkVar.getContext());
            zzbv.zzea();
            parse = gd.m6571a(parse.toString(), "fbs_aeid", str);
            zzbv.zzez().m6404d(jkVar.getContext(), str);
        }
        new hv(jkVar.getContext(), jkVar.mo3262n().f7336a, parse.toString()).zzqq();
    }
}
