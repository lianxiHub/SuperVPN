package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.zzd;

@avl
public final class zzmb extends zzjb {
    public zzmb(zzjb com_google_android_gms_internal_zzjb) {
        super(com_google_android_gms_internal_zzjb.f7629a, com_google_android_gms_internal_zzjb.f7630b, com_google_android_gms_internal_zzjb.f7631c, com_google_android_gms_internal_zzjb.f7632d, com_google_android_gms_internal_zzjb.f7633e, com_google_android_gms_internal_zzjb.f7634f, com_google_android_gms_internal_zzjb.f7635g, com_google_android_gms_internal_zzjb.f7636h, com_google_android_gms_internal_zzjb.f7637i, com_google_android_gms_internal_zzjb.f7638j);
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int zze = zzd.zze(parcel);
        zzd.zza(parcel, 2, this.a, false);
        zzd.zzc(parcel, 3, this.b);
        zzd.zzc(parcel, 6, this.e);
        zzd.zzai(parcel, zze);
    }
}
