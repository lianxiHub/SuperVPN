package com.google.android.gms.internal;

import android.os.IInterface;

public interface adx extends IInterface {
    zzib mo2778a(zzie com_google_android_gms_internal_zzie);
}
