package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public final class agq extends xq implements agn {
    agq(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.client.IVideoController");
    }

    public final void mo2795a() {
        zzb(1, zzax());
    }

    public final void mo2796a(agr com_google_android_gms_internal_agr) {
        Parcel zzax = zzax();
        zm.m8271a(zzax, (IInterface) com_google_android_gms_internal_agr);
        zzb(8, zzax);
    }

    public final void mo2797a(boolean z) {
        Parcel zzax = zzax();
        zm.m8273a(zzax, z);
        zzb(3, zzax);
    }

    public final void mo2798b() {
        zzb(2, zzax());
    }

    public final boolean mo2799c() {
        Parcel zza = zza(4, zzax());
        boolean a = zm.m8274a(zza);
        zza.recycle();
        return a;
    }

    public final int mo2800d() {
        Parcel zza = zza(5, zzax());
        int readInt = zza.readInt();
        zza.recycle();
        return readInt;
    }

    public final float mo2801e() {
        Parcel zza = zza(9, zzax());
        float readFloat = zza.readFloat();
        zza.recycle();
        return readFloat;
    }

    public final float mo2802f() {
        Parcel zza = zza(6, zzax());
        float readFloat = zza.readFloat();
        zza.recycle();
        return readFloat;
    }

    public final float mo2803g() {
        Parcel zza = zza(7, zzax());
        float readFloat = zza.readFloat();
        zza.recycle();
        return readFloat;
    }

    public final boolean mo2804h() {
        Parcel zza = zza(10, zzax());
        boolean a = zm.m8274a(zza);
        zza.recycle();
        return a;
    }
}
