package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;

public abstract class C1796q extends yo implements C1795p {
    public C1796q() {
        attachInterface(this, "com.google.android.gms.ads.internal.request.IAdRequestService");
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        C1859v c1859v = null;
        if (zza(i, parcel, parcel2, i2)) {
            return true;
        }
        IBinder readStrongBinder;
        IInterface queryLocalInterface;
        switch (i) {
            case 1:
                Parcelable a = mo2964a((zzaak) zm.m8270a(parcel, zzaak.CREATOR));
                parcel2.writeNoException();
                zm.m8276b(parcel2, a);
                break;
            case 2:
                C1810s c1852u;
                zzaak com_google_android_gms_internal_zzaak = (zzaak) zm.m8270a(parcel, zzaak.CREATOR);
                readStrongBinder = parcel.readStrongBinder();
                if (readStrongBinder != null) {
                    queryLocalInterface = readStrongBinder.queryLocalInterface("com.google.android.gms.ads.internal.request.IAdResponseListener");
                    c1852u = queryLocalInterface instanceof C1810s ? (C1810s) queryLocalInterface : new C1852u(readStrongBinder);
                }
                mo2965a(com_google_android_gms_internal_zzaak, c1852u);
                parcel2.writeNoException();
                break;
            case 3:
                zzabd com_google_android_gms_internal_zzabd = (zzabd) zm.m8270a(parcel, zzabd.CREATOR);
                readStrongBinder = parcel.readStrongBinder();
                if (readStrongBinder != null) {
                    queryLocalInterface = readStrongBinder.queryLocalInterface("com.google.android.gms.ads.internal.request.INonagonResponseListener");
                    c1859v = queryLocalInterface instanceof C1859v ? (C1859v) queryLocalInterface : new C1860w(readStrongBinder);
                }
                mo2966a(com_google_android_gms_internal_zzabd, c1859v);
                parcel2.writeNoException();
                break;
            default:
                return false;
        }
        return true;
    }
}
