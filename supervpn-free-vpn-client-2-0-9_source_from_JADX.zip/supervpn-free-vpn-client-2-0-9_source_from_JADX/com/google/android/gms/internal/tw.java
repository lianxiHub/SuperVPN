package com.google.android.gms.internal;

import com.google.android.gms.internal.zzdgq.C1870a;
import com.google.android.gms.internal.zzdgq.C1870a.C1869a;
import java.io.IOException;

public final class tw {

    public static final class C1839a extends xu implements yp {
        private static final C1839a f6874e;
        private static volatile yr f6875f;
        private C1870a f6876d;

        public static final class C1838a extends xv implements yp {
            private C1838a() {
                super(C1839a.f6874e);
            }
        }

        static {
            xu c1839a = new C1839a();
            f6874e = c1839a;
            c1839a.mo3331a(yb.f7083d, null, null);
            c1839a.f6809b.m8217b();
        }

        private C1839a() {
        }

        public static C1839a m7825b() {
            return f6874e;
        }

        public final C1870a m7827a() {
            return this.f6876d == null ? C1870a.m8414c() : this.f6876d;
        }

        protected final Object mo3331a(int i, Object obj, Object obj2) {
            switch (tx.f6893a[i - 1]) {
                case 1:
                    return new C1839a();
                case 2:
                    return f6874e;
                case 3:
                    return null;
                case 4:
                    return new C1838a();
                case 5:
                    this.f6876d = (C1870a) ((yc) obj).mo3366a(this.f6876d, ((C1839a) obj2).f6876d);
                    return this;
                case 6:
                    xk xkVar = (xk) obj;
                    xp xpVar = (xp) obj2;
                    Object obj3 = null;
                    while (obj3 == null) {
                        try {
                            int a = xkVar.mo3350a();
                            switch (a) {
                                case 0:
                                    obj3 = 1;
                                    break;
                                case 18:
                                    xv xvVar;
                                    if (this.f6876d != null) {
                                        xu xuVar = this.f6876d;
                                        xv xvVar2 = (xv) xuVar.mo3331a(yb.f7085f, null, null);
                                        xvVar2.m7682a(xuVar);
                                        xvVar = (C1869a) xvVar2;
                                    } else {
                                        xvVar = null;
                                    }
                                    this.f6876d = (C1870a) xkVar.mo3351a(C1870a.m8414c(), xpVar);
                                    if (xvVar == null) {
                                        break;
                                    }
                                    xvVar.m7682a(this.f6876d);
                                    this.f6876d = (C1870a) xvVar.m7684c();
                                    break;
                                default:
                                    if (!xkVar.mo3354b(a)) {
                                        obj3 = 1;
                                        break;
                                    }
                                    break;
                            }
                        } catch (zzeer e) {
                            throw new RuntimeException(e.m8566a(this));
                        } catch (IOException e2) {
                            throw new RuntimeException(new zzeer(e2.getMessage()).m8566a(this));
                        }
                    }
                    break;
                case 7:
                    break;
                case 8:
                    if (f6875f == null) {
                        synchronized (C1839a.class) {
                            if (f6875f == null) {
                                f6875f = new xw(f6874e);
                            }
                        }
                    }
                    return f6875f;
                default:
                    throw new UnsupportedOperationException();
            }
            return f6874e;
        }

        public final void mo3332a(zzedw com_google_android_gms_internal_zzedw) {
            if (this.f6876d != null) {
                com_google_android_gms_internal_zzedw.mo3401a(2, this.f6876d == null ? C1870a.m8414c() : this.f6876d);
            }
        }

        public final int mo3333d() {
            int i = this.c;
            if (i == -1) {
                i = 0;
                if (this.f6876d != null) {
                    i = zzedw.m8523b(2, this.f6876d == null ? C1870a.m8414c() : this.f6876d) + 0;
                }
                this.c = i;
            }
            return i;
        }
    }

    public static final class C1841b extends xu implements yp {
        private static final C1841b f6877g;
        private static volatile yr f6878h;
        private C1845d f6879d;
        private C1839a f6880e;
        private int f6881f;

        public static final class C1840a extends xv implements yp {
            private C1840a() {
                super(C1841b.f6877g);
            }
        }

        static {
            xu c1841b = new C1841b();
            f6877g = c1841b;
            c1841b.mo3331a(yb.f7083d, null, null);
            c1841b.f6809b.m8217b();
        }

        private C1841b() {
        }

        public static C1841b m7831e() {
            return f6877g;
        }

        public final C1845d m7833a() {
            return this.f6879d == null ? C1845d.m7848e() : this.f6879d;
        }

        protected final Object mo3331a(int i, Object obj, Object obj2) {
            boolean z = true;
            switch (tx.f6893a[i - 1]) {
                case 1:
                    return new C1841b();
                case 2:
                    return f6877g;
                case 3:
                    return null;
                case 4:
                    return new C1840a();
                case 5:
                    yc ycVar = (yc) obj;
                    C1841b c1841b = (C1841b) obj2;
                    this.f6879d = (C1845d) ycVar.mo3366a(this.f6879d, c1841b.f6879d);
                    this.f6880e = (C1839a) ycVar.mo3366a(this.f6880e, c1841b.f6880e);
                    boolean z2 = this.f6881f != 0;
                    int i2 = this.f6881f;
                    if (c1841b.f6881f == 0) {
                        z = false;
                    }
                    this.f6881f = ycVar.mo3364a(z2, i2, z, c1841b.f6881f);
                    return this;
                case 6:
                    xk xkVar = (xk) obj;
                    xp xpVar = (xp) obj2;
                    boolean z3 = false;
                    while (!z3) {
                        try {
                            int a = xkVar.mo3350a();
                            xu xuVar;
                            xv xvVar;
                            xv xvVar2;
                            switch (a) {
                                case 0:
                                    z3 = true;
                                    break;
                                case 10:
                                    if (this.f6879d != null) {
                                        xuVar = this.f6879d;
                                        xvVar = (xv) xuVar.mo3331a(yb.f7085f, null, null);
                                        xvVar.m7682a(xuVar);
                                        xvVar2 = (C1844a) xvVar;
                                    } else {
                                        xvVar2 = null;
                                    }
                                    this.f6879d = (C1845d) xkVar.mo3351a(C1845d.m7848e(), xpVar);
                                    if (xvVar2 == null) {
                                        break;
                                    }
                                    xvVar2.m7682a(this.f6879d);
                                    this.f6879d = (C1845d) xvVar2.m7684c();
                                    break;
                                case 18:
                                    if (this.f6880e != null) {
                                        xuVar = this.f6880e;
                                        xvVar = (xv) xuVar.mo3331a(yb.f7085f, null, null);
                                        xvVar.m7682a(xuVar);
                                        xvVar2 = (C1838a) xvVar;
                                    } else {
                                        xvVar2 = null;
                                    }
                                    this.f6880e = (C1839a) xkVar.mo3351a(C1839a.m7825b(), xpVar);
                                    if (xvVar2 == null) {
                                        break;
                                    }
                                    xvVar2.m7682a(this.f6880e);
                                    this.f6880e = (C1839a) xvVar2.m7684c();
                                    break;
                                case 24:
                                    this.f6881f = xkVar.mo3359e();
                                    break;
                                default:
                                    if (!xkVar.mo3354b(a)) {
                                        z3 = true;
                                        break;
                                    }
                                    break;
                            }
                        } catch (zzeer e) {
                            throw new RuntimeException(e.m8566a(this));
                        } catch (IOException e2) {
                            throw new RuntimeException(new zzeer(e2.getMessage()).m8566a(this));
                        }
                    }
                    break;
                case 7:
                    break;
                case 8:
                    if (f6878h == null) {
                        synchronized (C1841b.class) {
                            if (f6878h == null) {
                                f6878h = new xw(f6877g);
                            }
                        }
                    }
                    return f6878h;
                default:
                    throw new UnsupportedOperationException();
            }
            return f6877g;
        }

        public final void mo3332a(zzedw com_google_android_gms_internal_zzedw) {
            if (this.f6879d != null) {
                com_google_android_gms_internal_zzedw.mo3401a(1, this.f6879d == null ? C1845d.m7848e() : this.f6879d);
            }
            if (this.f6880e != null) {
                com_google_android_gms_internal_zzedw.mo3401a(2, this.f6880e == null ? C1839a.m7825b() : this.f6880e);
            }
            if (this.f6881f != zzdfu.UNKNOWN_FORMAT.m8409a()) {
                com_google_android_gms_internal_zzedw.mo3410b(3, this.f6881f);
            }
        }

        public final C1839a m7836b() {
            return this.f6880e == null ? C1839a.m7825b() : this.f6880e;
        }

        public final zzdfu m7837c() {
            zzdfu a = zzdfu.m8408a(this.f6881f);
            return a == null ? zzdfu.UNRECOGNIZED : a;
        }

        public final int mo3333d() {
            int i = this.c;
            if (i == -1) {
                i = 0;
                if (this.f6879d != null) {
                    i = zzedw.m8523b(1, this.f6879d == null ? C1845d.m7848e() : this.f6879d) + 0;
                }
                if (this.f6880e != null) {
                    i += zzedw.m8523b(2, this.f6880e == null ? C1839a.m7825b() : this.f6880e);
                }
                if (this.f6881f != zzdfu.UNKNOWN_FORMAT.m8409a()) {
                    i += zzedw.m8531d(3, this.f6881f);
                }
                this.c = i;
            }
            return i;
        }
    }

    public static final class C1843c extends xu implements yp {
        private static final C1843c f6882h;
        private static volatile yr f6883i;
        private int f6884d;
        private C1841b f6885e;
        private zzedk f6886f = zzedk.f7556a;
        private zzedk f6887g = zzedk.f7556a;

        public static final class C1842a extends xv implements yp {
            private C1842a() {
                super(C1843c.f6882h);
            }
        }

        static {
            xu c1843c = new C1843c();
            f6882h = c1843c;
            c1843c.mo3331a(yb.f7083d, null, null);
            c1843c.f6809b.m8217b();
        }

        private C1843c() {
        }

        public static C1843c m7839a(zzedk com_google_android_gms_internal_zzedk) {
            return (C1843c) xu.m7699a(f6882h, com_google_android_gms_internal_zzedk);
        }

        public final int m7841a() {
            return this.f6884d;
        }

        protected final Object mo3331a(int i, Object obj, Object obj2) {
            boolean z = true;
            switch (tx.f6893a[i - 1]) {
                case 1:
                    return new C1843c();
                case 2:
                    return f6882h;
                case 3:
                    return null;
                case 4:
                    return new C1842a();
                case 5:
                    yc ycVar = (yc) obj;
                    C1843c c1843c = (C1843c) obj2;
                    this.f6884d = ycVar.mo3364a(this.f6884d != 0, this.f6884d, c1843c.f6884d != 0, c1843c.f6884d);
                    this.f6885e = (C1841b) ycVar.mo3366a(this.f6885e, c1843c.f6885e);
                    this.f6886f = ycVar.mo3368a(this.f6886f != zzedk.f7556a, this.f6886f, c1843c.f6886f != zzedk.f7556a, c1843c.f6886f);
                    boolean z2 = this.f6887g != zzedk.f7556a;
                    zzedk com_google_android_gms_internal_zzedk = this.f6887g;
                    if (c1843c.f6887g == zzedk.f7556a) {
                        z = false;
                    }
                    this.f6887g = ycVar.mo3368a(z2, com_google_android_gms_internal_zzedk, z, c1843c.f6887g);
                    return this;
                case 6:
                    xk xkVar = (xk) obj;
                    xp xpVar = (xp) obj2;
                    boolean z3 = false;
                    while (!z3) {
                        try {
                            int a = xkVar.mo3350a();
                            switch (a) {
                                case 0:
                                    z3 = true;
                                    break;
                                case 8:
                                    this.f6884d = xkVar.mo3353b();
                                    break;
                                case 18:
                                    xv xvVar;
                                    if (this.f6885e != null) {
                                        xu xuVar = this.f6885e;
                                        xv xvVar2 = (xv) xuVar.mo3331a(yb.f7085f, null, null);
                                        xvVar2.m7682a(xuVar);
                                        xvVar = (C1840a) xvVar2;
                                    } else {
                                        xvVar = null;
                                    }
                                    this.f6885e = (C1841b) xkVar.mo3351a(C1841b.m7831e(), xpVar);
                                    if (xvVar == null) {
                                        break;
                                    }
                                    xvVar.m7682a(this.f6885e);
                                    this.f6885e = (C1841b) xvVar.m7684c();
                                    break;
                                case 26:
                                    this.f6886f = xkVar.mo3357d();
                                    break;
                                case 34:
                                    this.f6887g = xkVar.mo3357d();
                                    break;
                                default:
                                    if (!xkVar.mo3354b(a)) {
                                        z3 = true;
                                        break;
                                    }
                                    break;
                            }
                        } catch (zzeer e) {
                            throw new RuntimeException(e.m8566a(this));
                        } catch (IOException e2) {
                            throw new RuntimeException(new zzeer(e2.getMessage()).m8566a(this));
                        }
                    }
                    break;
                case 7:
                    break;
                case 8:
                    if (f6883i == null) {
                        synchronized (C1843c.class) {
                            if (f6883i == null) {
                                f6883i = new xw(f6882h);
                            }
                        }
                    }
                    return f6883i;
                default:
                    throw new UnsupportedOperationException();
            }
            return f6882h;
        }

        public final void mo3332a(zzedw com_google_android_gms_internal_zzedw) {
            if (this.f6884d != 0) {
                com_google_android_gms_internal_zzedw.mo3410b(1, this.f6884d);
            }
            if (this.f6885e != null) {
                com_google_android_gms_internal_zzedw.mo3401a(2, this.f6885e == null ? C1841b.m7831e() : this.f6885e);
            }
            if (!this.f6886f.m8504b()) {
                com_google_android_gms_internal_zzedw.mo3402a(3, this.f6886f);
            }
            if (!this.f6887g.m8504b()) {
                com_google_android_gms_internal_zzedw.mo3402a(4, this.f6887g);
            }
        }

        public final C1841b m7844b() {
            return this.f6885e == null ? C1841b.m7831e() : this.f6885e;
        }

        public final zzedk m7845c() {
            return this.f6886f;
        }

        public final int mo3333d() {
            int i = this.c;
            if (i == -1) {
                i = 0;
                if (this.f6884d != 0) {
                    i = zzedw.m8528c(1, this.f6884d) + 0;
                }
                if (this.f6885e != null) {
                    i += zzedw.m8523b(2, this.f6885e == null ? C1841b.m7831e() : this.f6885e);
                }
                if (!this.f6886f.m8504b()) {
                    i += zzedw.m8524b(3, this.f6886f);
                }
                if (!this.f6887g.m8504b()) {
                    i += zzedw.m8524b(4, this.f6887g);
                }
                this.c = i;
            }
            return i;
        }

        public final zzedk m7847e() {
            return this.f6887g;
        }
    }

    public static final class C1845d extends xu implements yp {
        private static final C1845d f6888g;
        private static volatile yr f6889h;
        private int f6890d;
        private int f6891e;
        private zzedk f6892f = zzedk.f7556a;

        public static final class C1844a extends xv implements yp {
            private C1844a() {
                super(C1845d.f6888g);
            }
        }

        static {
            xu c1845d = new C1845d();
            f6888g = c1845d;
            c1845d.mo3331a(yb.f7083d, null, null);
            c1845d.f6809b.m8217b();
        }

        private C1845d() {
        }

        public static C1845d m7848e() {
            return f6888g;
        }

        public final zzdfw m7850a() {
            zzdfw a = zzdfw.m8410a(this.f6890d);
            return a == null ? zzdfw.UNRECOGNIZED : a;
        }

        protected final Object mo3331a(int i, Object obj, Object obj2) {
            boolean z = false;
            boolean z2 = true;
            switch (tx.f6893a[i - 1]) {
                case 1:
                    return new C1845d();
                case 2:
                    return f6888g;
                case 3:
                    return null;
                case 4:
                    return new C1844a();
                case 5:
                    yc ycVar = (yc) obj;
                    C1845d c1845d = (C1845d) obj2;
                    this.f6890d = ycVar.mo3364a(this.f6890d != 0, this.f6890d, c1845d.f6890d != 0, c1845d.f6890d);
                    this.f6891e = ycVar.mo3364a(this.f6891e != 0, this.f6891e, c1845d.f6891e != 0, c1845d.f6891e);
                    boolean z3 = this.f6892f != zzedk.f7556a;
                    zzedk com_google_android_gms_internal_zzedk = this.f6892f;
                    if (c1845d.f6892f == zzedk.f7556a) {
                        z2 = false;
                    }
                    this.f6892f = ycVar.mo3368a(z3, com_google_android_gms_internal_zzedk, z2, c1845d.f6892f);
                    return this;
                case 6:
                    xk xkVar = (xk) obj;
                    while (!z) {
                        try {
                            int a = xkVar.mo3350a();
                            switch (a) {
                                case 0:
                                    z = true;
                                    break;
                                case 8:
                                    this.f6890d = xkVar.mo3359e();
                                    break;
                                case 16:
                                    this.f6891e = xkVar.mo3359e();
                                    break;
                                case 90:
                                    this.f6892f = xkVar.mo3357d();
                                    break;
                                default:
                                    if (!xkVar.mo3354b(a)) {
                                        z = true;
                                        break;
                                    }
                                    break;
                            }
                        } catch (zzeer e) {
                            throw new RuntimeException(e.m8566a(this));
                        } catch (IOException e2) {
                            throw new RuntimeException(new zzeer(e2.getMessage()).m8566a(this));
                        }
                    }
                    break;
                case 7:
                    break;
                case 8:
                    if (f6889h == null) {
                        synchronized (C1845d.class) {
                            if (f6889h == null) {
                                f6889h = new xw(f6888g);
                            }
                        }
                    }
                    return f6889h;
                default:
                    throw new UnsupportedOperationException();
            }
            return f6888g;
        }

        public final void mo3332a(zzedw com_google_android_gms_internal_zzedw) {
            if (this.f6890d != zzdfw.UNKNOWN_CURVE.m8411a()) {
                com_google_android_gms_internal_zzedw.mo3410b(1, this.f6890d);
            }
            if (this.f6891e != zzdfy.UNKNOWN_HASH.m8413a()) {
                com_google_android_gms_internal_zzedw.mo3410b(2, this.f6891e);
            }
            if (!this.f6892f.m8504b()) {
                com_google_android_gms_internal_zzedw.mo3402a(11, this.f6892f);
            }
        }

        public final zzdfy m7853b() {
            zzdfy a = zzdfy.m8412a(this.f6891e);
            return a == null ? zzdfy.UNRECOGNIZED : a;
        }

        public final zzedk m7854c() {
            return this.f6892f;
        }

        public final int mo3333d() {
            int i = this.c;
            if (i == -1) {
                i = 0;
                if (this.f6890d != zzdfw.UNKNOWN_CURVE.m8411a()) {
                    i = zzedw.m8531d(1, this.f6890d) + 0;
                }
                if (this.f6891e != zzdfy.UNKNOWN_HASH.m8413a()) {
                    i += zzedw.m8531d(2, this.f6891e);
                }
                if (!this.f6892f.m8504b()) {
                    i += zzedw.m8524b(11, this.f6892f);
                }
                this.c = i;
            }
            return i;
        }
    }
}
