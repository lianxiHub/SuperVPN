package com.google.android.gms.internal;

final class aq implements ja {
    private /* synthetic */ ao f5018a;

    aq(ao aoVar) {
        this.f5018a = aoVar;
    }

    public final void run() {
        ii.m6518c("JS engine could not be obtained. Cancelling ad request");
        this.f5018a.f4920a.m6181a();
    }
}
