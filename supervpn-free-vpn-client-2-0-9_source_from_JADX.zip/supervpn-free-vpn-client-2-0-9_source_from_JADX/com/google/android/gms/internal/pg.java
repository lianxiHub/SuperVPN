package com.google.android.gms.internal;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;

public final class pg implements pf {
    public final PendingResult mo3300a(GoogleApiClient googleApiClient) {
        return googleApiClient.zze(new ph(this, googleApiClient));
    }
}
