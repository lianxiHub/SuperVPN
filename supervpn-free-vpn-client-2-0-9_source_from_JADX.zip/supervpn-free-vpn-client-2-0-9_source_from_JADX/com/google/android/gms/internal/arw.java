package com.google.android.gms.internal;

final class arw implements Runnable {
    private /* synthetic */ arr f5155a;

    arw(arr com_google_android_gms_internal_arr) {
        this.f5155a = com_google_android_gms_internal_arr;
    }

    public final void run() {
        try {
            this.f5155a.f5151a.mo2983b();
        } catch (Throwable e) {
            ii.m6519c("Could not call onAdClosed.", e);
        }
    }
}
