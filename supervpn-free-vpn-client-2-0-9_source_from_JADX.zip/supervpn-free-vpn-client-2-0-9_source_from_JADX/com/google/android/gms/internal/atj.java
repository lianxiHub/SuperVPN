package com.google.android.gms.internal;

import android.os.IInterface;

public interface atj extends IInterface {
}
