package com.google.android.gms.internal;

@avl
public interface gt {
    void cancel();

    Object zzns();
}
