package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.dynamic.C1758a;

public final class aft extends xq implements afs {
    aft(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.client.IAdLoaderBuilderCreator");
    }

    public final IBinder mo2792a(C1758a c1758a, String str, aqs com_google_android_gms_internal_aqs, int i) {
        Parcel zzax = zzax();
        zm.m8271a(zzax, (IInterface) c1758a);
        zzax.writeString(str);
        zm.m8271a(zzax, (IInterface) com_google_android_gms_internal_aqs);
        zzax.writeInt(11200000);
        zzax = zza(1, zzax);
        IBinder readStrongBinder = zzax.readStrongBinder();
        zzax.recycle();
        return readStrongBinder;
    }
}
