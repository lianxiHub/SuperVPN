package com.google.android.gms.internal;

final class wx implements Runnable {
    private /* synthetic */ ww f7034a;

    wx(ww wwVar) {
        this.f7034a = wwVar;
    }

    public final void run() {
        this.f7034a.m8086b();
    }
}
