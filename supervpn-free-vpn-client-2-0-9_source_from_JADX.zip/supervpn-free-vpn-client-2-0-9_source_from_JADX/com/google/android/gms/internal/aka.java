package com.google.android.gms.internal;

import android.text.TextUtils;
import com.google.android.gms.ads.internal.js.zzai;
import java.util.Map;

final class aka implements anb {
    final /* synthetic */ zzai f4751a;
    final /* synthetic */ ajz f4752b;

    aka(ajz com_google_android_gms_internal_ajz, zzai com_google_android_gms_ads_internal_js_zzai) {
        this.f4752b = com_google_android_gms_internal_ajz;
        this.f4751a = com_google_android_gms_ads_internal_js_zzai;
    }

    public final void zza(jk jkVar, Map map) {
        jk jkVar2 = (jk) this.f4752b.f4749a.get();
        if (jkVar2 == null) {
            this.f4751a.zzb("/loadHtml", (anb) this);
            return;
        }
        jkVar2.mo3256k().m6899a(new akb(this, map));
        String str = (String) map.get("overlayHtml");
        String str2 = (String) map.get("baseUrl");
        if (TextUtils.isEmpty(str2)) {
            jkVar2.loadData(str, "text/html", WebRequest.CHARSET_UTF_8);
        } else {
            jkVar2.loadDataWithBaseURL(str2, str, "text/html", WebRequest.CHARSET_UTF_8, null);
        }
    }
}
