package com.google.android.gms.internal;

public interface ua {
    byte[] mo3340a(byte[] bArr, byte[] bArr2);
}
