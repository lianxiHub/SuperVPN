package com.google.android.gms.internal;

final class C1802f implements jc {
    private /* synthetic */ C1795p f5779a;
    private /* synthetic */ C1801e f5780b;

    C1802f(C1801e c1801e, C1795p c1795p) {
        this.f5780b = c1801e;
        this.f5779a = c1795p;
    }

    public final /* synthetic */ void zzc(Object obj) {
        if (!this.f5780b.m6419a(this.f5779a, (zzaak) obj)) {
            this.f5780b.mo3213a();
        }
    }
}
