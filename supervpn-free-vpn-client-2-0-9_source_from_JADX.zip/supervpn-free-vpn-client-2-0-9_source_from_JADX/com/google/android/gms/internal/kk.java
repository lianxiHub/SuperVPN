package com.google.android.gms.internal;

import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.webkit.JsPromptResult;

final class kk implements OnCancelListener {
    private /* synthetic */ JsPromptResult f6151a;

    kk(JsPromptResult jsPromptResult) {
        this.f6151a = jsPromptResult;
    }

    public final void onCancel(DialogInterface dialogInterface) {
        this.f6151a.cancel();
    }
}
