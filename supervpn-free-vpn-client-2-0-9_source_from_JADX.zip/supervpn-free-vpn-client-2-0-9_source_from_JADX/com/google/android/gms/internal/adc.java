package com.google.android.gms.internal;

import java.util.Comparator;

final class adc implements Comparator {
    adc(adb com_google_android_gms_internal_adb) {
    }

    public final /* synthetic */ int compare(Object obj, Object obj2) {
        adi com_google_android_gms_internal_adi = (adi) obj;
        adi com_google_android_gms_internal_adi2 = (adi) obj2;
        int i = com_google_android_gms_internal_adi.f4363c - com_google_android_gms_internal_adi2.f4363c;
        return i != 0 ? i : (int) (com_google_android_gms_internal_adi.f4361a - com_google_android_gms_internal_adi2.f4361a);
    }
}
