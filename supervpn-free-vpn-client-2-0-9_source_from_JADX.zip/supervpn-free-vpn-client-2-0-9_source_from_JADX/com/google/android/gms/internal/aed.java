package com.google.android.gms.internal;

public interface aed {
    void zza(aeh com_google_android_gms_internal_aeh);
}
