package com.google.android.gms.internal;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

final class abc extends BroadcastReceiver {
    private /* synthetic */ abb f4204a;

    abc(abb com_google_android_gms_internal_abb) {
        this.f4204a = com_google_android_gms_internal_abb;
    }

    public final void onReceive(Context context, Intent intent) {
        this.f4204a.m4685a(3);
    }
}
