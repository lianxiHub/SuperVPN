package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.dynamic.C1758a;
import com.google.android.gms.dynamic.C1758a.C1759a;
import java.util.List;

public final class ali extends xq implements alg {
    ali(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.formats.client.INativeCustomTemplateAd");
    }

    public final String mo2885a(String str) {
        Parcel zzax = zzax();
        zzax.writeString(str);
        zzax = zza(1, zzax);
        String readString = zzax.readString();
        zzax.recycle();
        return readString;
    }

    public final List mo2886a() {
        Parcel zza = zza(3, zzax());
        List createStringArrayList = zza.createStringArrayList();
        zza.recycle();
        return createStringArrayList;
    }

    public final boolean mo2887a(C1758a c1758a) {
        Parcel zzax = zzax();
        zm.m8271a(zzax, (IInterface) c1758a);
        zzax = zza(10, zzax);
        boolean a = zm.m8274a(zzax);
        zzax.recycle();
        return a;
    }

    public final C1758a mo2888b() {
        Parcel zza = zza(11, zzax());
        C1758a a = C1759a.m4494a(zza.readStrongBinder());
        zza.recycle();
        return a;
    }

    public final akp mo2889b(String str) {
        akp com_google_android_gms_internal_akp;
        Parcel zzax = zzax();
        zzax.writeString(str);
        Parcel zza = zza(2, zzax);
        IBinder readStrongBinder = zza.readStrongBinder();
        if (readStrongBinder == null) {
            com_google_android_gms_internal_akp = null;
        } else {
            IInterface queryLocalInterface = readStrongBinder.queryLocalInterface("com.google.android.gms.ads.internal.formats.client.INativeAdImage");
            com_google_android_gms_internal_akp = queryLocalInterface instanceof akp ? (akp) queryLocalInterface : new akr(readStrongBinder);
        }
        zza.recycle();
        return com_google_android_gms_internal_akp;
    }

    public final agn mo2890c() {
        Parcel zza = zza(7, zzax());
        agn a = ago.m4954a(zza.readStrongBinder());
        zza.recycle();
        return a;
    }

    public final void mo2891c(String str) {
        Parcel zzax = zzax();
        zzax.writeString(str);
        zzb(5, zzax);
    }

    public final void mo2892d() {
        zzb(6, zzax());
    }

    public final C1758a mo2893e() {
        Parcel zza = zza(9, zzax());
        C1758a a = C1759a.m4494a(zza.readStrongBinder());
        zza.recycle();
        return a;
    }

    public final void mo2894f() {
        zzb(8, zzax());
    }

    public final String mo2866l() {
        Parcel zza = zza(4, zzax());
        String readString = zza.readString();
        zza.recycle();
        return readString;
    }
}
