package com.google.android.gms.internal;

final class ig extends Thread {
    private /* synthetic */ String f5955a;

    ig(C1806if c1806if, String str) {
        this.f5955a = str;
    }

    public final void run() {
        new ij().mo3190a(this.f5955a);
    }
}
