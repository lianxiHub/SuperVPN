package com.google.android.gms.internal;

import android.view.MotionEvent;

public interface ajp {
    void mo2895a();

    void mo2896a(MotionEvent motionEvent);
}
