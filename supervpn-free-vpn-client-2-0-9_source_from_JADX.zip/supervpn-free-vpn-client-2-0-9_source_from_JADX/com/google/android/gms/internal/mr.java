package com.google.android.gms.internal;

import com.google.android.gms.analytics.C1728e;

final class mr implements C1728e {
    private int f6305a = 2;

    mr() {
    }

    public final int mo3287a() {
        return this.f6305a;
    }

    public final void mo3288a(String str) {
    }

    public final void mo3289b(String str) {
    }

    public final void mo3290c(String str) {
    }
}
