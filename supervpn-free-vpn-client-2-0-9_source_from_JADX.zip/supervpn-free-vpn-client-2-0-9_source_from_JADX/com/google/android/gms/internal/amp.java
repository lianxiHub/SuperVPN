package com.google.android.gms.internal;

import com.facebook.internal.NativeProtocol;
import java.util.Map;

final class amp implements anb {
    amp() {
    }

    public final void zza(jk jkVar, Map map) {
        String str = (String) map.get(NativeProtocol.WEB_DIALOG_ACTION);
        if ("pause".equals(str)) {
            jkVar.zzci();
        } else if ("resume".equals(str)) {
            jkVar.zzcj();
        }
    }
}
