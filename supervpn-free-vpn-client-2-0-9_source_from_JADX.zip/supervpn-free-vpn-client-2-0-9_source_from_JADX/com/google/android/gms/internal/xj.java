package com.google.android.gms.internal;

final class xj implements xh {
    private xj() {
    }

    public final byte[] mo3349a(byte[] bArr, int i, int i2) {
        Object obj = new byte[i2];
        System.arraycopy(bArr, i, obj, 0, i2);
        return obj;
    }
}
