package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;

@avl
@TargetApi(11)
public final class ko extends kq {
    public ko(jk jkVar, boolean z) {
        super(jkVar, z);
    }

    public final WebResourceResponse shouldInterceptRequest(WebView webView, String str) {
        return m7060a(webView, str, null);
    }
}
