package com.google.android.gms.internal;

import java.util.List;

public final class zzefp extends RuntimeException {
    private final List f7569a = null;

    public zzefp(ym ymVar) {
        super("Message was missing required fields.  (Lite runtime could not determine which fields were missing).");
    }

    public final zzeer m8567a() {
        return new zzeer(getMessage());
    }
}
