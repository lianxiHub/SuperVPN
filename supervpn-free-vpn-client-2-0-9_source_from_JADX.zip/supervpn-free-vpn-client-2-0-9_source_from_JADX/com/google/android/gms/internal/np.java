package com.google.android.gms.internal;

import android.content.SharedPreferences.Editor;
import android.util.Pair;
import com.google.android.gms.common.internal.zzbp;
import java.util.UUID;

public final class np {
    private final String f6396a;
    private final long f6397b;
    private /* synthetic */ nn f6398c;

    private np(nn nnVar, String str, long j) {
        this.f6398c = nnVar;
        zzbp.zzgf(str);
        zzbp.zzbh(j > 0);
        this.f6396a = str;
        this.f6397b = j;
    }

    private final void m7386b() {
        long currentTimeMillis = this.f6398c.m4364i().currentTimeMillis();
        Editor edit = this.f6398c.f6392a.edit();
        edit.remove(m7389e());
        edit.remove(m7390f());
        edit.putLong(m7388d(), currentTimeMillis);
        edit.commit();
    }

    private final long m7387c() {
        return this.f6398c.f6392a.getLong(m7388d(), 0);
    }

    private final String m7388d() {
        return String.valueOf(this.f6396a).concat(":start");
    }

    private final String m7389e() {
        return String.valueOf(this.f6396a).concat(":count");
    }

    private final String m7390f() {
        return String.valueOf(this.f6396a).concat(":value");
    }

    public final Pair m7391a() {
        long c = m7387c();
        c = c == 0 ? 0 : Math.abs(c - this.f6398c.m4364i().currentTimeMillis());
        if (c < this.f6397b) {
            return null;
        }
        if (c > (this.f6397b << 1)) {
            m7386b();
            return null;
        }
        String string = this.f6398c.f6392a.getString(m7390f(), null);
        long j = this.f6398c.f6392a.getLong(m7389e(), 0);
        m7386b();
        return (string == null || j <= 0) ? null : new Pair(string, Long.valueOf(j));
    }

    public final void m7392a(String str) {
        if (m7387c() == 0) {
            m7386b();
        }
        if (str == null) {
            str = "";
        }
        synchronized (this) {
            long j = this.f6398c.f6392a.getLong(m7389e(), 0);
            if (j <= 0) {
                Editor edit = this.f6398c.f6392a.edit();
                edit.putString(m7390f(), str);
                edit.putLong(m7389e(), 1);
                edit.apply();
                return;
            }
            Object obj = (UUID.randomUUID().getLeastSignificantBits() & Long.MAX_VALUE) < Long.MAX_VALUE / (j + 1) ? 1 : null;
            Editor edit2 = this.f6398c.f6392a.edit();
            if (obj != null) {
                edit2.putString(m7390f(), str);
            }
            edit2.putLong(m7389e(), j + 1);
            edit2.apply();
        }
    }
}
