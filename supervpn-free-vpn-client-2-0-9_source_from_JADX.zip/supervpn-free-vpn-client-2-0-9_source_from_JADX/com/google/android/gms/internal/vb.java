package com.google.android.gms.internal;

import com.google.android.gms.internal.tw.C1841b;
import com.google.android.gms.internal.tw.C1843c;
import com.google.android.gms.internal.tw.C1845d;
import com.google.android.gms.internal.zzdgq.zza;
import java.security.GeneralSecurityException;

final class vb implements ub {
    vb() {
    }

    private static ua m8003a(C1843c c1843c) {
        wc.m8057a(c1843c.m7841a(), 0);
        C1841b b = c1843c.m7844b();
        uo.m7945a(b.m7833a().m7850a());
        uo.m7943a(b.m7833a().m7853b());
        if (b.m7837c() == zzdfu.UNKNOWN_FORMAT) {
            throw new GeneralSecurityException("unknown EC point format");
        }
        uj.f6928a.m7936a(b.m7836b().m7827a());
        C1845d a = c1843c.m7844b().m7833a();
        return new va(uo.m7944a(a.m7850a(), c1843c.m7845c().m8505c(), c1843c.m7847e().m8505c()), a.m7854c().m8505c(), uo.m7943a(a.m7853b()), c1843c.m7844b().m7836b().m7827a(), c1843c.m7844b().m7837c());
    }

    private final ua m8004d(zzedk com_google_android_gms_internal_zzedk) {
        try {
            return m8003a(C1843c.m7839a(com_google_android_gms_internal_zzedk));
        } catch (zzeer e) {
            throw new GeneralSecurityException("invalid EciesAeadHkdfPublicKey.");
        }
    }

    public final /* synthetic */ Object mo3335a(zzedk com_google_android_gms_internal_zzedk) {
        return m8004d(com_google_android_gms_internal_zzedk);
    }

    public final /* synthetic */ ym mo3336b(ym ymVar) {
        throw new GeneralSecurityException("Not implemented.");
    }

    public final /* synthetic */ ym mo3337b(zzedk com_google_android_gms_internal_zzedk) {
        throw new GeneralSecurityException("Not implemented.");
    }

    public final zza mo3338c(zzedk com_google_android_gms_internal_zzedk) {
        throw new GeneralSecurityException("Not implemented.");
    }
}
