package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;

@avl
public final class ate implements atf {
    public final iq mo3104a(Context context) {
        return im.m6809a(new Bundle());
    }
}
