package com.google.android.gms.internal;

import android.os.IInterface;

public interface afz extends IInterface {
    void mo2788a(String str, String str2);
}
