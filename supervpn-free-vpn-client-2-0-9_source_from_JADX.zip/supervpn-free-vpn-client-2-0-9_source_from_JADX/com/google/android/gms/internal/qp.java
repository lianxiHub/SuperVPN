package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.dynamic.C1758a;

public final class qp extends xq implements qn {
    qp(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.flags.IFlagProvider");
    }

    public final boolean getBooleanFlagValue(String str, boolean z, int i) {
        Parcel zzax = zzax();
        zzax.writeString(str);
        zm.m8273a(zzax, z);
        zzax.writeInt(i);
        zzax = zza(2, zzax);
        boolean a = zm.m8274a(zzax);
        zzax.recycle();
        return a;
    }

    public final int getIntFlagValue(String str, int i, int i2) {
        Parcel zzax = zzax();
        zzax.writeString(str);
        zzax.writeInt(i);
        zzax.writeInt(i2);
        zzax = zza(3, zzax);
        int readInt = zzax.readInt();
        zzax.recycle();
        return readInt;
    }

    public final long getLongFlagValue(String str, long j, int i) {
        Parcel zzax = zzax();
        zzax.writeString(str);
        zzax.writeLong(j);
        zzax.writeInt(i);
        zzax = zza(4, zzax);
        long readLong = zzax.readLong();
        zzax.recycle();
        return readLong;
    }

    public final String getStringFlagValue(String str, String str2, int i) {
        Parcel zzax = zzax();
        zzax.writeString(str);
        zzax.writeString(str2);
        zzax.writeInt(i);
        zzax = zza(5, zzax);
        String readString = zzax.readString();
        zzax.recycle();
        return readString;
    }

    public final void init(C1758a c1758a) {
        Parcel zzax = zzax();
        zm.m8271a(zzax, (IInterface) c1758a);
        zzb(1, zzax);
    }
}
