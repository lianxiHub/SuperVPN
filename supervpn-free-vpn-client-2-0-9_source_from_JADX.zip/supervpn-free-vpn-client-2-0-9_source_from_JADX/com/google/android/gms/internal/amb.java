package com.google.android.gms.internal;

import com.google.android.gms.ads.formats.NativeAppInstallAd.OnAppInstallAdLoadedListener;

@avl
public final class amb extends all {
    private final OnAppInstallAdLoadedListener f4836a;

    public amb(OnAppInstallAdLoadedListener onAppInstallAdLoadedListener) {
        this.f4836a = onAppInstallAdLoadedListener;
    }

    public final void mo2958a(aky com_google_android_gms_internal_aky) {
        this.f4836a.onAppInstallAdLoaded(new alb(com_google_android_gms_internal_aky));
    }
}
