package com.google.android.gms.internal;

final class ac implements Runnable {
    private /* synthetic */ ef f4256a;
    private /* synthetic */ ab f4257b;

    ac(ab abVar, ef efVar) {
        this.f4257b = abVar;
        this.f4256a = efVar;
    }

    public final void run() {
        this.f4257b.f4168h.zza(this.f4256a);
        if (this.f4257b.f4172l != null) {
            this.f4257b.f4172l.release();
            this.f4257b.f4172l = null;
        }
    }
}
