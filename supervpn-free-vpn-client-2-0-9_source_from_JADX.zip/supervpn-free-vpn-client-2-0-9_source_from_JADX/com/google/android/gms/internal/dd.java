package com.google.android.gms.internal;

import android.os.IInterface;
import com.google.android.gms.dynamic.C1758a;

public interface dd extends IInterface {
    void mo3152a(C1758a c1758a);

    void mo3153a(C1758a c1758a, int i);

    void mo3154a(C1758a c1758a, zzaek com_google_android_gms_internal_zzaek);

    void mo3155b(C1758a c1758a);

    void mo3156b(C1758a c1758a, int i);

    void mo3157c(C1758a c1758a);

    void mo3158d(C1758a c1758a);

    void mo3159e(C1758a c1758a);

    void mo3160f(C1758a c1758a);

    void mo3161g(C1758a c1758a);
}
