package com.google.android.gms.internal;

import android.app.Activity;
import com.google.android.gms.dynamic.C1761c;
import com.google.android.gms.internal.aet.C1794a;

final class afb extends C1794a {
    private /* synthetic */ Activity f4466a;
    private /* synthetic */ aet f4467b;

    afb(aet com_google_android_gms_internal_aet, Activity activity) {
        this.f4467b = com_google_android_gms_internal_aet;
        this.f4466a = activity;
        super(com_google_android_gms_internal_aet);
    }

    public final /* synthetic */ Object mo2789a() {
        asz a = this.f4467b.f4437h.m6074a(this.f4466a);
        if (a != null) {
            return a;
        }
        aet.m4892a(this.f4466a, "ad_overlay");
        return null;
    }

    public final /* synthetic */ Object mo2790a(agc com_google_android_gms_internal_agc) {
        return com_google_android_gms_internal_agc.createAdOverlay(C1761c.m4495a(this.f4466a));
    }
}
