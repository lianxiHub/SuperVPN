package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.net.Uri;
import android.os.Build.VERSION;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.ViewTreeObserver.OnScrollChangedListener;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.facebook.appevents.AppEventsConstants;
import com.facebook.internal.ServerProtocol;
import com.google.android.gms.ads.internal.overlay.zzm;
import com.google.android.gms.ads.internal.zzbo;
import com.google.android.gms.ads.internal.zzbv;
import com.google.android.gms.ads.internal.zzv;
import com.google.android.gms.common.util.zzp;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

@avl
final class jx extends WebView implements OnGlobalLayoutListener, DownloadListener, jk {
    private ais f6035A;
    private ait f6036B;
    private WeakReference f6037C;
    private zzm f6038D;
    private boolean f6039E;
    private id f6040F;
    private int f6041G = -1;
    private int f6042H = -1;
    private int f6043I = -1;
    private int f6044J = -1;
    private Map f6045K;
    private final WindowManager f6046L;
    private final aeb f6047M;
    private final kb f6048a;
    private final Object f6049b = new Object();
    private final sv f6050c;
    private final zzajk f6051d;
    private final zzbo f6052e;
    private final zzv f6053f;
    private jl f6054g;
    private zzm f6055h;
    private zzjb f6056i;
    private boolean f6057j;
    private boolean f6058k;
    private boolean f6059l;
    private boolean f6060m;
    private Boolean f6061n;
    private int f6062o;
    private boolean f6063p = true;
    private boolean f6064q = false;
    private String f6065r = "";
    private kc f6066s;
    private boolean f6067t;
    private boolean f6068u;
    private ajp f6069v;
    private int f6070w;
    private int f6071x;
    private ais f6072y;
    private ais f6073z;

    private jx(kb kbVar, zzjb com_google_android_gms_internal_zzjb, boolean z, boolean z2, sv svVar, zzajk com_google_android_gms_internal_zzajk, aiu com_google_android_gms_internal_aiu, zzbo com_google_android_gms_ads_internal_zzbo, zzv com_google_android_gms_ads_internal_zzv, aeb com_google_android_gms_internal_aeb) {
        super(kbVar);
        this.f6048a = kbVar;
        this.f6056i = com_google_android_gms_internal_zzjb;
        this.f6059l = z;
        this.f6062o = -1;
        this.f6050c = svVar;
        this.f6051d = com_google_android_gms_internal_zzajk;
        this.f6052e = com_google_android_gms_ads_internal_zzbo;
        this.f6053f = com_google_android_gms_ads_internal_zzv;
        this.f6046L = (WindowManager) getContext().getSystemService("window");
        this.f6047M = com_google_android_gms_internal_aeb;
        setBackgroundColor(0);
        WebSettings settings = getSettings();
        settings.setAllowFileAccess(false);
        try {
            settings.setJavaScriptEnabled(true);
        } catch (Throwable e) {
            ii.m6517b("Unable to enable Javascript.", e);
        }
        settings.setSavePassword(false);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        if (VERSION.SDK_INT >= 21) {
            settings.setMixedContentMode(2);
        }
        settings.setUserAgentString(zzbv.zzea().m6636a((Context) kbVar, com_google_android_gms_internal_zzajk.f7336a));
        zzbv.zzec().mo3196a(getContext(), settings);
        setDownloadListener(this);
        m6974I();
        if (zzp.zzalf()) {
            addJavascriptInterface(new kf(this), "googleAdsJsInterface");
        }
        removeJavascriptInterface("accessibility");
        removeJavascriptInterface("accessibilityTraversal");
        this.f6040F = new id(this.f6048a.m7037a(), this, this, null);
        m6982a(com_google_android_gms_internal_aiu);
        zzbv.zzec().mo3208b((Context) kbVar);
    }

    private final boolean m6971F() {
        if (!this.f6054g.m6909b() && !this.f6054g.m6910c()) {
            return false;
        }
        int i;
        int i2;
        zzbv.zzea();
        DisplayMetrics a = gd.m6573a(this.f6046L);
        afc.m4920a();
        int b = ie.m6794b(a, a.widthPixels);
        afc.m4920a();
        int b2 = ie.m6794b(a, a.heightPixels);
        Activity a2 = this.f6048a.m7037a();
        if (a2 == null || a2.getWindow() == null) {
            i = b2;
            i2 = b;
        } else {
            zzbv.zzea();
            int[] a3 = gd.m6601a(a2);
            afc.m4920a();
            i2 = ie.m6794b(a, a3[0]);
            afc.m4920a();
            i = ie.m6794b(a, a3[1]);
        }
        if (this.f6042H == b && this.f6041G == b2 && this.f6043I == i2 && this.f6044J == i) {
            return false;
        }
        boolean z = (this.f6042H == b && this.f6041G == b2) ? false : true;
        this.f6042H = b;
        this.f6041G = b2;
        this.f6043I = i2;
        this.f6044J = i;
        new asw(this).m6042a(b, b2, i2, i, a.density, this.f6046L.getDefaultDisplay().getRotation());
        return z;
    }

    private final Boolean m6972G() {
        Boolean bool;
        synchronized (this.f6049b) {
            bool = this.f6061n;
        }
        return bool;
    }

    private final void m6973H() {
        ain.m5190a(this.f6036B.m5199a(), this.f6073z, "aeh2");
    }

    private final void m6974I() {
        synchronized (this.f6049b) {
            if (this.f6059l || this.f6056i.f7632d) {
                ii.m6516b("Enabling hardware acceleration on an overlay.");
                m6975J();
            } else if (VERSION.SDK_INT < 18) {
                ii.m6516b("Disabling hardware acceleration on an AdView.");
                synchronized (this.f6049b) {
                    if (!this.f6060m) {
                        zzbv.zzec().mo3200c((View) this);
                    }
                    this.f6060m = true;
                }
            } else {
                ii.m6516b("Enabling hardware acceleration on an AdView.");
                m6975J();
            }
        }
    }

    private final void m6975J() {
        synchronized (this.f6049b) {
            if (this.f6060m) {
                zzbv.zzec().mo3198b((View) this);
            }
            this.f6060m = false;
        }
    }

    private final void m6976K() {
        synchronized (this.f6049b) {
            if (!this.f6039E) {
                this.f6039E = true;
                zzbv.zzee().m6498z();
            }
        }
    }

    private final void m6977L() {
        synchronized (this.f6049b) {
            this.f6045K = null;
        }
    }

    private final void m6978M() {
        if (this.f6036B != null) {
            aiu a = this.f6036B.m5199a();
            if (a != null && zzbv.zzee().m6478f() != null) {
                zzbv.zzee().m6478f().m5187a(a);
            }
        }
    }

    static jx m6980a(Context context, zzjb com_google_android_gms_internal_zzjb, boolean z, boolean z2, sv svVar, zzajk com_google_android_gms_internal_zzajk, aiu com_google_android_gms_internal_aiu, zzbo com_google_android_gms_ads_internal_zzbo, zzv com_google_android_gms_ads_internal_zzv, aeb com_google_android_gms_internal_aeb) {
        return new jx(new kb(context), com_google_android_gms_internal_zzjb, z, z2, svVar, com_google_android_gms_internal_zzajk, com_google_android_gms_internal_aiu, com_google_android_gms_ads_internal_zzbo, com_google_android_gms_ads_internal_zzv, com_google_android_gms_internal_aeb);
    }

    private final void m6982a(aiu com_google_android_gms_internal_aiu) {
        m6978M();
        this.f6036B = new ait(new aiu(true, "make_wv", this.f6056i.f7629a));
        this.f6036B.m5199a().m5204a(com_google_android_gms_internal_aiu);
        this.f6073z = ain.m5189a(this.f6036B.m5199a());
        this.f6036B.m5200a("native:view_create", this.f6073z);
        this.f6035A = null;
        this.f6072y = null;
    }

    private final void m6983a(Boolean bool) {
        synchronized (this.f6049b) {
            this.f6061n = bool;
        }
        zzbv.zzee().m6464a(bool);
    }

    private final void m6986c(String str) {
        synchronized (this.f6049b) {
            if (mo3267q()) {
                ii.m6521e("The webview is destroyed. Ignoring action.");
            } else {
                loadUrl(str);
            }
        }
    }

    private final void m6987d(String str) {
        if (zzp.zzalh()) {
            if (m6972G() == null) {
                synchronized (this.f6049b) {
                    this.f6061n = zzbv.zzee().m6483k();
                    if (this.f6061n == null) {
                        try {
                            evaluateJavascript("(function(){})()", null);
                            m6983a(Boolean.valueOf(true));
                        } catch (IllegalStateException e) {
                            m6983a(Boolean.valueOf(false));
                        }
                    }
                }
            }
            if (m6972G().booleanValue()) {
                synchronized (this.f6049b) {
                    if (mo3267q()) {
                        ii.m6521e("The webview is destroyed. Ignoring action.");
                    } else {
                        evaluateJavascript(str, null);
                    }
                }
                return;
            }
            String str2 = "javascript:";
            String valueOf = String.valueOf(str);
            m6986c(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
            return;
        }
        str2 = "javascript:";
        valueOf = String.valueOf(str);
        m6986c(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
    }

    private final void m6988e(boolean z) {
        Map hashMap = new HashMap();
        hashMap.put("isVisible", z ? AppEventsConstants.EVENT_PARAM_VALUE_YES : AppEventsConstants.EVENT_PARAM_VALUE_NO);
        mo3238a("onAdVisibilityChanged", hashMap);
    }

    public final void mo3224A() {
        this.f6040F.m6779a();
    }

    public final void mo3225B() {
        if (this.f6035A == null) {
            this.f6035A = ain.m5189a(this.f6036B.m5199a());
            this.f6036B.m5200a("native:view_load", this.f6035A);
        }
    }

    public final OnClickListener mo3226C() {
        return (OnClickListener) this.f6037C.get();
    }

    public final ajp mo3227D() {
        ajp com_google_android_gms_internal_ajp;
        synchronized (this.f6049b) {
            com_google_android_gms_internal_ajp = this.f6069v;
        }
        return com_google_android_gms_internal_ajp;
    }

    public final void mo3228E() {
        setBackgroundColor(0);
    }

    public final WebView mo3229a() {
        return this;
    }

    public final void mo3230a(int i) {
        if (i == 0) {
            ain.m5190a(this.f6036B.m5199a(), this.f6073z, "aebb2");
        }
        m6973H();
        if (this.f6036B.m5199a() != null) {
            this.f6036B.m5199a().m5206a("close_type", String.valueOf(i));
        }
        Map hashMap = new HashMap(2);
        hashMap.put("closetype", String.valueOf(i));
        hashMap.put(ServerProtocol.FALLBACK_DIALOG_PARAM_VERSION, this.f6051d.f7336a);
        mo3238a("onhide", hashMap);
    }

    public final void mo3231a(Context context) {
        this.f6048a.setBaseContext(context);
        this.f6040F.m6780a(this.f6048a.m7037a());
    }

    public final void mo3232a(Context context, zzjb com_google_android_gms_internal_zzjb, aiu com_google_android_gms_internal_aiu) {
        synchronized (this.f6049b) {
            this.f6040F.m6781b();
            mo3231a(context);
            this.f6055h = null;
            this.f6056i = com_google_android_gms_internal_zzjb;
            this.f6059l = false;
            this.f6057j = false;
            this.f6065r = "";
            this.f6062o = -1;
            zzbv.zzec();
            gi.m6652b((jk) this);
            loadUrl("about:blank");
            this.f6054g.m6919l();
            setOnTouchListener(null);
            setOnClickListener(null);
            this.f6063p = true;
            this.f6064q = false;
            this.f6066s = null;
            m6982a(com_google_android_gms_internal_aiu);
            this.f6067t = false;
            this.f6070w = 0;
            zzbv.zzex();
            anz.m5600a((jk) this);
            m6977L();
        }
    }

    public final void mo3233a(zzm com_google_android_gms_ads_internal_overlay_zzm) {
        synchronized (this.f6049b) {
            this.f6055h = com_google_android_gms_ads_internal_overlay_zzm;
        }
    }

    public final void mo3181a(acb com_google_android_gms_internal_acb) {
        synchronized (this.f6049b) {
            this.f6067t = com_google_android_gms_internal_acb.f4259a;
        }
        m6988e(com_google_android_gms_internal_acb.f4259a);
    }

    public final void mo3234a(ajp com_google_android_gms_internal_ajp) {
        synchronized (this.f6049b) {
            this.f6069v = com_google_android_gms_internal_ajp;
        }
    }

    public final void mo3235a(kc kcVar) {
        synchronized (this.f6049b) {
            if (this.f6066s != null) {
                ii.m6518c("Attempt to create multiple AdWebViewVideoControllers.");
                return;
            }
            this.f6066s = kcVar;
        }
    }

    public final void mo3236a(zzjb com_google_android_gms_internal_zzjb) {
        synchronized (this.f6049b) {
            this.f6056i = com_google_android_gms_internal_zzjb;
            requestLayout();
        }
    }

    public final void mo3237a(String str) {
        synchronized (this.f6049b) {
            try {
                super.loadUrl(str);
            } catch (Exception e) {
                Throwable e2 = e;
                zzbv.zzee().m6466a(e2, "AdWebViewImpl.loadUrlUnsafe");
                ii.m6519c("Could not call loadUrl. ", e2);
            } catch (NoClassDefFoundError e3) {
                e2 = e3;
                zzbv.zzee().m6466a(e2, "AdWebViewImpl.loadUrlUnsafe");
                ii.m6519c("Could not call loadUrl. ", e2);
            } catch (IncompatibleClassChangeError e4) {
                e2 = e4;
                zzbv.zzee().m6466a(e2, "AdWebViewImpl.loadUrlUnsafe");
                ii.m6519c("Could not call loadUrl. ", e2);
            } catch (UnsatisfiedLinkError e5) {
                e2 = e5;
                zzbv.zzee().m6466a(e2, "AdWebViewImpl.loadUrlUnsafe");
                ii.m6519c("Could not call loadUrl. ", e2);
            }
        }
    }

    public final void mo3238a(String str, Map map) {
        try {
            zzb(str, zzbv.zzea().m6638a(map));
        } catch (JSONException e) {
            ii.m6521e("Could not convert parameters to JSON.");
        }
    }

    public final void mo3239a(boolean z) {
        synchronized (this.f6049b) {
            Object obj = z != this.f6059l ? 1 : null;
            this.f6059l = z;
            m6974I();
            if (obj != null) {
                new asw(this).m6046c(z ? "expanded" : "default");
            }
        }
    }

    public final void mo3240b() {
        m6973H();
        Map hashMap = new HashMap(1);
        hashMap.put(ServerProtocol.FALLBACK_DIALOG_PARAM_VERSION, this.f6051d.f7336a);
        mo3238a("onhide", hashMap);
    }

    public final void mo3241b(int i) {
        synchronized (this.f6049b) {
            this.f6062o = i;
            if (this.f6055h != null) {
                this.f6055h.setRequestedOrientation(this.f6062o);
            }
        }
    }

    public final void mo3242b(zzm com_google_android_gms_ads_internal_overlay_zzm) {
        synchronized (this.f6049b) {
            this.f6038D = com_google_android_gms_ads_internal_overlay_zzm;
        }
    }

    public final void mo3243b(String str) {
        synchronized (this.f6049b) {
            if (str == null) {
                str = "";
            }
            this.f6065r = str;
        }
    }

    public final void mo3244b(boolean z) {
        synchronized (this.f6049b) {
            if (this.f6055h != null) {
                this.f6055h.zza(this.f6054g.m6909b(), z);
            } else {
                this.f6057j = z;
            }
        }
    }

    public final void mo3245c() {
        if (this.f6072y == null) {
            ain.m5190a(this.f6036B.m5199a(), this.f6073z, "aes2");
            this.f6072y = ain.m5189a(this.f6036B.m5199a());
            this.f6036B.m5200a("native:view_show", this.f6072y);
        }
        Map hashMap = new HashMap(1);
        hashMap.put(ServerProtocol.FALLBACK_DIALOG_PARAM_VERSION, this.f6051d.f7336a);
        mo3238a("onshow", hashMap);
    }

    public final void mo3246c(boolean z) {
        synchronized (this.f6049b) {
            this.f6063p = z;
        }
    }

    public final void mo3247d() {
        Map hashMap = new HashMap(3);
        zzbv.zzea();
        hashMap.put("app_muted", String.valueOf(gd.m6621e()));
        zzbv.zzea();
        hashMap.put("app_volume", String.valueOf(gd.m6615d()));
        zzbv.zzea();
        hashMap.put("device_volume", String.valueOf(gd.m6629i(getContext())));
        mo3238a("volume", hashMap);
    }

    public final void mo3248d(boolean z) {
        synchronized (this.f6049b) {
            this.f6070w = (z ? 1 : -1) + this.f6070w;
            if (this.f6070w <= 0 && this.f6055h != null) {
                this.f6055h.zzmu();
            }
        }
    }

    public final void destroy() {
        synchronized (this.f6049b) {
            m6978M();
            this.f6040F.m6781b();
            if (this.f6055h != null) {
                this.f6055h.close();
                this.f6055h.onDestroy();
                this.f6055h = null;
            }
            this.f6054g.m6919l();
            if (this.f6058k) {
                return;
            }
            zzbv.zzex();
            anz.m5600a((jk) this);
            m6977L();
            this.f6058k = true;
            et.m6522a("Initiating WebView self destruct sequence in 3...");
            this.f6054g.m6914g();
        }
    }

    public final Activity mo3250e() {
        return this.f6048a.m7037a();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    @android.annotation.TargetApi(19)
    public final void evaluateJavascript(java.lang.String r3, android.webkit.ValueCallback r4) {
        /*
        r2 = this;
        r1 = r2.f6049b;
        monitor-enter(r1);
        r0 = r2.mo3267q();	 Catch:{ all -> 0x001c }
        if (r0 == 0) goto L_0x0017;
    L_0x0009:
        r0 = "The webview is destroyed. Ignoring action.";
        com.google.android.gms.internal.ii.m6521e(r0);	 Catch:{ all -> 0x001c }
        if (r4 == 0) goto L_0x0015;
    L_0x0011:
        r0 = 0;
        r4.onReceiveValue(r0);	 Catch:{ all -> 0x001c }
    L_0x0015:
        monitor-exit(r1);	 Catch:{ all -> 0x001c }
    L_0x0016:
        return;
    L_0x0017:
        super.evaluateJavascript(r3, r4);	 Catch:{ all -> 0x001c }
        monitor-exit(r1);	 Catch:{ all -> 0x001c }
        goto L_0x0016;
    L_0x001c:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x001c }
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.jx.evaluateJavascript(java.lang.String, android.webkit.ValueCallback):void");
    }

    public final Context mo3251f() {
        return this.f6048a.m7038b();
    }

    protected final void finalize() {
        try {
            if (this.f6049b != null) {
                synchronized (this.f6049b) {
                    if (!this.f6058k) {
                        this.f6054g.m6919l();
                        zzbv.zzex();
                        anz.m5600a((jk) this);
                        m6977L();
                        m6976K();
                    }
                }
            }
            super.finalize();
        } catch (Throwable th) {
            super.finalize();
        }
    }

    public final zzv mo3252g() {
        return this.f6053f;
    }

    public final zzm mo3253h() {
        zzm com_google_android_gms_ads_internal_overlay_zzm;
        synchronized (this.f6049b) {
            com_google_android_gms_ads_internal_overlay_zzm = this.f6055h;
        }
        return com_google_android_gms_ads_internal_overlay_zzm;
    }

    public final zzm mo3254i() {
        zzm com_google_android_gms_ads_internal_overlay_zzm;
        synchronized (this.f6049b) {
            com_google_android_gms_ads_internal_overlay_zzm = this.f6038D;
        }
        return com_google_android_gms_ads_internal_overlay_zzm;
    }

    public final zzjb mo3255j() {
        zzjb com_google_android_gms_internal_zzjb;
        synchronized (this.f6049b) {
            com_google_android_gms_internal_zzjb = this.f6056i;
        }
        return com_google_android_gms_internal_zzjb;
    }

    public final jl mo3256k() {
        return this.f6054g;
    }

    public final boolean mo3257l() {
        boolean z;
        synchronized (this.f6049b) {
            z = this.f6057j;
        }
        return z;
    }

    public final void loadData(String str, String str2, String str3) {
        synchronized (this.f6049b) {
            if (mo3267q()) {
                ii.m6521e("The webview is destroyed. Ignoring action.");
            } else {
                super.loadData(str, str2, str3);
            }
        }
    }

    public final void loadDataWithBaseURL(String str, String str2, String str3, String str4, String str5) {
        synchronized (this.f6049b) {
            if (mo3267q()) {
                ii.m6521e("The webview is destroyed. Ignoring action.");
            } else {
                super.loadDataWithBaseURL(str, str2, str3, str4, str5);
            }
        }
    }

    public final void loadUrl(String str) {
        synchronized (this.f6049b) {
            if (mo3267q()) {
                ii.m6521e("The webview is destroyed. Ignoring action.");
            } else {
                try {
                    super.loadUrl(str);
                } catch (Exception e) {
                    Throwable e2 = e;
                    zzbv.zzee().m6466a(e2, "AdWebViewImpl.loadUrl");
                    ii.m6519c("Could not call loadUrl. ", e2);
                } catch (NoClassDefFoundError e3) {
                    e2 = e3;
                    zzbv.zzee().m6466a(e2, "AdWebViewImpl.loadUrl");
                    ii.m6519c("Could not call loadUrl. ", e2);
                } catch (IncompatibleClassChangeError e4) {
                    e2 = e4;
                    zzbv.zzee().m6466a(e2, "AdWebViewImpl.loadUrl");
                    ii.m6519c("Could not call loadUrl. ", e2);
                }
            }
        }
    }

    public final sv mo3261m() {
        return this.f6050c;
    }

    public final zzajk mo3262n() {
        return this.f6051d;
    }

    public final boolean mo3263o() {
        boolean z;
        synchronized (this.f6049b) {
            z = this.f6059l;
        }
        return z;
    }

    protected final void onAttachedToWindow() {
        boolean z = true;
        synchronized (this.f6049b) {
            super.onAttachedToWindow();
            if (!mo3267q()) {
                this.f6040F.m6782c();
            }
            boolean z2 = this.f6067t;
            if (this.f6054g == null || !this.f6054g.m6910c()) {
                z = z2;
            } else {
                if (!this.f6068u) {
                    OnGlobalLayoutListener d = this.f6054g.m6911d();
                    if (d != null) {
                        zzbv.zzey();
                        if (this == null) {
                            throw null;
                        }
                        jf.m6821a((View) this, d);
                    }
                    OnScrollChangedListener e = this.f6054g.m6912e();
                    if (e != null) {
                        zzbv.zzey();
                        if (this == null) {
                            throw null;
                        }
                        jf.m6822a((View) this, e);
                    }
                    this.f6068u = true;
                }
                m6971F();
            }
            m6988e(z);
        }
    }

    protected final void onDetachedFromWindow() {
        synchronized (this.f6049b) {
            if (!mo3267q()) {
                this.f6040F.m6783d();
            }
            super.onDetachedFromWindow();
            if (this.f6068u && this.f6054g != null && this.f6054g.m6910c() && getViewTreeObserver() != null && getViewTreeObserver().isAlive()) {
                OnGlobalLayoutListener d = this.f6054g.m6911d();
                if (d != null) {
                    zzbv.zzec().mo3205a(getViewTreeObserver(), d);
                }
                OnScrollChangedListener e = this.f6054g.m6912e();
                if (e != null) {
                    getViewTreeObserver().removeOnScrollChangedListener(e);
                }
                this.f6068u = false;
            }
        }
        m6988e(false);
    }

    public final void onDownloadStart(String str, String str2, String str3, String str4, long j) {
        try {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setDataAndType(Uri.parse(str), str4);
            zzbv.zzea();
            gd.m6588a(getContext(), intent);
        } catch (ActivityNotFoundException e) {
            ii.m6516b(new StringBuilder((String.valueOf(str).length() + 51) + String.valueOf(str4).length()).append("Couldn't find an Activity to view url/mimetype: ").append(str).append(" / ").append(str4).toString());
        }
    }

    @TargetApi(21)
    protected final void onDraw(Canvas canvas) {
        if (!mo3267q()) {
            if (VERSION.SDK_INT != 21 || !canvas.isHardwareAccelerated() || isAttachedToWindow()) {
                super.onDraw(canvas);
                if (this.f6054g != null && this.f6054g.m6920m() != null) {
                    this.f6054g.m6920m().zzcr();
                }
            }
        }
    }

    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        if (((Boolean) zzbv.zzen().m5171a(aig.ar)).booleanValue()) {
            float axisValue = motionEvent.getAxisValue(9);
            float axisValue2 = motionEvent.getAxisValue(10);
            if (motionEvent.getActionMasked() == 8 && ((axisValue > 0.0f && !canScrollVertically(-1)) || ((axisValue < 0.0f && !canScrollVertically(1)) || ((axisValue2 > 0.0f && !canScrollHorizontally(-1)) || (axisValue2 < 0.0f && !canScrollHorizontally(1)))))) {
                return false;
            }
        }
        return super.onGenericMotionEvent(motionEvent);
    }

    public final void onGlobalLayout() {
        boolean F = m6971F();
        zzm h = mo3253h();
        if (h != null && F) {
            h.zzmr();
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    @android.annotation.SuppressLint({"DrawAllocation"})
    protected final void onMeasure(int r10, int r11) {
        /*
        r9 = this;
        r0 = 2147483647; // 0x7fffffff float:NaN double:1.060997895E-314;
        r8 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r7 = 8;
        r6 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r4 = r9.f6049b;
        monitor-enter(r4);
        r1 = r9.mo3267q();	 Catch:{ all -> 0x002e }
        if (r1 == 0) goto L_0x0019;
    L_0x0012:
        r0 = 0;
        r1 = 0;
        r9.setMeasuredDimension(r0, r1);	 Catch:{ all -> 0x002e }
        monitor-exit(r4);	 Catch:{ all -> 0x002e }
    L_0x0018:
        return;
    L_0x0019:
        r1 = r9.isInEditMode();	 Catch:{ all -> 0x002e }
        if (r1 != 0) goto L_0x0029;
    L_0x001f:
        r1 = r9.f6059l;	 Catch:{ all -> 0x002e }
        if (r1 != 0) goto L_0x0029;
    L_0x0023:
        r1 = r9.f6056i;	 Catch:{ all -> 0x002e }
        r1 = r1.f7636h;	 Catch:{ all -> 0x002e }
        if (r1 == 0) goto L_0x0031;
    L_0x0029:
        super.onMeasure(r10, r11);	 Catch:{ all -> 0x002e }
        monitor-exit(r4);	 Catch:{ all -> 0x002e }
        goto L_0x0018;
    L_0x002e:
        r0 = move-exception;
        monitor-exit(r4);	 Catch:{ all -> 0x002e }
        throw r0;
    L_0x0031:
        r1 = r9.f6056i;	 Catch:{ all -> 0x002e }
        r1 = r1.f7637i;	 Catch:{ all -> 0x002e }
        if (r1 == 0) goto L_0x0089;
    L_0x0037:
        r0 = com.google.android.gms.internal.aig.bV;	 Catch:{ all -> 0x002e }
        r1 = com.google.android.gms.ads.internal.zzbv.zzen();	 Catch:{ all -> 0x002e }
        r0 = r1.m5171a(r0);	 Catch:{ all -> 0x002e }
        r0 = (java.lang.Boolean) r0;	 Catch:{ all -> 0x002e }
        r0 = r0.booleanValue();	 Catch:{ all -> 0x002e }
        if (r0 != 0) goto L_0x004f;
    L_0x0049:
        r0 = com.google.android.gms.common.util.zzp.zzalf();	 Catch:{ all -> 0x002e }
        if (r0 != 0) goto L_0x0054;
    L_0x004f:
        super.onMeasure(r10, r11);	 Catch:{ all -> 0x002e }
        monitor-exit(r4);	 Catch:{ all -> 0x002e }
        goto L_0x0018;
    L_0x0054:
        r0 = "/contentHeight";
        r1 = new com.google.android.gms.internal.jy;	 Catch:{ all -> 0x002e }
        r1.<init>(r9);	 Catch:{ all -> 0x002e }
        r9.zza(r0, r1);	 Catch:{ all -> 0x002e }
        r0 = "(function() {  var height = -1;  if (document.body) {    height = document.body.offsetHeight;  } else if (document.documentElement) {    height = document.documentElement.offsetHeight;  }  var url = 'gmsg://mobileads.google.com/contentHeight?';  url += 'height=' + height;  try {    window.googleAdsJsInterface.notify(url);  } catch (e) {    var frame = document.getElementById('afma-notify-fluid');    if (!frame) {      frame = document.createElement('IFRAME');      frame.id = 'afma-notify-fluid';      frame.style.display = 'none';      var body = document.body || document.documentElement;      body.appendChild(frame);    }    frame.src = url;  }})();";
        r9.m6987d(r0);	 Catch:{ all -> 0x002e }
        r0 = r9.f6048a;	 Catch:{ all -> 0x002e }
        r0 = r0.getResources();	 Catch:{ all -> 0x002e }
        r0 = r0.getDisplayMetrics();	 Catch:{ all -> 0x002e }
        r0 = r0.density;	 Catch:{ all -> 0x002e }
        r1 = android.view.View.MeasureSpec.getSize(r10);	 Catch:{ all -> 0x002e }
        r2 = r9.f6071x;	 Catch:{ all -> 0x002e }
        switch(r2) {
            case -1: goto L_0x0084;
            default: goto L_0x007a;
        };	 Catch:{ all -> 0x002e }
    L_0x007a:
        r2 = r9.f6071x;	 Catch:{ all -> 0x002e }
        r2 = (float) r2;	 Catch:{ all -> 0x002e }
        r0 = r0 * r2;
        r0 = (int) r0;	 Catch:{ all -> 0x002e }
    L_0x007f:
        r9.setMeasuredDimension(r1, r0);	 Catch:{ all -> 0x002e }
        monitor-exit(r4);	 Catch:{ all -> 0x002e }
        goto L_0x0018;
    L_0x0084:
        r0 = android.view.View.MeasureSpec.getSize(r11);	 Catch:{ all -> 0x002e }
        goto L_0x007f;
    L_0x0089:
        r1 = r9.f6056i;	 Catch:{ all -> 0x002e }
        r1 = r1.f7632d;	 Catch:{ all -> 0x002e }
        if (r1 == 0) goto L_0x00a7;
    L_0x008f:
        r0 = new android.util.DisplayMetrics;	 Catch:{ all -> 0x002e }
        r0.<init>();	 Catch:{ all -> 0x002e }
        r1 = r9.f6046L;	 Catch:{ all -> 0x002e }
        r1 = r1.getDefaultDisplay();	 Catch:{ all -> 0x002e }
        r1.getMetrics(r0);	 Catch:{ all -> 0x002e }
        r1 = r0.widthPixels;	 Catch:{ all -> 0x002e }
        r0 = r0.heightPixels;	 Catch:{ all -> 0x002e }
        r9.setMeasuredDimension(r1, r0);	 Catch:{ all -> 0x002e }
        monitor-exit(r4);	 Catch:{ all -> 0x002e }
        goto L_0x0018;
    L_0x00a7:
        r2 = android.view.View.MeasureSpec.getMode(r10);	 Catch:{ all -> 0x002e }
        r3 = android.view.View.MeasureSpec.getSize(r10);	 Catch:{ all -> 0x002e }
        r5 = android.view.View.MeasureSpec.getMode(r11);	 Catch:{ all -> 0x002e }
        r1 = android.view.View.MeasureSpec.getSize(r11);	 Catch:{ all -> 0x002e }
        if (r2 == r6) goto L_0x00bb;
    L_0x00b9:
        if (r2 != r8) goto L_0x0157;
    L_0x00bb:
        r2 = r3;
    L_0x00bc:
        if (r5 == r6) goto L_0x00c0;
    L_0x00be:
        if (r5 != r8) goto L_0x00c1;
    L_0x00c0:
        r0 = r1;
    L_0x00c1:
        r5 = r9.f6056i;	 Catch:{ all -> 0x002e }
        r5 = r5.f7634f;	 Catch:{ all -> 0x002e }
        if (r5 > r2) goto L_0x00cd;
    L_0x00c7:
        r2 = r9.f6056i;	 Catch:{ all -> 0x002e }
        r2 = r2.f7631c;	 Catch:{ all -> 0x002e }
        if (r2 <= r0) goto L_0x0141;
    L_0x00cd:
        r0 = r9.f6048a;	 Catch:{ all -> 0x002e }
        r0 = r0.getResources();	 Catch:{ all -> 0x002e }
        r0 = r0.getDisplayMetrics();	 Catch:{ all -> 0x002e }
        r0 = r0.density;	 Catch:{ all -> 0x002e }
        r2 = r9.f6056i;	 Catch:{ all -> 0x002e }
        r2 = r2.f7634f;	 Catch:{ all -> 0x002e }
        r2 = (float) r2;	 Catch:{ all -> 0x002e }
        r2 = r2 / r0;
        r2 = (int) r2;	 Catch:{ all -> 0x002e }
        r5 = r9.f6056i;	 Catch:{ all -> 0x002e }
        r5 = r5.f7631c;	 Catch:{ all -> 0x002e }
        r5 = (float) r5;	 Catch:{ all -> 0x002e }
        r5 = r5 / r0;
        r5 = (int) r5;	 Catch:{ all -> 0x002e }
        r3 = (float) r3;	 Catch:{ all -> 0x002e }
        r3 = r3 / r0;
        r3 = (int) r3;	 Catch:{ all -> 0x002e }
        r1 = (float) r1;	 Catch:{ all -> 0x002e }
        r0 = r1 / r0;
        r0 = (int) r0;	 Catch:{ all -> 0x002e }
        r1 = 103; // 0x67 float:1.44E-43 double:5.1E-322;
        r6 = new java.lang.StringBuilder;	 Catch:{ all -> 0x002e }
        r6.<init>(r1);	 Catch:{ all -> 0x002e }
        r1 = "Not enough space to show ad. Needs ";
        r1 = r6.append(r1);	 Catch:{ all -> 0x002e }
        r1 = r1.append(r2);	 Catch:{ all -> 0x002e }
        r2 = "x";
        r1 = r1.append(r2);	 Catch:{ all -> 0x002e }
        r1 = r1.append(r5);	 Catch:{ all -> 0x002e }
        r2 = " dp, but only has ";
        r1 = r1.append(r2);	 Catch:{ all -> 0x002e }
        r1 = r1.append(r3);	 Catch:{ all -> 0x002e }
        r2 = "x";
        r1 = r1.append(r2);	 Catch:{ all -> 0x002e }
        r0 = r1.append(r0);	 Catch:{ all -> 0x002e }
        r1 = " dp.";
        r0 = r0.append(r1);	 Catch:{ all -> 0x002e }
        r0 = r0.toString();	 Catch:{ all -> 0x002e }
        com.google.android.gms.internal.ii.m6521e(r0);	 Catch:{ all -> 0x002e }
        r0 = r9.getVisibility();	 Catch:{ all -> 0x002e }
        if (r0 == r7) goto L_0x0139;
    L_0x0135:
        r0 = 4;
        r9.setVisibility(r0);	 Catch:{ all -> 0x002e }
    L_0x0139:
        r0 = 0;
        r1 = 0;
        r9.setMeasuredDimension(r0, r1);	 Catch:{ all -> 0x002e }
    L_0x013e:
        monitor-exit(r4);	 Catch:{ all -> 0x002e }
        goto L_0x0018;
    L_0x0141:
        r0 = r9.getVisibility();	 Catch:{ all -> 0x002e }
        if (r0 == r7) goto L_0x014b;
    L_0x0147:
        r0 = 0;
        r9.setVisibility(r0);	 Catch:{ all -> 0x002e }
    L_0x014b:
        r0 = r9.f6056i;	 Catch:{ all -> 0x002e }
        r0 = r0.f7634f;	 Catch:{ all -> 0x002e }
        r1 = r9.f6056i;	 Catch:{ all -> 0x002e }
        r1 = r1.f7631c;	 Catch:{ all -> 0x002e }
        r9.setMeasuredDimension(r0, r1);	 Catch:{ all -> 0x002e }
        goto L_0x013e;
    L_0x0157:
        r2 = r0;
        goto L_0x00bc;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.jx.onMeasure(int, int):void");
    }

    public final void onPause() {
        if (!mo3267q()) {
            try {
                super.onPause();
            } catch (Throwable e) {
                ii.m6517b("Could not pause webview.", e);
            }
        }
    }

    public final void onResume() {
        if (!mo3267q()) {
            try {
                super.onResume();
            } catch (Throwable e) {
                ii.m6517b("Could not resume webview.", e);
            }
        }
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.f6054g.m6910c()) {
            synchronized (this.f6049b) {
                if (this.f6069v != null) {
                    this.f6069v.mo2896a(motionEvent);
                }
            }
        } else if (this.f6050c != null) {
            this.f6050c.m7619a(motionEvent);
        }
        return mo3267q() ? false : super.onTouchEvent(motionEvent);
    }

    public final int mo3266p() {
        int i;
        synchronized (this.f6049b) {
            i = this.f6062o;
        }
        return i;
    }

    public final boolean mo3267q() {
        boolean z;
        synchronized (this.f6049b) {
            z = this.f6058k;
        }
        return z;
    }

    public final void mo3268r() {
        synchronized (this.f6049b) {
            et.m6522a("Destroying WebView!");
            m6976K();
            gd.f5832a.post(new ka(this));
        }
    }

    public final boolean mo3269s() {
        boolean z;
        synchronized (this.f6049b) {
            z = this.f6063p;
        }
        return z;
    }

    public final void setOnClickListener(OnClickListener onClickListener) {
        this.f6037C = new WeakReference(onClickListener);
        super.setOnClickListener(onClickListener);
    }

    public final void setWebViewClient(WebViewClient webViewClient) {
        super.setWebViewClient(webViewClient);
        if (webViewClient instanceof jl) {
            this.f6054g = (jl) webViewClient;
        }
    }

    public final void stopLoading() {
        if (!mo3267q()) {
            try {
                super.stopLoading();
            } catch (Throwable e) {
                ii.m6517b("Could not stop loading webview.", e);
            }
        }
    }

    public final boolean mo3275t() {
        boolean z;
        synchronized (this.f6049b) {
            z = this.f6064q;
        }
        return z;
    }

    public final String mo3276u() {
        String str;
        synchronized (this.f6049b) {
            str = this.f6065r;
        }
        return str;
    }

    public final jj mo3277v() {
        return null;
    }

    public final ais mo3278w() {
        return this.f6073z;
    }

    public final ait mo3279x() {
        return this.f6036B;
    }

    public final kc mo3280y() {
        kc kcVar;
        synchronized (this.f6049b) {
            kcVar = this.f6066s;
        }
        return kcVar;
    }

    public final boolean mo3281z() {
        boolean z;
        synchronized (this.f6049b) {
            z = this.f6070w > 0;
        }
        return z;
    }

    public final void zza(String str, anb com_google_android_gms_internal_anb) {
        if (this.f6054g != null) {
            this.f6054g.m6903a(str, com_google_android_gms_internal_anb);
        }
    }

    public final void zza(String str, JSONObject jSONObject) {
        if (jSONObject == null) {
            jSONObject = new JSONObject();
        }
        zzi(str, jSONObject.toString());
    }

    public final void zzb(String str, anb com_google_android_gms_internal_anb) {
        if (this.f6054g != null) {
            this.f6054g.m6908b(str, com_google_android_gms_internal_anb);
        }
    }

    public final void zzb(String str, JSONObject jSONObject) {
        if (jSONObject == null) {
            jSONObject = new JSONObject();
        }
        String jSONObject2 = jSONObject.toString();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("(window.AFMA_ReceiveMessage || function() {})('");
        stringBuilder.append(str);
        stringBuilder.append("'");
        stringBuilder.append(",");
        stringBuilder.append(jSONObject2);
        stringBuilder.append(");");
        String str2 = "Dispatching AFMA event: ";
        jSONObject2 = String.valueOf(stringBuilder.toString());
        ii.m6516b(jSONObject2.length() != 0 ? str2.concat(jSONObject2) : new String(str2));
        m6987d(stringBuilder.toString());
    }

    public final void zzci() {
        synchronized (this.f6049b) {
            this.f6064q = true;
            if (this.f6052e != null) {
                this.f6052e.zzci();
            }
        }
    }

    public final void zzcj() {
        synchronized (this.f6049b) {
            this.f6064q = false;
            if (this.f6052e != null) {
                this.f6052e.zzcj();
            }
        }
    }

    public final void zzi(String str, String str2) {
        m6987d(new StringBuilder((String.valueOf(str).length() + 3) + String.valueOf(str2).length()).append(str).append("(").append(str2).append(");").toString());
    }
}
