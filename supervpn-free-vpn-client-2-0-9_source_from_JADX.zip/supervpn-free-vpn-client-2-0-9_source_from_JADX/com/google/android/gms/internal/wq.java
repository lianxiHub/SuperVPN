package com.google.android.gms.internal;

public final class wq extends wz {
    private final StackTraceElement[] f7020d;

    public wq(td tdVar, String str, String str2, oh ohVar, int i, int i2, StackTraceElement[] stackTraceElementArr) {
        super(tdVar, str, str2, ohVar, i, 45);
        this.f7020d = stackTraceElementArr;
    }

    protected final void mo3344a() {
        if (this.f7020d != null) {
            sy syVar = new sy((String) this.c.invoke(null, new Object[]{this.f7020d}));
            synchronized (this.b) {
                this.b.f6442B = syVar.f6767a;
                if (syVar.f6768b.booleanValue()) {
                    this.b.f6449I = Integer.valueOf(syVar.f6769c.booleanValue() ? 0 : 1);
                }
            }
        }
    }
}
