package com.google.android.gms.internal;

final class ary implements Runnable {
    private /* synthetic */ arr f5158a;

    ary(arr com_google_android_gms_internal_arr) {
        this.f5158a = com_google_android_gms_internal_arr;
    }

    public final void run() {
        try {
            this.f5158a.f5151a.mo2984c();
        } catch (Throwable e) {
            ii.m6519c("Could not call onAdLeftApplication.", e);
        }
    }
}
