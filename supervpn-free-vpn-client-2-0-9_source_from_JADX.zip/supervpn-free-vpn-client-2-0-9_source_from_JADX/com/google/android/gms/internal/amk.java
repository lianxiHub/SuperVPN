package com.google.android.gms.internal;

import android.text.TextUtils;
import com.facebook.internal.NativeProtocol;
import com.google.android.gms.ads.internal.zzbv;
import java.util.Map;

@avl
public final class amk implements anb {
    public final void zza(jk jkVar, Map map) {
        String str = (String) map.get(NativeProtocol.WEB_DIALOG_ACTION);
        String str2;
        if ("tick".equals(str)) {
            str = (String) map.get("label");
            str2 = (String) map.get("start_label");
            String str3 = (String) map.get("timestamp");
            if (TextUtils.isEmpty(str)) {
                ii.m6521e("No label given for CSI tick.");
            } else if (TextUtils.isEmpty(str3)) {
                ii.m6521e("No timestamp given for CSI tick.");
            } else {
                try {
                    long parseLong = (Long.parseLong(str3) - zzbv.zzeg().currentTimeMillis()) + zzbv.zzeg().elapsedRealtime();
                    if (TextUtils.isEmpty(str2)) {
                        str2 = "native:view_load";
                    }
                    jkVar.mo3279x().m5201a(str, str2, parseLong);
                } catch (Throwable e) {
                    ii.m6519c("Malformed timestamp for CSI tick.", e);
                }
            }
        } else if ("experiment".equals(str)) {
            str = (String) map.get("value");
            if (TextUtils.isEmpty(str)) {
                ii.m6521e("No value given for CSI experiment.");
                return;
            }
            aiu a = jkVar.mo3279x().m5199a();
            if (a == null) {
                ii.m6521e("No ticker for WebView, dropping experiment ID.");
            } else {
                a.m5206a("e", str);
            }
        } else if ("extra".equals(str)) {
            str = (String) map.get("name");
            str2 = (String) map.get("value");
            if (TextUtils.isEmpty(str2)) {
                ii.m6521e("No value given for CSI extra.");
            } else if (TextUtils.isEmpty(str)) {
                ii.m6521e("No name given for CSI extra.");
            } else {
                aiu a2 = jkVar.mo3279x().m5199a();
                if (a2 == null) {
                    ii.m6521e("No ticker for WebView, dropping extra parameter.");
                } else {
                    a2.m5206a(str, str2);
                }
            }
        }
    }
}
