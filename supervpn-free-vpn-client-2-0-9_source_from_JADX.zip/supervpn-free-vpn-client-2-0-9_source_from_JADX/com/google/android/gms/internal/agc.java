package com.google.android.gms.internal;

import android.os.IInterface;
import com.google.android.gms.dynamic.C1758a;

public interface agc extends IInterface {
    afp createAdLoaderBuilder(C1758a c1758a, String str, aqs com_google_android_gms_internal_aqs, int i);

    asz createAdOverlay(C1758a c1758a);

    afu createBannerAdManager(C1758a c1758a, zzjb com_google_android_gms_internal_zzjb, String str, aqs com_google_android_gms_internal_aqs, int i);

    atj createInAppPurchaseManager(C1758a c1758a);

    afu createInterstitialAdManager(C1758a c1758a, zzjb com_google_android_gms_internal_zzjb, String str, aqs com_google_android_gms_internal_aqs, int i);

    akt createNativeAdViewDelegate(C1758a c1758a, C1758a c1758a2);

    cb createRewardedVideoAd(C1758a c1758a, aqs com_google_android_gms_internal_aqs, int i);

    afu createSearchAdManager(C1758a c1758a, zzjb com_google_android_gms_internal_zzjb, String str, int i);

    agi getMobileAdsSettingsManager(C1758a c1758a);

    agi getMobileAdsSettingsManagerWithClientJarVersion(C1758a c1758a, int i);
}
