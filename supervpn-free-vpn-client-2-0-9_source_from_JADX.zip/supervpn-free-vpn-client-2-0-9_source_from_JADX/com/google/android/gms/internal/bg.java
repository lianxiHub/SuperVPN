package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.zzbv;
import java.util.concurrent.Callable;

final class bg implements Callable {
    private /* synthetic */ Context f5515a;
    private /* synthetic */ bf f5516b;

    bg(bf bfVar, Context context) {
        this.f5516b = bfVar;
        this.f5515a = context;
    }

    public final /* synthetic */ Object call() {
        bd a;
        bh bhVar = (bh) this.f5516b.f5514a.get(this.f5515a);
        if (bhVar != null) {
            if ((bhVar.f5517a + ((Long) zzbv.zzen().m5171a(aig.aZ)).longValue() < zzbv.zzeg().currentTimeMillis() ? 1 : null) == null) {
                if (((Boolean) zzbv.zzen().m5171a(aig.aY)).booleanValue()) {
                    a = new be(this.f5515a, bhVar.f5518b).m6210a();
                    this.f5516b.f5514a.put(this.f5515a, new bh(this.f5516b, a));
                    return a;
                }
            }
        }
        a = new be(this.f5515a).m6210a();
        this.f5516b.f5514a.put(this.f5515a, new bh(this.f5516b, a));
        return a;
    }
}
