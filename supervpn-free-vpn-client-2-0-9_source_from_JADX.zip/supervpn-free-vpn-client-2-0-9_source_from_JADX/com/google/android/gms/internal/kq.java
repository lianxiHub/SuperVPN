package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.content.Context;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import com.google.android.gms.ads.internal.zzbv;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@avl
@TargetApi(11)
public class kq extends jl {
    public kq(jk jkVar, boolean z) {
        super(jkVar, z);
    }

    protected final WebResourceResponse m7060a(WebView webView, String str, Map map) {
        Exception e;
        if (webView instanceof jk) {
            jk jkVar = (jk) webView;
            if (this.b != null) {
                this.b.mo3175a(str, map, 1);
            }
            if (!"mraid.js".equalsIgnoreCase(new File(str).getName())) {
                return super.shouldInterceptRequest(webView, str);
            }
            if (jkVar.mo3256k() != null) {
                jkVar.mo3256k().m6921n();
            }
            String str2 = jkVar.mo3255j().f7632d ? (String) zzbv.zzen().m5171a(aig.f4579F) : jkVar.mo3263o() ? (String) zzbv.zzen().m5171a(aig.f4578E) : (String) zzbv.zzen().m5171a(aig.f4577D);
            String str3;
            try {
                Context context = jkVar.getContext();
                str3 = jkVar.mo3262n().f7336a;
                Map hashMap = new HashMap();
                hashMap.put("User-Agent", zzbv.zzea().m6636a(context, str3));
                hashMap.put("Cache-Control", "max-stale=3600");
                str3 = (String) new hj(context).m6747a(str2, hashMap).get(60, TimeUnit.SECONDS);
                return str3 == null ? null : new WebResourceResponse(WebRequest.CONTENT_TYPE_JAVASCRIPT, WebRequest.CHARSET_UTF_8, new ByteArrayInputStream(str3.getBytes(WebRequest.CHARSET_UTF_8)));
            } catch (IOException e2) {
                e = e2;
                str2 = "Could not fetch MRAID JS. ";
                str3 = String.valueOf(e.getMessage());
                ii.m6521e(str3.length() == 0 ? str2.concat(str3) : new String(str2));
                return null;
            } catch (ExecutionException e3) {
                e = e3;
                str2 = "Could not fetch MRAID JS. ";
                str3 = String.valueOf(e.getMessage());
                if (str3.length() == 0) {
                }
                ii.m6521e(str3.length() == 0 ? str2.concat(str3) : new String(str2));
                return null;
            } catch (InterruptedException e4) {
                e = e4;
                str2 = "Could not fetch MRAID JS. ";
                str3 = String.valueOf(e.getMessage());
                if (str3.length() == 0) {
                }
                ii.m6521e(str3.length() == 0 ? str2.concat(str3) : new String(str2));
                return null;
            } catch (TimeoutException e5) {
                e = e5;
                str2 = "Could not fetch MRAID JS. ";
                str3 = String.valueOf(e.getMessage());
                if (str3.length() == 0) {
                }
                ii.m6521e(str3.length() == 0 ? str2.concat(str3) : new String(str2));
                return null;
            }
        }
        ii.m6521e("Tried to intercept request from a WebView that wasn't an AdWebView.");
        return null;
    }
}
