package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

final class ft extends fu {
    private /* synthetic */ Context f5819a;
    private /* synthetic */ fv f5820b;

    ft(Context context, fv fvVar) {
        this.f5819a = context;
        this.f5820b = fvVar;
        super();
    }

    public final void zzdc() {
        SharedPreferences sharedPreferences = this.f5819a.getSharedPreferences("admob", 0);
        Bundle bundle = new Bundle();
        bundle.putString("content_url_hashes", sharedPreferences.getString("content_url_hashes", ""));
        if (this.f5820b != null) {
            this.f5820b.mo3185a(bundle);
        }
    }
}
