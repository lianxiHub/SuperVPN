package com.google.android.gms.internal;

import android.os.IBinder;

public final class ato extends xq implements atm {
    ato(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.purchase.client.IPlayStorePurchaseListener");
    }
}
