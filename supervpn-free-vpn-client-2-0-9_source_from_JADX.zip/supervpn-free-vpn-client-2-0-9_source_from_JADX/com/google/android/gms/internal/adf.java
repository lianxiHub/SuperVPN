package com.google.android.gms.internal;

import android.support.v4.internal.view.SupportMenu;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;

@avl
public final class adf extends ada {
    private MessageDigest f4360b;

    public final byte[] mo2776a(String str) {
        byte[] array;
        int i = 0;
        String[] split = str.split(" ");
        int a;
        if (split.length == 1) {
            a = ade.m4813a(split[0]);
            ByteBuffer allocate = ByteBuffer.allocate(4);
            allocate.order(ByteOrder.LITTLE_ENDIAN);
            allocate.putInt(a);
            array = allocate.array();
        } else if (split.length < 5) {
            byte[] bArr = new byte[(split.length << 1)];
            for (a = 0; a < split.length; a++) {
                int a2 = ade.m4813a(split[a]);
                a2 = (a2 >> 16) ^ (SupportMenu.USER_MASK & a2);
                byte[] bArr2 = new byte[]{(byte) a2, (byte) (a2 >> 8)};
                bArr[a << 1] = bArr2[0];
                bArr[(a << 1) + 1] = bArr2[1];
            }
            array = bArr;
        } else {
            array = new byte[split.length];
            while (i < split.length) {
                int a3 = ade.m4813a(split[i]);
                array[i] = (byte) ((a3 >> 24) ^ (((a3 & 255) ^ ((a3 >> 8) & 255)) ^ ((a3 >> 16) & 255)));
                i++;
            }
        }
        this.f4360b = m4808a();
        synchronized (this.a) {
            if (this.f4360b == null) {
                array = new byte[0];
            } else {
                this.f4360b.reset();
                this.f4360b.update(array);
                Object digest = this.f4360b.digest();
                array = new byte[(digest.length > 4 ? 4 : digest.length)];
                System.arraycopy(digest, 0, array, 0, array.length);
            }
        }
        return array;
    }
}
