package com.google.android.gms.internal;

public interface ajf {
    void mo3189a();
}
