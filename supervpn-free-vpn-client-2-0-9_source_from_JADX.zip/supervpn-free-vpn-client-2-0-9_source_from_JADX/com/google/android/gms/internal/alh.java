package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.dynamic.C1758a.C1759a;
import java.util.List;

public abstract class alh extends yo implements alg {
    public alh() {
        attachInterface(this, "com.google.android.gms.ads.internal.formats.client.INativeCustomTemplateAd");
    }

    public static alg m5350a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.formats.client.INativeCustomTemplateAd");
        return queryLocalInterface instanceof alg ? (alg) queryLocalInterface : new ali(iBinder);
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        if (zza(i, parcel, parcel2, i2)) {
            return true;
        }
        String a;
        IInterface b;
        switch (i) {
            case 1:
                a = mo2885a(parcel.readString());
                parcel2.writeNoException();
                parcel2.writeString(a);
                return true;
            case 2:
                b = mo2889b(parcel.readString());
                parcel2.writeNoException();
                zm.m8271a(parcel2, b);
                return true;
            case 3:
                List a2 = mo2886a();
                parcel2.writeNoException();
                parcel2.writeStringList(a2);
                return true;
            case 4:
                a = mo2866l();
                parcel2.writeNoException();
                parcel2.writeString(a);
                return true;
            case 5:
                mo2891c(parcel.readString());
                parcel2.writeNoException();
                return true;
            case 6:
                mo2892d();
                parcel2.writeNoException();
                return true;
            case 7:
                b = mo2890c();
                parcel2.writeNoException();
                zm.m8271a(parcel2, b);
                return true;
            case 8:
                mo2894f();
                parcel2.writeNoException();
                return true;
            case 9:
                b = mo2893e();
                parcel2.writeNoException();
                zm.m8271a(parcel2, b);
                return true;
            case 10:
                boolean a3 = mo2887a(C1759a.m4494a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                zm.m8273a(parcel2, a3);
                return true;
            case 11:
                b = mo2888b();
                parcel2.writeNoException();
                zm.m8271a(parcel2, b);
                return true;
            default:
                return false;
        }
    }
}
