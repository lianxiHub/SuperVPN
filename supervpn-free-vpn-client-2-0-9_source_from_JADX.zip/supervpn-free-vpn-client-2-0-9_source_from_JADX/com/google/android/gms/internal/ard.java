package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.Parcel;

public final class ard extends xq implements arb {
    ard(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.mediation.client.IMediationResponseMetadata");
    }

    public final int mo2990a() {
        Parcel zza = zza(1, zzax());
        int readInt = zza.readInt();
        zza.recycle();
        return readInt;
    }
}
