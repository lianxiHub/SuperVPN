package com.google.android.gms.internal;

import android.view.View;
import android.view.View.OnClickListener;

final class asm implements OnClickListener {
    private /* synthetic */ asl f5203a;

    asm(asl com_google_android_gms_internal_asl) {
        this.f5203a = com_google_android_gms_internal_asl;
    }

    public final void onClick(View view) {
        this.f5203a.m6057a(true);
    }
}
