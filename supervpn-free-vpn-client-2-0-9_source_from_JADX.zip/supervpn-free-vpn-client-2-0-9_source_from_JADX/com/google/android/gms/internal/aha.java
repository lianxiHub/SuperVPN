package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.reward.RewardedVideoAd;
import com.google.android.gms.common.internal.zzbp;
import com.google.android.gms.dynamic.C1761c;
import com.mopub.volley.DefaultRetryPolicy;

@avl
public final class aha {
    private static aha f4546a;
    private static final Object f4547b = new Object();
    private agi f4548c;
    private RewardedVideoAd f4549d;

    private aha() {
    }

    public static aha m5076a() {
        aha com_google_android_gms_internal_aha;
        synchronized (f4547b) {
            if (f4546a == null) {
                f4546a = new aha();
            }
            com_google_android_gms_internal_aha = f4546a;
        }
        return com_google_android_gms_internal_aha;
    }

    public final RewardedVideoAd m5077a(Context context) {
        RewardedVideoAd rewardedVideoAd;
        synchronized (f4547b) {
            if (this.f4549d != null) {
                rewardedVideoAd = this.f4549d;
            } else {
                this.f4549d = new cn(context, (cb) aet.m4891a(context, false, new afa(afc.m4921b(), context, new aqq())));
                rewardedVideoAd = this.f4549d;
            }
        }
        return rewardedVideoAd;
    }

    public final void m5078a(float f) {
        boolean z = true;
        boolean z2 = 0.0f <= f && f <= DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;
        zzbp.zzb(z2, (Object) "The app volume must be a value between 0 and 1 inclusive.");
        if (this.f4548c == null) {
            z = false;
        }
        zzbp.zza(z, (Object) "MobileAds.initialize() must be called prior to setting the app volume.");
        try {
            this.f4548c.setAppVolume(f);
        } catch (Throwable e) {
            ii.m6517b("Unable to set app volume.", e);
        }
    }

    public final void m5079a(Context context, String str) {
        zzbp.zza(this.f4548c != null, (Object) "MobileAds.initialize() must be called prior to opening debug menu.");
        try {
            this.f4548c.zzc(C1761c.m4495a((Object) context), str);
        } catch (Throwable e) {
            ii.m6517b("Unable to open debug menu.", e);
        }
    }

    public final void m5080a(Context context, String str, ahc com_google_android_gms_internal_ahc) {
        synchronized (f4547b) {
            if (this.f4548c != null) {
            } else if (context == null) {
                throw new IllegalArgumentException("Context cannot be null.");
            } else {
                try {
                    this.f4548c = (agi) aet.m4891a(context, false, new aey(afc.m4921b(), context));
                    this.f4548c.initialize();
                    if (str != null) {
                        this.f4548c.zzc(str, C1761c.m4495a(new ahb(this, context)));
                    }
                } catch (Throwable e) {
                    ii.m6519c("MobileAdsSettingManager initialization failed", e);
                }
            }
        }
    }

    public final void m5081a(boolean z) {
        zzbp.zza(this.f4548c != null, (Object) "MobileAds.initialize() must be called prior to setting the app volume.");
        try {
            this.f4548c.setAppMuted(z);
        } catch (Throwable e) {
            ii.m6517b("Unable to set app mute state.", e);
        }
    }
}
