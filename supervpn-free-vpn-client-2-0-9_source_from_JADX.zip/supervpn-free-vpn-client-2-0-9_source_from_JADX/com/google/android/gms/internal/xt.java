package com.google.android.gms.internal;

public interface xt extends Comparable {
    zzefz m8150a();

    boolean m8151b();
}
