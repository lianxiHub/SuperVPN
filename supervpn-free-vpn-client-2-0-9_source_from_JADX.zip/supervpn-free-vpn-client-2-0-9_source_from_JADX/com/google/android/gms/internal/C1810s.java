package com.google.android.gms.internal;

import android.os.IInterface;

public interface C1810s extends IInterface {
    void mo3285a(zzaao com_google_android_gms_internal_zzaao);
}
