package com.google.android.gms.internal;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.webkit.JsPromptResult;

final class kl implements OnClickListener {
    private /* synthetic */ JsPromptResult f6152a;

    kl(JsPromptResult jsPromptResult) {
        this.f6152a = jsPromptResult;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        this.f6152a.cancel();
    }
}
