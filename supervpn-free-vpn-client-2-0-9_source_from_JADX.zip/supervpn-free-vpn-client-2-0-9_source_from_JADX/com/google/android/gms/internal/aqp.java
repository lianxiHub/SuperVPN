package com.google.android.gms.internal;

final class aqp implements Runnable {
    private /* synthetic */ aqi f5119a;

    aqp(aqo com_google_android_gms_internal_aqo, aqi com_google_android_gms_internal_aqi) {
        this.f5119a = com_google_android_gms_internal_aqi;
    }

    public final void run() {
        try {
            this.f5119a.f5082c.mo3009c();
        } catch (Throwable e) {
            ii.m6519c("Could not destroy mediation adapter.", e);
        }
    }
}
