package com.google.android.gms.internal;

final class bv implements Runnable {
    private /* synthetic */ bu f5543a;

    bv(bu buVar) {
        this.f5543a = buVar;
    }

    public final void run() {
        this.f5543a.zzg(1);
    }
}
