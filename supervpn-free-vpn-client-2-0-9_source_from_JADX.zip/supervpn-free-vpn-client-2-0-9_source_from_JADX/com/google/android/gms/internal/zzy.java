package com.google.android.gms.internal;

public class zzy extends zzaa {
    public zzy(aim com_google_android_gms_internal_aim) {
        super(com_google_android_gms_internal_aim);
    }
}
