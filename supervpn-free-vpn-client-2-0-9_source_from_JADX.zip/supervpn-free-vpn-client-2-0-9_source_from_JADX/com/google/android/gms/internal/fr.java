package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

final class fr extends fu {
    private /* synthetic */ Context f5815a;
    private /* synthetic */ fv f5816b;

    fr(Context context, fv fvVar) {
        this.f5815a = context;
        this.f5816b = fvVar;
        super();
    }

    public final void zzdc() {
        SharedPreferences sharedPreferences = this.f5815a.getSharedPreferences("admob", 0);
        Bundle bundle = new Bundle();
        bundle.putBoolean("content_url_opted_out", sharedPreferences.getBoolean("content_url_opted_out", true));
        if (this.f5816b != null) {
            this.f5816b.mo3185a(bundle);
        }
    }
}
