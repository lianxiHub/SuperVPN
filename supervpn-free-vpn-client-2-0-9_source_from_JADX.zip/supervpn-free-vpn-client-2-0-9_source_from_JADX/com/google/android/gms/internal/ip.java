package com.google.android.gms.internal;

import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

@avl
final class ip implements iq {
    private final Object f5962a;
    private final ir f5963b = new ir();

    ip(Object obj) {
        this.f5962a = obj;
        this.f5963b.m6813a();
    }

    public final boolean cancel(boolean z) {
        return false;
    }

    public final Object get() {
        return this.f5962a;
    }

    public final Object get(long j, TimeUnit timeUnit) {
        return this.f5962a;
    }

    public final boolean isCancelled() {
        return false;
    }

    public final boolean isDone() {
        return true;
    }

    public final void zza(Runnable runnable, Executor executor) {
        this.f5963b.m6814a(runnable, executor);
    }
}
