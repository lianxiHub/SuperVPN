package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.internal.view.SupportMenu;
import android.util.SparseArray;
import com.google.android.gms.common.internal.safeparcel.zzc;
import com.google.android.gms.common.internal.safeparcel.zzd;
import com.google.android.gms.common.internal.zzbp;
import com.google.android.gms.common.util.zza;
import com.google.android.gms.common.util.zzb;
import com.google.android.gms.common.util.zzn;
import com.google.android.gms.common.util.zzo;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class zzbdi extends zzbda {
    public static final Creator CREATOR = new qa();
    private final int f7384a;
    private final Parcel f7385b;
    private final int f7386c = 2;
    private final zzbdd f7387d;
    private final String f7388e;
    private int f7389f;
    private int f7390g;

    zzbdi(int i, Parcel parcel, zzbdd com_google_android_gms_internal_zzbdd) {
        this.f7384a = i;
        this.f7385b = (Parcel) zzbp.zzu(parcel);
        this.f7387d = com_google_android_gms_internal_zzbdd;
        if (this.f7387d == null) {
            this.f7388e = null;
        } else {
            this.f7388e = this.f7387d.m8388a();
        }
        this.f7389f = 2;
    }

    private static HashMap m8391a(Bundle bundle) {
        HashMap hashMap = new HashMap();
        for (String str : bundle.keySet()) {
            hashMap.put(str, bundle.getString(str));
        }
        return hashMap;
    }

    private static void m8392a(StringBuilder stringBuilder, int i, Object obj) {
        switch (i) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                stringBuilder.append(obj);
                return;
            case 7:
                stringBuilder.append("\"").append(zzn.zzgk(obj.toString())).append("\"");
                return;
            case 8:
                stringBuilder.append("\"").append(zzb.encode((byte[]) obj)).append("\"");
                return;
            case 9:
                stringBuilder.append("\"").append(zzb.zzj((byte[]) obj));
                stringBuilder.append("\"");
                return;
            case 10:
                zzo.zza(stringBuilder, (HashMap) obj);
                return;
            case 11:
                throw new IllegalArgumentException("Method does not accept concrete type.");
            default:
                throw new IllegalArgumentException("Unknown type = " + i);
        }
    }

    private final void m8393a(StringBuilder stringBuilder, zzbcy com_google_android_gms_internal_zzbcy, Parcel parcel, int i) {
        double[] dArr = null;
        int i2 = 0;
        int length;
        if (com_google_android_gms_internal_zzbcy.f7366d) {
            stringBuilder.append("[");
            int dataPosition;
            switch (com_google_android_gms_internal_zzbcy.f7365c) {
                case 0:
                    int[] zzw = com.google.android.gms.common.internal.safeparcel.zzb.zzw(parcel, i);
                    length = zzw.length;
                    while (i2 < length) {
                        if (i2 != 0) {
                            stringBuilder.append(",");
                        }
                        stringBuilder.append(Integer.toString(zzw[i2]));
                        i2++;
                    }
                    break;
                case 1:
                    Object[] objArr;
                    length = com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, i);
                    dataPosition = parcel.dataPosition();
                    if (length != 0) {
                        int readInt = parcel.readInt();
                        objArr = new BigInteger[readInt];
                        while (i2 < readInt) {
                            objArr[i2] = new BigInteger(parcel.createByteArray());
                            i2++;
                        }
                        parcel.setDataPosition(length + dataPosition);
                    }
                    zza.zza(stringBuilder, objArr);
                    break;
                case 2:
                    zza.zza(stringBuilder, com.google.android.gms.common.internal.safeparcel.zzb.zzx(parcel, i));
                    break;
                case 3:
                    zza.zza(stringBuilder, com.google.android.gms.common.internal.safeparcel.zzb.zzy(parcel, i));
                    break;
                case 4:
                    length = com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, i);
                    i2 = parcel.dataPosition();
                    if (length != 0) {
                        dArr = parcel.createDoubleArray();
                        parcel.setDataPosition(length + i2);
                    }
                    zza.zza(stringBuilder, dArr);
                    break;
                case 5:
                    zza.zza(stringBuilder, com.google.android.gms.common.internal.safeparcel.zzb.zzz(parcel, i));
                    break;
                case 6:
                    zza.zza(stringBuilder, com.google.android.gms.common.internal.safeparcel.zzb.zzv(parcel, i));
                    break;
                case 7:
                    zza.zza(stringBuilder, com.google.android.gms.common.internal.safeparcel.zzb.zzaa(parcel, i));
                    break;
                case 8:
                case 9:
                case 10:
                    throw new UnsupportedOperationException("List of type BASE64, BASE64_URL_SAFE, or STRING_MAP is not supported");
                case 11:
                    Parcel[] zzae = com.google.android.gms.common.internal.safeparcel.zzb.zzae(parcel, i);
                    dataPosition = zzae.length;
                    for (int i3 = 0; i3 < dataPosition; i3++) {
                        if (i3 > 0) {
                            stringBuilder.append(",");
                        }
                        zzae[i3].setDataPosition(0);
                        m8395a(stringBuilder, com_google_android_gms_internal_zzbcy.m8384b(), zzae[i3]);
                    }
                    break;
                default:
                    throw new IllegalStateException("Unknown field type out.");
            }
            stringBuilder.append("]");
            return;
        }
        switch (com_google_android_gms_internal_zzbcy.f7365c) {
            case 0:
                stringBuilder.append(com.google.android.gms.common.internal.safeparcel.zzb.zzg(parcel, i));
                return;
            case 1:
                stringBuilder.append(com.google.android.gms.common.internal.safeparcel.zzb.zzk(parcel, i));
                return;
            case 2:
                stringBuilder.append(com.google.android.gms.common.internal.safeparcel.zzb.zzi(parcel, i));
                return;
            case 3:
                stringBuilder.append(com.google.android.gms.common.internal.safeparcel.zzb.zzl(parcel, i));
                return;
            case 4:
                stringBuilder.append(com.google.android.gms.common.internal.safeparcel.zzb.zzn(parcel, i));
                return;
            case 5:
                stringBuilder.append(com.google.android.gms.common.internal.safeparcel.zzb.zzp(parcel, i));
                return;
            case 6:
                stringBuilder.append(com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, i));
                return;
            case 7:
                stringBuilder.append("\"").append(zzn.zzgk(com.google.android.gms.common.internal.safeparcel.zzb.zzq(parcel, i))).append("\"");
                return;
            case 8:
                stringBuilder.append("\"").append(zzb.encode(com.google.android.gms.common.internal.safeparcel.zzb.zzt(parcel, i))).append("\"");
                return;
            case 9:
                stringBuilder.append("\"").append(zzb.zzj(com.google.android.gms.common.internal.safeparcel.zzb.zzt(parcel, i)));
                stringBuilder.append("\"");
                return;
            case 10:
                Bundle zzs = com.google.android.gms.common.internal.safeparcel.zzb.zzs(parcel, i);
                Set<String> keySet = zzs.keySet();
                keySet.size();
                stringBuilder.append("{");
                length = 1;
                for (String str : keySet) {
                    if (length == 0) {
                        stringBuilder.append(",");
                    }
                    stringBuilder.append("\"").append(str).append("\"");
                    stringBuilder.append(":");
                    stringBuilder.append("\"").append(zzn.zzgk(zzs.getString(str))).append("\"");
                    length = 0;
                }
                stringBuilder.append("}");
                return;
            case 11:
                Parcel zzad = com.google.android.gms.common.internal.safeparcel.zzb.zzad(parcel, i);
                zzad.setDataPosition(0);
                m8395a(stringBuilder, com_google_android_gms_internal_zzbcy.m8384b(), zzad);
                return;
            default:
                throw new IllegalStateException("Unknown field type out");
        }
    }

    private final void m8394a(StringBuilder stringBuilder, zzbcy com_google_android_gms_internal_zzbcy, Object obj) {
        if (com_google_android_gms_internal_zzbcy.f7364b) {
            ArrayList arrayList = (ArrayList) obj;
            stringBuilder.append("[");
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                if (i != 0) {
                    stringBuilder.append(",");
                }
                m8392a(stringBuilder, com_google_android_gms_internal_zzbcy.f7363a, arrayList.get(i));
            }
            stringBuilder.append("]");
            return;
        }
        m8392a(stringBuilder, com_google_android_gms_internal_zzbcy.f7363a, obj);
    }

    private final void m8395a(StringBuilder stringBuilder, Map map, Parcel parcel) {
        SparseArray sparseArray = new SparseArray();
        for (Entry entry : map.entrySet()) {
            Entry entry2;
            sparseArray.put(((zzbcy) entry2.getValue()).f7368f, entry2);
        }
        stringBuilder.append('{');
        int zzd = com.google.android.gms.common.internal.safeparcel.zzb.zzd(parcel);
        Object obj = null;
        while (parcel.dataPosition() < zzd) {
            int readInt = parcel.readInt();
            entry2 = (Entry) sparseArray.get(SupportMenu.USER_MASK & readInt);
            if (entry2 != null) {
                if (obj != null) {
                    stringBuilder.append(",");
                }
                String str = (String) entry2.getKey();
                zzbcy com_google_android_gms_internal_zzbcy = (zzbcy) entry2.getValue();
                stringBuilder.append("\"").append(str).append("\":");
                if (com_google_android_gms_internal_zzbcy.m8383a()) {
                    switch (com_google_android_gms_internal_zzbcy.f7365c) {
                        case 0:
                            m8394a(stringBuilder, com_google_android_gms_internal_zzbcy, pt.m7479a(com_google_android_gms_internal_zzbcy, Integer.valueOf(com.google.android.gms.common.internal.safeparcel.zzb.zzg(parcel, readInt))));
                            break;
                        case 1:
                            m8394a(stringBuilder, com_google_android_gms_internal_zzbcy, pt.m7479a(com_google_android_gms_internal_zzbcy, com.google.android.gms.common.internal.safeparcel.zzb.zzk(parcel, readInt)));
                            break;
                        case 2:
                            m8394a(stringBuilder, com_google_android_gms_internal_zzbcy, pt.m7479a(com_google_android_gms_internal_zzbcy, Long.valueOf(com.google.android.gms.common.internal.safeparcel.zzb.zzi(parcel, readInt))));
                            break;
                        case 3:
                            m8394a(stringBuilder, com_google_android_gms_internal_zzbcy, pt.m7479a(com_google_android_gms_internal_zzbcy, Float.valueOf(com.google.android.gms.common.internal.safeparcel.zzb.zzl(parcel, readInt))));
                            break;
                        case 4:
                            m8394a(stringBuilder, com_google_android_gms_internal_zzbcy, pt.m7479a(com_google_android_gms_internal_zzbcy, Double.valueOf(com.google.android.gms.common.internal.safeparcel.zzb.zzn(parcel, readInt))));
                            break;
                        case 5:
                            m8394a(stringBuilder, com_google_android_gms_internal_zzbcy, pt.m7479a(com_google_android_gms_internal_zzbcy, com.google.android.gms.common.internal.safeparcel.zzb.zzp(parcel, readInt)));
                            break;
                        case 6:
                            m8394a(stringBuilder, com_google_android_gms_internal_zzbcy, pt.m7479a(com_google_android_gms_internal_zzbcy, Boolean.valueOf(com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, readInt))));
                            break;
                        case 7:
                            m8394a(stringBuilder, com_google_android_gms_internal_zzbcy, pt.m7479a(com_google_android_gms_internal_zzbcy, com.google.android.gms.common.internal.safeparcel.zzb.zzq(parcel, readInt)));
                            break;
                        case 8:
                        case 9:
                            m8394a(stringBuilder, com_google_android_gms_internal_zzbcy, pt.m7479a(com_google_android_gms_internal_zzbcy, com.google.android.gms.common.internal.safeparcel.zzb.zzt(parcel, readInt)));
                            break;
                        case 10:
                            m8394a(stringBuilder, com_google_android_gms_internal_zzbcy, pt.m7479a(com_google_android_gms_internal_zzbcy, m8391a(com.google.android.gms.common.internal.safeparcel.zzb.zzs(parcel, readInt))));
                            break;
                        case 11:
                            throw new IllegalArgumentException("Method does not accept concrete type.");
                        default:
                            throw new IllegalArgumentException("Unknown field out type = " + com_google_android_gms_internal_zzbcy.f7365c);
                    }
                }
                m8393a(stringBuilder, com_google_android_gms_internal_zzbcy, parcel, readInt);
                obj = 1;
            }
        }
        if (parcel.dataPosition() != zzd) {
            throw new zzc("Overread allowed size end=" + zzd, parcel);
        }
        stringBuilder.append('}');
    }

    private Parcel m8396b() {
        switch (this.f7389f) {
            case 0:
                this.f7390g = zzd.zze(this.f7385b);
                break;
            case 1:
                break;
        }
        zzd.zzai(this.f7385b, this.f7390g);
        this.f7389f = 2;
        return this.f7385b;
    }

    public final Object mo3384a(String str) {
        throw new UnsupportedOperationException("Converting to JSON does not require this method.");
    }

    public final Map mo3386a() {
        return this.f7387d == null ? null : this.f7387d.m8389a(this.f7388e);
    }

    public final boolean mo3385b(String str) {
        throw new UnsupportedOperationException("Converting to JSON does not require this method.");
    }

    public String toString() {
        zzbp.zzb(this.f7387d, (Object) "Cannot convert to JSON on client side.");
        Parcel b = m8396b();
        b.setDataPosition(0);
        StringBuilder stringBuilder = new StringBuilder(100);
        m8395a(stringBuilder, this.f7387d.m8389a(this.f7388e), b);
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        Parcelable parcelable;
        int zze = zzd.zze(parcel);
        zzd.zzc(parcel, 1, this.f7384a);
        zzd.zza(parcel, 2, m8396b(), false);
        switch (this.f7386c) {
            case 0:
                parcelable = null;
                break;
            case 1:
                parcelable = this.f7387d;
                break;
            case 2:
                parcelable = this.f7387d;
                break;
            default:
                throw new IllegalStateException("Invalid creation type: " + this.f7386c);
        }
        zzd.zza(parcel, 3, parcelable, i, false);
        zzd.zzai(parcel, zze);
    }
}
