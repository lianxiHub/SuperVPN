package com.google.android.gms.internal;

import android.app.Activity;
import android.app.Application.ActivityLifecycleCallbacks;
import android.os.Bundle;

final class ace implements acl {
    private /* synthetic */ Activity f4275a;
    private /* synthetic */ Bundle f4276b;

    ace(acd com_google_android_gms_internal_acd, Activity activity, Bundle bundle) {
        this.f4275a = activity;
        this.f4276b = bundle;
    }

    public final void mo2772a(ActivityLifecycleCallbacks activityLifecycleCallbacks) {
        activityLifecycleCallbacks.onActivityCreated(this.f4275a, this.f4276b);
    }
}
