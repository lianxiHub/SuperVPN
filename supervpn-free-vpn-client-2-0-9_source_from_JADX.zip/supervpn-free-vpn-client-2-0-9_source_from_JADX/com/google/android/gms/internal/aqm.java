package com.google.android.gms.internal;

import java.util.concurrent.Callable;

final class aqm implements Callable {
    private /* synthetic */ aqf f5101a;
    private /* synthetic */ aql f5102b;

    aqm(aql com_google_android_gms_internal_aql, aqf com_google_android_gms_internal_aqf) {
        this.f5102b = com_google_android_gms_internal_aql;
        this.f5101a = com_google_android_gms_internal_aqf;
    }

    private final aqi m5795a() {
        synchronized (this.f5102b.f5095i) {
            if (this.f5102b.f5096j) {
                return null;
            }
            return this.f5101a.m5774a(this.f5102b.f5092f, this.f5102b.f5093g);
        }
    }

    public final /* synthetic */ Object call() {
        return m5795a();
    }
}
