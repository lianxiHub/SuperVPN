package com.google.android.gms.internal;

import android.content.Context;
import android.content.pm.PackageInfo;

public interface ed {
    iq mo3183a(Context context);

    iq mo3184a(String str, PackageInfo packageInfo);
}
