package com.google.android.gms.internal;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class ww {
    private static String f7026a = ww.class.getSimpleName();
    private final td f7027b;
    private final String f7028c;
    private final String f7029d;
    private final int f7030e = 2;
    private volatile Method f7031f = null;
    private final Class[] f7032g;
    private CountDownLatch f7033h = new CountDownLatch(1);

    public ww(td tdVar, String str, String str2, Class... clsArr) {
        this.f7027b = tdVar;
        this.f7028c = str;
        this.f7029d = str2;
        this.f7032g = clsArr;
        this.f7027b.m7661d().submit(new wx(this));
    }

    private final String m8084a(byte[] bArr, String str) {
        return new String(this.f7027b.m7663f().m7628a(bArr, str), WebRequest.CHARSET_UTF_8);
    }

    private final void m8086b() {
        try {
            Class loadClass = this.f7027b.m7662e().loadClass(m8084a(this.f7027b.m7664g(), this.f7028c));
            if (loadClass != null) {
                this.f7031f = loadClass.getMethod(m8084a(this.f7027b.m7664g(), this.f7029d), this.f7032g);
                if (this.f7031f == null) {
                    this.f7033h.countDown();
                } else {
                    this.f7033h.countDown();
                }
            }
        } catch (zzcy e) {
        } catch (UnsupportedEncodingException e2) {
        } catch (ClassNotFoundException e3) {
        } catch (NoSuchMethodException e4) {
        } catch (NullPointerException e5) {
        } finally {
            this.f7033h.countDown();
        }
    }

    public final Method m8087a() {
        if (this.f7031f != null) {
            return this.f7031f;
        }
        try {
            return this.f7033h.await(2, TimeUnit.SECONDS) ? this.f7031f : null;
        } catch (InterruptedException e) {
            return null;
        }
    }
}
