package com.google.android.gms.internal;

import java.util.Map;

final class kd implements Runnable {
    private /* synthetic */ Map f6139a;
    private /* synthetic */ kc f6140b;

    kd(kc kcVar, Map map) {
        this.f6140b = kcVar;
        this.f6139a = map;
    }

    public final void run() {
        this.f6140b.f6127a.mo3238a("pubVideoCmd", this.f6139a);
    }
}
