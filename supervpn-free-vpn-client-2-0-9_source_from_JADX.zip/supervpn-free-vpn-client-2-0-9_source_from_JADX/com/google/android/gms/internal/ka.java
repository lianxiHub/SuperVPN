package com.google.android.gms.internal;

final class ka implements Runnable {
    private /* synthetic */ jx f6123a;

    ka(jx jxVar) {
        this.f6123a = jxVar;
    }

    public final void run() {
        super.destroy();
    }
}
