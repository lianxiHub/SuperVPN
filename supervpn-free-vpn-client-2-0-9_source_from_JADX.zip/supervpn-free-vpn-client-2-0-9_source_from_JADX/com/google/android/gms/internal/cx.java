package com.google.android.gms.internal;

import com.google.android.gms.dynamic.C1758a;
import com.google.android.gms.dynamic.C1761c;

@avl
public final class cx extends de {
    private volatile cu f5589a;
    private volatile cy f5590b;
    private volatile cv f5591c;

    public cx(cv cvVar) {
        this.f5591c = cvVar;
    }

    public final void mo3152a(C1758a c1758a) {
        if (this.f5589a != null) {
            this.f5589a.mo3151c();
        }
    }

    public final void mo3153a(C1758a c1758a, int i) {
        if (this.f5589a != null) {
            this.f5589a.mo3148a(i);
        }
    }

    public final void mo3154a(C1758a c1758a, zzaek com_google_android_gms_internal_zzaek) {
        if (this.f5591c != null) {
            this.f5591c.mo3123a(com_google_android_gms_internal_zzaek);
        }
    }

    public final void m6334a(cu cuVar) {
        this.f5589a = cuVar;
    }

    public final void m6335a(cy cyVar) {
        this.f5590b = cyVar;
    }

    public final void mo3155b(C1758a c1758a) {
        if (this.f5590b != null) {
            this.f5590b.mo3149a(C1761c.m4496a(c1758a).getClass().getName());
        }
    }

    public final void mo3156b(C1758a c1758a, int i) {
        if (this.f5590b != null) {
            this.f5590b.mo3150a(C1761c.m4496a(c1758a).getClass().getName(), i);
        }
    }

    public final void mo3157c(C1758a c1758a) {
        if (this.f5591c != null) {
            this.f5591c.mo3124d();
        }
    }

    public final void mo3158d(C1758a c1758a) {
        if (this.f5591c != null) {
            this.f5591c.mo3125e();
        }
    }

    public final void mo3159e(C1758a c1758a) {
        if (this.f5591c != null) {
            this.f5591c.mo3126f();
        }
    }

    public final void mo3160f(C1758a c1758a) {
        if (this.f5591c != null) {
            this.f5591c.mo3127g();
        }
    }

    public final void mo3161g(C1758a c1758a) {
        if (this.f5591c != null) {
            this.f5591c.mo3128h();
        }
    }
}
