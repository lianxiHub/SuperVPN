package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.dynamic.C1758a.C1759a;

public abstract class agd extends yo implements agc {
    public agd() {
        attachInterface(this, "com.google.android.gms.ads.internal.client.IClientApi");
    }

    public static agc asInterface(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IClientApi");
        return queryLocalInterface instanceof agc ? (agc) queryLocalInterface : new age(iBinder);
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        if (zza(i, parcel, parcel2, i2)) {
            return true;
        }
        IInterface createBannerAdManager;
        switch (i) {
            case 1:
                createBannerAdManager = createBannerAdManager(C1759a.m4494a(parcel.readStrongBinder()), (zzjb) zm.m8270a(parcel, zzjb.CREATOR), parcel.readString(), aqt.m5801a(parcel.readStrongBinder()), parcel.readInt());
                parcel2.writeNoException();
                zm.m8271a(parcel2, createBannerAdManager);
                break;
            case 2:
                createBannerAdManager = createInterstitialAdManager(C1759a.m4494a(parcel.readStrongBinder()), (zzjb) zm.m8270a(parcel, zzjb.CREATOR), parcel.readString(), aqt.m5801a(parcel.readStrongBinder()), parcel.readInt());
                parcel2.writeNoException();
                zm.m8271a(parcel2, createBannerAdManager);
                break;
            case 3:
                createBannerAdManager = createAdLoaderBuilder(C1759a.m4494a(parcel.readStrongBinder()), parcel.readString(), aqt.m5801a(parcel.readStrongBinder()), parcel.readInt());
                parcel2.writeNoException();
                zm.m8271a(parcel2, createBannerAdManager);
                break;
            case 4:
                createBannerAdManager = getMobileAdsSettingsManager(C1759a.m4494a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                zm.m8271a(parcel2, createBannerAdManager);
                break;
            case 5:
                createBannerAdManager = createNativeAdViewDelegate(C1759a.m4494a(parcel.readStrongBinder()), C1759a.m4494a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                zm.m8271a(parcel2, createBannerAdManager);
                break;
            case 6:
                createBannerAdManager = createRewardedVideoAd(C1759a.m4494a(parcel.readStrongBinder()), aqt.m5801a(parcel.readStrongBinder()), parcel.readInt());
                parcel2.writeNoException();
                zm.m8271a(parcel2, createBannerAdManager);
                break;
            case 7:
                createBannerAdManager = createInAppPurchaseManager(C1759a.m4494a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                zm.m8271a(parcel2, createBannerAdManager);
                break;
            case 8:
                createBannerAdManager = createAdOverlay(C1759a.m4494a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                zm.m8271a(parcel2, createBannerAdManager);
                break;
            case 9:
                createBannerAdManager = getMobileAdsSettingsManagerWithClientJarVersion(C1759a.m4494a(parcel.readStrongBinder()), parcel.readInt());
                parcel2.writeNoException();
                zm.m8271a(parcel2, createBannerAdManager);
                break;
            case 10:
                createBannerAdManager = createSearchAdManager(C1759a.m4494a(parcel.readStrongBinder()), (zzjb) zm.m8270a(parcel, zzjb.CREATOR), parcel.readString(), parcel.readInt());
                parcel2.writeNoException();
                zm.m8271a(parcel2, createBannerAdManager);
                break;
            default:
                return false;
        }
        return true;
    }
}
