package com.google.android.gms.internal;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.webkit.JsResult;

final class kj implements OnClickListener {
    private /* synthetic */ JsResult f6150a;

    kj(JsResult jsResult) {
        this.f6150a = jsResult;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        this.f6150a.confirm();
    }
}
