package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.List;

public abstract class akz extends yo implements aky {
    public akz() {
        attachInterface(this, "com.google.android.gms.ads.internal.formats.client.INativeAppInstallAd");
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        if (zza(i, parcel, parcel2, i2)) {
            return true;
        }
        IInterface j;
        String a;
        switch (i) {
            case 2:
                j = mo2864j();
                parcel2.writeNoException();
                zm.m8271a(parcel2, j);
                break;
            case 3:
                a = mo2851a();
                parcel2.writeNoException();
                parcel2.writeString(a);
                break;
            case 4:
                List b = mo2854b();
                parcel2.writeNoException();
                parcel2.writeList(b);
                break;
            case 5:
                a = mo2856c();
                parcel2.writeNoException();
                parcel2.writeString(a);
                break;
            case 6:
                j = mo2858d();
                parcel2.writeNoException();
                zm.m8271a(parcel2, j);
                break;
            case 7:
                a = mo2859e();
                parcel2.writeNoException();
                parcel2.writeString(a);
                break;
            case 8:
                double f = mo2860f();
                parcel2.writeNoException();
                parcel2.writeDouble(f);
                break;
            case 9:
                a = mo2861g();
                parcel2.writeNoException();
                parcel2.writeString(a);
                break;
            case 10:
                a = mo2862h();
                parcel2.writeNoException();
                parcel2.writeString(a);
                break;
            case 11:
                Parcelable n = mo2868n();
                parcel2.writeNoException();
                zm.m8276b(parcel2, n);
                break;
            case 12:
                mo2871q();
                parcel2.writeNoException();
                break;
            case 13:
                j = mo2863i();
                parcel2.writeNoException();
                zm.m8271a(parcel2, j);
                break;
            case 14:
                mo2852a((Bundle) zm.m8270a(parcel, Bundle.CREATOR));
                parcel2.writeNoException();
                break;
            case 15:
                boolean b2 = mo2855b((Bundle) zm.m8270a(parcel, Bundle.CREATOR));
                parcel2.writeNoException();
                zm.m8273a(parcel2, b2);
                break;
            case 16:
                mo2857c((Bundle) zm.m8270a(parcel, Bundle.CREATOR));
                parcel2.writeNoException();
                break;
            case 17:
                j = mo2870p();
                parcel2.writeNoException();
                zm.m8271a(parcel2, j);
                break;
            default:
                return false;
        }
        return true;
    }
}
