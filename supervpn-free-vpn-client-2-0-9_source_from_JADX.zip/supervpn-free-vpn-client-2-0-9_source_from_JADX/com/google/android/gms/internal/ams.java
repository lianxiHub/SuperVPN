package com.google.android.gms.internal;

import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import com.google.android.gms.ads.internal.zzbv;
import java.util.HashMap;
import java.util.Map;

final class ams implements anb {
    ams() {
    }

    public final void zza(jk jkVar, Map map) {
        WindowManager windowManager = (WindowManager) jkVar.getContext().getSystemService("window");
        zzbv.zzea();
        View view = (View) jkVar;
        DisplayMetrics a = gd.m6573a(windowManager);
        int i = a.widthPixels;
        int i2 = a.heightPixels;
        int[] iArr = new int[2];
        Map hashMap = new HashMap();
        view.getLocationInWindow(iArr);
        hashMap.put("xInPixels", Integer.valueOf(iArr[0]));
        hashMap.put("yInPixels", Integer.valueOf(iArr[1]));
        hashMap.put("windowWidthInPixels", Integer.valueOf(i));
        hashMap.put("windowHeightInPixels", Integer.valueOf(i2));
        jkVar.mo3238a("locationReady", hashMap);
        ii.m6521e("GET LOCATION COMPILED");
    }
}
