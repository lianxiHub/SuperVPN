package com.google.android.gms.internal;

import com.google.android.gms.dynamic.C1758a;

public final class ahi extends afv {
    private afi f4555a;

    public final void destroy() {
    }

    public final String getAdUnitId() {
        return null;
    }

    public final String getMediationAdapterClassName() {
        return null;
    }

    public final agn getVideoController() {
        return null;
    }

    public final boolean isLoading() {
        return false;
    }

    public final boolean isReady() {
        return false;
    }

    public final void pause() {
    }

    public final void resume() {
    }

    public final void setImmersiveMode(boolean z) {
    }

    public final void setManualImpressionsEnabled(boolean z) {
    }

    public final void setUserId(String str) {
    }

    public final void showInterstitial() {
    }

    public final void stopLoading() {
    }

    public final void zza(aff com_google_android_gms_internal_aff) {
    }

    public final void zza(afi com_google_android_gms_internal_afi) {
        this.f4555a = com_google_android_gms_internal_afi;
    }

    public final void zza(afz com_google_android_gms_internal_afz) {
    }

    public final void zza(agf com_google_android_gms_internal_agf) {
    }

    public final void zza(aja com_google_android_gms_internal_aja) {
    }

    public final void zza(atg com_google_android_gms_internal_atg) {
    }

    public final void zza(atm com_google_android_gms_internal_atm, String str) {
    }

    public final void zza(cg cgVar) {
    }

    public final void zza(zzjb com_google_android_gms_internal_zzjb) {
    }

    public final void zza(zzle com_google_android_gms_internal_zzle) {
    }

    public final void zza(zzmd com_google_android_gms_internal_zzmd) {
    }

    public final boolean zzb(zzix com_google_android_gms_internal_zzix) {
        ii.m6518c("This app is using a lightweight version of the Google Mobile Ads SDK that requires the latest Google Play services to be installed, but Google Play services is either missing or out of date.");
        ie.f5948a.post(new ahj(this));
        return false;
    }

    public final C1758a zzbk() {
        return null;
    }

    public final zzjb zzbl() {
        return null;
    }

    public final void zzbn() {
    }

    public final afz zzbw() {
        return null;
    }

    public final afi zzbx() {
        return null;
    }

    public final String zzch() {
        return null;
    }
}
