package com.google.android.gms.internal;

public interface jp {
    void zza(jk jkVar, boolean z);
}
