package com.google.android.gms.internal;

import java.security.Key;
import javax.crypto.Mac;

public final class wa implements uf {
    private Mac f6989a;
    private final int f6990b;
    private final String f6991c;
    private final Key f6992d;

    public wa(String str, Key key, int i) {
        this.f6991c = str;
        this.f6990b = i;
        this.f6992d = key;
        this.f6989a = (Mac) vp.f6975b.m8043a(str);
        this.f6989a.init(key);
    }

    public final byte[] mo3343a(byte[] bArr) {
        Mac mac;
        try {
            mac = (Mac) this.f6989a.clone();
        } catch (CloneNotSupportedException e) {
            mac = (Mac) vp.f6975b.m8043a(this.f6991c);
            mac.init(this.f6992d);
        }
        mac.update(bArr);
        Object obj = new byte[this.f6990b];
        System.arraycopy(mac.doFinal(), 0, obj, 0, this.f6990b);
        return obj;
    }
}
