package com.google.android.gms.internal;

import android.os.IInterface;

public interface aja extends IInterface {
    void mo2843a(aix com_google_android_gms_internal_aix);
}
