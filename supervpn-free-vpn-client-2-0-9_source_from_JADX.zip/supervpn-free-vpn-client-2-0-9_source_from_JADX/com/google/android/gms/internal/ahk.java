package com.google.android.gms.internal;

import com.google.android.gms.dynamic.C1758a;

public final class ahk extends agj {
    public final void initialize() {
    }

    public final void setAppMuted(boolean z) {
    }

    public final void setAppVolume(float f) {
    }

    public final void zzc(C1758a c1758a, String str) {
    }

    public final void zzc(String str, C1758a c1758a) {
    }

    public final void zzt(String str) {
    }
}
