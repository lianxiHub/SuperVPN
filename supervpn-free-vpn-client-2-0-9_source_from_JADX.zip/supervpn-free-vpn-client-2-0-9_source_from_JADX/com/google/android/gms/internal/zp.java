package com.google.android.gms.internal;

public abstract class zp extends zu {
    protected zr f4110R;

    protected int mo2733a() {
        int i = 0;
        if (this.f4110R == null) {
            return 0;
        }
        int i2 = 0;
        while (i < this.f4110R.m8336a()) {
            i2 += this.f4110R.m8339b(i).m8343a();
            i++;
        }
        return i2;
    }

    public void mo2734a(zo zoVar) {
        if (this.f4110R != null) {
            for (int i = 0; i < this.f4110R.m8336a(); i++) {
                this.f4110R.m8339b(i).m8344a(zoVar);
            }
        }
    }

    protected final boolean m4550a(zn znVar, int i) {
        int l = znVar.m8300l();
        if (!znVar.m8287b(i)) {
            return false;
        }
        int i2 = i >>> 3;
        zw zwVar = new zw(i, znVar.m8284a(l, znVar.m8300l() - l));
        zs zsVar = null;
        if (this.f4110R == null) {
            this.f4110R = new zr();
        } else {
            zsVar = this.f4110R.m8337a(i2);
        }
        if (zsVar == null) {
            zsVar = new zs();
            this.f4110R.m8338a(i2, zsVar);
        }
        zsVar.m8345a(zwVar);
        return true;
    }

    public zp m4551c() {
        zp zpVar = (zp) super.mo2736d();
        zt.m8348a(this, zpVar);
        return zpVar;
    }

    public /* synthetic */ Object clone() {
        return m4551c();
    }

    public /* synthetic */ zu mo2736d() {
        return (zp) clone();
    }
}
