package com.google.android.gms.internal;

import android.text.TextUtils;
import com.google.android.gms.analytics.C1741q;
import java.util.HashMap;
import java.util.Map;

public final class lf extends C1741q {
    public String f6207a;
    public long f6208b;
    public String f6209c;
    public String f6210d;

    public final /* synthetic */ void mo3283a(C1741q c1741q) {
        lf lfVar = (lf) c1741q;
        if (!TextUtils.isEmpty(this.f6207a)) {
            lfVar.f6207a = this.f6207a;
        }
        if (this.f6208b != 0) {
            lfVar.f6208b = this.f6208b;
        }
        if (!TextUtils.isEmpty(this.f6209c)) {
            lfVar.f6209c = this.f6209c;
        }
        if (!TextUtils.isEmpty(this.f6210d)) {
            lfVar.f6210d = this.f6210d;
        }
    }

    public final String toString() {
        Map hashMap = new HashMap();
        hashMap.put("variableName", this.f6207a);
        hashMap.put("timeInMillis", Long.valueOf(this.f6208b));
        hashMap.put("category", this.f6209c);
        hashMap.put("label", this.f6210d);
        return C1741q.m4447a((Object) hashMap);
    }
}
