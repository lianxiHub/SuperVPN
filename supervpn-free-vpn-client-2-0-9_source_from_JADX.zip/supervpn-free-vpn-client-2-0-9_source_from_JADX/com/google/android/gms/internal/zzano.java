package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public final class zzano implements Parcelable {
    @Deprecated
    public static final Creator CREATOR = new mm();
    private String f7348a;
    private String f7349b;
    private String f7350c;

    @Deprecated
    zzano(Parcel parcel) {
        this.f7348a = parcel.readString();
        this.f7349b = parcel.readString();
        this.f7350c = parcel.readString();
    }

    public final String m8371a() {
        return this.f7348a;
    }

    public final String m8372b() {
        return this.f7350c;
    }

    @Deprecated
    public final int describeContents() {
        return 0;
    }

    @Deprecated
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.f7348a);
        parcel.writeString(this.f7349b);
        parcel.writeString(this.f7350c);
    }
}
