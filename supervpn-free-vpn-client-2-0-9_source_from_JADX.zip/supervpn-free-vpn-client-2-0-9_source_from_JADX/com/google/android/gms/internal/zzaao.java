package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzd;
import java.util.Collections;
import java.util.List;

@avl
public final class zzaao extends zza {
    public static final Creator CREATOR = new C1813n();
    public final zzaek f7268A;
    public final List f7269B;
    public final List f7270C;
    public final boolean f7271D;
    public final zzaaq f7272E;
    public final boolean f7273F;
    public String f7274G;
    public final List f7275H;
    public final boolean f7276I;
    public final String f7277J;
    public final zzaes f7278K;
    public final String f7279L;
    public final boolean f7280M;
    public final boolean f7281N;
    private zzaak f7282O;
    private int f7283P;
    private zzaba f7284Q;
    private Bundle f7285R;
    public final String f7286a;
    public String f7287b;
    public final List f7288c;
    public final int f7289d;
    public final List f7290e;
    public final long f7291f;
    public final boolean f7292g;
    public final long f7293h;
    public final List f7294i;
    public final long f7295j;
    public final int f7296k;
    public final String f7297l;
    public final long f7298m;
    public final String f7299n;
    public final boolean f7300o;
    public final String f7301p;
    public final String f7302q;
    public final boolean f7303r;
    public final boolean f7304s;
    public final boolean f7305t;
    public final boolean f7306u;
    public final boolean f7307v;
    public String f7308w;
    public final String f7309x;
    public final boolean f7310y;
    public final boolean f7311z;

    public zzaao(int i) {
        this(19, null, null, null, i, null, -1, false, -1, null, -1, -1, null, -1, null, false, null, null, false, false, false, true, false, null, null, null, false, false, null, null, null, false, null, false, null, null, false, null, null, null, true, false, null);
    }

    public zzaao(int i, long j) {
        this(19, null, null, null, i, null, -1, false, -1, null, j, -1, null, -1, null, false, null, null, false, false, false, true, false, null, null, null, false, false, null, null, null, false, null, false, null, null, false, null, null, null, true, false, null);
    }

    zzaao(int i, String str, String str2, List list, int i2, List list2, long j, boolean z, long j2, List list3, long j3, int i3, String str3, long j4, String str4, boolean z2, String str5, String str6, boolean z3, boolean z4, boolean z5, boolean z6, boolean z7, zzaba com_google_android_gms_internal_zzaba, String str7, String str8, boolean z8, boolean z9, zzaek com_google_android_gms_internal_zzaek, List list4, List list5, boolean z10, zzaaq com_google_android_gms_internal_zzaaq, boolean z11, String str9, List list6, boolean z12, String str10, zzaes com_google_android_gms_internal_zzaes, String str11, boolean z13, boolean z14, Bundle bundle) {
        this.f7283P = i;
        this.f7286a = str;
        this.f7287b = str2;
        this.f7288c = list != null ? Collections.unmodifiableList(list) : null;
        this.f7289d = i2;
        this.f7290e = list2 != null ? Collections.unmodifiableList(list2) : null;
        this.f7291f = j;
        this.f7292g = z;
        this.f7293h = j2;
        this.f7294i = list3 != null ? Collections.unmodifiableList(list3) : null;
        this.f7295j = j3;
        this.f7296k = i3;
        this.f7297l = str3;
        this.f7298m = j4;
        this.f7299n = str4;
        this.f7300o = z2;
        this.f7301p = str5;
        this.f7302q = str6;
        this.f7303r = z3;
        this.f7304s = z4;
        this.f7305t = z5;
        this.f7306u = z6;
        this.f7280M = z13;
        this.f7307v = z7;
        this.f7284Q = com_google_android_gms_internal_zzaba;
        this.f7308w = str7;
        this.f7309x = str8;
        if (this.f7287b == null && this.f7284Q != null) {
            zzabo com_google_android_gms_internal_zzabo = (zzabo) this.f7284Q.m8366a(zzabo.CREATOR);
            if (!(com_google_android_gms_internal_zzabo == null || TextUtils.isEmpty(com_google_android_gms_internal_zzabo.f7324a))) {
                this.f7287b = com_google_android_gms_internal_zzabo.f7324a;
            }
        }
        this.f7310y = z8;
        this.f7311z = z9;
        this.f7268A = com_google_android_gms_internal_zzaek;
        this.f7269B = list4;
        this.f7270C = list5;
        this.f7271D = z10;
        this.f7272E = com_google_android_gms_internal_zzaaq;
        this.f7273F = z11;
        this.f7274G = str9;
        this.f7275H = list6;
        this.f7276I = z12;
        this.f7277J = str10;
        this.f7278K = com_google_android_gms_internal_zzaes;
        this.f7279L = str11;
        this.f7281N = z14;
        this.f7285R = bundle;
    }

    public zzaao(zzaak com_google_android_gms_internal_zzaak, String str, String str2, List list, List list2, long j, boolean z, long j2, List list3, long j3, int i, String str3, long j4, String str4, String str5, boolean z2, boolean z3, boolean z4, boolean z5, boolean z6, String str6, boolean z7, boolean z8, zzaek com_google_android_gms_internal_zzaek, List list4, List list5, boolean z9, zzaaq com_google_android_gms_internal_zzaaq, boolean z10, String str7, List list6, boolean z11, String str8, zzaes com_google_android_gms_internal_zzaes, String str9, boolean z12, boolean z13) {
        this(19, str, str2, list, -2, list2, j, z, -1, list3, j3, i, str3, j4, str4, false, null, str5, z2, z3, z4, z5, false, null, null, str6, z7, z8, com_google_android_gms_internal_zzaek, list4, list5, z9, com_google_android_gms_internal_zzaaq, z10, str7, list6, z11, str8, com_google_android_gms_internal_zzaes, str9, z12, z13, null);
        this.f7282O = com_google_android_gms_internal_zzaak;
    }

    public zzaao(zzaak com_google_android_gms_internal_zzaak, String str, String str2, List list, List list2, long j, boolean z, long j2, List list3, long j3, int i, String str3, long j4, String str4, boolean z2, String str5, String str6, boolean z3, boolean z4, boolean z5, boolean z6, boolean z7, String str7, boolean z8, boolean z9, zzaek com_google_android_gms_internal_zzaek, List list4, List list5, boolean z10, zzaaq com_google_android_gms_internal_zzaaq, boolean z11, String str8, List list6, boolean z12, String str9, zzaes com_google_android_gms_internal_zzaes, String str10, boolean z13, boolean z14) {
        this(19, str, str2, list, -2, list2, j, z, j2, list3, j3, i, str3, j4, str4, z2, str5, str6, z3, z4, z5, z6, z7, null, null, str7, z8, z9, com_google_android_gms_internal_zzaek, list4, list5, z10, com_google_android_gms_internal_zzaaq, z11, str8, list6, z12, str9, com_google_android_gms_internal_zzaes, str10, z13, z14, null);
        this.f7282O = com_google_android_gms_internal_zzaak;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        if (!(this.f7282O == null || this.f7282O.f7242a < 9 || TextUtils.isEmpty(this.f7287b))) {
            this.f7284Q = new zzaba(new zzabo(this.f7287b));
            this.f7287b = null;
        }
        int zze = zzd.zze(parcel);
        zzd.zzc(parcel, 1, this.f7283P);
        zzd.zza(parcel, 2, this.f7286a, false);
        zzd.zza(parcel, 3, this.f7287b, false);
        zzd.zzb(parcel, 4, this.f7288c, false);
        zzd.zzc(parcel, 5, this.f7289d);
        zzd.zzb(parcel, 6, this.f7290e, false);
        zzd.zza(parcel, 7, this.f7291f);
        zzd.zza(parcel, 8, this.f7292g);
        zzd.zza(parcel, 9, this.f7293h);
        zzd.zzb(parcel, 10, this.f7294i, false);
        zzd.zza(parcel, 11, this.f7295j);
        zzd.zzc(parcel, 12, this.f7296k);
        zzd.zza(parcel, 13, this.f7297l, false);
        zzd.zza(parcel, 14, this.f7298m);
        zzd.zza(parcel, 15, this.f7299n, false);
        zzd.zza(parcel, 18, this.f7300o);
        zzd.zza(parcel, 19, this.f7301p, false);
        zzd.zza(parcel, 21, this.f7302q, false);
        zzd.zza(parcel, 22, this.f7303r);
        zzd.zza(parcel, 23, this.f7304s);
        zzd.zza(parcel, 24, this.f7305t);
        zzd.zza(parcel, 25, this.f7306u);
        zzd.zza(parcel, 26, this.f7307v);
        zzd.zza(parcel, 28, this.f7284Q, i, false);
        zzd.zza(parcel, 29, this.f7308w, false);
        zzd.zza(parcel, 30, this.f7309x, false);
        zzd.zza(parcel, 31, this.f7310y);
        zzd.zza(parcel, 32, this.f7311z);
        zzd.zza(parcel, 33, this.f7268A, i, false);
        zzd.zzb(parcel, 34, this.f7269B, false);
        zzd.zzb(parcel, 35, this.f7270C, false);
        zzd.zza(parcel, 36, this.f7271D);
        zzd.zza(parcel, 37, this.f7272E, i, false);
        zzd.zza(parcel, 38, this.f7273F);
        zzd.zza(parcel, 39, this.f7274G, false);
        zzd.zzb(parcel, 40, this.f7275H, false);
        zzd.zza(parcel, 42, this.f7276I);
        zzd.zza(parcel, 43, this.f7277J, false);
        zzd.zza(parcel, 44, this.f7278K, i, false);
        zzd.zza(parcel, 45, this.f7279L, false);
        zzd.zza(parcel, 46, this.f7280M);
        zzd.zza(parcel, 47, this.f7281N);
        zzd.zza(parcel, 48, this.f7285R, false);
        zzd.zzai(parcel, zze);
    }
}
