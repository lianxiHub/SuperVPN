package com.google.android.gms.internal;

import java.util.concurrent.Future;

final class gb implements Runnable {
    private /* synthetic */ iw f5828a;
    private /* synthetic */ Future f5829b;

    gb(iw iwVar, Future future) {
        this.f5828a = iwVar;
        this.f5829b = future;
    }

    public final void run() {
        if (this.f5828a.isCancelled()) {
            this.f5829b.cancel(true);
        }
    }
}
