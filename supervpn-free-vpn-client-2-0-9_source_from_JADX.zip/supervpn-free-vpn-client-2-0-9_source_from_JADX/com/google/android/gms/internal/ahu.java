package com.google.android.gms.internal;

import java.util.Collections;
import java.util.List;

@avl
public final class ahu implements ahv {
    public final List mo2828a(List list) {
        return list == null ? Collections.emptyList() : list;
    }
}
