package com.google.android.gms.internal;

import java.util.concurrent.Callable;

final class ln implements Callable {
    private /* synthetic */ lh f6229a;

    ln(lh lhVar) {
        this.f6229a = lhVar;
    }

    public final /* synthetic */ Object call() {
        this.f6229a.f6217a.m7266f();
        return null;
    }
}
