package com.google.android.gms.internal;

import android.text.TextUtils;
import com.facebook.internal.NativeProtocol;
import com.google.android.gms.analytics.C1741q;
import java.util.HashMap;
import java.util.Map;

public final class le extends C1741q {
    public String f6204a;
    public String f6205b;
    public String f6206c;

    public final /* synthetic */ void mo3283a(C1741q c1741q) {
        le leVar = (le) c1741q;
        if (!TextUtils.isEmpty(this.f6204a)) {
            leVar.f6204a = this.f6204a;
        }
        if (!TextUtils.isEmpty(this.f6205b)) {
            leVar.f6205b = this.f6205b;
        }
        if (!TextUtils.isEmpty(this.f6206c)) {
            leVar.f6206c = this.f6206c;
        }
    }

    public final String toString() {
        Map hashMap = new HashMap();
        hashMap.put("network", this.f6204a);
        hashMap.put(NativeProtocol.WEB_DIALOG_ACTION, this.f6205b);
        hashMap.put("target", this.f6206c);
        return C1741q.m4447a((Object) hashMap);
    }
}
