package com.google.android.gms.internal;

import android.os.Bundle;
import android.view.View;
import com.facebook.appevents.AppEventsConstants;
import com.google.android.gms.dynamic.C1758a;
import com.google.android.gms.dynamic.C1761c;
import java.util.List;

@avl
public final class ajl extends ald implements aju {
    private String f4705a;
    private List f4706b;
    private String f4707c;
    private akp f4708d;
    private String f4709e;
    private String f4710f;
    private ajg f4711g;
    private Bundle f4712h;
    private agn f4713i;
    private View f4714j;
    private Object f4715k = new Object();
    private ajr f4716l;

    public ajl(String str, List list, String str2, akp com_google_android_gms_internal_akp, String str3, String str4, ajg com_google_android_gms_internal_ajg, Bundle bundle, agn com_google_android_gms_internal_agn, View view) {
        this.f4705a = str;
        this.f4706b = list;
        this.f4707c = str2;
        this.f4708d = com_google_android_gms_internal_akp;
        this.f4709e = str3;
        this.f4710f = str4;
        this.f4711g = com_google_android_gms_internal_ajg;
        this.f4712h = bundle;
        this.f4713i = com_google_android_gms_internal_agn;
        this.f4714j = view;
    }

    public final String mo2872a() {
        return this.f4705a;
    }

    public final void mo2873a(Bundle bundle) {
        synchronized (this.f4715k) {
            if (this.f4716l == null) {
                ii.m6518c("Attempt to perform click before content ad initialized.");
                return;
            }
            this.f4716l.mo2906b(bundle);
        }
    }

    public final void mo2853a(ajr com_google_android_gms_internal_ajr) {
        synchronized (this.f4715k) {
            this.f4716l = com_google_android_gms_internal_ajr;
        }
    }

    public final List mo2854b() {
        return this.f4706b;
    }

    public final boolean mo2874b(Bundle bundle) {
        boolean z;
        synchronized (this.f4715k) {
            if (this.f4716l == null) {
                ii.m6518c("Attempt to record impression before content ad initialized.");
                z = false;
            } else {
                z = this.f4716l.mo2905a(bundle);
            }
        }
        return z;
    }

    public final String mo2875c() {
        return this.f4707c;
    }

    public final void mo2876c(Bundle bundle) {
        synchronized (this.f4715k) {
            if (this.f4716l == null) {
                ii.m6518c("Attempt to perform click before app install ad initialized.");
                return;
            }
            this.f4716l.mo2908c(bundle);
        }
    }

    public final akp mo2877d() {
        return this.f4708d;
    }

    public final String mo2878e() {
        return this.f4709e;
    }

    public final String mo2879f() {
        return this.f4710f;
    }

    public final agn mo2880g() {
        return this.f4713i;
    }

    public final C1758a mo2881h() {
        return C1761c.m4495a(this.f4716l);
    }

    public final Bundle mo2882i() {
        return this.f4712h;
    }

    public final akk mo2883j() {
        return this.f4711g;
    }

    public final String mo2865k() {
        return AppEventsConstants.EVENT_PARAM_VALUE_YES;
    }

    public final String mo2866l() {
        return "";
    }

    public final ajg mo2867m() {
        return this.f4711g;
    }

    public final void mo2884n() {
        gd.f5832a.post(new ajm(this));
        this.f4705a = null;
        this.f4706b = null;
        this.f4707c = null;
        this.f4708d = null;
        this.f4709e = null;
        this.f4710f = null;
        this.f4711g = null;
        this.f4712h = null;
        this.f4715k = null;
        this.f4713i = null;
        this.f4714j = null;
    }

    public final View mo2869o() {
        return this.f4714j;
    }
}
