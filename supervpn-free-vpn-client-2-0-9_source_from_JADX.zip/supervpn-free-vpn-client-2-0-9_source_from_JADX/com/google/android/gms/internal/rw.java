package com.google.android.gms.internal;

public final class rw {
    static boolean m7553a(Object obj, Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }
}
