package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.dynamic.C1758a;

public final class akx extends xq implements akw {
    akx(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.formats.client.INativeAdViewDelegateCreator");
    }

    public final IBinder mo2922a(C1758a c1758a, C1758a c1758a2, C1758a c1758a3, int i) {
        Parcel zzax = zzax();
        zm.m8271a(zzax, (IInterface) c1758a);
        zm.m8271a(zzax, (IInterface) c1758a2);
        zm.m8271a(zzax, (IInterface) c1758a3);
        zzax.writeInt(11200000);
        zzax = zza(1, zzax);
        IBinder readStrongBinder = zzax.readStrongBinder();
        zzax.recycle();
        return readStrongBinder;
    }
}
