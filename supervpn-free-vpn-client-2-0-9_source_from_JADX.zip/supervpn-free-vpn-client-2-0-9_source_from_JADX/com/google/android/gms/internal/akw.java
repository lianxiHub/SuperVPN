package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import com.google.android.gms.dynamic.C1758a;

public interface akw extends IInterface {
    IBinder mo2922a(C1758a c1758a, C1758a c1758a2, C1758a c1758a3, int i);
}
