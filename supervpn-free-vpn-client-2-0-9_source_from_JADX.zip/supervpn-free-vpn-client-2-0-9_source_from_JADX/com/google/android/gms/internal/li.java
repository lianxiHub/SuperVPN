package com.google.android.gms.internal;

final class li implements Runnable {
    private /* synthetic */ int f6218a;
    private /* synthetic */ lh f6219b;

    li(lh lhVar, int i) {
        this.f6219b = lhVar;
        this.f6218a = i;
    }

    public final void run() {
        this.f6219b.f6217a.m7257a(((long) this.f6218a) * 1000);
    }
}
