package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.zzbv;

public final class wn extends wz {
    private long f7016d = -1;

    public wn(td tdVar, String str, String str2, oh ohVar, int i, int i2) {
        super(tdVar, str, str2, ohVar, i, 12);
    }

    protected final void mo3344a() {
        if (((Boolean) zzbv.zzen().m5171a(aig.bo)).booleanValue()) {
            this.b.f6470f = Long.valueOf(-1);
            if (this.f7016d == -1) {
                this.f7016d = ((Long) this.c.invoke(null, new Object[]{this.a.m7654a()})).longValue();
            }
            synchronized (this.b) {
                this.b.f6470f = Long.valueOf(this.f7016d);
            }
            return;
        }
        this.b.f6470f = Long.valueOf(-1);
        this.b.f6470f = (Long) this.c.invoke(null, new Object[]{this.a.m7654a()});
    }
}
