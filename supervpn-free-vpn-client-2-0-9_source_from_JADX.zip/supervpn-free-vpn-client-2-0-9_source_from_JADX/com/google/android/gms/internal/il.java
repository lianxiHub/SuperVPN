package com.google.android.gms.internal;

public interface il {
    Object mo3111a(Object obj);
}
