package com.google.android.gms.internal;

import java.util.HashMap;

public final class sy extends qj {
    public Long f6767a;
    public Boolean f6768b;
    public Boolean f6769c;

    public sy(String str) {
        mo3304a(str);
    }

    protected final HashMap mo3303a() {
        HashMap hashMap = new HashMap();
        hashMap.put(Integer.valueOf(0), this.f6767a);
        hashMap.put(Integer.valueOf(1), this.f6768b);
        hashMap.put(Integer.valueOf(2), this.f6769c);
        return hashMap;
    }

    protected final void mo3304a(String str) {
        HashMap b = qj.m7509b(str);
        if (b != null) {
            this.f6767a = (Long) b.get(Integer.valueOf(0));
            this.f6768b = (Boolean) b.get(Integer.valueOf(1));
            this.f6769c = (Boolean) b.get(Integer.valueOf(2));
        }
    }
}
