package com.google.android.gms.internal;

public final class oj extends zp {
    public Long f6513a;
    public Long f6514b;
    public Long f6515c;
    private Long f6516d;
    private Long f6517e;

    public oj() {
        this.f6516d = null;
        this.f6517e = null;
        this.f6513a = null;
        this.f6514b = null;
        this.f6515c = null;
        this.S = -1;
    }

    protected final int mo2733a() {
        int a = super.mo2733a();
        if (this.f6516d != null) {
            a += zo.m8317c(1, this.f6516d.longValue());
        }
        if (this.f6517e != null) {
            a += zo.m8317c(2, this.f6517e.longValue());
        }
        if (this.f6513a != null) {
            a += zo.m8317c(3, this.f6513a.longValue());
        }
        if (this.f6514b != null) {
            a += zo.m8317c(4, this.f6514b.longValue());
        }
        return this.f6515c != null ? a + zo.m8317c(5, this.f6515c.longValue()) : a;
    }

    public final /* synthetic */ zu mo2737a(zn znVar) {
        while (true) {
            int a = znVar.m8281a();
            switch (a) {
                case 0:
                    break;
                case 8:
                    this.f6516d = Long.valueOf(znVar.m8296h());
                    continue;
                case 16:
                    this.f6517e = Long.valueOf(znVar.m8296h());
                    continue;
                case 24:
                    this.f6513a = Long.valueOf(znVar.m8296h());
                    continue;
                case 32:
                    this.f6514b = Long.valueOf(znVar.m8296h());
                    continue;
                case 40:
                    this.f6515c = Long.valueOf(znVar.m8296h());
                    continue;
                default:
                    if (!super.m4550a(znVar, a)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }

    public final void mo2734a(zo zoVar) {
        if (this.f6516d != null) {
            zoVar.m8328b(1, this.f6516d.longValue());
        }
        if (this.f6517e != null) {
            zoVar.m8328b(2, this.f6517e.longValue());
        }
        if (this.f6513a != null) {
            zoVar.m8328b(3, this.f6513a.longValue());
        }
        if (this.f6514b != null) {
            zoVar.m8328b(4, this.f6514b.longValue());
        }
        if (this.f6515c != null) {
            zoVar.m8328b(5, this.f6515c.longValue());
        }
        super.mo2734a(zoVar);
    }
}
