package com.google.android.gms.internal;

final class auy implements jp {
    private /* synthetic */ auw f5360a;

    auy(auw com_google_android_gms_internal_auw) {
        this.f5360a = com_google_android_gms_internal_auw;
    }

    public final void zza(jk jkVar, boolean z) {
        this.f5360a.f5357c.f5349f.zzdn();
        this.f5360a.f5356b.set(jkVar);
    }
}
