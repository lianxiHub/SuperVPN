package com.google.android.gms.internal;

import android.os.IInterface;

public interface aqs extends IInterface {
    aqv mo2994a(String str);

    boolean mo2995b(String str);
}
