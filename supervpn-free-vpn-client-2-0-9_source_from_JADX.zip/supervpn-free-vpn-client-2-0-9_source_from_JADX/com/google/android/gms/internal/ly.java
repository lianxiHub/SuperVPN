package com.google.android.gms.internal;

import java.util.Map;
import org.apache.http.HttpResponse;

public interface ly {
    HttpResponse mo3221a(akm com_google_android_gms_internal_akm, Map map);
}
