package com.google.android.gms.internal;

final class ado implements Runnable {
    private /* synthetic */ adn f4381a;

    ado(adn com_google_android_gms_internal_adn) {
        this.f4381a = com_google_android_gms_internal_adn;
    }

    public final void run() {
        this.f4381a.m4831c();
    }
}
