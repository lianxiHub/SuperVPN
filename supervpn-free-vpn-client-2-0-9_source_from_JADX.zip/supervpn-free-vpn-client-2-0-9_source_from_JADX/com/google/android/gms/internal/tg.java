package com.google.android.gms.internal;

final class tg implements Runnable {
    private /* synthetic */ td f6803a;

    tg(td tdVar) {
        this.f6803a = tdVar;
    }

    public final void run() {
        aig.m5174a(this.f6803a.f6783a);
    }
}
