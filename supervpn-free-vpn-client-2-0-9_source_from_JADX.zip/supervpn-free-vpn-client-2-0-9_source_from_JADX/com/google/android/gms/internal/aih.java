package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.zzbv;
import java.util.concurrent.Callable;

final class aih implements Callable {
    private /* synthetic */ Context f4627a;

    aih(Context context) {
        this.f4627a = context;
    }

    public final /* synthetic */ Object call() {
        zzbv.zzen().m5172a(this.f4627a);
        return null;
    }
}
