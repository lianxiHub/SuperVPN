package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

final class fc extends fu {
    private /* synthetic */ Context f5785a;
    private /* synthetic */ fv f5786b;

    fc(Context context, fv fvVar) {
        this.f5785a = context;
        this.f5786b = fvVar;
        super();
    }

    public final void zzdc() {
        SharedPreferences sharedPreferences = this.f5785a.getSharedPreferences("admob", 0);
        Bundle bundle = new Bundle();
        bundle.putInt("version_code", sharedPreferences.getInt("version_code", 0));
        if (this.f5786b != null) {
            this.f5786b.mo3185a(bundle);
        }
    }
}
