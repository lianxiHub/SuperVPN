package com.google.android.gms.internal;

import android.view.View;

public final class abg implements acm {
    private final View f4208a;
    private final ee f4209b;

    public abg(View view, ee eeVar) {
        this.f4208a = view;
        this.f4209b = eeVar;
    }

    public final View mo2763a() {
        return this.f4208a;
    }

    public final boolean mo2764b() {
        return this.f4209b == null || this.f4208a == null;
    }

    public final acm mo2765c() {
        return this;
    }
}
