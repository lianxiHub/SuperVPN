package com.google.android.gms.internal;

final class cp implements Runnable {
    private /* synthetic */ zzix f5569a;
    private /* synthetic */ aqv f5570b;
    private /* synthetic */ co f5571c;

    cp(co coVar, zzix com_google_android_gms_internal_zzix, aqv com_google_android_gms_internal_aqv) {
        this.f5571c = coVar;
        this.f5569a = com_google_android_gms_internal_zzix;
        this.f5570b = com_google_android_gms_internal_aqv;
    }

    public final void run() {
        this.f5571c.m6298a(this.f5569a, this.f5570b);
    }
}
