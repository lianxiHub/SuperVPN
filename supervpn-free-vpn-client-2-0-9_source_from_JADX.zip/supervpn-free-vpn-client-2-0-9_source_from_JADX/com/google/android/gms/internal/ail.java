package com.google.android.gms.internal;

import android.text.TextUtils;

@avl
public final class ail {
    public static aij m5188a(aii com_google_android_gms_internal_aii) {
        if (!com_google_android_gms_internal_aii.m5177a()) {
            et.m6522a("CsiReporterFactory: CSI is not enabled. No CSI reporter created.");
            return null;
        } else if (com_google_android_gms_internal_aii.m5179c() == null) {
            throw new IllegalArgumentException("Context can't be null. Please set up context in CsiConfiguration.");
        } else if (!TextUtils.isEmpty(com_google_android_gms_internal_aii.m5180d())) {
            return new aij(com_google_android_gms_internal_aii.m5179c(), com_google_android_gms_internal_aii.m5180d(), com_google_android_gms_internal_aii.m5178b(), com_google_android_gms_internal_aii.m5181e());
        } else {
            throw new IllegalArgumentException("AfmaVersion can't be null or empty. Please set up afmaVersion in CsiConfiguration.");
        }
    }
}
