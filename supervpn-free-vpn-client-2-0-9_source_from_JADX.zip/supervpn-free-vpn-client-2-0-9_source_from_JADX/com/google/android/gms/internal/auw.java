package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.zzbv;
import java.lang.ref.WeakReference;
import org.json.JSONObject;

final class auw implements Runnable {
    final /* synthetic */ JSONObject f5355a;
    final /* synthetic */ iw f5356b;
    final /* synthetic */ auv f5357c;

    auw(auv com_google_android_gms_internal_auv, JSONObject jSONObject, iw iwVar) {
        this.f5357c = com_google_android_gms_internal_auv;
        this.f5355a = jSONObject;
        this.f5356b = iwVar;
    }

    public final void run() {
        try {
            jk a = this.f5357c.m6154a();
            this.f5357c.f5349f.zzd(a);
            WeakReference weakReference = new WeakReference(a);
            a.mo3256k().m6896a(this.f5357c.m6146a(weakReference), this.f5357c.m6153b(weakReference));
            this.f5357c.m6150a(a);
            a.mo3256k().m6900a(new aux(this, a));
            a.mo3256k().m6899a(new auy(this));
            a.loadUrl((String) zzbv.zzen().m5171a(aig.bK));
        } catch (Throwable e) {
            ii.m6519c("Exception occurred while getting video view", e);
            this.f5356b.set(null);
        }
    }
}
