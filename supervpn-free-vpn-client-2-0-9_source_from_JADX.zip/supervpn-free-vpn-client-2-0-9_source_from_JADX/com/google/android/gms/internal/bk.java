package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.js.zzai;
import com.google.android.gms.ads.internal.js.zzy;
import org.json.JSONObject;

final class bk implements jc {
    private /* synthetic */ anb f5524a;
    private /* synthetic */ JSONObject f5525b;
    private /* synthetic */ zzy f5526c;

    bk(bi biVar, anb com_google_android_gms_internal_anb, JSONObject jSONObject, zzy com_google_android_gms_ads_internal_js_zzy) {
        this.f5524a = com_google_android_gms_internal_anb;
        this.f5525b = jSONObject;
        this.f5526c = com_google_android_gms_ads_internal_js_zzy;
    }

    public final /* synthetic */ void zzc(Object obj) {
        zzai com_google_android_gms_ads_internal_js_zzai = (zzai) obj;
        com_google_android_gms_ads_internal_js_zzai.zza("/loadSdkConstants", this.f5524a);
        try {
            com_google_android_gms_ads_internal_js_zzai.zza("AFMA_getSdkConstants", this.f5525b);
        } catch (Throwable e) {
            ii.m6517b("Error requesting an ad url", e);
            this.f5526c.release();
        }
    }
}
