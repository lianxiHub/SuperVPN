package com.google.android.gms.internal;

final class hs extends iw implements aqr {
    private hs(hj hjVar) {
    }

    public final void mo3220a(Object obj) {
        super.set(obj);
    }
}
