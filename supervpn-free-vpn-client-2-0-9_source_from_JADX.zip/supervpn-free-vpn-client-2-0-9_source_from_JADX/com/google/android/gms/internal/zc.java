package com.google.android.gms.internal;

final class zc implements zd {
    private /* synthetic */ zzedk f7121a;

    zc(zzedk com_google_android_gms_internal_zzedk) {
        this.f7121a = com_google_android_gms_internal_zzedk;
    }

    public final byte mo3377a(int i) {
        return this.f7121a.mo3388a(i);
    }

    public final int mo3378a() {
        return this.f7121a.mo3389a();
    }
}
