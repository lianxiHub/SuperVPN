package com.google.android.gms.internal;

class zzedr extends zzedq {
    protected final byte[] f7559b;

    zzedr(byte[] bArr) {
        this.f7559b = bArr;
    }

    public byte mo3388a(int i) {
        return this.f7559b[i];
    }

    public int mo3389a() {
        return this.f7559b.length;
    }

    protected final int mo3390a(int i, int i2, int i3) {
        return yd.m8177a(i, this.f7559b, mo3397f(), i3);
    }

    public final zzedk mo3391a(int i, int i2) {
        int b = zzedk.m8495b(i, i2, mo3389a());
        return b == 0 ? zzedk.f7556a : new zzedn(this.f7559b, mo3397f() + i, b);
    }

    final void mo3392a(xe xeVar) {
        xeVar.mo3408a(this.f7559b, mo3397f(), mo3389a());
    }

    protected void mo3393a(byte[] bArr, int i, int i2, int i3) {
        System.arraycopy(this.f7559b, 0, bArr, 0, i3);
    }

    final boolean mo3394a(zzedk com_google_android_gms_internal_zzedk, int i, int i2) {
        if (i2 > com_google_android_gms_internal_zzedk.mo3389a()) {
            throw new IllegalArgumentException("Length too large: " + i2 + mo3389a());
        } else if (i2 + 0 > com_google_android_gms_internal_zzedk.mo3389a()) {
            throw new IllegalArgumentException("Ran off end of other: 0" + ", " + i2 + ", " + com_google_android_gms_internal_zzedk.mo3389a());
        } else if (!(com_google_android_gms_internal_zzedk instanceof zzedr)) {
            return com_google_android_gms_internal_zzedk.mo3391a(0, i2 + 0).equals(mo3391a(0, i2));
        } else {
            zzedr com_google_android_gms_internal_zzedr = (zzedr) com_google_android_gms_internal_zzedk;
            byte[] bArr = this.f7559b;
            byte[] bArr2 = com_google_android_gms_internal_zzedr.f7559b;
            int f = mo3397f() + i2;
            int f2 = mo3397f();
            int f3 = com_google_android_gms_internal_zzedr.mo3397f();
            while (f2 < f) {
                if (bArr[f2] != bArr2[f3]) {
                    return false;
                }
                f2++;
                f3++;
            }
            return true;
        }
    }

    public final xk mo3395d() {
        return xk.m8110a(this.f7559b, mo3397f(), mo3389a(), true);
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzedk)) {
            return false;
        }
        if (mo3389a() != ((zzedk) obj).mo3389a()) {
            return false;
        }
        if (mo3389a() == 0) {
            return true;
        }
        if (!(obj instanceof zzedr)) {
            return obj.equals(this);
        }
        zzedr com_google_android_gms_internal_zzedr = (zzedr) obj;
        int e = m8507e();
        int e2 = com_google_android_gms_internal_zzedr.m8507e();
        return (e == 0 || e2 == 0 || e == e2) ? mo3394a((zzedr) obj, 0, mo3389a()) : false;
    }

    protected int mo3397f() {
        return 0;
    }
}
