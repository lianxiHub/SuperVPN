package com.google.android.gms.internal;

import android.view.View;

public final class abf implements acm {
    private ajr f4207a;

    public abf(ajr com_google_android_gms_internal_ajr) {
        this.f4207a = com_google_android_gms_internal_ajr;
    }

    public final View mo2763a() {
        return this.f4207a != null ? this.f4207a.mo2911f() : null;
    }

    public final boolean mo2764b() {
        return this.f4207a == null;
    }

    public final acm mo2765c() {
        return this;
    }
}
