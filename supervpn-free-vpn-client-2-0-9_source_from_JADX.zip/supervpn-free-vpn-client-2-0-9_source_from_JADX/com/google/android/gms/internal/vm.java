package com.google.android.gms.internal;

import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;
import javax.crypto.KeyAgreement;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public final class vm {
    private ECPublicKey f6968a;

    public vm(ECPublicKey eCPublicKey) {
        this.f6968a = eCPublicKey;
    }

    public final vn m8038a(String str, byte[] bArr, byte[] bArr2, int i, zzdhu com_google_android_gms_internal_zzdhu) {
        int i2 = 1;
        KeyPairGenerator keyPairGenerator = (KeyPairGenerator) vp.f6977d.m8043a("EC");
        keyPairGenerator.initialize(this.f6968a.getParams());
        KeyPair generateKeyPair = keyPairGenerator.generateKeyPair();
        ECPublicKey eCPublicKey = (ECPublicKey) generateKeyPair.getPublic();
        ECPrivateKey eCPrivateKey = (ECPrivateKey) generateKeyPair.getPrivate();
        vk.m8034a(this.f6968a.getW(), this.f6968a.getParams().getCurve());
        KeyAgreement keyAgreement = (KeyAgreement) vp.f6976c.m8043a("ECDH");
        keyAgreement.init(eCPrivateKey);
        keyAgreement.doPhase(this.f6968a, true);
        byte[] generateSecret = keyAgreement.generateSecret();
        generateSecret = wc.m8059a(vk.m8035a(eCPublicKey.getParams().getCurve(), com_google_android_gms_internal_zzdhu, eCPublicKey.getW()), generateSecret);
        Mac mac = (Mac) vp.f6975b.m8043a(str);
        if (i > mac.getMacLength() * 255) {
            throw new GeneralSecurityException("size too large");
        }
        if (bArr == null || bArr.length == 0) {
            mac.init(new SecretKeySpec(new byte[mac.getMacLength()], str));
        } else {
            mac.init(new SecretKeySpec(bArr, str));
        }
        Object obj = new byte[i];
        mac.init(new SecretKeySpec(mac.doFinal(generateSecret), str));
        generateSecret = new byte[0];
        int i3 = 0;
        while (true) {
            mac.update(generateSecret);
            mac.update(bArr2);
            mac.update((byte) i2);
            generateSecret = mac.doFinal();
            if (generateSecret.length + i3 < i) {
                System.arraycopy(generateSecret, 0, obj, i3, generateSecret.length);
                i3 += generateSecret.length;
                i2++;
            } else {
                System.arraycopy(generateSecret, 0, obj, i3, i - i3);
                return new vn(r5, obj);
            }
        }
    }
}
