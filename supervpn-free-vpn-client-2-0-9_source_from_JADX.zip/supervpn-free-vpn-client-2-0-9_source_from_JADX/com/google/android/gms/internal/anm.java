package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.zzbv;
import java.util.Map;

@avl
public final class anm implements anb {
    public final void zza(jk jkVar, Map map) {
        if (zzbv.zzez().m6399a(jkVar.getContext())) {
            int i = -1;
            try {
                i = Integer.parseInt((String) map.get("eventType"));
            } catch (Throwable e) {
                ii.m6517b("Parse Scion log event type error", e);
            }
            String str = (String) map.get("eventId");
            switch (i) {
                case 0:
                    zzbv.zzez().m6404d(jkVar.getContext(), str);
                    return;
                case 1:
                    zzbv.zzez().m6406e(jkVar.getContext(), str);
                    return;
                case 2:
                    zzbv.zzez().m6411g(jkVar.getContext(), str);
                    return;
                default:
                    return;
            }
        }
    }
}
