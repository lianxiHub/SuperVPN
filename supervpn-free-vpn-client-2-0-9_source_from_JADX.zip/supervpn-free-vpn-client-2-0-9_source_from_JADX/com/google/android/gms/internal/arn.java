package com.google.android.gms.internal;

import android.os.Bundle;
import android.view.View;
import com.google.android.gms.ads.formats.NativeAd.Image;
import com.google.android.gms.ads.mediation.NativeAppInstallAdMapper;
import com.google.android.gms.dynamic.C1758a;
import com.google.android.gms.dynamic.C1761c;
import java.util.ArrayList;
import java.util.List;

@avl
public final class arn extends arf {
    private final NativeAppInstallAdMapper f5137a;

    public arn(NativeAppInstallAdMapper nativeAppInstallAdMapper) {
        this.f5137a = nativeAppInstallAdMapper;
    }

    public final String mo3022a() {
        return this.f5137a.getHeadline();
    }

    public final void mo3023a(C1758a c1758a) {
        this.f5137a.handleClick((View) C1761c.m4496a(c1758a));
    }

    public final List mo3024b() {
        List<Image> images = this.f5137a.getImages();
        if (images == null) {
            return null;
        }
        List arrayList = new ArrayList();
        for (Image image : images) {
            arrayList.add(new aji(image.getDrawable(), image.getUri(), image.getScale()));
        }
        return arrayList;
    }

    public final void mo3025b(C1758a c1758a) {
        this.f5137a.trackView((View) C1761c.m4496a(c1758a));
    }

    public final String mo3026c() {
        return this.f5137a.getBody();
    }

    public final void mo3027c(C1758a c1758a) {
        this.f5137a.untrackView((View) C1761c.m4496a(c1758a));
    }

    public final akp mo3028d() {
        Image icon = this.f5137a.getIcon();
        return icon != null ? new aji(icon.getDrawable(), icon.getUri(), icon.getScale()) : null;
    }

    public final String mo3029e() {
        return this.f5137a.getCallToAction();
    }

    public final double mo3030f() {
        return this.f5137a.getStarRating();
    }

    public final String mo3031g() {
        return this.f5137a.getStore();
    }

    public final String mo3032h() {
        return this.f5137a.getPrice();
    }

    public final void mo3033i() {
        this.f5137a.recordImpression();
    }

    public final boolean mo3034j() {
        return this.f5137a.getOverrideImpressionRecording();
    }

    public final boolean mo3035k() {
        return this.f5137a.getOverrideClickHandling();
    }

    public final Bundle mo3036l() {
        return this.f5137a.getExtras();
    }

    public final agn mo3037m() {
        return this.f5137a.getVideoController() != null ? this.f5137a.getVideoController().zzbc() : null;
    }

    public final C1758a mo3038n() {
        Object adChoicesContent = this.f5137a.getAdChoicesContent();
        return adChoicesContent == null ? null : C1761c.m4495a(adChoicesContent);
    }

    public final akk mo3039o() {
        return null;
    }

    public final C1758a mo3040p() {
        return null;
    }
}
