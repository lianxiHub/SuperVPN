package com.google.android.gms.internal;

public class xv extends xb {
    protected xu f6804a;
    private final xu f6805b;
    private boolean f6806c = false;

    protected xv(xu xuVar) {
        this.f6805b = xuVar;
        this.f6804a = (xu) xuVar.mo3331a(yb.f7084e, null, null);
    }

    private static void m7679a(xu xuVar, xu xuVar2) {
        Object obj = ya.f7079a;
        xuVar.mo3331a(yb.f7081b, obj, (Object) xuVar2);
        xuVar.f6809b = obj.mo3367a(xuVar.f6809b, xuVar2.f6809b);
    }

    public final /* synthetic */ xb mo3323a() {
        return (xv) clone();
    }

    protected final /* synthetic */ xb mo3324a(xa xaVar) {
        return m7682a((xu) xaVar);
    }

    public final xv m7682a(xu xuVar) {
        m7683b();
        m7679a(this.f6804a, xuVar);
        return this;
    }

    protected final void m7683b() {
        if (this.f6806c) {
            xu xuVar = (xu) this.f6804a.mo3331a(yb.f7084e, null, null);
            m7679a(xuVar, this.f6804a);
            this.f6804a = xuVar;
            this.f6806c = false;
        }
    }

    public final xu m7684c() {
        if (this.f6806c) {
            return this.f6804a;
        }
        xu xuVar = this.f6804a;
        xuVar.mo3331a(yb.f7083d, null, null);
        xuVar.f6809b.m8217b();
        this.f6806c = true;
        return this.f6804a;
    }

    public /* synthetic */ Object clone() {
        xu xuVar;
        xv xvVar = (xv) this.f6805b.mo3331a(yb.f7085f, null, null);
        if (this.f6806c) {
            xuVar = this.f6804a;
        } else {
            xuVar = this.f6804a;
            xuVar.mo3331a(yb.f7083d, null, null);
            xuVar.f6809b.m8217b();
            this.f6806c = true;
            xuVar = this.f6804a;
        }
        xvVar.m7682a(xuVar);
        return xvVar;
    }

    public final xu m7685d() {
        xu xuVar;
        boolean z = true;
        if (this.f6806c) {
            xuVar = this.f6804a;
        } else {
            xuVar = this.f6804a;
            xuVar.mo3331a(yb.f7083d, null, null);
            xuVar.f6809b.m8217b();
            this.f6806c = true;
            xuVar = this.f6804a;
        }
        xuVar = xuVar;
        if (xuVar.mo3331a(yb.f7080a, Boolean.TRUE, null) == null) {
            z = false;
        }
        if (z) {
            return xuVar;
        }
        throw new zzefp(xuVar);
    }

    public final /* synthetic */ ym mo3326e() {
        xu xuVar;
        boolean z = true;
        if (this.f6806c) {
            xuVar = this.f6804a;
        } else {
            xuVar = this.f6804a;
            xuVar.mo3331a(yb.f7083d, null, null);
            xuVar.f6809b.m8217b();
            this.f6806c = true;
            xuVar = this.f6804a;
        }
        xuVar = xuVar;
        if (xuVar.mo3331a(yb.f7080a, Boolean.TRUE, null) == null) {
            z = false;
        }
        if (z) {
            return xuVar;
        }
        throw new zzefp(xuVar);
    }

    public final /* synthetic */ ym mo3327m() {
        return this.f6805b;
    }
}
