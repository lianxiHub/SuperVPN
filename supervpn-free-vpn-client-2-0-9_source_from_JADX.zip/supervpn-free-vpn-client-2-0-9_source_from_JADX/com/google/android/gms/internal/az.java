package com.google.android.gms.internal;

import java.util.Map;

final class az implements anb {
    private /* synthetic */ aw f5409a;

    az(aw awVar) {
        this.f5409a = awVar;
    }

    public final void zza(jk jkVar, Map map) {
        synchronized (this.f5409a.f5403e) {
            if (this.f5409a.f5406h.isDone()) {
                return;
            }
            bc bcVar = new bc(-2, map);
            if (this.f5409a.f5404f.equals(bcVar.m6202h())) {
                this.f5409a.f5406h.set(bcVar);
                return;
            }
        }
    }
}
