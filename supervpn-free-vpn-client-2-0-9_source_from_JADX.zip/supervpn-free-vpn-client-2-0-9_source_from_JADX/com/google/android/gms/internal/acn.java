package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.zzbv;
import java.util.ArrayList;

@avl
public final class acn {
    private final int f4284a;
    private final int f4285b;
    private final int f4286c;
    private final adb f4287d;
    private final adk f4288e;
    private final Object f4289f = new Object();
    private ArrayList f4290g = new ArrayList();
    private ArrayList f4291h = new ArrayList();
    private ArrayList f4292i = new ArrayList();
    private int f4293j = 0;
    private int f4294k = 0;
    private int f4295l = 0;
    private int f4296m;
    private String f4297n = "";
    private String f4298o = "";
    private String f4299p = "";

    public acn(int i, int i2, int i3, int i4, int i5, int i6, int i7) {
        this.f4284a = i;
        this.f4285b = i2;
        this.f4286c = i3;
        this.f4287d = new adb(i4);
        this.f4288e = new adk(i5, i6, i7);
    }

    private static String m4754a(ArrayList arrayList, int i) {
        if (arrayList.isEmpty()) {
            return "";
        }
        StringBuffer stringBuffer = new StringBuffer();
        arrayList = arrayList;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            stringBuffer.append((String) obj);
            stringBuffer.append(' ');
            if (stringBuffer.length() > 100) {
                break;
            }
        }
        stringBuffer.deleteCharAt(stringBuffer.length() - 1);
        String stringBuffer2 = stringBuffer.toString();
        return stringBuffer2.length() >= 100 ? stringBuffer2.substring(0, 100) : stringBuffer2;
    }

    private final void m4755c(String str, boolean z, float f, float f2, float f3, float f4) {
        if (str != null && str.length() >= this.f4286c) {
            synchronized (this.f4289f) {
                this.f4290g.add(str);
                this.f4293j += str.length();
                if (z) {
                    this.f4291h.add(str);
                    this.f4292i.add(new acz(f, f2, f3, f4, this.f4291h.size() - 1));
                }
            }
        }
    }

    public final void m4756a(int i) {
        this.f4294k = i;
    }

    public final void m4757a(String str, boolean z, float f, float f2, float f3, float f4) {
        m4755c(str, z, f, f2, f3, f4);
        synchronized (this.f4289f) {
            if (this.f4295l < 0) {
                ii.m6516b("ActivityContent: negative number of WebViews.");
            }
            m4766h();
        }
    }

    public final boolean m4758a() {
        boolean z;
        synchronized (this.f4289f) {
            z = this.f4295l == 0;
        }
        return z;
    }

    public final String m4759b() {
        return this.f4297n;
    }

    public final void m4760b(String str, boolean z, float f, float f2, float f3, float f4) {
        m4755c(str, z, f, f2, f3, f4);
    }

    public final String m4761c() {
        return this.f4298o;
    }

    public final String m4762d() {
        return this.f4299p;
    }

    public final void m4763e() {
        synchronized (this.f4289f) {
            this.f4296m -= 100;
        }
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof acn)) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        acn com_google_android_gms_internal_acn = (acn) obj;
        return com_google_android_gms_internal_acn.f4297n != null && com_google_android_gms_internal_acn.f4297n.equals(this.f4297n);
    }

    public final void m4764f() {
        synchronized (this.f4289f) {
            this.f4295l--;
        }
    }

    public final void m4765g() {
        synchronized (this.f4289f) {
            this.f4295l++;
        }
    }

    public final void m4766h() {
        synchronized (this.f4289f) {
            int i = (this.f4293j * this.f4284a) + (this.f4294k * this.f4285b);
            if (i > this.f4296m) {
                this.f4296m = i;
                if (((Boolean) zzbv.zzen().m5171a(aig.f4589P)).booleanValue() && !zzbv.zzee().m6472b()) {
                    this.f4297n = this.f4287d.m4811a(this.f4290g);
                    this.f4298o = this.f4287d.m4811a(this.f4291h);
                }
                if (((Boolean) zzbv.zzen().m5171a(aig.f4591R)).booleanValue() && !zzbv.zzee().m6474c()) {
                    this.f4299p = this.f4288e.m4824a(this.f4291h, this.f4292i);
                }
            }
        }
    }

    public final int hashCode() {
        return this.f4297n.hashCode();
    }

    public final int m4767i() {
        return this.f4296m;
    }

    final int m4768j() {
        return this.f4293j;
    }

    public final String toString() {
        int i = this.f4294k;
        int i2 = this.f4296m;
        int i3 = this.f4293j;
        String a = m4754a(this.f4290g, 100);
        String a2 = m4754a(this.f4291h, 100);
        String str = this.f4297n;
        String str2 = this.f4298o;
        String str3 = this.f4299p;
        return new StringBuilder(((((String.valueOf(a).length() + 165) + String.valueOf(a2).length()) + String.valueOf(str).length()) + String.valueOf(str2).length()) + String.valueOf(str3).length()).append("ActivityContent fetchId: ").append(i).append(" score:").append(i2).append(" total_length:").append(i3).append("\n text: ").append(a).append("\n viewableText").append(a2).append("\n signture: ").append(str).append("\n viewableSignture: ").append(str2).append("\n viewableSignatureForVertical: ").append(str3).toString();
    }
}
