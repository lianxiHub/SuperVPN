package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.dynamic.C1758a;
import com.google.android.gms.dynamic.C1758a.C1759a;

public final class akv extends xq implements akt {
    akv(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.formats.client.INativeAdViewDelegate");
    }

    public final C1758a mo2810a(String str) {
        Parcel zzax = zzax();
        zzax.writeString(str);
        zzax = zza(2, zzax);
        C1758a a = C1759a.m4494a(zzax.readStrongBinder());
        zzax.recycle();
        return a;
    }

    public final void mo2811a() {
        zzb(4, zzax());
    }

    public final void mo2812a(C1758a c1758a) {
        Parcel zzax = zzax();
        zm.m8271a(zzax, (IInterface) c1758a);
        zzb(3, zzax);
    }

    public final void mo2813a(C1758a c1758a, int i) {
        Parcel zzax = zzax();
        zm.m8271a(zzax, (IInterface) c1758a);
        zzax.writeInt(i);
        zzb(5, zzax);
    }

    public final void mo2814a(String str, C1758a c1758a) {
        Parcel zzax = zzax();
        zzax.writeString(str);
        zm.m8271a(zzax, (IInterface) c1758a);
        zzb(1, zzax);
    }
}
