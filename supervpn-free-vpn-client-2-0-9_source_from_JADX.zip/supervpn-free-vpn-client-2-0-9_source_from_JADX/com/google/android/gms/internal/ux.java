package com.google.android.gms.internal;

import com.google.android.gms.internal.ud.C1854a;
import com.google.android.gms.internal.ud.C1856b;
import com.google.android.gms.internal.zzdgq.zza;
import com.google.android.gms.internal.zzdgq.zza.zzb;
import java.security.GeneralSecurityException;

final class ux implements ub {
    ux() {
    }

    private static th m7991a(C1854a c1854a) {
        wc.m8057a(c1854a.m7907a(), 0);
        return new uw(c1854a.m7910b().m7923b(), (th) uj.f6928a.m7937a(c1854a.m7910b().m7920a()));
    }

    private static C1854a m7992a(C1856b c1856b) {
        return (C1854a) C1854a.m7905c().m7899a(c1856b.m7914a()).m7898a(0).m7685d();
    }

    private final th m7993d(zzedk com_google_android_gms_internal_zzedk) {
        try {
            return m7991a(C1854a.m7900a(com_google_android_gms_internal_zzedk));
        } catch (zzeer e) {
            throw new GeneralSecurityException("invalid KMSEnvelopeAead key");
        }
    }

    private static C1854a m7994e(zzedk com_google_android_gms_internal_zzedk) {
        try {
            return m7992a(C1856b.m7912a(com_google_android_gms_internal_zzedk));
        } catch (Throwable e) {
            throw new GeneralSecurityException("invalid KmsEnvelopeAead key format", e);
        }
    }

    public final /* synthetic */ Object mo3335a(zzedk com_google_android_gms_internal_zzedk) {
        return m7993d(com_google_android_gms_internal_zzedk);
    }

    public final /* synthetic */ ym mo3336b(ym ymVar) {
        return m7992a((C1856b) ymVar);
    }

    public final /* synthetic */ ym mo3337b(zzedk com_google_android_gms_internal_zzedk) {
        return m7994e(com_google_android_gms_internal_zzedk);
    }

    public final zza mo3338c(zzedk com_google_android_gms_internal_zzedk) {
        return (zza) zza.m8479e().m8470a("type.googleapis.com/google.cloud.crypto.tink.KmsEnvelopeAeadKey").m8469a(m7994e(com_google_android_gms_internal_zzedk).mo3328i()).m8468a(zzb.REMOTE).m7685d();
    }
}
