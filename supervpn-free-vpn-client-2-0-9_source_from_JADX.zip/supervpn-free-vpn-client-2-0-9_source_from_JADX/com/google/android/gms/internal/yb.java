package com.google.android.gms.internal;

public final class yb {
    public static final int f7080a = 1;
    public static final int f7081b = 2;
    public static final int f7082c = 3;
    public static final int f7083d = 4;
    public static final int f7084e = 5;
    public static final int f7085f = 6;
    public static final int f7086g = 7;
    public static final int f7087h = 8;
    private static final /* synthetic */ int[] f7088i = new int[]{f7080a, f7081b, f7082c, f7083d, f7084e, f7085f, f7086g, f7087h};
    private static int f7089j = 1;
    private static int f7090k = 2;
    private static final /* synthetic */ int[] f7091l = new int[]{f7089j, f7090k};

    public static int[] m8176a() {
        return (int[]) f7088i.clone();
    }
}
