package com.google.android.gms.internal;

final class aqh extends arc {
    private /* synthetic */ int f5079a;

    aqh(int i) {
        this.f5079a = i;
    }

    public final int mo2990a() {
        return this.f5079a;
    }
}
