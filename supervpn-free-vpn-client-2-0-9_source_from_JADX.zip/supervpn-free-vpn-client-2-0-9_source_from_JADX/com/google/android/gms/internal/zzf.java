package com.google.android.gms.internal;

public final class zzf extends zzy {
    public zzf(aim com_google_android_gms_internal_aim) {
        super(com_google_android_gms_internal_aim);
    }
}
