package com.google.android.gms.internal;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.net.Uri;
import com.google.android.gms.ads.internal.zzbv;

final class hd implements OnClickListener {
    private /* synthetic */ hc f5885a;

    hd(hc hcVar) {
        this.f5885a = hcVar;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        zzbv.zzea();
        gd.m6589a(this.f5885a.f5881a, Uri.parse("https://support.google.com/dfp_premium/answer/7160685#push"));
    }
}
