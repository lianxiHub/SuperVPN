package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzd;

public final class zzbdf extends zza {
    public static final Creator CREATOR = new px();
    final String f7381a;
    final zzbcy f7382b;
    private int f7383c;

    zzbdf(int i, String str, zzbcy com_google_android_gms_internal_zzbcy) {
        this.f7383c = i;
        this.f7381a = str;
        this.f7382b = com_google_android_gms_internal_zzbcy;
    }

    zzbdf(String str, zzbcy com_google_android_gms_internal_zzbcy) {
        this.f7383c = 1;
        this.f7381a = str;
        this.f7382b = com_google_android_gms_internal_zzbcy;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int zze = zzd.zze(parcel);
        zzd.zzc(parcel, 1, this.f7383c);
        zzd.zza(parcel, 2, this.f7381a, false);
        zzd.zza(parcel, 3, this.f7382b, i, false);
        zzd.zzai(parcel, zze);
    }
}
