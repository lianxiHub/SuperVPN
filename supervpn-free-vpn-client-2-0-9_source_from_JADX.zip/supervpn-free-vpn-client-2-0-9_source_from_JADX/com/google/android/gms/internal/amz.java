package com.google.android.gms.internal;

import java.util.Map;

final class amz implements anb {
    amz() {
    }

    public final void zza(jk jkVar, Map map) {
        String str = "Received log message: ";
        String valueOf = String.valueOf((String) map.get("string"));
        ii.m6520d(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
    }
}
