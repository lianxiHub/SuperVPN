package com.google.android.gms.internal;

interface xh {
    byte[] mo3349a(byte[] bArr, int i, int i2);
}
