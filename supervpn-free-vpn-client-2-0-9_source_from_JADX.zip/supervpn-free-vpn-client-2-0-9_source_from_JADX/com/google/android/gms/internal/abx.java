package com.google.android.gms.internal;

import org.json.JSONObject;

public interface abx {
    void mo2766a(JSONObject jSONObject, boolean z);

    boolean mo2767a();

    void mo2768b();
}
