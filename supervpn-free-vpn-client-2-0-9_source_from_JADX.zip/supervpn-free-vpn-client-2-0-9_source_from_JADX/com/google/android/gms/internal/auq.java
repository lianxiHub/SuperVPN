package com.google.android.gms.internal;

import java.util.List;

final class auq implements il {
    private /* synthetic */ String f5326a;
    private /* synthetic */ Integer f5327b;
    private /* synthetic */ Integer f5328c;
    private /* synthetic */ int f5329d;
    private /* synthetic */ int f5330e;
    private /* synthetic */ int f5331f;
    private /* synthetic */ int f5332g;
    private /* synthetic */ boolean f5333h;

    auq(auk com_google_android_gms_internal_auk, String str, Integer num, Integer num2, int i, int i2, int i3, int i4, boolean z) {
        this.f5326a = str;
        this.f5327b = num;
        this.f5328c = num2;
        this.f5329d = i;
        this.f5330e = i2;
        this.f5331f = i3;
        this.f5332g = i4;
        this.f5333h = z;
    }

    public final /* synthetic */ Object mo3111a(Object obj) {
        Integer num = null;
        List list = (List) obj;
        if (list == null || list.isEmpty()) {
            return null;
        }
        String str = this.f5326a;
        Integer num2 = this.f5327b;
        Integer num3 = this.f5328c;
        if (this.f5329d > 0) {
            num = Integer.valueOf(this.f5329d);
        }
        return new ajg(str, list, num2, num3, num, this.f5330e + this.f5331f, this.f5332g, this.f5333h);
    }
}
