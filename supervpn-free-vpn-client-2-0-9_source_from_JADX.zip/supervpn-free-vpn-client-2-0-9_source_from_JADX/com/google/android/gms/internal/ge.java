package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import java.util.List;

final class ge implements ajf {
    private /* synthetic */ List f5840a;
    private /* synthetic */ aje f5841b;
    private /* synthetic */ Context f5842c;

    ge(gd gdVar, List list, aje com_google_android_gms_internal_aje, Context context) {
        this.f5840a = list;
        this.f5841b = com_google_android_gms_internal_aje;
        this.f5842c = context;
    }

    public final void mo3189a() {
        for (String str : this.f5840a) {
            String str2 = "Pinging url: ";
            String valueOf = String.valueOf(str);
            ii.m6520d(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
            this.f5841b.m5237a(Uri.parse(str), null, null);
        }
        this.f5841b.m5234a((Activity) this.f5842c);
    }
}
