package com.google.android.gms.internal;

import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;

final /* synthetic */ class in implements Runnable {
    private final iw f5957a;
    private final il f5958b;
    private final iq f5959c;

    in(iw iwVar, il ilVar, iq iqVar) {
        this.f5957a = iwVar;
        this.f5958b = ilVar;
        this.f5959c = iqVar;
    }

    public final void run() {
        Throwable e;
        iw iwVar = this.f5957a;
        try {
            iwVar.set(this.f5958b.mo3111a(this.f5959c.get()));
        } catch (CancellationException e2) {
            iwVar.cancel(true);
        } catch (ExecutionException e3) {
            e = e3;
            Throwable cause = e.getCause();
            if (cause != null) {
                e = cause;
            }
            iwVar.setException(e);
        } catch (Throwable e4) {
            Thread.currentThread().interrupt();
            iwVar.setException(e4);
        }
    }
}
