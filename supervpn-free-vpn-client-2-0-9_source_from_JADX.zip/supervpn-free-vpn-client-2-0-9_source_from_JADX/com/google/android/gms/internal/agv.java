package com.google.android.gms.internal;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.search.SearchAdRequest;
import java.util.Collections;
import java.util.Date;
import java.util.Map;
import java.util.Set;

@avl
public final class agv {
    private final Date f4483a;
    private final String f4484b;
    private final int f4485c;
    private final Set f4486d;
    private final Location f4487e;
    private final boolean f4488f;
    private final Bundle f4489g;
    private final Map f4490h;
    private final String f4491i;
    private final String f4492j;
    private final SearchAdRequest f4493k;
    private final int f4494l;
    private final Set f4495m;
    private final Bundle f4496n;
    private final Set f4497o;
    private final boolean f4498p;

    public agv(agw com_google_android_gms_internal_agw) {
        this(com_google_android_gms_internal_agw, null);
    }

    public agv(agw com_google_android_gms_internal_agw, SearchAdRequest searchAdRequest) {
        this.f4483a = com_google_android_gms_internal_agw.f4505g;
        this.f4484b = com_google_android_gms_internal_agw.f4506h;
        this.f4485c = com_google_android_gms_internal_agw.f4507i;
        this.f4486d = Collections.unmodifiableSet(com_google_android_gms_internal_agw.f4499a);
        this.f4487e = com_google_android_gms_internal_agw.f4508j;
        this.f4488f = com_google_android_gms_internal_agw.f4509k;
        this.f4489g = com_google_android_gms_internal_agw.f4500b;
        this.f4490h = Collections.unmodifiableMap(com_google_android_gms_internal_agw.f4501c);
        this.f4491i = com_google_android_gms_internal_agw.f4510l;
        this.f4492j = com_google_android_gms_internal_agw.f4511m;
        this.f4493k = searchAdRequest;
        this.f4494l = com_google_android_gms_internal_agw.f4512n;
        this.f4495m = Collections.unmodifiableSet(com_google_android_gms_internal_agw.f4502d);
        this.f4496n = com_google_android_gms_internal_agw.f4503e;
        this.f4497o = Collections.unmodifiableSet(com_google_android_gms_internal_agw.f4504f);
        this.f4498p = com_google_android_gms_internal_agw.f4513o;
    }

    @Deprecated
    public final NetworkExtras m4976a(Class cls) {
        return (NetworkExtras) this.f4490h.get(cls);
    }

    public final Date m4977a() {
        return this.f4483a;
    }

    public final boolean m4978a(Context context) {
        Set set = this.f4495m;
        afc.m4920a();
        return set.contains(ie.m6786a(context));
    }

    public final Bundle m4979b(Class cls) {
        return this.f4489g.getBundle(cls.getName());
    }

    public final String m4980b() {
        return this.f4484b;
    }

    public final int m4981c() {
        return this.f4485c;
    }

    public final Bundle m4982c(Class cls) {
        Bundle bundle = this.f4489g.getBundle("com.google.android.gms.ads.mediation.customevent.CustomEventAdapter");
        return bundle != null ? bundle.getBundle(cls.getName()) : null;
    }

    public final Set m4983d() {
        return this.f4486d;
    }

    public final Location m4984e() {
        return this.f4487e;
    }

    public final boolean m4985f() {
        return this.f4488f;
    }

    public final String m4986g() {
        return this.f4491i;
    }

    public final String m4987h() {
        return this.f4492j;
    }

    public final SearchAdRequest m4988i() {
        return this.f4493k;
    }

    public final Map m4989j() {
        return this.f4490h;
    }

    public final Bundle m4990k() {
        return this.f4489g;
    }

    public final int m4991l() {
        return this.f4494l;
    }

    public final Bundle m4992m() {
        return this.f4496n;
    }

    public final Set m4993n() {
        return this.f4497o;
    }

    public final boolean m4994o() {
        return this.f4498p;
    }
}
