package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

final class fa extends fu {
    private /* synthetic */ Context f5781a;
    private /* synthetic */ fv f5782b;

    fa(Context context, fv fvVar) {
        this.f5781a = context;
        this.f5782b = fvVar;
        super();
    }

    public final void zzdc() {
        SharedPreferences sharedPreferences = this.f5781a.getSharedPreferences("admob", 0);
        Bundle bundle = new Bundle();
        bundle.putBoolean("auto_collect_location", sharedPreferences.getBoolean("auto_collect_location", false));
        if (this.f5782b != null) {
            this.f5782b.mo3185a(bundle);
        }
    }
}
