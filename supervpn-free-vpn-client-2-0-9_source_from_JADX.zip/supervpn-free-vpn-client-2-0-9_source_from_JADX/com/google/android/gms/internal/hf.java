package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.List;

@avl
public final class hf {
    private final String[] f5886a;
    private final double[] f5887b;
    private final double[] f5888c;
    private final int[] f5889d;
    private int f5890e;

    private hf(hi hiVar) {
        int size = hiVar.f5897b.size();
        this.f5886a = (String[]) hiVar.f5896a.toArray(new String[size]);
        this.f5887b = m6736a(hiVar.f5897b);
        this.f5888c = m6736a(hiVar.f5898c);
        this.f5889d = new int[size];
        this.f5890e = 0;
    }

    private static double[] m6736a(List list) {
        double[] dArr = new double[list.size()];
        for (int i = 0; i < dArr.length; i++) {
            dArr[i] = ((Double) list.get(i)).doubleValue();
        }
        return dArr;
    }

    public final List m6737a() {
        List arrayList = new ArrayList(this.f5886a.length);
        for (int i = 0; i < this.f5886a.length; i++) {
            arrayList.add(new hh(this.f5886a[i], this.f5888c[i], this.f5887b[i], ((double) this.f5889d[i]) / ((double) this.f5890e), this.f5889d[i]));
        }
        return arrayList;
    }

    public final void m6738a(double d) {
        this.f5890e++;
        int i = 0;
        while (i < this.f5888c.length) {
            if (this.f5888c[i] <= d && d < this.f5887b[i]) {
                int[] iArr = this.f5889d;
                iArr[i] = iArr[i] + 1;
            }
            if (d >= this.f5888c[i]) {
                i++;
            } else {
                return;
            }
        }
    }
}
