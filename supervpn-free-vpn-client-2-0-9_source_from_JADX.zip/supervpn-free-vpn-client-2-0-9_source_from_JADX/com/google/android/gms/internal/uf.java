package com.google.android.gms.internal;

public interface uf {
    byte[] mo3343a(byte[] bArr);
}
