package com.google.android.gms.internal;

final /* synthetic */ class uk {
    static final /* synthetic */ int[] f6930a = new int[yb.m8176a().length];

    static {
        try {
            f6930a[yb.f7084e - 1] = 1;
        } catch (NoSuchFieldError e) {
        }
        try {
            f6930a[yb.f7080a - 1] = 2;
        } catch (NoSuchFieldError e2) {
        }
        try {
            f6930a[yb.f7083d - 1] = 3;
        } catch (NoSuchFieldError e3) {
        }
        try {
            f6930a[yb.f7085f - 1] = 4;
        } catch (NoSuchFieldError e4) {
        }
        try {
            f6930a[yb.f7081b - 1] = 5;
        } catch (NoSuchFieldError e5) {
        }
        try {
            f6930a[yb.f7082c - 1] = 6;
        } catch (NoSuchFieldError e6) {
        }
        try {
            f6930a[yb.f7086g - 1] = 7;
        } catch (NoSuchFieldError e7) {
        }
        try {
            f6930a[yb.f7087h - 1] = 8;
        } catch (NoSuchFieldError e8) {
        }
    }
}
