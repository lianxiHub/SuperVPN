package com.google.android.gms.internal;

import android.content.ComponentName;
import android.os.RemoteException;
import com.google.android.gms.analytics.C1745s;
import com.google.android.gms.common.internal.zzbp;
import com.google.android.gms.common.stats.zza;
import java.util.Collections;

public final class lv extends lp {
    private final lx f6257a = new lx(this);
    private nf f6258b;
    private final ms f6259c;
    private nv f6260d;

    protected lv(lr lrVar) {
        super(lrVar);
        this.f6260d = new nv(lrVar.m7163c());
        this.f6259c = new lw(this, lrVar);
    }

    private final void m7188a(ComponentName componentName) {
        C1745s.m4456d();
        if (this.f6258b != null) {
            this.f6258b = null;
            m4347a("Disconnected from device AnalyticsService", componentName);
            m4370o().m7156e();
        }
    }

    private final void m7191a(nf nfVar) {
        C1745s.m4456d();
        this.f6258b = nfVar;
        m7193e();
        m4370o().m7157f();
    }

    private final void m7193e() {
        this.f6260d.m7402a();
        this.f6259c.m7204a(((Long) mz.f6312A.m7321a()).longValue());
    }

    private final void m7194f() {
        C1745s.m4456d();
        if (m7197b()) {
            m4350b("Inactivity, disconnecting from device AnalyticsService");
            m7199d();
        }
    }

    protected final void mo2540a() {
    }

    public final boolean m7196a(ne neVar) {
        zzbp.zzu(neVar);
        C1745s.m4456d();
        m4380y();
        nf nfVar = this.f6258b;
        if (nfVar == null) {
            return false;
        }
        try {
            nfVar.mo3296a(neVar.m7333b(), neVar.m7335d(), neVar.m7337f() ? mq.m7293h() : mq.m7294i(), Collections.emptyList());
            m7193e();
            return true;
        } catch (RemoteException e) {
            m4350b("Failed to send hits to AnalyticsService");
            return false;
        }
    }

    public final boolean m7197b() {
        C1745s.m4456d();
        m4380y();
        return this.f6258b != null;
    }

    public final boolean m7198c() {
        C1745s.m4456d();
        m4380y();
        if (this.f6258b != null) {
            return true;
        }
        nf a = this.f6257a.m7210a();
        if (a == null) {
            return false;
        }
        this.f6258b = a;
        m7193e();
        return true;
    }

    public final void m7199d() {
        C1745s.m4456d();
        m4380y();
        try {
            zza.zzaky();
            m4365j().unbindService(this.f6257a);
        } catch (IllegalStateException e) {
        } catch (IllegalArgumentException e2) {
        }
        if (this.f6258b != null) {
            this.f6258b = null;
            m4370o().m7156e();
        }
    }
}
