package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.android.gms.ads.internal.js.zzai;
import com.google.android.gms.ads.internal.overlay.zzm;
import com.google.android.gms.ads.internal.zzbo;
import com.google.android.gms.ads.internal.zzv;
import java.util.Map;
import org.json.JSONObject;

@avl
public interface jk extends zzai, zzbo, acc {
    void mo3224A();

    void mo3225B();

    OnClickListener mo3226C();

    ajp mo3227D();

    void mo3228E();

    WebView mo3229a();

    void mo3230a(int i);

    void mo3231a(Context context);

    void mo3232a(Context context, zzjb com_google_android_gms_internal_zzjb, aiu com_google_android_gms_internal_aiu);

    void mo3233a(zzm com_google_android_gms_ads_internal_overlay_zzm);

    void mo3234a(ajp com_google_android_gms_internal_ajp);

    void mo3235a(kc kcVar);

    void mo3236a(zzjb com_google_android_gms_internal_zzjb);

    void mo3237a(String str);

    void mo3238a(String str, Map map);

    void mo3239a(boolean z);

    void mo3240b();

    void mo3241b(int i);

    void mo3242b(zzm com_google_android_gms_ads_internal_overlay_zzm);

    void mo3243b(String str);

    void mo3244b(boolean z);

    void mo3245c();

    void mo3246c(boolean z);

    void mo3247d();

    void mo3248d(boolean z);

    void destroy();

    Activity mo3250e();

    Context mo3251f();

    zzv mo3252g();

    Context getContext();

    int getHeight();

    LayoutParams getLayoutParams();

    void getLocationOnScreen(int[] iArr);

    int getMeasuredHeight();

    int getMeasuredWidth();

    ViewParent getParent();

    int getWidth();

    zzm mo3253h();

    zzm mo3254i();

    zzjb mo3255j();

    jl mo3256k();

    boolean mo3257l();

    void loadData(String str, String str2, String str3);

    void loadDataWithBaseURL(String str, String str2, String str3, String str4, String str5);

    void loadUrl(String str);

    sv mo3261m();

    void measure(int i, int i2);

    zzajk mo3262n();

    boolean mo3263o();

    void onPause();

    void onResume();

    int mo3266p();

    boolean mo3267q();

    void mo3268r();

    boolean mo3269s();

    void setBackgroundColor(int i);

    void setOnClickListener(OnClickListener onClickListener);

    void setOnTouchListener(OnTouchListener onTouchListener);

    void setWebChromeClient(WebChromeClient webChromeClient);

    void setWebViewClient(WebViewClient webViewClient);

    void stopLoading();

    boolean mo3275t();

    String mo3276u();

    jj mo3277v();

    ais mo3278w();

    ait mo3279x();

    kc mo3280y();

    boolean mo3281z();

    void zza(String str, JSONObject jSONObject);

    void zzi(String str, String str2);
}
