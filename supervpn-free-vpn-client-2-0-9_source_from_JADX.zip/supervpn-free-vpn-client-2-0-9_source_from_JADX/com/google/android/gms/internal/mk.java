package com.google.android.gms.internal;

import java.util.concurrent.Callable;

final class mk implements Callable {
    private /* synthetic */ mj f6298a;

    mk(mj mjVar) {
        this.f6298a = mjVar;
    }

    public final /* synthetic */ Object call() {
        return this.f6298a.m7279d();
    }
}
