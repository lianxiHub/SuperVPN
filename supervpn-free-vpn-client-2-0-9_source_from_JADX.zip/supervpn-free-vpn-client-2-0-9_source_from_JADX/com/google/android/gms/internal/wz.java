package com.google.android.gms.internal;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.Callable;

public abstract class wz implements Callable {
    protected final td f6996a;
    protected final oh f6997b;
    protected Method f6998c;
    private String f6999d = getClass().getSimpleName();
    private String f7000e;
    private String f7001f;
    private int f7002g;
    private int f7003h;

    public wz(td tdVar, String str, String str2, oh ohVar, int i, int i2) {
        this.f6996a = tdVar;
        this.f7000e = str;
        this.f7001f = str2;
        this.f6997b = ohVar;
        this.f7002g = i;
        this.f7003h = i2;
    }

    protected abstract void mo3344a();

    public Void mo3345b() {
        try {
            long nanoTime = System.nanoTime();
            this.f6998c = this.f6996a.m7655a(this.f7000e, this.f7001f);
            if (this.f6998c != null) {
                mo3344a();
                ry i = this.f6996a.m7666i();
                if (!(i == null || this.f7002g == Integer.MIN_VALUE)) {
                    i.m7559a(this.f7003h, this.f7002g, (System.nanoTime() - nanoTime) / 1000);
                }
            }
        } catch (IllegalAccessException e) {
        } catch (InvocationTargetException e2) {
        }
        return null;
    }

    public /* synthetic */ Object call() {
        return mo3345b();
    }
}
