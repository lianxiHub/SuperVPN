package com.google.android.gms.internal;

import com.google.android.gms.ads.doubleclick.AppEventListener;

@avl
public final class aes extends aga {
    private final AppEventListener f4428a;

    public aes(AppEventListener appEventListener) {
        this.f4428a = appEventListener;
    }

    public final AppEventListener m4883a() {
        return this.f4428a;
    }

    public final void mo2788a(String str, String str2) {
        this.f4428a.onAppEvent(str, str2);
    }
}
