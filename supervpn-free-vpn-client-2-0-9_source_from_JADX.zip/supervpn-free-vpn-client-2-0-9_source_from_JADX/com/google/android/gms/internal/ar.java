package com.google.android.gms.internal;

import android.content.Context;

final class ar implements Runnable {
    private /* synthetic */ am f5121a;
    private /* synthetic */ Context f5122b;
    private /* synthetic */ zzaak f5123c;
    private /* synthetic */ aw f5124d;

    ar(am amVar, Context context, zzaak com_google_android_gms_internal_zzaak, aw awVar) {
        this.f5121a = amVar;
        this.f5122b = context;
        this.f5123c = com_google_android_gms_internal_zzaak;
        this.f5124d = awVar;
    }

    public final void run() {
        this.f5121a.f4829e.mo3119a(this.f5122b, this.f5123c.f7252k, this.f5124d.f5399a);
    }
}
