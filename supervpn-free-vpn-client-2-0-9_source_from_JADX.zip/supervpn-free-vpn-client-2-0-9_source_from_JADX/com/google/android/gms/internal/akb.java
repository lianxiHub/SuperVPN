package com.google.android.gms.internal;

import java.util.Map;
import org.json.JSONObject;

final class akb implements jp {
    private /* synthetic */ Map f4753a;
    private /* synthetic */ aka f4754b;

    akb(aka com_google_android_gms_internal_aka, Map map) {
        this.f4754b = com_google_android_gms_internal_aka;
        this.f4753a = map;
    }

    public final void zza(jk jkVar, boolean z) {
        this.f4754b.f4752b.f4750b = (String) this.f4753a.get("id");
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("messageType", "htmlLoaded");
            jSONObject.put("id", this.f4754b.f4752b.f4750b);
            this.f4754b.f4751a.zzb("sendMessageToNativeJs", jSONObject);
        } catch (Throwable e) {
            ii.m6517b("Unable to dispatch sendMessageToNativeJs event", e);
        }
    }
}
