package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import com.google.android.gms.dynamic.C1758a;

public interface atc extends IInterface {
    IBinder mo3103a(C1758a c1758a);
}
