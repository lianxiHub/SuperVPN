package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.zzbv;
import java.security.GeneralSecurityException;

final class ra {
    static ua f6609a;

    static boolean m7539a() {
        if (f6609a != null) {
            return true;
        }
        String str = (String) zzbv.zzen().m5171a(aig.bw);
        if (str.length() == 0) {
            return false;
        }
        try {
            try {
                uc a = ug.m7926a(qk.m7513a(str, true));
                vc.m8011a();
                f6609a = vc.m8010a(a);
                return f6609a != null;
            } catch (GeneralSecurityException e) {
                return false;
            }
        } catch (IllegalArgumentException e2) {
            return false;
        }
    }
}
