package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzd;
import com.google.android.gms.common.internal.zzbq;

public final class zzcpx extends zza {
    public static final Creator CREATOR = new sn();
    private int f7467a;
    private zzbq f7468b;

    zzcpx(int i, zzbq com_google_android_gms_common_internal_zzbq) {
        this.f7467a = i;
        this.f7468b = com_google_android_gms_common_internal_zzbq;
    }

    public zzcpx(zzbq com_google_android_gms_common_internal_zzbq) {
        this(1, com_google_android_gms_common_internal_zzbq);
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int zze = zzd.zze(parcel);
        zzd.zzc(parcel, 1, this.f7467a);
        zzd.zza(parcel, 2, this.f7468b, i, false);
        zzd.zzai(parcel, zze);
    }
}
