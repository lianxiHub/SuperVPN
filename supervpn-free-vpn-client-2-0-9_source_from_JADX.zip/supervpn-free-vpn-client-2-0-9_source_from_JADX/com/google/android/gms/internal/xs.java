package com.google.android.gms.internal;

final /* synthetic */ class xs {
    static final /* synthetic */ int[] f7070a = new int[zzege.values().length];
    private static /* synthetic */ int[] f7071b = new int[zzefz.values().length];

    static {
        try {
            f7071b[zzefz.DOUBLE.ordinal()] = 1;
        } catch (NoSuchFieldError e) {
        }
        try {
            f7071b[zzefz.FLOAT.ordinal()] = 2;
        } catch (NoSuchFieldError e2) {
        }
        try {
            f7071b[zzefz.INT64.ordinal()] = 3;
        } catch (NoSuchFieldError e3) {
        }
        try {
            f7071b[zzefz.UINT64.ordinal()] = 4;
        } catch (NoSuchFieldError e4) {
        }
        try {
            f7071b[zzefz.INT32.ordinal()] = 5;
        } catch (NoSuchFieldError e5) {
        }
        try {
            f7071b[zzefz.FIXED64.ordinal()] = 6;
        } catch (NoSuchFieldError e6) {
        }
        try {
            f7071b[zzefz.FIXED32.ordinal()] = 7;
        } catch (NoSuchFieldError e7) {
        }
        try {
            f7071b[zzefz.BOOL.ordinal()] = 8;
        } catch (NoSuchFieldError e8) {
        }
        try {
            f7071b[zzefz.GROUP.ordinal()] = 9;
        } catch (NoSuchFieldError e9) {
        }
        try {
            f7071b[zzefz.MESSAGE.ordinal()] = 10;
        } catch (NoSuchFieldError e10) {
        }
        try {
            f7071b[zzefz.STRING.ordinal()] = 11;
        } catch (NoSuchFieldError e11) {
        }
        try {
            f7071b[zzefz.BYTES.ordinal()] = 12;
        } catch (NoSuchFieldError e12) {
        }
        try {
            f7071b[zzefz.UINT32.ordinal()] = 13;
        } catch (NoSuchFieldError e13) {
        }
        try {
            f7071b[zzefz.SFIXED32.ordinal()] = 14;
        } catch (NoSuchFieldError e14) {
        }
        try {
            f7071b[zzefz.SFIXED64.ordinal()] = 15;
        } catch (NoSuchFieldError e15) {
        }
        try {
            f7071b[zzefz.SINT32.ordinal()] = 16;
        } catch (NoSuchFieldError e16) {
        }
        try {
            f7071b[zzefz.SINT64.ordinal()] = 17;
        } catch (NoSuchFieldError e17) {
        }
        try {
            f7071b[zzefz.ENUM.ordinal()] = 18;
        } catch (NoSuchFieldError e18) {
        }
        try {
            f7070a[zzege.INT.ordinal()] = 1;
        } catch (NoSuchFieldError e19) {
        }
        try {
            f7070a[zzege.LONG.ordinal()] = 2;
        } catch (NoSuchFieldError e20) {
        }
        try {
            f7070a[zzege.FLOAT.ordinal()] = 3;
        } catch (NoSuchFieldError e21) {
        }
        try {
            f7070a[zzege.DOUBLE.ordinal()] = 4;
        } catch (NoSuchFieldError e22) {
        }
        try {
            f7070a[zzege.BOOLEAN.ordinal()] = 5;
        } catch (NoSuchFieldError e23) {
        }
        try {
            f7070a[zzege.STRING.ordinal()] = 6;
        } catch (NoSuchFieldError e24) {
        }
        try {
            f7070a[zzege.BYTE_STRING.ordinal()] = 7;
        } catch (NoSuchFieldError e25) {
        }
        try {
            f7070a[zzege.ENUM.ordinal()] = 8;
        } catch (NoSuchFieldError e26) {
        }
        try {
            f7070a[zzege.MESSAGE.ordinal()] = 9;
        } catch (NoSuchFieldError e27) {
        }
    }
}
