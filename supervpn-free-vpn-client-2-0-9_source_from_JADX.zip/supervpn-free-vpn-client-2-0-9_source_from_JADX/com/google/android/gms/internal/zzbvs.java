package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzd;

public final class zzbvs extends zza {
    public static final Creator CREATOR = new qu();
    private int f7444a;
    private String f7445b;
    private String f7446c;

    zzbvs(int i, String str, String str2) {
        this.f7444a = i;
        this.f7445b = str;
        this.f7446c = str2;
    }

    public zzbvs(String str, String str2) {
        this(1, str, str2);
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int zze = zzd.zze(parcel);
        zzd.zzc(parcel, 1, this.f7444a);
        zzd.zza(parcel, 2, this.f7445b, false);
        zzd.zza(parcel, 3, this.f7446c, false);
        zzd.zzai(parcel, zze);
    }
}
