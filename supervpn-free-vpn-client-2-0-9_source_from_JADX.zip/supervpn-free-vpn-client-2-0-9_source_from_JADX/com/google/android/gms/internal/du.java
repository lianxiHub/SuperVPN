package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.ads.internal.zzbv;
import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

@avl
public final class du {
    private final AtomicReference f5629a = new AtomicReference(null);
    private final Object f5630b = new Object();
    private String f5631c = null;
    private AtomicBoolean f5632d = new AtomicBoolean(false);
    private final AtomicInteger f5633e = new AtomicInteger(-1);
    private final AtomicReference f5634f = new AtomicReference(null);
    private final AtomicReference f5635g = new AtomicReference(null);
    private ConcurrentMap f5636h = new ConcurrentHashMap(9);

    private final Object m6388a(String str, Context context) {
        Object obj = null;
        if (m6392a(context, "com.google.android.gms.measurement.AppMeasurement", this.f5634f, true)) {
            try {
                obj = m6395j(context, str).invoke(this.f5634f.get(), new Object[0]);
            } catch (Exception e) {
                m6391a(e, str, true);
            }
        }
        return obj;
    }

    private final void m6389a(Context context, String str, Bundle bundle) {
        if (m6392a(context, "com.google.android.gms.measurement.AppMeasurement", this.f5634f, true)) {
            Method k = m6396k(context);
            try {
                k.invoke(this.f5634f.get(), new Object[]{"am", str, bundle});
            } catch (Exception e) {
                m6391a(e, "logEventInternal", true);
            }
        }
    }

    private final void m6390a(Context context, String str, String str2) {
        if (m6392a(context, "com.google.android.gms.measurement.AppMeasurement", this.f5634f, true)) {
            Method i = m6394i(context, str2);
            try {
                i.invoke(this.f5634f.get(), new Object[]{str});
                et.m6522a(new StringBuilder((String.valueOf(str2).length() + 37) + String.valueOf(str).length()).append("Invoke Firebase method ").append(str2).append(", Ad Unit Id: ").append(str).toString());
            } catch (Exception e) {
                m6391a(e, str2, false);
            }
        }
    }

    private final void m6391a(Exception exception, String str, boolean z) {
        if (!this.f5632d.get()) {
            ii.m6519c(new StringBuilder(String.valueOf(str).length() + 30).append("Invoke Firebase method ").append(str).append(" error.").toString(), exception);
            if (z) {
                ii.m6521e("The Google Mobile Ads SDK will not integrate with Firebase. Admob/Firbase integration requires the latest Firebase SDK jar, but Firebase SDK is either missing or out of date");
                this.f5632d.set(true);
            }
        }
    }

    private final boolean m6392a(Context context, String str, AtomicReference atomicReference, boolean z) {
        if (atomicReference.get() == null) {
            try {
                atomicReference.compareAndSet(null, context.getClassLoader().loadClass(str).getDeclaredMethod("getInstance", new Class[]{Context.class}).invoke(null, new Object[]{context}));
            } catch (Exception e) {
                m6391a(e, "getInstance", z);
                return false;
            }
        }
        return true;
    }

    private static Bundle m6393h(Context context, String str) {
        Bundle bundle = new Bundle();
        bundle.putLong("_aeid", Long.parseLong(str));
        return bundle;
    }

    private final Method m6394i(Context context, String str) {
        Method method = (Method) this.f5636h.get(str);
        if (method != null) {
            return method;
        }
        try {
            method = context.getClassLoader().loadClass("com.google.android.gms.measurement.AppMeasurement").getDeclaredMethod(str, new Class[]{String.class});
            this.f5636h.put(str, method);
            return method;
        } catch (Exception e) {
            m6391a(e, str, false);
            return null;
        }
    }

    private final Method m6395j(Context context, String str) {
        Method method = (Method) this.f5636h.get(str);
        if (method != null) {
            return method;
        }
        try {
            method = context.getClassLoader().loadClass("com.google.android.gms.measurement.AppMeasurement").getDeclaredMethod(str, new Class[0]);
            this.f5636h.put(str, method);
            return method;
        } catch (Exception e) {
            m6391a(e, str, false);
            return null;
        }
    }

    private final Method m6396k(Context context) {
        Method method = (Method) this.f5636h.get("logEventInternal");
        if (method != null) {
            return method;
        }
        try {
            method = context.getClassLoader().loadClass("com.google.android.gms.measurement.AppMeasurement").getDeclaredMethod("logEventInternal", new Class[]{String.class, String.class, Bundle.class});
            this.f5636h.put("logEventInternal", method);
            return method;
        } catch (Exception e) {
            m6391a(e, "logEventInternal", true);
            return null;
        }
    }

    private final Method m6397k(Context context, String str) {
        Method method = (Method) this.f5636h.get(str);
        if (method != null) {
            return method;
        }
        try {
            method = context.getClassLoader().loadClass("com.google.firebase.analytics.FirebaseAnalytics").getDeclaredMethod(str, new Class[]{Activity.class, String.class, String.class});
            this.f5636h.put(str, method);
            return method;
        } catch (Exception e) {
            m6391a(e, str, false);
            return null;
        }
    }

    public final void m6398a(Context context, String str) {
        if (m6399a(context)) {
            m6390a(context, str, "beginAdUnitExposure");
        }
    }

    public final boolean m6399a(Context context) {
        if (!((Boolean) zzbv.zzen().m5171a(aig.ae)).booleanValue() || this.f5632d.get()) {
            return false;
        }
        if (this.f5633e.get() == -1) {
            afc.m4920a();
            if (!ie.m6797c(context)) {
                afc.m4920a();
                if (ie.m6800f(context)) {
                    ii.m6521e("Google Play Service is out of date, the Google Mobile Ads SDK will not integrate with Firebase. Admob/Firebase integration requires updated Google Play Service.");
                    this.f5633e.set(0);
                }
            }
            this.f5633e.set(1);
        }
        return this.f5633e.get() == 1;
    }

    public final void m6400b(Context context, String str) {
        if (m6399a(context)) {
            m6390a(context, str, "endAdUnitExposure");
        }
    }

    public final boolean m6401b(Context context) {
        return ((Boolean) zzbv.zzen().m5171a(aig.af)).booleanValue() && m6399a(context);
    }

    public final void m6402c(Context context, String str) {
        if (m6399a(context) && (context instanceof Activity) && m6392a(context, "com.google.firebase.analytics.FirebaseAnalytics", this.f5635g, false)) {
            Method k = m6397k(context, "setCurrentScreen");
            try {
                Activity activity = (Activity) context;
                k.invoke(this.f5635g.get(), new Object[]{activity, str, context.getPackageName()});
            } catch (Exception e) {
                m6391a(e, "setCurrentScreen", false);
            }
        }
    }

    public final boolean m6403c(Context context) {
        return ((Boolean) zzbv.zzen().m5171a(aig.ag)).booleanValue() && m6399a(context);
    }

    public final void m6404d(Context context, String str) {
        if (m6399a(context)) {
            Bundle h = m6393h(context, str);
            h.putInt("_r", 1);
            m6389a(context, "_ac", h);
        }
    }

    public final boolean m6405d(Context context) {
        return ((Boolean) zzbv.zzen().m5171a(aig.ah)).booleanValue() && m6399a(context);
    }

    public final void m6406e(Context context, String str) {
        if (m6399a(context)) {
            m6389a(context, "_ai", m6393h(context, str));
        }
    }

    public final boolean m6407e(Context context) {
        return ((Boolean) zzbv.zzen().m5171a(aig.ai)).booleanValue() && m6399a(context);
    }

    public final String m6408f(Context context) {
        if (!m6399a(context)) {
            return "";
        }
        if (!m6392a(context, "com.google.android.gms.measurement.AppMeasurement", this.f5634f, true)) {
            return "";
        }
        try {
            String str = (String) m6395j(context, "getCurrentScreenName").invoke(this.f5634f.get(), new Object[0]);
            if (str == null) {
                str = (String) m6395j(context, "getCurrentScreenClass").invoke(this.f5634f.get(), new Object[0]);
            }
            return str == null ? "" : str;
        } catch (Exception e) {
            m6391a(e, "getCurrentScreenName", false);
            return "";
        }
    }

    public final void m6409f(Context context, String str) {
        if (m6399a(context)) {
            m6389a(context, "_aq", m6393h(context, str));
        }
    }

    public final String m6410g(Context context) {
        if (!m6399a(context)) {
            return null;
        }
        synchronized (this.f5630b) {
            if (this.f5631c != null) {
                String str = this.f5631c;
                return str;
            }
            this.f5631c = (String) m6388a("getGmpAppId", context);
            str = this.f5631c;
            return str;
        }
    }

    public final void m6411g(Context context, String str) {
        if (m6399a(context)) {
            m6389a(context, "_aa", m6393h(context, str));
        }
    }

    public final String m6412h(Context context) {
        if (!m6399a(context)) {
            return null;
        }
        long longValue = ((Long) zzbv.zzen().m5171a(aig.ao)).longValue();
        if (longValue < 0) {
            return (String) m6388a("getAppInstanceId", context);
        }
        if (this.f5629a.get() == null) {
            this.f5629a.compareAndSet(null, new ThreadPoolExecutor(((Integer) zzbv.zzen().m5171a(aig.ap)).intValue(), ((Integer) zzbv.zzen().m5171a(aig.ap)).intValue(), 1, TimeUnit.MINUTES, new LinkedBlockingQueue(), new dx(this)));
        }
        Future submit = ((ThreadPoolExecutor) this.f5629a.get()).submit(new dw(this, context));
        try {
            return (String) submit.get(longValue, TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            submit.cancel(true);
            return e instanceof TimeoutException ? "TIME_OUT" : null;
        }
    }

    public final String m6413i(Context context) {
        if (!m6399a(context)) {
            return null;
        }
        Object a = m6388a("generateEventId", context);
        return a != null ? a.toString() : null;
    }

    final /* synthetic */ String m6414j(Context context) {
        return (String) m6388a("getAppInstanceId", context);
    }
}
