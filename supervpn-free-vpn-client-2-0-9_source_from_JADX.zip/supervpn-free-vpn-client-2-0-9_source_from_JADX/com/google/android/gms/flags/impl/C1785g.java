package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

final class C1785g implements Callable {
    private /* synthetic */ SharedPreferences f4099a;
    private /* synthetic */ String f4100b;
    private /* synthetic */ Long f4101c;

    C1785g(SharedPreferences sharedPreferences, String str, Long l) {
        this.f4099a = sharedPreferences;
        this.f4100b = str;
        this.f4101c = l;
    }

    public final /* synthetic */ Object call() {
        return Long.valueOf(this.f4099a.getLong(this.f4100b, this.f4101c.longValue()));
    }
}
