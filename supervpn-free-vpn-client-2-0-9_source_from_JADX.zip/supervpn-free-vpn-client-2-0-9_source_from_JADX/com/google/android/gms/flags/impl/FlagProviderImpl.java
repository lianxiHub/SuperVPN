package com.google.android.gms.flags.impl;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager.NameNotFoundException;
import android.util.Log;
import com.google.android.gms.common.util.DynamiteApi;
import com.google.android.gms.dynamic.C1758a;
import com.google.android.gms.dynamic.C1761c;
import com.google.android.gms.internal.qo;

@DynamiteApi
public class FlagProviderImpl extends qo {
    private boolean f4091a = false;
    private SharedPreferences f4092b;

    public boolean getBooleanFlagValue(String str, boolean z, int i) {
        return !this.f4091a ? z : C1780b.m4531a(this.f4092b, str, Boolean.valueOf(z)).booleanValue();
    }

    public int getIntFlagValue(String str, int i, int i2) {
        return !this.f4091a ? i : C1782d.m4532a(this.f4092b, str, Integer.valueOf(i)).intValue();
    }

    public long getLongFlagValue(String str, long j, int i) {
        return !this.f4091a ? j : C1784f.m4533a(this.f4092b, str, Long.valueOf(j)).longValue();
    }

    public String getStringFlagValue(String str, String str2, int i) {
        return !this.f4091a ? str2 : C1786h.m4534a(this.f4092b, str, str2);
    }

    public void init(C1758a c1758a) {
        Context context = (Context) C1761c.m4496a(c1758a);
        if (!this.f4091a) {
            try {
                this.f4092b = C1788j.m4535a(context.createPackageContext("com.google.android.gms", 0));
                this.f4091a = true;
            } catch (NameNotFoundException e) {
            } catch (Exception e2) {
                String str = "FlagProviderImpl";
                String str2 = "Could not retrieve sdk flags, continuing with defaults: ";
                String valueOf = String.valueOf(e2.getMessage());
                Log.w(str, valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
            }
        }
    }
}
