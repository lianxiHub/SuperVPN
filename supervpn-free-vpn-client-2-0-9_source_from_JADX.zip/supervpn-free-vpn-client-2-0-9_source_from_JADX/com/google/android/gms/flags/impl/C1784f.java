package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import android.util.Log;
import com.google.android.gms.internal.qq;

public final class C1784f extends C1779a {
    public static Long m4533a(SharedPreferences sharedPreferences, String str, Long l) {
        try {
            return (Long) qq.m7527a(new C1785g(sharedPreferences, str, l));
        } catch (Exception e) {
            String str2 = "FlagDataUtils";
            String str3 = "Flag value not available, returning default: ";
            String valueOf = String.valueOf(e.getMessage());
            Log.w(str2, valueOf.length() != 0 ? str3.concat(valueOf) : new String(str3));
            return l;
        }
    }
}
