package com.google.android.gms.flags.impl;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.android.gms.internal.qq;

public final class C1788j {
    private static SharedPreferences f4105a = null;

    public static SharedPreferences m4535a(Context context) {
        SharedPreferences sharedPreferences;
        synchronized (SharedPreferences.class) {
            if (f4105a == null) {
                f4105a = (SharedPreferences) qq.m7527a(new C1789k(context));
            }
            sharedPreferences = f4105a;
        }
        return sharedPreferences;
    }
}
