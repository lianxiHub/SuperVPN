package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

final class C1781c implements Callable {
    private /* synthetic */ SharedPreferences f4093a;
    private /* synthetic */ String f4094b;
    private /* synthetic */ Boolean f4095c;

    C1781c(SharedPreferences sharedPreferences, String str, Boolean bool) {
        this.f4093a = sharedPreferences;
        this.f4094b = str;
        this.f4095c = bool;
    }

    public final /* synthetic */ Object call() {
        return Boolean.valueOf(this.f4093a.getBoolean(this.f4094b, this.f4095c.booleanValue()));
    }
}
