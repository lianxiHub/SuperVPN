package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

final class C1783e implements Callable {
    private /* synthetic */ SharedPreferences f4096a;
    private /* synthetic */ String f4097b;
    private /* synthetic */ Integer f4098c;

    C1783e(SharedPreferences sharedPreferences, String str, Integer num) {
        this.f4096a = sharedPreferences;
        this.f4097b = str;
        this.f4098c = num;
    }

    public final /* synthetic */ Object call() {
        return Integer.valueOf(this.f4096a.getInt(this.f4097b, this.f4098c.intValue()));
    }
}
