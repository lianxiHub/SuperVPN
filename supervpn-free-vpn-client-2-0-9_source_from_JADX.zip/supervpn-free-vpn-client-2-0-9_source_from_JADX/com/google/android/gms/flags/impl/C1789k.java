package com.google.android.gms.flags.impl;

import android.content.Context;
import java.util.concurrent.Callable;

final class C1789k implements Callable {
    private /* synthetic */ Context f4106a;

    C1789k(Context context) {
        this.f4106a = context;
    }

    public final /* synthetic */ Object call() {
        return this.f4106a.getSharedPreferences("google_sdk_flags", 0);
    }
}
