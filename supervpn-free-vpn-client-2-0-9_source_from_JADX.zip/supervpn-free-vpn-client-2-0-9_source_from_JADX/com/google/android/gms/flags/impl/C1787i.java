package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

final class C1787i implements Callable {
    private /* synthetic */ SharedPreferences f4102a;
    private /* synthetic */ String f4103b;
    private /* synthetic */ String f4104c;

    C1787i(SharedPreferences sharedPreferences, String str, String str2) {
        this.f4102a = sharedPreferences;
        this.f4103b = str;
        this.f4104c = str2;
    }

    public final /* synthetic */ Object call() {
        return this.f4102a.getString(this.f4103b, this.f4104c);
    }
}
